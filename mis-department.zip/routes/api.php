<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserPermissionController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\LocationBranchController;
use App\Http\Controllers\DomainZoneController;
use App\Http\Controllers\StaffPositionController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\MISDataEntryController;
use App\Http\Controllers\AdvanceController;
use App\Http\Controllers\MovementRegisterController;
use App\Http\Controllers\StockRegisterController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\TargetActivityController;
use App\Http\Controllers\ReportRequestController;
use App\Http\Controllers\CabinetDocumentController;
use App\Http\Controllers\DataQualityController;
use App\Http\Controllers\MonitoringController;
use App\Http\Controllers\AnalyticsController;
use App\Http\Controllers\BackupSettingsController;
use App\Http\Controllers\StaffTransferController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| API routes protected with Laravel authorization, gates, and audit logging.
|
*/

Route::get('/auth/csrf', function () {
    return response()->json(['csrf_token' => csrf_token()]);
});

Route::get('/auth/me', [AuthController::class, 'me']);
Route::post('/auth/login', [AuthController::class, 'login']);
Route::post('/auth/logout', [AuthController::class, 'logout']);
Route::post('/auth/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/auth/reset-password', [AuthController::class, 'resetPassword']);

// Protected API Routes with authorization & audit logging
Route::middleware(['auth'])->group(function () {
    // User & Permission Management
    Route::get('/users', [UserPermissionController::class, 'index'])
        ->middleware('permission:users-permissions,view');

    Route::post('/users', [UserPermissionController::class, 'store'])
        ->middleware('permission:users-permissions,create');

    Route::put('/users/{id}', [UserPermissionController::class, 'update'])
        ->middleware('permission:users-permissions,edit');

    Route::delete('/users/{id}', [UserPermissionController::class, 'destroy'])
        ->middleware('permission:users-permissions,delete');

    // Audit Logs
    Route::get('/audit-logs', [AuditLogController::class, 'index'])
        ->middleware('permission:audit-log,view');

    Route::post('/audit-logs', [AuditLogController::class, 'store']);

    // Department Management
    Route::get('/department-management', [DepartmentController::class, 'index'])
        ->middleware('permission:department-management,view');

    Route::post('/department-management', [DepartmentController::class, 'store'])
        ->middleware('permission:department-management,create');

    Route::get('/department-management/{id}', [DepartmentController::class, 'show'])
        ->middleware('permission:department-management,view');

    Route::put('/department-management/{id}', [DepartmentController::class, 'update'])
        ->middleware('permission:department-management,edit');

    Route::delete('/department-management/{id}', [DepartmentController::class, 'destroy'])
        ->middleware('permission:department-management,delete');

    Route::post('/department-management/{id}/status', [DepartmentController::class, 'updateStatus'])
        ->middleware('permission:department-management,approve');

    Route::post('/department-management/action', [DepartmentController::class, 'logAction']);

    // Location & Branch
    Route::get('/location-branch', [LocationBranchController::class, 'index'])
        ->middleware('permission:location-branch,view');
    Route::post('/location-branch', [LocationBranchController::class, 'store'])
        ->middleware('permission:location-branch,create');
    Route::put('/location-branch/{id}', [LocationBranchController::class, 'update'])
        ->middleware('permission:location-branch,edit');
    Route::delete('/location-branch/{id}', [LocationBranchController::class, 'destroy'])
        ->middleware('permission:location-branch,delete');

    // Branch specific endpoints
    Route::get('/location-branch/branches', [LocationBranchController::class, 'index'])
        ->middleware('permission:location-branch,view');
    Route::post('/location-branch/branches', [LocationBranchController::class, 'store'])
        ->middleware('permission:location-branch,create');
    Route::get('/location-branch/branches/{id}', [LocationBranchController::class, 'show'])
        ->middleware('permission:location-branch,view');
    Route::put('/location-branch/branches/{id}', [LocationBranchController::class, 'update'])
        ->middleware('permission:location-branch,edit');
    Route::delete('/location-branch/branches/{id}', [LocationBranchController::class, 'destroy'])
        ->middleware('permission:location-branch,delete');
    Route::post('/location-branch/branches/{id}/status', [LocationBranchController::class, 'updateStatus'])
        ->middleware('permission:location-branch,approve');

    // Administrative locations endpoints
    Route::get('/location-branch/administrative', [LocationBranchController::class, 'locations'])
        ->middleware('permission:location-branch,view');
    Route::post('/location-branch/administrative', [LocationBranchController::class, 'storeLocation'])
        ->middleware('permission:location-branch,create');
    Route::put('/location-branch/administrative/{id}', [LocationBranchController::class, 'updateLocation'])
        ->middleware('permission:location-branch,edit');
    Route::delete('/location-branch/administrative/{id}', [LocationBranchController::class, 'destroyLocation'])
        ->middleware('permission:location-branch,delete');
    Route::post('/location-branch/action', [LocationBranchController::class, 'logAction']);

    // Domain & Zone Head Information
    Route::get('/domain-zone-management', [DomainZoneController::class, 'index'])
        ->middleware('permission:domain-zone-management,view');
    Route::post('/domain-zone-management', [DomainZoneController::class, 'store'])
        ->middleware('permission:domain-zone-management,create');
    Route::get('/domain-zone-management/{id}', [DomainZoneController::class, 'show'])
        ->middleware('permission:domain-zone-management,view');
    Route::put('/domain-zone-management/{id}', [DomainZoneController::class, 'update'])
        ->middleware('permission:domain-zone-management,edit');
    Route::delete('/domain-zone-management/{id}', [DomainZoneController::class, 'destroy'])
        ->middleware('permission:domain-zone-management,delete');

    // Staff Position List
    Route::get('/staff-position-list', [StaffPositionController::class, 'index'])
        ->middleware('permission:staff-position-list,view');
    Route::post('/staff-position-list', [StaffPositionController::class, 'store'])
        ->middleware('permission:staff-position-list,create');
    Route::get('/staff-position-list/{id}', [StaffPositionController::class, 'show'])
        ->middleware('permission:staff-position-list,view');
    Route::put('/staff-position-list/{id}', [StaffPositionController::class, 'update'])
        ->middleware('permission:staff-position-list,edit');
    Route::delete('/staff-position-list/{id}', [StaffPositionController::class, 'destroy'])
        ->middleware('permission:staff-position-list,delete');
    Route::post('/staff-position-list/{id}/status', [StaffPositionController::class, 'updateStatus'])
        ->middleware('permission:staff-position-list,approve');
    Route::post('/staff-position-list/action', [StaffPositionController::class, 'logAction']);

    // Staff Transfers & Branch Closures
    Route::get('/staff-transfers', [StaffTransferController::class, 'index'])
        ->middleware('permission:staff-position-list,view');
    Route::get('/staff-transfers/branches', [StaffTransferController::class, 'branches'])
        ->middleware('permission:staff-position-list,view');
    Route::get('/staff-transfers/staff', [StaffTransferController::class, 'staff'])
        ->middleware('permission:staff-position-list,view');
    Route::get('/staff-transfers/timeline/{staffId}', [StaffTransferController::class, 'timeline'])
        ->middleware('permission:staff-position-list,view');
    Route::post('/staff-transfers', [StaffTransferController::class, 'store'])
        ->middleware('permission:staff-position-list,create');
    Route::delete('/staff-transfers/{id}', [StaffTransferController::class, 'destroy'])
        ->middleware('permission:staff-position-list,delete');

    // Leave Management
    Route::get('/leave-management', [LeaveController::class, 'index'])
        ->middleware('permission:leave-management,view');
    Route::get('/leave-management/staff-summary', [LeaveController::class, 'staffSummary'])
        ->middleware('permission:leave-management,view');
    Route::post('/leave-management', [LeaveController::class, 'store'])
        ->middleware('permission:leave-management,create');
    Route::put('/leave-management/{id}', [LeaveController::class, 'update'])
        ->middleware('permission:leave-management,edit');
    Route::delete('/leave-management/{id}', [LeaveController::class, 'destroy'])
        ->middleware('permission:leave-management,delete');

    // Advance Management
    Route::get('/advance-management', [AdvanceController::class, 'index'])
        ->middleware('permission:advance-management,view');
    Route::post('/advance-management', [AdvanceController::class, 'store'])
        ->middleware('permission:advance-management,create');
    Route::put('/advance-management/{id}', [AdvanceController::class, 'update'])
        ->middleware('permission:advance-management,edit');
    Route::delete('/advance-management/{id}', [AdvanceController::class, 'destroy'])
        ->middleware('permission:advance-management,delete');

    // MIS Data Entry
    Route::get('/mis-data-entry/forms', [MISDataEntryController::class, 'forms'])
        ->middleware('permission:mis-data-entry,view');
    Route::post('/mis-data-entry/forms', [MISDataEntryController::class, 'storeForm'])
        ->middleware('permission:mis-data-entry,create');
    Route::delete('/mis-data-entry/forms/{id}', [MISDataEntryController::class, 'destroyForm'])
        ->middleware('permission:mis-data-entry,delete');
    Route::get('/mis-data-entry/submissions', [MISDataEntryController::class, 'submissions'])
        ->middleware('permission:mis-data-entry,view');

    // Movement Register
    Route::get('/movement-register', [MovementRegisterController::class, 'index'])
        ->middleware('permission:movement-register,view');

    Route::post('/movement-register', [MovementRegisterController::class, 'store'])
        ->middleware('permission:movement-register,create');

    Route::get('/movement-register/{id}', [MovementRegisterController::class, 'show'])
        ->middleware('permission:movement-register,view');

    Route::put('/movement-register/{id}', [MovementRegisterController::class, 'update'])
        ->middleware('permission:movement-register,edit');

    Route::delete('/movement-register/{id}', [MovementRegisterController::class, 'destroy'])
        ->middleware('permission:movement-register,delete');

    Route::post('/movement-register/{id}/return', [MovementRegisterController::class, 'markReturn'])
        ->middleware('permission:movement-register,edit');

    Route::post('/movement-register/{id}/approve', [MovementRegisterController::class, 'approve'])
        ->middleware('permission:movement-register,approve');

    Route::post('/movement-register/action', [MovementRegisterController::class, 'logAction']);

    // Stock Register
    Route::get('/stock-register/items', [StockRegisterController::class, 'index'])
        ->middleware('permission:stock-register,view');

    Route::post('/stock-register/items', [StockRegisterController::class, 'storeItem'])
        ->middleware('permission:stock-register,create');

    Route::get('/stock-register/items/{id}', [StockRegisterController::class, 'showItem'])
        ->middleware('permission:stock-register,view');

    Route::put('/stock-register/items/{id}', [StockRegisterController::class, 'updateItem'])
        ->middleware('permission:stock-register,edit');

    Route::delete('/stock-register/items/{id}', [StockRegisterController::class, 'destroyItem'])
        ->middleware('permission:stock-register,delete');

    Route::get('/stock-register/transactions', [StockRegisterController::class, 'transactions'])
        ->middleware('permission:stock-register,view');

    Route::post('/stock-register/transactions', [StockRegisterController::class, 'storeTransaction'])
        ->middleware('permission:stock-register,create');

    Route::delete('/stock-register/transactions/{id}', [StockRegisterController::class, 'destroyTransaction'])
        ->middleware('permission:stock-register,delete');

    Route::post('/stock-register/action', [StockRegisterController::class, 'logAction']);

    // Reports Module
    Route::get('/reports', [ReportController::class, 'index'])
        ->middleware('permission:reports,view');

    Route::get('/reports/filter-options', [ReportController::class, 'filterOptions']);

    Route::post('/reports/action', [ReportController::class, 'logAction']);

    // Dashboard Live Analytics
    Route::get('/dashboard/stats', [DashboardController::class, 'apiStats'])
        ->middleware('permission:dashboard,view');
    Route::get('/dashboard/chart', [DashboardController::class, 'apiChart'])
        ->middleware('permission:dashboard,view');
    Route::get('/dashboard/activities', [DashboardController::class, 'apiActivities'])
        ->middleware('permission:dashboard,view');
    Route::get('/dashboard/alerts', [DashboardController::class, 'apiAlerts'])
        ->middleware('permission:dashboard,view');
    Route::get('/dashboard/pending-tasks', [DashboardController::class, 'apiPendingTasks'])
        ->middleware('permission:dashboard,view');
    Route::get('/dashboard/stock-summary', [DashboardController::class, 'apiStockSummary'])
        ->middleware('permission:dashboard,view');
    Route::get('/dashboard/movement-summary', [DashboardController::class, 'apiMovementSummary'])
        ->middleware('permission:dashboard,view');

    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index'])
        ->middleware('permission:notifications,view');
    Route::post('/notifications/{id}/read', [NotificationController::class, 'markRead']);
    Route::post('/notifications/mark-all-read', [NotificationController::class, 'markAllRead']);

    // Target Activity
    Route::get('/target-activity', [TargetActivityController::class, 'index'])
        ->middleware('permission:target-activity,view');
    Route::post('/target-activity', [TargetActivityController::class, 'store'])
        ->middleware('permission:target-activity,create');

    // Report Requests
    Route::get('/report-requests', [ReportRequestController::class, 'index'])
        ->middleware('permission:report-requests,view');
    Route::post('/report-requests', [ReportRequestController::class, 'store'])
        ->middleware('permission:report-requests,create');

    // Note & Document Cabinet
    Route::get('/note-document-cabinet', [CabinetDocumentController::class, 'index'])
        ->middleware('permission:note-document-cabinet,view');
    Route::post('/note-document-cabinet', [CabinetDocumentController::class, 'store'])
        ->middleware('permission:note-document-cabinet,create');

    // Data Quality
    Route::get('/data-quality', [DataQualityController::class, 'index'])
        ->middleware('permission:data-quality,view');
    Route::post('/data-quality/verify', [DataQualityController::class, 'verify'])
        ->middleware('permission:data-quality,edit');

    // Monitoring
    Route::get('/monitoring', [MonitoringController::class, 'index'])
        ->middleware('permission:monitoring,view');

    // Analytics
    Route::get('/analytics', [AnalyticsController::class, 'index'])
        ->middleware('permission:analytics,view');

    // Backup Settings
    Route::get('/backup-settings', [BackupSettingsController::class, 'index'])
        ->middleware('permission:backup-settings,view');
    Route::post('/backup-settings/trigger', [BackupSettingsController::class, 'triggerBackup'])
        ->middleware('permission:backup-settings,create');

    // Action authorization checker and audit recorder
    Route::post('/actions/perform', function (Request $request) {
        $module = $request->input('module');
        $action = $request->input('action', 'view');
        $reference = $request->input('reference');

        $user = \App\Auth\AuthManager::user();
        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        if (!$user->isSuperAdmin() && !$user->hasPermission($module, $action)) {
            \App\Models\AuditLog::record($module, 'UNAUTHORIZED_ATTEMPT', "Denied action: {$action}", $user);
            return response()->json([
                'authorized' => false,
                'error' => 'Forbidden',
                'message' => "You do not have permission to {$action} in {$module}."
            ], 403);
        }

        \App\Models\AuditLog::record($module, strtoupper($action), $reference, $user);

        return response()->json([
            'authorized' => true,
            'success' => true,
            'message' => "Action '{$action}' performed and recorded in audit log."
        ]);
    });
});

Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'app' => 'MIS Department',
        'framework' => 'Laravel Blade Architecture',
        'timestamp' => date('c'),
    ]);
});
