<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\UserPermissionController;
use App\Http\Controllers\AuditLogController;

/*
|--------------------------------------------------------------------------
| Web Routes with Laravel Role & Permission Middleware
|--------------------------------------------------------------------------
|
| Every protected route verifies permissions using Laravel-native middleware,
| gates, and policies. Super Admin has full system access unconditionally.
| Every important action is recorded in the audit log.
|
*/

// Authentication Routes
Route::get('/', function () {
    return view('auth.login', ['title' => 'Sign In | MIS Department']);
})->name('login');

Route::get('/login', function () {
    return view('auth.login', ['title' => 'Sign In | MIS Department']);
});

Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::post('/password/email', [AuthController::class, 'forgotPassword']);
Route::post('/password/reset', [AuthController::class, 'resetPassword']);

// Protected MIS Application Modules - Every route verifies permission
Route::middleware(['auth'])->group(function () {

    // Dashboard
    Route::middleware(['permission:dashboard,view'])->get('/dashboard', [\App\Http\Controllers\DashboardController::class, 'index'])->name('dashboard');

    // Location & Branch
    Route::middleware(['permission:location-branch,view'])->get('/location-branch', function () {
        return view('location-branch.index', ['title' => 'Location & Branch']);
    })->name('location-branch');

    // Domain & Zone Head
    Route::middleware(['permission:domain-zone-management,view'])->get('/domain-zone-management', function () {
        return view('domain-zone-management.index', ['title' => 'Domain & Zone Head Information']);
    })->name('domain-zone-management');

    // Department Management
    Route::middleware(['permission:department-management,view'])->get('/department-management', function () {
        return view('department-management.index', ['title' => 'Department Management']);
    })->name('department-management');

    // Staff Position List
    Route::middleware(['permission:staff-position-list,view'])->get('/staff-position-list', function () {
        return view('staff-position-list.index', ['title' => 'Staff Position List']);
    })->name('staff-position-list');

    // Leave Management
    Route::middleware(['permission:leave-management,view'])->get('/leave-management', function () {
        return view('leave-management.index', ['title' => 'Leave Management']);
    })->name('leave-management');

    // Movement Register
    Route::middleware(['permission:movement-register,view'])->get('/movement-register', function () {
        return view('movement-register.index', ['title' => 'Movement Register']);
    })->name('movement-register');

    // Stock Register
    Route::middleware(['permission:stock-register,view'])->get('/stock-register', function () {
        return view('stock-register.index', ['title' => 'Stock Register']);
    })->name('stock-register');

    // MIS Data Entry
    Route::middleware(['permission:mis-data-entry,view'])->get('/mis-data-entry', function () {
        return view('mis-data-entry.index', ['title' => 'MIS Data Entry']);
    })->name('mis-data-entry');

    // Advance Management
    Route::middleware(['permission:advance-management,view'])->get('/advance-management', function () {
        return view('advance-management.index', ['title' => 'Advance Management']);
    })->name('advance-management');

    // Target & Activity
    Route::middleware(['permission:target-activity,view'])->get('/target-activity', function () {
        return view('target-activity.index', ['title' => 'Target & Activity']);
    })->name('target-activity');

    // Monitoring
    Route::middleware(['permission:monitoring,view'])->get('/monitoring', function () {
        return view('monitoring.index', ['title' => 'Monitoring']);
    })->name('monitoring');

    // MIS Reports
    Route::middleware(['permission:reports,view'])->get('/reports', function () {
        return view('reports.index', ['title' => 'MIS Reports']);
    })->name('reports');

    // Report Requests
    Route::middleware(['permission:report-requests,view'])->get('/report-requests', function () {
        return view('report-requests.index', ['title' => 'Report Requests']);
    })->name('report-requests');

    // Analytics
    Route::middleware(['permission:analytics,view'])->get('/analytics', function () {
        return view('analytics.index', ['title' => 'Analytics']);
    })->name('analytics');

    // Notifications
    Route::middleware(['permission:notifications,view'])->get('/notifications', function () {
        return view('notifications.index', ['title' => 'Notifications']);
    })->name('notifications');

    // Users & Permissions Management
    Route::middleware(['permission:users-permissions,view'])->group(function () {
        Route::get('/users-permissions', function () {
            return view('users-permissions.index', ['title' => 'Users & Permissions']);
        })->name('users-permissions');

        Route::post('/users-permissions', [UserPermissionController::class, 'store'])
            ->middleware('permission:users-permissions,create');

        Route::put('/users-permissions/{id}', [UserPermissionController::class, 'update'])
            ->middleware('permission:users-permissions,edit');

        Route::delete('/users-permissions/{id}', [UserPermissionController::class, 'destroy'])
            ->middleware('permission:users-permissions,delete');
    });

    // Note & Document Cabinet
    Route::middleware(['permission:note-document-cabinet,view'])->get('/note-document-cabinet', function () {
        return view('note-document-cabinet.index', ['title' => 'Note & Document Cabinet']);
    })->name('note-document-cabinet');

    // Excel Import / Export
    Route::middleware(['permission:excel-import-export,view'])->get('/excel-import-export', function () {
        return view('excel-import-export.index', ['title' => 'Excel Import / Export']);
    })->name('excel-import-export');

    // Backup & Settings
    Route::middleware(['permission:backup-settings,view'])->get('/backup-settings', function () {
        return view('backup-settings.index', ['title' => 'Backup & Settings']);
    })->name('backup-settings');

    // Data Quality
    Route::middleware(['permission:data-quality,view'])->get('/data-quality', function () {
        return view('data-quality.index', ['title' => 'Data Quality']);
    })->name('data-quality');

    // Audit Log
    Route::middleware(['permission:audit-log,view'])->get('/audit-log', function () {
        return view('audit-log.index', ['title' => 'Audit Log']);
    })->name('audit-log');
});
