# MIS Department Frontend

Updated with a functional frontend/demo implementation for:

- Advance Management: Add, View, Edit, Delete, Search, Status filter, balance calculation and CSV export.
- Users & Permissions: Super Admin user management with module-wise View/Create/Edit/Update/Delete/Approve/Print/Export permissions and organizational/geographic scope.
- LocalStorage persistence for demo records.
- Audit log entries for Advance and User permission changes.

## Important
This is a frontend/demo implementation. For production, connect authentication, authorization, CRUD APIs, file storage and database persistence to the Laravel/API backend. Client-side permission checks must not be treated as a security boundary.


## Added Modules
- Movement Register: employee movement, out/return, status, filters, CRUD, CSV and print.
- Stock Register: item master, receive/issue/return/transfer transaction, stock balance, ledger, filters, CRUD, CSV, print and chart.
- Both modules use localStorage for frontend demo data and are linked in the sidebar.


Responsive update: all pages include mobile/tablet responsive layout rules, horizontally scrollable data tables, responsive modals/forms/charts, and mobile navigation support.
