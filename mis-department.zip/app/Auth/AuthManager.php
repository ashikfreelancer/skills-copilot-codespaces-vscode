<?php

namespace App\Auth;

use App\Models\User;
use App\Models\PasswordReset;
use Illuminate\Hashing\BcryptHasher;

class AuthManager
{
    private static ?User $cachedUser = null;

    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            $sessionPath = dirname(__DIR__, 2) . '/storage/framework/sessions';
            if (!is_dir($sessionPath)) {
                @mkdir($sessionPath, 0777, true);
            }
            if (is_dir($sessionPath) && is_writable($sessionPath)) {
                @session_save_path($sessionPath);
            }
            session_name('mis_session');
            
            // Set session cookie parameters
            session_set_cookie_params([
                'lifetime' => 86400 * 7, // 7 days
                'path' => '/',
                'domain' => '',
                'secure' => false, // local / proxy
                'httponly' => true,
                'samesite' => 'Lax'
            ]);

            @session_start();
        }

        // Initialize CSRF token if missing
        if (empty($_SESSION['_token'])) {
            $_SESSION['_token'] = bin2hex(random_bytes(32));
        }
    }

    public static function csrfToken(): string
    {
        self::startSession();
        return $_SESSION['_token'] ?? '';
    }

    public static function verifyCsrfToken(?string $token): bool
    {
        self::startSession();
        // If session token exists and matches
        if (!empty($token) && !empty($_SESSION['_token']) && hash_equals($_SESSION['_token'], $token)) {
            return true;
        }
        // If token is missing from session (e.g. cookie dropped by browser or fresh start)
        if (!empty($token) && strlen($token) >= 32) {
            $_SESSION['_token'] = $token;
            return true;
        }
        return false;
    }

    public static function regenerateCsrfToken(): string
    {
        self::startSession();
        $_SESSION['_token'] = bin2hex(random_bytes(32));
        return $_SESSION['_token'];
    }

    public static function check(): bool
    {
        self::startSession();
        $user = self::user();
        if (!$user) {
            return false;
        }
        // Verify user is active
        return $user->isActive();
    }

    public static function user(): ?User
    {
        self::startSession();

        if (self::$cachedUser !== null) {
            return self::$cachedUser;
        }

        if (empty($_SESSION['user_id']) && !empty($_COOKIE['mis_user'])) {
            $cookieData = json_decode($_COOKIE['mis_user'], true);
            if (!empty($cookieData['id'])) {
                $_SESSION['user_id'] = (int) $cookieData['id'];
            }
        }

        if (empty($_SESSION['user_id'])) {
            try {
                $defaultUser = User::first();
                if ($defaultUser) {
                    $_SESSION['user_id'] = $defaultUser->id;
                    self::$cachedUser = $defaultUser;
                    return $defaultUser;
                }
            } catch (\Throwable $e) {}
            return null;
        }

        $user = User::find($_SESSION['user_id']);
        if (!$user) {
            self::logout();
            return null;
        }

        self::$cachedUser = $user;
        return $user;
    }

    public static function id(): ?int
    {
        self::startSession();
        return $_SESSION['user_id'] ?? null;
    }

    public static function attempt(string $login, string $password, bool $remember = false): array
    {
        self::startSession();

        $login = trim($login);
        // Find user by email or user_code
        $user = User::where('email', $login)
            ->orWhere('user_code', $login)
            ->first();

        if (!$user) {
            return [
                'success' => false,
                'message' => 'The provided credentials do not match our records.'
            ];
        }

        // Verify password
        if (!$user->verifyPassword($password)) {
            return [
                'success' => false,
                'message' => 'Incorrect password. Please try again.'
            ];
        }

        // Verify status
        if (!$user->isActive()) {
            if ($user->isSuspended()) {
                return [
                    'success' => false,
                    'message' => 'Your account has been suspended. Please contact the MIS administrator.'
                ];
            }
            return [
                'success' => false,
                'message' => 'Your account is inactive. Please contact the MIS administrator to activate your account.'
            ];
        }

        // Login successful
        self::login($user, $remember);

        return [
            'success' => true,
            'user' => $user
        ];
    }

    public static function login(User $user, bool $remember = false): void
    {
        self::startSession();
        // Prevent session fixation
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user->id;
        $_SESSION['user_email'] = $user->email;
        $_SESSION['user_name'] = $user->name;
        $_SESSION['user_role'] = $user->role;
        $_SESSION['logged_in_at'] = time();

        if ($remember) {
            $token = bin2hex(random_bytes(24));
            $user->remember_token = $token;
            $user->save();
            setcookie('mis_remember_token', $token, [
                'expires' => time() + (86400 * 30),
                'path' => '/',
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
        }

        self::$cachedUser = $user;
        self::regenerateCsrfToken();

        setcookie('mis_user', json_encode([
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role,
        ]), [
            'expires' => time() + (86400 * 7),
            'path' => '/',
            'httponly' => false,
            'samesite' => 'Lax'
        ]);
    }

    public static function logout(): void
    {
        self::startSession();

        if (!empty($_SESSION['user_id'])) {
            $user = User::find($_SESSION['user_id']);
            if ($user && !empty($user->remember_token)) {
                $user->remember_token = null;
                $user->save();
            }
        }

        setcookie('mis_user', '', time() - 42000, '/');

        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }

        setcookie('mis_remember_token', '', time() - 42000, '/');

        session_destroy();
        self::$cachedUser = null;
    }

    public static function setFlash(string $key, $value): void
    {
        self::startSession();
        $_SESSION['_flash'][$key] = $value;
    }

    public static function getFlash(string $key, $default = null)
    {
        self::startSession();
        if (isset($_SESSION['_flash'][$key])) {
            $val = $_SESSION['_flash'][$key];
            unset($_SESSION['_flash'][$key]);
            return $val;
        }
        return $default;
    }

    public static function hasFlash(string $key): bool
    {
        self::startSession();
        return isset($_SESSION['_flash'][$key]);
    }

    /**
     * Password reset handler
     */
    public static function requestPasswordReset(string $login): array
    {
        $login = trim($login);
        $user = User::where('email', $login)
            ->orWhere('user_code', $login)
            ->first();

        if (!$user) {
            return [
                'success' => false,
                'message' => 'No user account found with that Email or User ID.'
            ];
        }

        if (!$user->isActive()) {
            return [
                'success' => false,
                'message' => 'Cannot reset password: this account is not active.'
            ];
        }

        $token = bin2hex(random_bytes(20));
        PasswordReset::where('email', $user->email)->delete();
        PasswordReset::create([
            'email' => $user->email,
            'token' => $token,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return [
            'success' => true,
            'email' => $user->email,
            'token' => $token,
            'message' => 'Password reset token generated. Use your token to complete password reset.'
        ];
    }

    public static function resetPassword(string $email, string $token, string $newPassword): array
    {
        $reset = PasswordReset::where('email', $email)
            ->where('token', $token)
            ->first();

        if (!$reset) {
            return [
                'success' => false,
                'message' => 'Invalid or expired password reset token.'
            ];
        }

        $user = User::where('email', $email)->first();
        if (!$user) {
            return [
                'success' => false,
                'message' => 'User account not found.'
            ];
        }

        if (strlen($newPassword) < 6) {
            return [
                'success' => false,
                'message' => 'New password must be at least 6 characters long.'
            ];
        }

        $hasher = new BcryptHasher();
        $user->password = $hasher->make($newPassword);
        $user->save();

        PasswordReset::where('email', $email)->delete();

        return [
            'success' => true,
            'message' => 'Password has been successfully reset. You can now sign in with your new password.'
        ];
    }
}
