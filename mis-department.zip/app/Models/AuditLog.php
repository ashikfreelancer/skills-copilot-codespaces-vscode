<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuditLog extends Model
{
    protected $table = 'audit_logs';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'username',
        'module',
        'action',
        'reference',
        'ip_address',
        'user_agent',
        'created_at',
    ];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Record an audit log entry
     */
    public static function record(
        string $module,
        string $action,
        ?string $reference = null,
        ?User $user = null,
        ?string $ip = null,
        ?string $userAgent = null
    ): self {
        return self::create([
            'user_id' => $user ? $user->id : null,
            'username' => $user ? ($user->name . ' (' . $user->role . ')') : 'System / Guest',
            'module' => $module,
            'action' => strtoupper($action),
            'reference' => $reference,
            'ip_address' => $ip ?? ($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'),
            'user_agent' => $userAgent ?? ($_SERVER['HTTP_USER_AGENT'] ?? 'MIS Client'),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
