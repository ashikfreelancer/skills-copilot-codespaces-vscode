<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    protected $table = 'branches';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'division',
        'district',
        'thana',
        'upazila',
        'union_name',
        'ward',
        'branch',
        'code',
        'manager',
        'mobile',
        'personal_mobile',
        'email',
        'status',
        'address',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function administrativeLocation()
    {
        return $this->belongsTo(AdministrativeLocation::class, 'upazila', 'name');
    }

    /**
     * Staff currently stationed at this branch
     */
    public function staff()
    {
        return $this->hasMany(StaffPosition::class, 'current_posting', 'branch');
    }

    /**
     * Staff transfers originating from this branch
     */
    public function transfersOut()
    {
        return $this->hasMany(StaffTransfer::class, 'from_branch', 'branch');
    }

    /**
     * Staff transfers arriving to this branch
     */
    public function transfersIn()
    {
        return $this->hasMany(StaffTransfer::class, 'to_branch', 'branch');
    }

    /**
     * Movement registers destined for this branch
     */
    public function movements()
    {
        return $this->hasMany(MovementRegister::class, 'destination', 'branch');
    }

    /**
     * Stock items stored at this branch
     */
    public function stockItems()
    {
        return $this->hasMany(StockItem::class, 'location', 'branch');
    }

    /**
     * Stock transactions executed at this branch
     */
    public function stockTransactions()
    {
        return $this->hasMany(StockTransaction::class, 'location', 'branch');
    }
}
