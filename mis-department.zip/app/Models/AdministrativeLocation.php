<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdministrativeLocation extends Model
{
    protected $table = 'administrative_locations';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'type',
        'name',
        'division',
        'district',
        'thana',
        'status',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function branches()
    {
        return $this->hasMany(Branch::class, 'upazila', 'name');
    }

    public function branchesByDistrict()
    {
        return $this->hasMany(Branch::class, 'district', 'name');
    }

    public function branchesByDivision()
    {
        return $this->hasMany(Branch::class, 'division', 'name');
    }

    public function movements()
    {
        return $this->hasMany(MovementRegister::class, 'location', 'name');
    }
}
