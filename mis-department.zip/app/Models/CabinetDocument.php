<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CabinetDocument extends Model
{
    protected $table = 'cabinet_documents';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'title',
        'category',
        'doc_type',
        'memo_no',
        'doc_date',
        'department',
        'version',
        'description',
        'remarks',
        'attachments',
        'history',
    ];
}
