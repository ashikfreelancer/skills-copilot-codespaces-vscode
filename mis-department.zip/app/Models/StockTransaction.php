<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockTransaction extends Model
{
    use HasFactory;

    protected $table = 'stock_transactions';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'date',
        'item_id',
        'type',
        'qty',
        'unit_price',
        'location',
        'reference',
        'party',
        'staff_id',
        'purpose',
        'approved_by',
        'remarks',
    ];

    protected $casts = [
        'qty' => 'float',
        'unit_price' => 'float',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function item(): BelongsTo
    {
        return $this->belongsTo(StockItem::class, 'item_id', 'id');
    }

    public function staff(): BelongsTo
    {
        return $this->belongsTo(StaffPosition::class, 'staff_id', 'staff_id');
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class, 'location', 'branch');
    }
}
