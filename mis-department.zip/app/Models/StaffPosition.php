<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StaffPosition extends Model
{
    protected $table = 'staff_positions';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'serial',
        'name',
        'gender',
        'dob',
        'father',
        'mother',
        'staff_id',
        'designation',
        'join_date',
        'posting_date',
        'promotion_date',
        'education',
        'home_district',
        'previous_posting',
        'current_posting',
        'department',
        'status',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function isComplete(): bool
    {
        return !empty($this->dob) &&
               !empty($this->father) &&
               !empty($this->mother) &&
               !empty($this->education) &&
               !empty($this->home_district);
    }

    /**
     * History of branch transfers and closures as Eloquent relationship
     */
    public function transfers()
    {
        return $this->hasMany(StaffTransfer::class, 'staff_id', 'staff_id')->orderBy('transfer_date', 'desc');
    }

    /**
     * Relationship to Department
     */
    public function departmentModel()
    {
        return $this->belongsTo(Department::class, 'department', 'name');
    }

    /**
     * Relationship to Current Branch
     */
    public function currentBranch()
    {
        return $this->belongsTo(Branch::class, 'current_posting', 'branch');
    }

    /**
     * Relationship to Previous Branch
     */
    public function previousBranch()
    {
        return $this->belongsTo(Branch::class, 'previous_posting', 'branch');
    }

    /**
     * Movement register activities logged for this staff member
     */
    public function movementRegisters()
    {
        return $this->hasMany(MovementRegister::class, 'employee_id', 'staff_id');
    }

    /**
     * Leaves submitted / taken by this staff member
     */
    public function leaves()
    {
        return $this->hasMany(Leave::class, 'staff_id', 'staff_id');
    }

    /**
     * Financial advances given to this staff member
     */
    public function advances()
    {
        return $this->hasMany(Advance::class, 'employee_id', 'staff_id');
    }

    /**
     * Stock items received / issued to this staff member
     */
    public function stockTransactions()
    {
        return $this->hasMany(StockTransaction::class, 'staff_id', 'staff_id');
    }

    /**
     * Domain and Zone leadership appointments
     */
    public function domainZoneHeadings()
    {
        return $this->hasMany(DomainZone::class, 'employee_id', 'staff_id');
    }
}
