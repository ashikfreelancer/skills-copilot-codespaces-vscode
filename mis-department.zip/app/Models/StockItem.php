<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StockItem extends Model
{
    use HasFactory;

    protected $table = 'stock_items';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'code',
        'name',
        'category',
        'unit',
        'opening',
        'min',
        'location',
        'supplier',
        'status',
    ];

    protected $casts = [
        'opening' => 'float',
        'min' => 'float',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function transactions(): HasMany
    {
        return $this->hasMany(StockTransaction::class, 'item_id', 'id');
    }

    public function branchLocation()
    {
        return $this->belongsTo(Branch::class, 'location', 'branch');
    }

    public function calculateStock(?string $location = null): array
    {
        $opening = (float)$this->opening;
        $query = $this->transactions();
        if ($location) {
            $query->where('location', $location);
        }
        $txs = $query->get();

        $received = 0.0;
        $issued = 0.0;

        foreach ($txs as $tx) {
            $qty = (float)$tx->qty;
            if (in_array($tx->type, ['Receive', 'Return', 'Transfer In'])) {
                $received += $qty;
            } elseif (in_array($tx->type, ['Issue', 'Transfer Out'])) {
                $issued += $qty;
            } elseif ($tx->type === 'Adjustment') {
                if ($qty >= 0) {
                    $received += $qty;
                } else {
                    $issued += abs($qty);
                }
            }
        }

        $balance = $opening + $received - $issued;
        $statusBadge = 'Available';
        if ($balance <= 0) {
            $statusBadge = 'Out';
        } elseif ($balance <= (float)$this->min) {
            $statusBadge = 'Low';
        }

        return [
            'opening' => $opening,
            'received' => $received,
            'issued' => $issued,
            'balance' => $balance,
            'statusBadge' => $statusBadge,
        ];
    }
}
