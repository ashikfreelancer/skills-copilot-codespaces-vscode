<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    protected $table = 'leaves';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'staff_id',
        'staff_name',
        'department',
        'leave_type',
        'from_date',
        'to_date',
        'days',
        'status',
        'reason',
        'approved_by',
    ];

    protected $casts = [
        'days' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Staff member applying for leave
     */
    public function staff()
    {
        return $this->belongsTo(StaffPosition::class, 'staff_id', 'staff_id');
    }

    /**
     * Department associated with leave
     */
    public function departmentModel()
    {
        return $this->belongsTo(Department::class, 'department', 'name');
    }
}
