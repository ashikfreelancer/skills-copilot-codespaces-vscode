<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TargetActivity extends Model
{
    protected $table = 'target_activities';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'period',
        'area',
        'indicator',
        'target',
        'achieved',
        'description',
    ];

    protected $casts = [
        'target' => 'float',
        'achieved' => 'float',
    ];
}
