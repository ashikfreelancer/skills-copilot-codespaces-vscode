<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MovementRegister extends Model
{
    use HasFactory;

    protected $table = 'movement_registers';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'date',
        'employee_id',
        'employee_name',
        'designation',
        'department',
        'domain',
        'zone',
        'location',
        'type',
        'out_time',
        'expected_return',
        'actual_return',
        'purpose',
        'destination',
        'contact',
        'vehicle',
        'accompanied_by',
        'approved_by',
        'status',
        'remarks',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Search scope across employee name, id, purpose, destination, department, zone
     */
    public function scopeSearch($query, $search)
    {
        if (empty($search)) {
            return $query;
        }

        return $query->where(function ($q) use ($search) {
            $q->where('employee_name', 'like', "%{$search}%")
              ->orWhere('employee_id', 'like', "%{$search}%")
              ->orWhere('purpose', 'like', "%{$search}%")
              ->orWhere('destination', 'like', "%{$search}%")
              ->orWhere('location', 'like', "%{$search}%")
              ->orWhere('designation', 'like', "%{$search}%")
              ->orWhere('department', 'like', "%{$search}%")
              ->orWhere('remarks', 'like', "%{$search}%");
        });
    }

    /**
     * Filter scope
     */
    public function scopeFilter($query, array $filters)
    {
        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (!empty($filters['type'])) {
            $query->where('type', $filters['type']);
        }
        if (!empty($filters['department'])) {
            $query->where('department', $filters['department']);
        }
        if (!empty($filters['domain'])) {
            $query->where('domain', $filters['domain']);
        }
        if (!empty($filters['zone'])) {
            $query->where('zone', $filters['zone']);
        }
        if (!empty($filters['location'])) {
            $query->where('location', $filters['location']);
        }
        if (!empty($filters['employee_id'])) {
            $query->where('employee_id', $filters['employee_id']);
        }
        if (!empty($filters['from'])) {
            $query->where('date', '>=', $filters['from']);
        }
        if (!empty($filters['to'])) {
            $query->where('date', '<=', $filters['to']);
        }

        return $query;
    }

    /**
     * The staff member performing the movement
     */
    public function staff()
    {
        return $this->belongsTo(StaffPosition::class, 'employee_id', 'staff_id');
    }

    /**
     * Department associated with this movement
     */
    public function departmentModel()
    {
        return $this->belongsTo(Department::class, 'department', 'name');
    }

    /**
     * Domain and Zone reference
     */
    public function zoneModel()
    {
        return $this->belongsTo(DomainZone::class, 'zone', 'zone');
    }

    /**
     * Destination Branch (if destination is a registered branch)
     */
    public function branchDestination()
    {
        return $this->belongsTo(Branch::class, 'destination', 'branch');
    }

    /**
     * Administrative Location (Division/District/Thana)
     */
    public function administrativeLocation()
    {
        return $this->belongsTo(AdministrativeLocation::class, 'location', 'name');
    }
}
