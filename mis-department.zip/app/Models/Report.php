<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $table = 'reports';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'title',
        'category',
        'period',
        'scope',
        'status',
        'report_type',
        'template',
        'branch_office',
        'submission_status',
        'remarks',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Branch linked to this report submission
     */
    public function branch()
    {
        return $this->belongsTo(Branch::class, 'branch_office', 'branch');
    }
}
