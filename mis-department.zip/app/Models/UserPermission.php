<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserPermission extends Model
{
    protected $table = 'user_permissions';

    protected $fillable = [
        'user_id',
        'module',
        'can_view',
        'can_create',
        'can_edit',
        'can_update',
        'can_delete',
        'can_approve',
        'can_reject',
        'can_print',
        'can_export',
        'can_import',
    ];

    protected $casts = [
        'can_view' => 'boolean',
        'can_create' => 'boolean',
        'can_edit' => 'boolean',
        'can_update' => 'boolean',
        'can_delete' => 'boolean',
        'can_approve' => 'boolean',
        'can_reject' => 'boolean',
        'can_print' => 'boolean',
        'can_export' => 'boolean',
        'can_import' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
