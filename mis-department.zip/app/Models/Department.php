<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use HasFactory;

    protected $table = 'departments';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'name',
        'code',
        'description',
        'status',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Scope a query to search across department name, code, description.
     */
    public function scopeSearch($query, $search)
    {
        if (empty($search)) {
            return $query;
        }

        return $query->where(function ($q) use ($search) {
            $q->where('name', 'like', "%{$search}%")
              ->orWhere('code', 'like', "%{$search}%")
              ->orWhere('description', 'like', "%{$search}%");
        });
    }

    /**
     * Scope a query to filter by status.
     */
    public function scopeFilter($query, array $filters)
    {
        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        return $query;
    }

    /**
     * Scope for active departments.
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'Active');
    }

    /**
     * Boot model to generate custom ID if not set.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = 'DEP-' . round(microtime(true) * 1000) . '-' . mt_rand(100, 999);
            }
        });
    }

    /**
     * Department associated users.
     */
    public function users()
    {
        return $this->hasMany(User::class, 'department', 'name');
    }

    /**
     * Staff assigned to this Department
     */
    public function staff()
    {
        return $this->hasMany(StaffPosition::class, 'department', 'name');
    }

    /**
     * Movement records by staff in this Department
     */
    public function movementRegisters()
    {
        return $this->hasMany(MovementRegister::class, 'department', 'name');
    }

    /**
     * Leaves taken by staff in this Department
     */
    public function leaves()
    {
        return $this->hasMany(Leave::class, 'department', 'name');
    }

    /**
     * Financial advances allocated to staff in this Department
     */
    public function advances()
    {
        return $this->hasMany(Advance::class, 'department', 'name');
    }

    /**
     * Staff transfers involving this Department
     */
    public function staffTransfers()
    {
        return $this->hasMany(StaffTransfer::class, 'department', 'name');
    }
}
