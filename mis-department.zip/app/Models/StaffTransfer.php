<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StaffTransfer extends Model
{
    protected $table = 'staff_transfers';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'staff_id',
        'staff_name',
        'designation',
        'department',
        'type',              // 'Transfer' or 'Close'
        'from_branch',
        'to_branch',
        'transfer_date',
        'order_number',
        'approved_by',
        'handover_status',   // 'Completed', 'In Progress', 'Pending Clearance'
        'charge_handed_to',
        'reason',
        'remarks',
        'status',            // 'Approved', 'Completed', 'Pending'
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relationship to StaffPosition model
     */
    public function staffPosition()
    {
        return $this->belongsTo(StaffPosition::class, 'staff_id', 'staff_id');
    }

    /**
     * Relationship to origin Branch
     */
    public function originBranch()
    {
        return $this->belongsTo(Branch::class, 'from_branch', 'branch');
    }

    /**
     * Relationship to destination Branch
     */
    public function destinationBranch()
    {
        return $this->belongsTo(Branch::class, 'to_branch', 'branch');
    }

    /**
     * Scope for filter by staff
     */
    public function scopeForStaff($query, $staffId)
    {
        return $query->where('staff_id', $staffId);
    }

    /**
     * Scope for transfers
     */
    public function scopeTransfers($query)
    {
        return $query->where('type', 'Transfer');
    }

    /**
     * Scope for closures / releases
     */
    public function scopeClosures($query)
    {
        return $query->where('type', 'Close');
    }
}
