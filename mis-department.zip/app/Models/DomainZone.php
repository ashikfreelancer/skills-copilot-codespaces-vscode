<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DomainZone extends Model
{
    use HasFactory;

    protected $table = 'domain_zones';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'domain',
        'zone',
        'head_type',
        'head_name',
        'designation',
        'employee_id',
        'mobile',
        'email',
        'address',
        'status',
        'remarks',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Scope a query to filter by search keyword.
     */
    public function scopeSearch($query, $search)
    {
        if (empty($search)) {
            return $query;
        }

        return $query->where(function ($q) use ($search) {
            $q->where('head_name', 'like', "%{$search}%")
              ->orWhere('employee_id', 'like', "%{$search}%")
              ->orWhere('mobile', 'like', "%{$search}%")
              ->orWhere('email', 'like', "%{$search}%")
              ->orWhere('domain', 'like', "%{$search}%")
              ->orWhere('zone', 'like', "%{$search}%");
        });
    }

    /**
     * Scope a query to filter by domain, zone, head_type, status.
     */
    public function scopeFilter($query, array $filters)
    {
        if (!empty($filters['domain'])) {
            $query->where('domain', $filters['domain']);
        }

        if (!empty($filters['zone'])) {
            $query->where('zone', $filters['zone']);
        }

        if (!empty($filters['head_type'])) {
            $query->where('head_type', $filters['head_type']);
        }

        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        return $query;
    }

    /**
     * Staff member designated as Head of this Domain/Zone
     */
    public function headStaff()
    {
        return $this->belongsTo(StaffPosition::class, 'employee_id', 'staff_id');
    }

    /**
     * Movements under this Zone
     */
    public function movements()
    {
        return $this->hasMany(MovementRegister::class, 'zone', 'zone');
    }

    /**
     * Movements under this Domain
     */
    public function domainMovements()
    {
        return $this->hasMany(MovementRegister::class, 'domain', 'domain');
    }
}
