<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DataQualityVerification extends Model
{
    protected $table = 'data_quality_verifications';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    protected $fillable = [
        'id',
        'record_id',
        'module',
        'verified_by',
        'status',
        'remarks',
        'created_at',
    ];
}
