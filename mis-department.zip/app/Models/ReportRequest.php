<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReportRequest extends Model
{
    protected $table = 'report_requests';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id',
        'requester',
        'department',
        'report',
        'request_date',
        'deadline',
        'priority',
        'assigned',
        'status',
        'remarks',
    ];
}
