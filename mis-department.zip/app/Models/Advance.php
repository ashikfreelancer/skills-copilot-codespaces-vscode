<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Advance extends Model
{
    protected $table = 'advances';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'employee',
        'employee_id',
        'department',
        'designation',
        'purpose',
        'request_date',
        'due_date',
        'amount',
        'adjusted',
        'status',
        'approval',
        'notes',
    ];

    protected $casts = [
        'amount' => 'float',
        'adjusted' => 'float',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function getBalanceAttribute(): float
    {
        return max(0, $this->amount - $this->adjusted);
    }

    /**
     * Staff member taking advance
     */
    public function staff()
    {
        return $this->belongsTo(StaffPosition::class, 'employee_id', 'staff_id');
    }

    /**
     * Department associated with advance
     */
    public function departmentModel()
    {
        return $this->belongsTo(Department::class, 'department', 'name');
    }
}
