<?php

namespace App\Services;

use App\Models\Leave;
use Carbon\Carbon;

class LeaveCalculationService
{
    /**
     * Standard Annual Leave Quotas by Category
     */
    const DEFAULT_QUOTAS = [
        'Casual Leave' => 14,
        'Sick Leave' => 14,
        'Earned Leave' => 20,
        'Maternity Leave' => 120,
        'Special Leave' => 10,
    ];

    /**
     * Calculate available balance for an employee for a specific leave type
     * Balance = Total Quota - Approved Days
     */
    public function calculateRemainingBalance(int $employeeId, string $leaveType, int $year = null): array
    {
        $year = $year ?: date('Y');
        $totalQuota = self::DEFAULT_QUOTAS[$leaveType] ?? 14;

        // Fetch approved leave days for current fiscal year
        $approvedDays = Leave::where('employee_id', $employeeId)
            ->where('leave_type', $leaveType)
            ->where('status', 'Approved')
            ->whereYear('start_date', $year)
            ->sum('total_days');

        $pendingDays = Leave::where('employee_id', $employeeId)
            ->where('leave_type', $leaveType)
            ->where('status', 'Pending')
            ->whereYear('start_date', $year)
            ->sum('total_days');

        $availableBalance = max(0, $totalQuota - $approvedDays);

        return [
            'leave_type' => $leaveType,
            'total_quota' => $totalQuota,
            'approved_days' => $approvedDays,
            'pending_days' => $pendingDays,
            'available_balance' => $availableBalance,
            'can_apply' => $availableBalance > 0
        ];
    }

    /**
     * Calculate working days excluding standard weekends
     */
    public function calculateDuration(string $startDate, string $endDate): int
    {
        $start = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);

        if ($end->lt($start)) {
            return 0;
        }

        return $start->diffInDays($end) + 1;
    }

    /**
     * Check if a requested date range overlaps with existing leaves
     */
    public function hasOverlap(int $employeeId, string $startDate, string $endDate, int $excludeId = null): bool
    {
        $query = Leave::where('employee_id', $employeeId)
            ->where('status', '!=', 'Rejected')
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('start_date', [$startDate, $endDate])
                  ->orWhereBetween('end_date', [$startDate, $endDate])
                  ->orWhere(function ($sub) use ($startDate, $endDate) {
                      $sub->where('start_date', '<=', $startDate)
                          ->where('end_date', '>=', $endDate);
                  });
            });

        if ($excludeId) {
            $query->where('id', '!=', $excludeId);
        }

        return $query->exists();
    }
}
