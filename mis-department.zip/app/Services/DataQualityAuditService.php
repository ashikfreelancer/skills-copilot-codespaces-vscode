<?php

namespace App\Services;

use App\Models\Branch;
use App\Models\Department;
use App\Models\StaffPosition;

class DataQualityAuditService
{
    /**
     * Scan enterprise dataset for missing required fields, duplicates, or anomalies
     * Return comprehensive hygiene score out of 100
     */
    public function performAudit(): array
    {
        $issues = [];
        $totalChecks = 0;
        $failedChecks = 0;

        // Check 1: Branches without phone or email
        $branchesMissingContact = Branch::whereNull('phone')
            ->orWhereNull('email')
            ->orWhere('phone', '')
            ->orWhere('email', '')
            ->count();
        $totalChecks++;
        if ($branchesMissingContact > 0) {
            $failedChecks++;
            $issues[] = [
                'module' => 'location-branch',
                'severity' => 'Medium',
                'description' => "{$branchesMissingContact} branch(es) have missing contact details (phone/email)."
            ];
        }

        // Check 2: Departments without an assigned head
        $deptMissingHead = Department::whereNull('head_of_department')
            ->orWhere('head_of_department', '')
            ->count();
        $totalChecks++;
        if ($deptMissingHead > 0) {
            $failedChecks++;
            $issues[] = [
                'module' => 'department-management',
                'severity' => 'High',
                'description' => "{$deptMissingHead} department(s) lack a designated Head of Department."
            ];
        }

        // Check 3: Staff with zero or missing salary configuration
        $staffMissingSalary = StaffPosition::whereNull('basic_salary')
            ->orWhere('basic_salary', '<=', 0)
            ->count();
        $totalChecks++;
        if ($staffMissingSalary > 0) {
            $failedChecks++;
            $issues[] = [
                'module' => 'staff-position-list',
                'severity' => 'High',
                'description' => "{$staffMissingSalary} staff member(s) have unconfigured basic salary."
            ];
        }

        // Calculation: Hygiene score
        $healthScore = $totalChecks > 0 
            ? round((($totalChecks - $failedChecks) / $totalChecks) * 100) 
            : 100;

        return [
            'health_score' => $healthScore,
            'rating' => $healthScore >= 90 ? 'Excellent' : ($healthScore >= 70 ? 'Satisfactory' : 'Needs Attention'),
            'total_checks' => $totalChecks,
            'issues_found' => count($issues),
            'issues' => $issues,
            'audited_at' => date('Y-m-d H:i:s')
        ];
    }
}
