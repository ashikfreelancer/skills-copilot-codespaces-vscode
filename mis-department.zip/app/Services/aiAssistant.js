import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..', '..');

// Initialize Gemini client with recommended telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

/**
 * Scan codebase files dynamically (excluding node_modules, git, temp)
 */
export function getProjectCatalog() {
  const catalog = [];
  const scannedDirs = ['resources/views', 'app', 'database', 'public/assets', 'routes', 'config'];

  function scan(dir) {
    const fullDir = path.join(rootDir, dir);
    if (!fs.existsSync(fullDir)) return;

    const entries = fs.readdirSync(fullDir, { withFileTypes: true });
    for (const ent of entries) {
      if (ent.name.startsWith('.') || ent.name === 'node_modules') continue;
      const relPath = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        scan(relPath);
      } else {
        const ext = path.extname(ent.name);
        if (['.php', '.blade.php', '.js', '.css', '.sql', '.json'].some(e => relPath.endsWith(e))) {
          catalog.push({
            name: ent.name,
            path: relPath,
            category: getCategory(relPath),
            description: getFileDescription(relPath, ent.name)
          });
        }
      }
    }
  }

  for (const d of scannedDirs) {
    scan(d);
  }

  // Include root key files
  ['server.js', 'blade.js', 'package.json'].forEach(f => {
    if (fs.existsSync(path.join(rootDir, f))) {
      catalog.push({
        name: f,
        path: f,
        category: 'Core System',
        description: f === 'server.js' ? 'Express Backend & REST API Server (6,900+ lines)' : (f === 'blade.js' ? 'Laravel Blade Compiler & Template Engine' : 'Package & Dependency Config')
      });
    }
  });

  return catalog;
}

function getCategory(filePath) {
  if (filePath.startsWith('resources/views/layouts')) return 'Blade Master Layout';
  if (filePath.startsWith('resources/views/components')) return 'Blade Reusable Component';
  if (filePath.startsWith('resources/views/partials')) return 'Blade Layout Partial';
  if (filePath.startsWith('resources/views/errors')) return 'Blade HTTP Error Handler';
  if (filePath.startsWith('resources/views/auth')) return 'Blade Authentication';
  if (filePath.startsWith('resources/views/')) return 'Blade Module View';
  if (filePath.startsWith('app/Services')) return 'Business Logic & Calculation Service';
  if (filePath.startsWith('app/Http/Controllers')) return 'HTTP Controller';
  if (filePath.startsWith('app/Http/Requests')) return 'Form Request Validation';
  if (filePath.startsWith('app/Http/Middleware')) return 'Security Middleware';
  if (filePath.startsWith('app/Models')) return 'Database Eloquent Model';
  if (filePath.startsWith('database/migrations')) return 'Database Migration Schema';
  if (filePath.startsWith('database/seeders')) return 'Database Initializer Seeder';
  if (filePath.startsWith('public/assets/js')) return 'Client-Side JavaScript / Concurrency Guard';
  if (filePath.startsWith('public/assets/css')) return 'Application Stylesheet';
  if (filePath.startsWith('routes')) return 'Web & API Route Definitions';
  if (filePath.startsWith('config')) return 'Enterprise Configuration';
  return 'System File';
}

function getFileDescription(filePath, fileName) {
  const p = filePath.toLowerCase();
  if (p.includes('leavecalculationservice')) return 'ছুটি অনুমোদন, বার্ষিক কোটা থেকে অবশিষ্ট ব্যালেন্স হিসাব ও তারিখের ওভারল্যাপ যাচাই।';
  if (p.includes('stockvaluationservice')) return 'রিয়েল-টাইম স্টক ব্যালেন্স (Opening + In - Out), ইনভেন্টরি ভ্যালুয়েশন ও রি-অর্ডার এলার্ট।';
  if (p.includes('advanceamortizationservice')) return 'অগ্রিম লোন অ্যামরটাইজেশন, কিস্তি পুনরুদ্ধার ও বকেয়া হিসাব।';
  if (p.includes('dataqualityauditservice')) return 'ডাটাবেজের নাল ও ডুপ্লিকেট স্ক্যান করে ১০০ ভিত্তিক ডাটা হেলথ স্কোর নিরীক্ষা।';
  if (p.includes('leaveapplicationrequest')) return 'ছুটির আবেদন ফর্মের ডেডিকেটেড রিকোয়েস্ট ভ্যালিডেশন।';
  if (p.includes('advancemanagementrequest')) return 'অগ্রিম ঋণ ফর্মের টাকার অংক (৫০০-৫,০০,০০০) ও কিস্তি ভ্যালিডেশন।';
  if (p.includes('targetactivityrequest')) return 'টার্গেট ও অর্জনের ত্রৈমাসিক/বার্ষিক ইনপুট ভ্যালিডেশন।';
  if (p.includes('staffpositionrequest')) return 'স্টাফ পদবি, জাতীয় পে-স্কেল গ্রেড ও বেতন ভ্যালিডেশন।';
  if (p.includes('app.blade.php')) return 'মাস্টার লারাভেল ব্লেড লেআউট (CSRF, সিডিএন স্ক্রিপ্টস, টোস্ট ও স্লটস)।';
  if (p.includes('sidebar.blade.php')) return '২২টি মডিউলের আইকন, ডাইনামিক রুট ও রোল-বেসড মেনুবার।';
  if (p.includes('403.blade.php')) return 'অননুমোদিত অ্যাক্সেস ট্র্যাকিং ও অডিট লগিং এরর ব্লেড ভিউ।';
  if (p.includes('404.blade.php')) return 'পেজ নট ফাউন্ড রেসকিউ ও ড্যাশবোর্ড নেভিগেশন ভিউ।';
  if (p.includes('login.blade.php')) return 'মাল্টি-রোল লগইন (অ্যাডমিন, ম্যানেজার, অফিসার, ভিউয়ার) ও সেশন হ্যান্ডলার।';
  if (p.includes('stock-register/index.blade.php')) return 'স্টক রেজিস্টার ও ইনভেন্টরি খতিয়ান ব্লেড ইন্টারফেস (/stock-register)।';
  if (p.includes('leave-management/index.blade.php')) return 'ছুটি ব্যবস্থাপনা, কোটা ব্যালেন্স ও অনুমোদন ক্যালেন্ডার (/leave-management)।';
  if (p.includes('advance-management/index.blade.php')) return 'অগ্রিম ঋণ বিতরণ, কিস্তি শিডিউল ও রিকভারি ইন্টারফেস (/advance-management)।';
  if (p.includes('department-management/index.blade.php')) return 'ডিপার্টমেন্ট কোড, হেডকাউন্ট ও বাজেট এলোকেশন ইন্টারফেস (/department-management)।';
  if (p.includes('location-branch/index.blade.php')) return 'ব্রাঞ্চ কোড, জোন অ্যাসাইনমেন্ট ও জিও-কোঅর্ডিনেট ইন্টারফেস (/location-branch)।';
  if (p.includes('mis-data-entry/index.blade.php')) return 'মাসিক কেপিআই ডাটা এন্ট্রি ও ইন্ডিকেটর ভ্যালিডেশন (/mis-data-entry)।';
  if (p.includes('movement-register/index.blade.php')) return 'গেট পাস ও গাড়ি/মালপত্র যাতায়াত রেজিস্টার (/movement-register)।';
  if (p.includes('target-activity/index.blade.php')) return 'টার্গেট বনাম অর্জনের শতকরা হার ও পারফরম্যান্স মেট্রিক্স (/target-activity)।';
  if (p.includes('monitoring/index.blade.php')) return 'সার্ভার মেমরি, সিস্টেম হেলথ ও আপটাইম মনিটরিং (/monitoring)।';
  if (p.includes('data-quality/index.blade.php')) return 'ডাটা হাইজিন অডিট, নাল ফিল্ড চেকার ও কোয়ালিটি স্কোর (/data-quality)।';
  if (p.includes('audit-log/index.blade.php')) return 'সিকিউরিটি অডিট ট্রেইল, আইপি, ইউজার ও অ্যাকশন হিস্ট্রি (/audit-log)।';
  if (p.includes('backup-settings/index.blade.php')) return 'ওয়ান-ক্লিক এসকিউএল ডাটাবেজ ব্যাকআপ ও ডাউনলোড (/backup-settings)।';
  if (p.includes('excel-import-export/index.blade.php')) return 'সিএসভি/এক্সেল টেমপ্লেট ও বাল্ক ডাটা ইমপোর্ট/এক্সপোর্ট (/excel-import-export)।';
  if (p.includes('users-permissions/index.blade.php')) return 'পূর্ণাঙ্গ RBAC রোল পারমিশন ম্যাট্রিক্স গ্রিড (/users-permissions)।';
  if (p.includes('analytics/index.blade.php')) return 'amCharts 5 ইন্টারঅ্যাকটিভ গ্রাফিক্যাল অ্যানালিটিক্স (/analytics)।';
  if (p.includes('dashboard/index.blade.php')) return 'প্রধান ড্যাশবোর্ড, রিয়েল-টাইম কেপিআই মেট্রিক্স ও চার্টস (/dashboard)।';
  if (p.includes('reports/index.blade.php')) return 'ডিপার্টমেন্টাল ও এগ্রিগেটেড প্রিন্ট-রেডি রিপোর্ট জেনারেশন (/reports)।';
  if (p.includes('mis.php')) return 'সিস্টেম বিজনেস রুলস, লিমিট ও কনফিগারেশন ফাইল।';
  return `${fileName} ফাইল (${getCategory(filePath)})`;
}

/**
 * Perform instant keyword matching across all project files
 */
export function searchProjectFiles(query) {
  if (!query || typeof query !== 'string') return [];
  const q = query.toLowerCase().trim();
  const catalog = getProjectCatalog();

  return catalog
    .map(file => {
      let score = 0;
      const nameL = file.name.toLowerCase();
      const pathL = file.path.toLowerCase();
      const descL = file.description.toLowerCase();
      const catL = file.category.toLowerCase();

      // Keyword weights
      if (nameL === q) score += 100;
      else if (nameL.includes(q)) score += 50;
      if (pathL.includes(q)) score += 30;
      if (descL.includes(q)) score += 20;
      if (catL.includes(q)) score += 15;

      // Special Bengali aliases
      const aliases = {
        'ছুটি': ['leave', 'quota', 'balance'],
        'স্টক': ['stock', 'inventory', 'valuation', 'item'],
        'লোন': ['advance', 'loan', 'amortization'],
        'অগ্রিম': ['advance', 'voucher'],
        'শাখা': ['branch', 'location'],
        'বিভাগ': ['department'],
        'টার্গেট': ['target', 'activity'],
        'ইউজার': ['user', 'permission', 'role'],
        'অডিট': ['audit', 'log'],
        'ব্যাকআপ': ['backup', 'database', 'sqlite'],
        'এক্সেল': ['excel', 'import', 'export', 'csv'],
        'মুভমেন্ট': ['movement', 'gate'],
        'রিপোর্ট': ['report'],
        'মাইগ্রেশন': ['migration', 'table']
      };

      for (const [bnWord, enKeywords] of Object.entries(aliases)) {
        if (q.includes(bnWord)) {
          for (const kw of enKeywords) {
            if (pathL.includes(kw) || descL.includes(kw)) score += 40;
          }
        }
      }

      return { ...file, score };
    })
    .filter(f => f.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 12);
}

/**
 * Generate intelligent Gemini-powered or Indexed-fallback assistant response
 */
export function queryAiAssistant({ message, history = [] }) {
  const trimmed = (message || '').trim();
  if (!trimmed) {
    return Promise.resolve({
      reply: 'অনুগ্রহ করে আপনি কোন ফাইল, ফিচার বা ক্যালকুলেশন খুঁজতে চান তা জানান। উদাহরণ: "লিভ ম্যানেজমেন্টের ফাইল কোথায়?" বা "Stock valuation কোথায় হিসাব হয়?"',
      matchedFiles: []
    });
  }

  const matchedFiles = searchProjectFiles(trimmed);
  const catalog = getProjectCatalog();

  // Try calling Gemini 3.8 Flash model
  return (async () => {
    try {
      if (process.env.GEMINI_API_KEY) {
        const systemInstruction = `
আপনি হলেন "MIS Department AI Smart Assistant" (এমআইএস স্মার্ট সহকারী)।
এই প্রজেক্টটি একটি সমৃদ্ধ এন্টারপ্রাইজ ম্যানেজমেন্ট ইনফরমেশন সিস্টেম (MIS), যেখানে মোট ১৬৩+ টি ফাইল রয়েছে (লারাভেল ব্লেড ভিউ, কন্ট্রোলার, সার্ভিস লেয়ার ক্যালকুলেশন, ফর্ম রিকোয়েস্ট ভ্যালিডেশন, রিলেশনাল ডাটাবেজ মাইগ্রেশন ও এপিআই)।

আপনার প্রধান দায়িত্ব:
১. ব্যবহারকারী যেকোনো ফাইল, মডিউল, ফাংশন, বা গাণিতিক হিসাব (ক্যালকুলেশন) সম্পর্কে জানতে চাইলে তাৎক্ষণিকভাবে ফাইলটির সঠিক পাথ (File Path), ফোল্ডার, এবং ফাইলটির কাজ ব্যাখ্যা করে দেওয়া।
২. ফাইলটির সাথে যদি ব্রাউজারের কোনো ওয়েব রুট সম্পর্কিত থাকে (যেমন: /leave-management, /stock-register, /dashboard), তবে তা স্পষ্ট করে উল্লেখ করা।
৩. ব্যবহারকারী বাংলায় প্রশ্ন করলে শুদ্ধ বাংলায় অত্যন্ত সুন্দর, প্রফেশনাল ও ফ্রেন্ডলি ভঙ্গিতে উত্তর দিন। প্রয়োজনে কোড ব্লক বা ফাইল পাথ \`code\` আকারে হাইলাইট করুন।
৪. কোনো ক্যালকুলেশনের ফাইল খুঁজলে (যেমন: Leave balance, Stock valuation, Advance loan recovery, Data quality scoring) সংশ্লিষ্ট Service ফাইল ও ব্লেড ভিউয়ের নাম জানিয়ে দিন।

প্রজেক্টের সাম্প্রতিক কিছু গুরুত্বপূর্ণ ফাইল ক্যাটালগ:
${catalog.slice(0, 75).map(f => `- [${f.category}] ${f.path}: ${f.description}`).join('\n')}
`;

        const promptText = `
User Query: "${trimmed}"

Matching Candidate Files from local index:
${matchedFiles.map(f => `- ${f.path} (${f.category}): ${f.description}`).join('\n')}

Please provide a helpful, elegant, professional response in Bengali detailing exactly where the requested file/feature is located, what it does, and how it is used.
`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptText,
          config: {
            systemInstruction: systemInstruction,
            temperature: 0.3,
          }
        });

        if (response && response.text) {
          return {
            reply: response.text,
            matchedFiles: matchedFiles.slice(0, 8),
            provider: 'gemini-3.8-flash'
          };
        }
      }
    } catch (err) {
      console.warn('[Gemini AI Assistant Note]:', err.message);
    }

    // High-performance intelligent Fallback using indexed metadata
    let fallbackReply = '';
    if (matchedFiles.length > 0) {
      fallbackReply = `আমি আপনার অনুরোধ অনুযায়ী সংশ্লিষ্ট **${matchedFiles.length}টি ফাইল** খুঁজে পেয়েছি:\n\n`;
      matchedFiles.slice(0, 6).forEach((f, idx) => {
        fallbackReply += `**${idx + 1}. \`${f.path}\`**\n`;
        fallbackReply += `• **ধরন:** ${f.category}\n`;
        fallbackReply += `• **বিবরণ:** ${f.description}\n\n`;
      });
      fallbackReply += `💡 যেকোনো ফাইলে ক্লিক করে অথবা সরাসরি সংশ্লিষ্ট ব্রাউজার রুটে গিয়ে ফিচারটি ব্যবহার করতে পারেন।`;
    } else {
      fallbackReply = `আমি আপনার খোঁজা বিষয়টির সাথে হুবহু কোনো ফাইল মেলাতে পারিনি। আপনি কি নিচের কোনো মডিউল খুঁজছেন?\n\n` +
        `• **ছুটি/Leave:** \`resources/views/leave-management/index.blade.php\` & \`app/Services/LeaveCalculationService.php\`\n` +
        `• **স্টক/Stock:** \`resources/views/stock-register/index.blade.php\` & \`app/Services/StockValuationService.php\`\n` +
        `• **অগ্রিম ঋণ/Advance:** \`resources/views/advance-management/index.blade.php\` & \`app/Services/AdvanceAmortizationService.php\`\n` +
        `• **শাখা ও লোকেশন:** \`resources/views/location-branch/index.blade.php\`\n` +
        `• **ব্যবহারকারী ও পারমিশন:** \`resources/views/users-permissions/index.blade.php\``;
    }

    return {
      reply: fallbackReply,
      matchedFiles: matchedFiles.slice(0, 8),
      provider: 'intelligent-filesystem-indexer'
    };
  })();
}
