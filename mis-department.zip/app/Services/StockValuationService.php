<?php

namespace App\Services;

use App\Models\StockItem;
use App\Models\StockTransaction;

class StockValuationService
{
    /**
     * Calculate current real-time stock balance & valuation for an item
     * Stock = Opening + Total Inflow - Total Outflow
     * Valuation = Current Quantity * Unit Price
     */
    public function calculateItemBalance(int $itemId): array
    {
        $item = StockItem::findOrFail($itemId);

        $totalIn = StockTransaction::where('item_id', $itemId)
            ->whereIn('type', ['IN', 'PURCHASE', 'RETURN_IN'])
            ->sum('quantity');

        $totalOut = StockTransaction::where('item_id', $itemId)
            ->whereIn('type', ['OUT', 'ISSUE', 'DAMAGE', 'TRANSFER_OUT'])
            ->sum('quantity');

        $currentQuantity = max(0, ($item->opening_stock ?? 0) + $totalIn - $totalOut);
        $totalValuation = round($currentQuantity * ($item->unit_price ?? 0), 2);
        $reorderNeeded = $currentQuantity <= ($item->reorder_level ?? 10);

        return [
            'item_id' => $itemId,
            'item_name' => $item->name,
            'item_code' => $item->code,
            'current_quantity' => $currentQuantity,
            'unit_price' => $item->unit_price,
            'total_valuation' => $totalValuation,
            'reorder_level' => $item->reorder_level,
            'reorder_needed' => $reorderNeeded,
            'status' => $currentQuantity == 0 ? 'Out of Stock' : ($reorderNeeded ? 'Low Stock' : 'In Stock')
        ];
    }

    /**
     * Calculate total inventory portfolio valuation across all items
     */
    public function calculateTotalInventoryValuation(): array
    {
        $items = StockItem::all();
        $totalValue = 0;
        $totalItems = 0;
        $lowStockCount = 0;

        foreach ($items as $item) {
            $balance = $this->calculateItemBalance($item->id);
            $totalValue += $balance['total_valuation'];
            $totalItems += $balance['current_quantity'];
            if ($balance['reorder_needed']) {
                $lowStockCount++;
            }
        }

        return [
            'total_valuation' => round($totalValue, 2),
            'total_units' => $totalItems,
            'total_skus' => count($items),
            'low_stock_alerts' => $lowStockCount
        ];
    }
}
