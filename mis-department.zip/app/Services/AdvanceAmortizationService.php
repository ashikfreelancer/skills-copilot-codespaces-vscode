<?php

namespace App\Services;

use App\Models\Advance;

class AdvanceAmortizationService
{
    /**
     * Calculate outstanding balance, monthly deduction, and recovery percentage
     * Outstanding = Total Advance - Recovered Amount
     * Recovery Rate = (Recovered / Total) * 100
     */
    public function calculateLoanSummary(int $advanceId): array
    {
        $advance = Advance::findOrFail($advanceId);

        $totalAmount = (float) $advance->amount;
        $recoveredAmount = (float) ($advance->recovered_amount ?? 0);
        $outstanding = max(0, $totalAmount - $recoveredAmount);
        $installments = max(1, (int) ($advance->installments ?? 1));
        $monthlyDeduction = round($totalAmount / $installments, 2);
        $percentRecovered = $totalAmount > 0 ? round(($recoveredAmount / $totalAmount) * 100, 1) : 0;

        return [
            'advance_id' => $advanceId,
            'employee_name' => $advance->employee_name,
            'total_amount' => $totalAmount,
            'recovered_amount' => $recoveredAmount,
            'outstanding_balance' => $outstanding,
            'installments' => $installments,
            'monthly_deduction' => $monthlyDeduction,
            'recovery_percentage' => $percentRecovered,
            'is_settled' => $outstanding <= 0.01
        ];
    }

    /**
     * Record an installment recovery payment
     */
    public function recordRecovery(int $advanceId, float $paymentAmount): array
    {
        $advance = Advance::findOrFail($advanceId);
        $newRecovered = min((float)$advance->amount, (float)($advance->recovered_amount ?? 0) + $paymentAmount);
        
        $advance->recovered_amount = $newRecovered;
        if ($newRecovered >= (float)$advance->amount) {
            $advance->status = 'Adjusted';
        }
        $advance->save();

        return $this->calculateLoanSummary($advanceId);
    }
}
