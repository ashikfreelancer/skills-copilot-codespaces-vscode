<?php

namespace App\Policies;

use App\Models\User;

class LocationBranchPolicy
{
    /**
     * Intercept all checks - Super Admin has unconditional access.
     */
    public function before(User $user, string $ability): ?bool
    {
        if ($user->isSuperAdmin()) {
            return true;
        }

        return null;
    }

    public function view(User $user): bool
    {
        return $user->hasPermission('location-branch', 'view');
    }

    public function create(User $user): bool
    {
        return $user->hasPermission('location-branch', 'create');
    }

    public function edit(User $user): bool
    {
        return $user->hasPermission('location-branch', 'edit');
    }

    public function update(User $user): bool
    {
        return $user->hasPermission('location-branch', 'update');
    }

    public function delete(User $user): bool
    {
        return $user->hasPermission('location-branch', 'delete');
    }

    public function approve(User $user): bool
    {
        return $user->hasPermission('location-branch', 'approve');
    }

    public function print(User $user): bool
    {
        return $user->hasPermission('location-branch', 'print');
    }

    public function export(User $user): bool
    {
        return $user->hasPermission('location-branch', 'export');
    }

    public function import(User $user): bool
    {
        return $user->hasPermission('location-branch', 'import');
    }
}
