<?php

namespace App\Policies;

use App\Models\User;
use App\Models\DomainZone;
use Illuminate\Auth\Access\HandlesAuthorization;

class DomainZonePolicy
{
    use HandlesAuthorization;

    /**
     * Intercept all checks for Super Admin.
     */
    public function before(User $user, string $ability)
    {
        if (strtolower($user->role ?? '') === 'super admin') {
            return true;
        }
    }

    /**
     * Determine whether the user can view any domain & zone heads.
     */
    public function viewAny(User $user): bool
    {
        return $this->canPerform($user, 'view');
    }

    /**
     * Determine whether the user can view the specific domain & zone head.
     */
    public function view(User $user, DomainZone $domainZone): bool
    {
        return $this->canPerform($user, 'view');
    }

    /**
     * Determine whether the user can create domain & zone records.
     */
    public function create(User $user): bool
    {
        return $this->canPerform($user, 'create');
    }

    /**
     * Determine whether the user can update the record.
     */
    public function update(User $user, DomainZone $domainZone): bool
    {
        return $this->canPerform($user, 'update') || $this->canPerform($user, 'edit');
    }

    /**
     * Determine whether the user can delete the record.
     */
    public function delete(User $user, DomainZone $domainZone): bool
    {
        return $this->canPerform($user, 'delete');
    }

    /**
     * Determine whether the user can approve or change status.
     */
    public function approve(User $user, DomainZone $domainZone): bool
    {
        return $this->canPerform($user, 'approve');
    }

    /**
     * Determine whether the user can print reports.
     */
    public function print(User $user): bool
    {
        return $this->canPerform($user, 'print');
    }

    /**
     * Determine whether the user can export data.
     */
    public function export(User $user): bool
    {
        return $this->canPerform($user, 'export');
    }

    /**
     * Determine whether the user can import data.
     */
    public function import(User $user): bool
    {
        return $this->canPerform($user, 'import');
    }

    private function canPerform(User $user, string $action): bool
    {
        $role = strtolower($user->role ?? '');
        if ($role === 'super admin') return true;
        if ($role === 'admin') return true;
        if ($role === 'accountant') {
            return in_array($action, ['view', 'print', 'export']);
        }
        if ($role === 'computer operator') {
            return in_array($action, ['view', 'create', 'edit', 'update', 'print']);
        }
        return false;
    }
}
