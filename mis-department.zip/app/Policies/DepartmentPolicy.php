<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Department;
use Illuminate\Auth\Access\HandlesAuthorization;

class DepartmentPolicy
{
    use HandlesAuthorization;

    /**
     * Intercept all checks for Super Admin.
     */
    public function before(User $user, string $ability)
    {
        if (strtolower($user->role ?? '') === 'super admin') {
            return true;
        }
    }

    /**
     * Determine whether the user can view any departments.
     */
    public function viewAny(User $user): bool
    {
        return $this->canPerform($user, 'view');
    }

    /**
     * Determine whether the user can view the specific department.
     */
    public function view(User $user, Department $department): bool
    {
        return $this->canPerform($user, 'view');
    }

    /**
     * Determine whether the user can create departments.
     */
    public function create(User $user): bool
    {
        return $this->canPerform($user, 'create');
    }

    /**
     * Determine whether the user can update the department.
     */
    public function update(User $user, Department $department): bool
    {
        return $this->canPerform($user, 'update') || $this->canPerform($user, 'edit');
    }

    /**
     * Determine whether the user can delete the department.
     */
    public function delete(User $user, Department $department): bool
    {
        return $this->canPerform($user, 'delete');
    }

    /**
     * Determine whether the user can activate / deactivate or approve.
     */
    public function approve(User $user, Department $department): bool
    {
        return $this->canPerform($user, 'approve');
    }

    /**
     * Determine whether the user can print department reports.
     */
    public function print(User $user): bool
    {
        return $this->canPerform($user, 'print');
    }

    /**
     * Determine whether the user can export department data.
     */
    public function export(User $user): bool
    {
        return $this->canPerform($user, 'export');
    }

    private function canPerform(User $user, string $action): bool
    {
        $role = strtolower($user->role ?? '');
        if ($role === 'super admin') return true;
        if ($role === 'admin') return true;
        if ($role === 'accountant') {
            return in_array($action, ['view', 'print', 'export']);
        }
        if ($role === 'computer operator') {
            return in_array($action, ['view', 'create', 'edit', 'update', 'print']);
        }
        return false;
    }
}
