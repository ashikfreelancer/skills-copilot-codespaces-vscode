<?php

namespace App\Policies;

use App\Models\User;
use App\Models\MovementRegister;
use Illuminate\Auth\Access\HandlesAuthorization;

class MovementRegisterPolicy
{
    use HandlesAuthorization;

    public function before(User $user, string $ability)
    {
        if (strtolower($user->role ?? '') === 'super admin') {
            return true;
        }
    }

    public function viewAny(User $user): bool
    {
        return $this->canPerform($user, 'view');
    }

    public function view(User $user, MovementRegister $movement): bool
    {
        return $this->canPerform($user, 'view');
    }

    public function create(User $user): bool
    {
        return $this->canPerform($user, 'create');
    }

    public function update(User $user, MovementRegister $movement): bool
    {
        return $this->canPerform($user, 'update') || $this->canPerform($user, 'edit');
    }

    public function delete(User $user, MovementRegister $movement): bool
    {
        return $this->canPerform($user, 'delete');
    }

    public function approve(User $user): bool
    {
        return $this->canPerform($user, 'approve');
    }

    public function print(User $user): bool
    {
        return $this->canPerform($user, 'print');
    }

    public function export(User $user): bool
    {
        return $this->canPerform($user, 'export');
    }

    protected function canPerform(User $user, string $action): bool
    {
        $permissions = $user->permissions ?? [];
        if (isset($permissions['movement-register'])) {
            return in_array($action, (array)$permissions['movement-register'], true);
        }
        return false;
    }
}
