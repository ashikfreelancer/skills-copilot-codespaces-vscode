<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ModulePolicy
{
    use HandlesAuthorization;

    /**
     * Perform pre-authorization checks.
     * The Super Admin must have full system access.
     */
    public function before(User $user, string $ability)
    {
        if ($user->isSuperAdmin()) {
            return true;
        }

        if (!$user->isActive()) {
            return false;
        }
    }

    /**
     * Determine whether the user can view the module.
     */
    public function view(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'view');
    }

    /**
     * Determine whether the user can create records in the module.
     */
    public function create(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'create');
    }

    /**
     * Determine whether the user can edit records in the module.
     */
    public function edit(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'edit');
    }

    /**
     * Determine whether the user can update records in the module.
     */
    public function update(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'update');
    }

    /**
     * Determine whether the user can delete records in the module.
     */
    public function delete(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'delete');
    }

    /**
     * Determine whether the user can approve records in the module.
     */
    public function approve(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'approve');
    }

    /**
     * Determine whether the user can reject records in the module.
     */
    public function reject(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'reject');
    }

    /**
     * Determine whether the user can print in the module.
     */
    public function print(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'print');
    }

    /**
     * Determine whether the user can export from the module.
     */
    public function export(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'export');
    }

    /**
     * Determine whether the user can import into the module.
     */
    public function import(User $user, string $module): bool
    {
        return $user->hasPermission($module, 'import');
    }
}
