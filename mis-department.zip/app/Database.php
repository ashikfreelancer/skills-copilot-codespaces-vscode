<?php

namespace App;

use Illuminate\Database\Capsule\Manager as Capsule;

class Database
{
    private static bool $booted = false;

    public static function init(): Capsule
    {
        if (self::$booted) {
            return Capsule::getInstance();
        }

        $dbDir = dirname(__DIR__) . '/database';
        if (!is_dir($dbDir)) {
            mkdir($dbDir, 0777, true);
        }

        $dbFile = $dbDir . '/database.sqlite';
        if (!file_exists($dbFile)) {
            touch($dbFile);
        }

        $capsule = new Capsule();
        $connection = getenv('DB_CONNECTION') ?: ($_ENV['DB_CONNECTION'] ?? 'sqlite');

        if ($connection === 'mysql') {
            $capsule->addConnection([
                'driver' => 'mysql',
                'host' => getenv('DB_HOST') ?: ($_ENV['DB_HOST'] ?? '127.0.0.1'),
                'port' => getenv('DB_PORT') ?: ($_ENV['DB_PORT'] ?? '3306'),
                'database' => getenv('DB_DATABASE') ?: ($_ENV['DB_DATABASE'] ?? 'mis_db'),
                'username' => getenv('DB_USERNAME') ?: ($_ENV['DB_USERNAME'] ?? 'root'),
                'password' => getenv('DB_PASSWORD') ?: ($_ENV['DB_PASSWORD'] ?? ''),
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => '',
                'strict' => false,
                'engine' => 'InnoDB',
            ]);
        } else {
            $capsule->addConnection([
                'driver' => 'sqlite',
                'database' => $dbFile,
                'prefix' => '',
            ]);
        }

        $capsule->setAsGlobal();
        $capsule->bootEloquent();

        self::$booted = true;
        self::ensureSchema($capsule);

        return $capsule;
    }

    private static function ensureSchema(Capsule $capsule): void
    {
        $schema = $capsule->schema();

        if (!$schema->hasTable('users')) {
            $schema->create('users', function ($table) {
                $table->increments('id');
                $table->string('user_code')->nullable()->unique();
                $table->string('name');
                $table->string('email')->unique();
                $table->string('password');
                $table->string('role')->default('MIS Viewer');
                $table->string('department')->default('MIS');
                $table->string('scope')->default('All');
                $table->string('status')->default('Active'); // Active, Inactive, Suspended
                $table->text('permissions')->nullable();
                $table->string('remember_token', 100)->nullable();
                $table->timestamps();
            });
        }

        if (!$schema->hasTable('password_resets')) {
            $schema->create('password_resets', function ($table) {
                $table->string('email')->index();
                $table->string('token');
                $table->timestamp('created_at')->nullable();
            });
        }

        if (!$schema->hasTable('sessions')) {
            $schema->create('sessions', function ($table) {
                $table->string('id')->primary();
                $table->unsignedInteger('user_id')->nullable()->index();
                $table->string('ip_address', 45)->nullable();
                $table->text('user_agent')->nullable();
                $table->text('payload');
                $table->integer('last_activity')->index();
            });
        }

        // Seed default users if empty
        self::seedUsers($capsule);
    }

    public static function seedUsers(Capsule $capsule): void
    {
        $userCount = $capsule->table('users')->count();
        if ($userCount === 0) {
            $hasher = new \Illuminate\Hashing\BcryptHasher();

            $capsule->table('users')->insert([
                [
                    'user_code' => 'U-001',
                    'name' => 'MIS Super Admin',
                    'email' => 'superadmin@mis.local',
                    'password' => $hasher->make('admin123'),
                    'role' => 'MIS Super Admin',
                    'department' => 'MIS',
                    'scope' => 'All',
                    'status' => 'Active',
                    'permissions' => json_encode(['*']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                [
                    'user_code' => 'U-002',
                    'name' => 'Zone Officer',
                    'email' => 'zone.officer@mis.local',
                    'password' => $hasher->make('entry123'),
                    'role' => 'MIS Data Entry',
                    'department' => 'MIS',
                    'scope' => 'Dhaka Zone',
                    'status' => 'Active',
                    'permissions' => json_encode(['view', 'create', 'edit']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                [
                    'user_code' => 'U-003',
                    'name' => 'MIS Reviewer',
                    'email' => 'reviewer@mis.local',
                    'password' => $hasher->make('review123'),
                    'role' => 'MIS Reviewer',
                    'department' => 'MIS',
                    'scope' => 'All',
                    'status' => 'Active',
                    'permissions' => json_encode(['view', 'approve', 'print', 'export']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                [
                    'user_code' => 'U-004',
                    'name' => 'Inactive User',
                    'email' => 'inactive.user@mis.local',
                    'password' => $hasher->make('password123'),
                    'role' => 'MIS Viewer',
                    'department' => 'MIS',
                    'scope' => 'All',
                    'status' => 'Inactive',
                    'permissions' => json_encode(['view']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                [
                    'user_code' => 'U-005',
                    'name' => 'Suspended User',
                    'email' => 'suspended.user@mis.local',
                    'password' => $hasher->make('password123'),
                    'role' => 'MIS Viewer',
                    'department' => 'MIS',
                    'scope' => 'All',
                    'status' => 'Suspended',
                    'permissions' => json_encode(['view']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ],
                [
                    'user_code' => 'U-006',
                    'name' => 'TMSS MIS Administrator',
                    'email' => 'admin@tmss.org',
                    'password' => $hasher->make('admin123'),
                    'role' => 'MIS Super Admin',
                    'department' => 'MIS',
                    'scope' => 'All',
                    'status' => 'Active',
                    'permissions' => json_encode(['*']),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]
            ]);
        }
    }
}
