<?php

namespace App\Http\Middleware;

use App\Auth\AuthManager;

class Authenticate
{
    public static function handle(): bool
    {
        AuthManager::startSession();

        if (!AuthManager::check()) {
            $isJson = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))
                || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

            if ($isJson) {
                http_response_code(401);
                header('Content-Type: application/json');
                echo json_encode([
                    'error' => 'Unauthenticated',
                    'message' => 'You must be signed in to access this resource.',
                    'redirect' => '/login'
                ]);
                exit;
            }

            AuthManager::setFlash('error', 'Please sign in to access the system.');
            header('Location: /login');
            exit;
        }

        return true;
    }
}
