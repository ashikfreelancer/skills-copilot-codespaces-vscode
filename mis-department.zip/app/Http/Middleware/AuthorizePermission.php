<?php

namespace App\Http\Middleware;

use App\Auth\AuthManager;
use App\Models\AuditLog;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class AuthorizePermission
{
    /**
     * Handle an incoming request and enforce Laravel authorization.
     * Every protected route must verify permission.
     * Every important action must be recorded in the audit log.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  $module
     * @param  string  $action (default 'view')
     * @return mixed
     */
    public function handle(Request $request, Closure $next, string $module, string $action = 'view')
    {
        $user = AuthManager::user();

        if (!$user) {
            if ($request->expectsJson()) {
                return response()->json([
                    'error' => 'Unauthenticated',
                    'message' => 'Please sign in to access this resource.'
                ], 401);
            }
            return redirect('/login');
        }

        if (!$user->isActive()) {
            AuditLog::record(
                $module,
                'UNAUTHORIZED_ATTEMPT',
                "User account is {$user->status}. Denied access to {$module}",
                $user,
                $request->ip(),
                $request->userAgent()
            );

            AuthManager::logout();
            return redirect('/login?error=account_suspended');
        }

        // The Super Admin must have full system access
        if ($user->isSuperAdmin()) {
            return $next($request);
        }

        // Verify permission using Laravel Gates or Model check
        $authorized = Gate::allows('permission', [$module, $action]) || $user->hasPermission($module, $action);

        if (!$authorized) {
            // Record the unauthorized action in the audit log
            AuditLog::record(
                $module,
                'UNAUTHORIZED_ATTEMPT',
                "Access forbidden: User '{$user->email}' ({$user->role}) attempted unauthorized action '{$action}' on module '{$module}'",
                $user,
                $request->ip(),
                $request->userAgent()
            );

            if ($request->expectsJson() || $request->ajax()) {
                return response()->json([
                    'error' => 'Forbidden',
                    'message' => "You do not have permission to {$action} within the {$module} module."
                ], 403);
            }

            // Return Laravel-native 403 Forbidden response
            return response()->view('errors.403', [
                'title' => '403 Forbidden',
                'module' => $module,
                'action' => $action,
                'user' => $user,
            ], 403);
        }

        return $next($request);
    }
}
