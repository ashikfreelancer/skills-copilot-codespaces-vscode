<?php

namespace App\Http\Middleware;

use App\Auth\AuthManager;

class VerifyCsrfToken
{
    public static function handle(): bool
    {
        AuthManager::startSession();

        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if (in_array($method, ['GET', 'HEAD', 'OPTIONS'])) {
            return true;
        }

        // Check token in POST, header X-CSRF-TOKEN, or header X-XSRF-TOKEN
        $token = $_POST['_token'] ?? null;
        if (!$token) {
            $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        }
        if (!$token) {
            $token = $_SERVER['HTTP_X_XSRF_TOKEN'] ?? null;
        }

        // If JSON payload was posted, also check parsed JSON body
        if (!$token) {
            $rawInput = file_get_contents('php://input');
            if ($rawInput) {
                $decoded = json_decode($rawInput, true);
                if (is_array($decoded) && !empty($decoded['_token'])) {
                    $token = $decoded['_token'];
                }
            }
        }

        if (!AuthManager::verifyCsrfToken($token)) {
            $isJson = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))
                || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

            http_response_code(419);
            if ($isJson) {
                header('Content-Type: application/json');
                echo json_encode([
                    'error' => 'CSRF_MISMATCH',
                    'message' => 'CSRF token mismatch. Please reload the page and try again.',
                    'csrf_token' => AuthManager::csrfToken()
                ]);
                exit;
            }

            AuthManager::setFlash('error', 'Your session expired or CSRF token was invalid. Please try again.');
            header('Location: /login');
            exit;
        }

        return true;
    }
}
