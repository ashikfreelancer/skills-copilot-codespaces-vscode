<?php

namespace App\Http\Middleware;

use App\Auth\AuthManager;

class CheckUserStatus
{
    public static function handle(): bool
    {
        AuthManager::startSession();

        $user = AuthManager::user();
        if ($user && !$user->isActive()) {
            $status = $user->status;
            AuthManager::logout();

            $isJson = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))
                || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

            $msg = $status === 'Suspended'
                ? 'Your account has been suspended. Please contact the administrator.'
                : 'Your account is currently inactive. Please contact the administrator.';

            if ($isJson) {
                http_response_code(403);
                header('Content-Type: application/json');
                echo json_encode([
                    'error' => 'Forbidden',
                    'message' => $msg,
                    'redirect' => '/login'
                ]);
                exit;
            }

            AuthManager::setFlash('error', $msg);
            header('Location: /login');
            exit;
        }

        return true;
    }
}
