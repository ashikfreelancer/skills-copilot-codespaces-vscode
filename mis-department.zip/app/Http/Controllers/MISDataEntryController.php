<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class MISDataEntryController extends Controller
{
    /**
     * List all MIS forms.
     */
    public function forms(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('mis-data-entry', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $rows = DB::table('mis_forms')->orderBy('created_at', 'desc')->get();
        $formatted = $rows->map(function ($r) {
            return [
                'id' => $r->id,
                'name' => $r->name,
                'period' => $r->period,
                'type' => $r->type,
                'department' => $r->department,
                'branch' => $r->branch,
                'status' => $r->status,
                'indicators' => json_decode($r->indicators ?? '[]', true) ?: [],
            ];
        });

        return response()->json(['success' => true, 'data' => $formatted]);
    }

    /**
     * Store new MIS form.
     */
    public function storeForm(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('mis-data-entry', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $id = $request->input('id') ?: 'MIS-' . time() . '-' . rand(100, 999);
        $name = $request->input('name', 'Custom MIS Form');
        $period = $request->input('period', date('Y-m'));
        $type = $request->input('type', 'Monthly');
        $department = $request->input('department', 'MIS');
        $branch = $request->input('branch', 'All');
        $status = $request->input('status', 'Active');
        $indicators = json_encode($request->input('indicators', []));

        DB::table('mis_forms')->insert([
            'id' => $id,
            'name' => $name,
            'period' => $period,
            'type' => $type,
            'department' => $department,
            'branch' => $branch,
            'status' => $status,
            'indicators' => $indicators,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        AuditLog::record('mis-data-entry', 'CREATE', "Created MIS Form {$id} ({$name})", $user);

        return response()->json([
            'success' => true,
            'message' => 'MIS Form saved successfully.',
            'id' => $id
        ], 201);
    }

    /**
     * Delete MIS form.
     */
    public function destroyForm(string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('mis-data-entry', 'delete')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        DB::table('mis_forms')->where('id', $id)->delete();
        AuditLog::record('mis-data-entry', 'DELETE', "Deleted MIS Form {$id}", $user);

        return response()->json(['success' => true, 'message' => 'MIS Form deleted successfully.']);
    }

    /**
     * List monthly submissions.
     */
    public function submissions(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('mis-data-entry', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $rows = DB::table('monthly_mis_submissions')
            ->orderBy('year', 'desc')
            ->orderBy('month_num', 'desc')
            ->get();

        return response()->json(['success' => true, 'data' => $rows]);
    }
}
