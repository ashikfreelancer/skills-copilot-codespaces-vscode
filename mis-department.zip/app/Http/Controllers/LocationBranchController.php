<?php

namespace App\Http\Controllers;

use App\Models\AdministrativeLocation;
use App\Models\Branch;
use App\Models\AuditLog;
use App\Http\Requests\AdministrativeLocationRequest;
use App\Http\Requests\BranchRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;

class LocationBranchController extends Controller
{
    /**
     * Display a listing of branches with search, filter, sort, and pagination.
     */
    public function index(Request $request): JsonResponse
    {
        Gate::authorize('view', Branch::class);

        $query = Branch::query();

        // Filter by Division
        if ($request->filled('division')) {
            $query->where('division', $request->division);
        }

        // Filter by District
        if ($request->filled('district')) {
            $query->where('district', $request->district);
        }

        // Filter by Thana
        if ($request->filled('thana')) {
            $query->where('thana', $request->thana);
        }

        // Filter by Upazila
        if ($request->filled('upazila')) {
            $query->where('upazila', $request->upazila);
        }

        // Filter by Status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Search query across code, branch name, manager, address
        if ($request->filled('search')) {
            $search = '%' . strtolower($request->search) . '%';
            $query->where(function ($q) use ($search) {
                $q->whereRaw('LOWER(branch) LIKE ?', [$search])
                  ->orWhereRaw('LOWER(code) LIKE ?', [$search])
                  ->orWhereRaw('LOWER(manager) LIKE ?', [$search])
                  ->orWhereRaw('LOWER(address) LIKE ?', [$search]);
            });
        }

        // Sorting
        $sortBy = $request->get('sort_by', 'created_at');
        $sortOrder = $request->get('sort_order', 'desc');
        $allowedSorts = ['branch', 'code', 'division', 'district', 'upazila', 'status', 'created_at'];
        if (in_array($sortBy, $allowedSorts)) {
            $query->orderBy($sortBy, strtolower($sortOrder) === 'asc' ? 'asc' : 'desc');
        }

        // Pagination
        $perPage = (int) $request->get('per_page', 50);
        $branches = $query->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => $branches->items(),
            'pagination' => [
                'total' => $branches->total(),
                'per_page' => $branches->perPage(),
                'current_page' => $branches->currentPage(),
                'last_page' => $branches->lastPage(),
            ],
        ]);
    }

    /**
     * Store a newly created branch.
     */
    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', Branch::class);

        $id = $request->input('id') ?: ('LOC-' . time() . '-' . rand(100, 999));
        $data = array_merge($request->all(), ['id' => $id]);

        $branch = Branch::create($data);

        AuditLog::record(
            'location-branch',
            'CREATE',
            "Created branch: {$branch->branch} ({$branch->code})"
        );

        return response()->json([
            'success' => true,
            'message' => 'Branch created successfully.',
            'data' => $branch,
        ], 201);
    }

    /**
     * Display the specified branch.
     */
    public function show(string $id): JsonResponse
    {
        $this->authorize('view', Branch::class);

        $branch = Branch::findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $branch,
        ]);
    }

    /**
     * Update the specified branch.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $this->authorize('update', Branch::class);

        $branch = Branch::findOrFail($id);
        $branch->update($request->all());

        AuditLog::record(
            'location-branch',
            'UPDATE',
            "Updated branch: {$branch->branch} ({$branch->code})"
        );

        return response()->json([
            'success' => true,
            'message' => 'Branch updated successfully.',
            'data' => $branch,
        ]);
    }

    /**
     * Remove the specified branch.
     */
    public function destroy(string $id): JsonResponse
    {
        $this->authorize('delete', Branch::class);

        $branch = Branch::findOrFail($id);
        $name = $branch->branch;
        $code = $branch->code;

        $branch->delete();

        AuditLog::record(
            'location-branch',
            'DELETE',
            "Deleted branch: {$name} ({$code})"
        );

        return response()->json([
            'success' => true,
            'message' => 'Branch deleted successfully.',
        ]);
    }

    /**
     * Aliases for backward route compatibility
     */
    public function storeBranch(Request $request): JsonResponse
    {
        return $this->store($request);
    }

    public function updateBranch(Request $request, string $id): JsonResponse
    {
        return $this->update($request, $id);
    }

    public function destroyBranch(string $id): JsonResponse
    {
        return $this->destroy($id);
    }

    /**
     * Change approval status of branch.
     */
    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $this->authorize('approve', Branch::class);

        $status = $request->input('status', 'Active');
        if (!in_array($status, ['Active', 'Inactive', 'Review'])) {
            $status = 'Active';
        }

        $branch = Branch::findOrFail($id);
        $oldStatus = $branch->status;
        $branch->status = $status;
        $branch->save();

        AuditLog::record(
            'location-branch',
            'APPROVE',
            "Status changed for branch {$branch->branch} from {$oldStatus} to {$branch->status}"
        );

        return response()->json([
            'success' => true,
            'message' => "Branch status updated to {$branch->status}.",
            'data' => $branch,
        ]);
    }

    /**
     * Administrative locations list.
     */
    public function locations(): JsonResponse
    {
        $this->authorize('view', Branch::class);

        $locations = AdministrativeLocation::orderBy('type')->orderBy('name')->get();

        return response()->json([
            'success' => true,
            'data' => $locations,
        ]);
    }

    /**
     * Store administrative location.
     */
    public function storeLocation(Request $request): JsonResponse
    {
        $this->authorize('create', Branch::class);

        $type = $request->input('type', 'Division');
        $name = $request->input('name', '');
        $prefix = strtoupper(substr($type, 0, 3));
        $id = $request->input('id') ?: ($prefix . '-' . time() . '-' . rand(100, 999));
        $data = array_merge($request->all(), ['id' => $id, 'type' => $type, 'name' => $name]);

        $location = AdministrativeLocation::create($data);

        AuditLog::record(
            'location-branch',
            'CREATE',
            "Created administrative location: {$location->type} - {$location->name}"
        );

        return response()->json([
            'success' => true,
            'message' => 'Administrative location created successfully.',
            'data' => $location,
        ], 201);
    }

    /**
     * Update administrative location.
     */
    public function updateLocation(Request $request, string $id): JsonResponse
    {
        $this->authorize('update', Branch::class);

        $location = AdministrativeLocation::findOrFail($id);
        $location->update($request->all());

        AuditLog::record(
            'location-branch',
            'UPDATE',
            "Updated administrative location: {$location->type} - {$location->name}"
        );

        return response()->json([
            'success' => true,
            'message' => 'Administrative location updated successfully.',
            'data' => $location,
        ]);
    }

    /**
     * Delete administrative location with dependency check.
     */
    public function destroyLocation(string $id): JsonResponse
    {
        $this->authorize('delete', Branch::class);

        $location = AdministrativeLocation::findOrFail($id);

        // Child dependency check
        $hasChildren = AdministrativeLocation::where('division', $location->name)
            ->orWhere('district', $location->name)
            ->orWhere('thana', $location->name)
            ->exists();

        if ($hasChildren) {
            return response()->json([
                'error' => 'Cannot delete location: child administrative locations exist. Delete child locations first.',
            ], 422);
        }

        $hasBranches = Branch::where('division', $location->name)
            ->orWhere('district', $location->name)
            ->orWhere('upazila', $location->name)
            ->exists();

        if ($hasBranches) {
            return response()->json([
                'error' => 'Cannot delete location: active branches are assigned to this location.',
            ], 422);
        }

        $location->delete();

        AuditLog::record(
            'location-branch',
            'DELETE',
            "Deleted administrative location: {$location->type} - {$location->name}"
        );

        return response()->json([
            'success' => true,
            'message' => 'Administrative location deleted successfully.',
        ]);
    }

    /**
     * Log user actions.
     */
    public function logAction(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        $action = strtoupper($request->input('action', 'VIEW'));
        AuditLog::record('location-branch', $action, $request->input('reference', 'Location & Branch directory'), $user);

        return response()->json(['success' => true]);
    }
}
