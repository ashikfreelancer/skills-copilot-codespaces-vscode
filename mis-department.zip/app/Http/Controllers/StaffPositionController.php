<?php

namespace App\Http\Controllers;

use App\Models\StaffPosition;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class StaffPositionController extends Controller
{
    /**
     * List all staff positions with search, filter, pagination, and metadata.
     */
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('staff-position-list', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $query = StaffPosition::query();

        if ($search = $request->input('search')) {
            $s = '%' . strtolower($search) . '%';
            $query->where(function ($q) use ($s) {
                $q->whereRaw('LOWER(name) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(staff_id) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(designation) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(department) LIKE ?', [$s]);
            });
        }

        if ($dept = $request->input('department')) {
            $query->where('department', $dept);
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }
        if ($district = $request->input('district')) {
            $query->where('home_district', $district);
        }
        if ($designation = $request->input('designation')) {
            $query->where('designation', $designation);
        }

        $sortBy = $request->input('sort_by', 'serial');
        $sortOrder = $request->input('sort_order', 'asc');
        $allowedSorts = ['id', 'serial', 'name', 'staff_id', 'designation', 'department', 'status', 'join_date'];
        if (in_array($sortBy, $allowedSorts)) {
            $query->orderBy($sortBy, strtolower($sortOrder) === 'desc' ? 'desc' : 'asc');
        } else {
            $query->orderBy('serial', 'asc');
        }

        $perPage = (int) $request->input('per_page', 25);
        $total = $query->count();
        $page = (int) $request->input('page', 1);
        $items = $query->skip(($page - 1) * $perPage)->take($perPage)->get();

        $departments = StaffPosition::select('department')->distinct()->pluck('department')->filter()->values();
        $positions = StaffPosition::select('designation')->distinct()->pluck('designation')->filter()->values();
        $districts = StaffPosition::select('home_district')->distinct()->pluck('home_district')->filter()->values();

        return response()->json([
            'success' => true,
            'data' => $items,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'last_page' => ceil($total / max(1, $perPage))
            ],
            'meta' => [
                'departments' => $departments,
                'positions' => $positions,
                'districts' => $districts,
            ]
        ]);
    }

    /**
     * Get single staff position.
     */
    public function show(string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('staff-position-list', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $item = StaffPosition::where('id', $id)->orWhere('staff_id', $id)->first();
        if (!$item) {
            return response()->json(['error' => 'Not Found', 'message' => 'Staff member not found.'], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $item
        ]);
    }

    /**
     * Create staff position.
     */
    public function store(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('staff-position-list', 'create')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'No permission to create staff.'], 403);
        }

        $errors = [];
        if (!$request->filled('name')) $errors['name'] = ['Name is required.'];
        if (!$request->filled('staff_id')) $errors['staff_id'] = ['Staff ID is required.'];
        if (!$request->filled('designation')) $errors['designation'] = ['Designation is required.'];
        if (!$request->filled('department')) $errors['department'] = ['Department is required.'];

        if (!empty($errors)) {
            return response()->json(['success' => false, 'errors' => $errors], 422);
        }

        $staffId = trim($request->input('staff_id'));
        if (StaffPosition::where('staff_id', $staffId)->exists()) {
            return response()->json([
                'success' => false,
                'errors' => ['staff_id' => ["Staff ID '{$staffId}' already exists."]]
            ], 422);
        }

        $count = StaffPosition::count();
        $serial = str_pad($count + 1, 4, '0', STR_PAD_LEFT);
        $id = $request->input('id') ?: 'SP-' . time() . '-' . rand(100, 999);

        $item = StaffPosition::create([
            'id' => $id,
            'serial' => $serial,
            'name' => $request->input('name'),
            'gender' => $request->input('gender', 'Male'),
            'dob' => $request->input('dob', ''),
            'father' => $request->input('father', ''),
            'mother' => $request->input('mother', ''),
            'staff_id' => $staffId,
            'designation' => $request->input('designation'),
            'join_date' => $request->input('join_date', ''),
            'posting_date' => $request->input('posting_date', ''),
            'promotion_date' => $request->input('promotion_date', ''),
            'education' => $request->input('education', ''),
            'home_district' => $request->input('home_district', ''),
            'previous_posting' => $request->input('previous_posting', ''),
            'current_posting' => $request->input('current_posting', ''),
            'department' => $request->input('department'),
            'status' => $request->input('status', 'Active'),
        ]);

        AuditLog::record('staff-position-list', 'CREATE', "Created staff {$item->name} ({$item->staff_id})", $user);

        return response()->json([
            'success' => true,
            'message' => 'Staff position created successfully.',
            'data' => $item
        ], 201);
    }

    /**
     * Update staff position.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('staff-position-list', 'edit')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $item = StaffPosition::where('id', $id)->orWhere('staff_id', $id)->first();
        if (!$item) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $item->update($request->only([
            'name', 'gender', 'dob', 'father', 'mother', 'designation',
            'join_date', 'posting_date', 'promotion_date', 'education',
            'home_district', 'previous_posting', 'current_posting',
            'department', 'status'
        ]));

        AuditLog::record('staff-position-list', 'UPDATE', "Updated staff {$item->name} ({$item->staff_id})", $user);

        return response()->json([
            'success' => true,
            'message' => 'Staff position updated successfully.',
            'data' => $item
        ]);
    }

    /**
     * Update staff status.
     */
    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('staff-position-list', 'approve')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'No permission to update status.'], 403);
        }

        $item = StaffPosition::where('id', $id)->orWhere('staff_id', $id)->first();
        if (!$item) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $status = $request->input('status', 'Active');
        $item->status = $status;
        $item->save();

        AuditLog::record('staff-position-list', 'APPROVE', "Changed status of {$item->name} to {$status}", $user);

        return response()->json([
            'success' => true,
            'message' => 'Status updated.',
            'data' => $item
        ]);
    }

    /**
     * Delete staff position.
     */
    public function destroy(string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('staff-position-list', 'delete')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $item = StaffPosition::where('id', $id)->orWhere('staff_id', $id)->first();
        if (!$item) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $name = $item->name;
        $staffId = $item->staff_id;
        $item->delete();

        AuditLog::record('staff-position-list', 'DELETE', "Deleted staff {$name} ({$staffId})", $user);

        return response()->json([
            'success' => true,
            'message' => 'Staff position deleted successfully.'
        ]);
    }

    /**
     * Log user actions.
     */
    public function logAction(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        $action = strtoupper($request->input('action', 'VIEW'));
        AuditLog::record('staff-position-list', $action, $request->input('reference', 'Staff Position List'), $user);

        return response()->json(['success' => true]);
    }
}
