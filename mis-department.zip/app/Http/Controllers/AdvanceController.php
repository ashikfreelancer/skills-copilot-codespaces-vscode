<?php

namespace App\Http\Controllers;

use App\Models\Advance;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class AdvanceController extends Controller
{
    /**
     * List all advance records with filters and financial statistics.
     */
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('advance-management', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $query = Advance::query();

        if ($dept = $request->input('department')) {
            $query->where('department', $dept);
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }
        if ($approval = $request->input('approval')) {
            $query->where('approval', $approval);
        }
        if ($search = $request->input('search')) {
            $s = '%' . strtolower($search) . '%';
            $query->where(function ($q) use ($s) {
                $q->whereRaw('LOWER(employee) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(employee_id) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(purpose) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(department) LIKE ?', [$s]);
            });
        }

        $query->orderBy('request_date', 'desc');
        $rows = $query->get();

        $totalIssued = Advance::sum('amount');
        $totalAdjusted = Advance::sum('adjusted');
        $outstanding = max(0, $totalIssued - $totalAdjusted);
        $pendingCount = Advance::where('approval', 'Pending')->count();
        $approvedCount = Advance::where('approval', 'Approved')->count();

        return response()->json([
            'success' => true,
            'data' => $rows,
            'summary' => [
                'total_issued' => $totalIssued,
                'total_adjusted' => $totalAdjusted,
                'outstanding' => $outstanding,
                'pending_approval' => $pendingCount,
                'approved' => $approvedCount
            ]
        ]);
    }

    /**
     * Store new advance request.
     */
    public function store(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('advance-management', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $id = $request->input('id') ?: 'ADV-' . time() . '-' . rand(100, 999);
        $amount = (float) $request->input('amount', 0);
        $adjusted = (float) $request->input('adjusted', 0);
        $status = $adjusted >= $amount ? 'Settled' : ($adjusted > 0 ? 'Partial' : 'Open');

        $advance = Advance::create([
            'id' => $id,
            'employee' => $request->input('employee'),
            'employee_id' => $request->input('employee_id'),
            'department' => $request->input('department'),
            'designation' => $request->input('designation'),
            'purpose' => $request->input('purpose'),
            'request_date' => $request->input('request_date', date('Y-m-d')),
            'due_date' => $request->input('due_date', date('Y-m-d', strtotime('+30 days'))),
            'amount' => $amount,
            'adjusted' => $adjusted,
            'status' => $status,
            'approval' => $request->input('approval', 'Pending'),
            'notes' => $request->input('notes', ''),
        ]);

        AuditLog::record('advance-management', 'CREATE', "Created Advance {$id} for {$advance->employee} (৳ {$amount})", $user);

        return response()->json([
            'success' => true,
            'message' => 'Advance created successfully.',
            'data' => $advance
        ], 201);
    }

    /**
     * Update advance request.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('advance-management', 'edit')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $advance = Advance::where('id', $id)->first();
        if (!$advance) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $data = $request->only(['purpose', 'due_date', 'amount', 'adjusted', 'approval', 'notes', 'status']);
        $amount = isset($data['amount']) ? (float)$data['amount'] : $advance->amount;
        $adjusted = isset($data['adjusted']) ? (float)$data['adjusted'] : $advance->adjusted;
        $data['status'] = $adjusted >= $amount ? 'Settled' : ($adjusted > 0 ? 'Partial' : 'Open');

        $advance->update($data);

        AuditLog::record('advance-management', 'UPDATE', "Updated Advance {$id} for {$advance->employee}", $user);

        return response()->json([
            'success' => true,
            'message' => 'Advance updated successfully.',
            'data' => $advance
        ]);
    }

    /**
     * Delete advance.
     */
    public function destroy(string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('advance-management', 'delete')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $advance = Advance::where('id', $id)->first();
        if (!$advance) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $advance->delete();
        AuditLog::record('advance-management', 'DELETE', "Deleted Advance {$id}", $user);

        return response()->json(['success' => true, 'message' => 'Advance deleted successfully.']);
    }
}
