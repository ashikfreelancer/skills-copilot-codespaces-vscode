<?php

namespace App\Http\Controllers;

use App\Auth\AuthManager;
use App\Models\AuditLog;
use App\Models\User;
use App\Models\UserPermission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class UserPermissionController
{
    /**
     * List all users, roles, and current permissions
     */
    public function index(Request $request)
    {
        $currentUser = AuthManager::user();
        if (!$currentUser || (!$currentUser->isSuperAdmin() && !$currentUser->hasPermission('users-permissions', 'view'))) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $users = User::select([
            'id', 'user_code', 'name', 'email', 'role', 'department',
            'scope', 'status', 'permissions', 'created_at'
        ])->get();

        return response()->json([
            'success' => true,
            'users' => $users,
            'roles' => User::ROLES,
            'modules' => User::MODULES,
            'actions' => User::ACTIONS,
        ]);
    }

    /**
     * Create a new user with granular permissions
     */
    public function store(Request $request)
    {
        $currentUser = AuthManager::user();
        if (!$currentUser || (!$currentUser->isSuperAdmin() && !$currentUser->hasPermission('users-permissions', 'create'))) {
            AuditLog::record('users-permissions', 'UNAUTHORIZED_ATTEMPT', 'Denied create user', $currentUser);
            return response()->json(['error' => 'Unauthorized to create users'], 403);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:150',
            'email' => 'required|string|email|unique:users,email',
            'password' => 'required|string|min:6',
            'role' => 'required|string',
            'department' => 'nullable|string',
            'scope' => 'nullable|string',
            'status' => 'nullable|string|in:Active,Inactive,Suspended',
            'permissions' => 'nullable|array',
        ]);

        $user = User::create([
            'user_code' => 'U-' . strtoupper(substr(uniqid(), -5)),
            'name' => $validated['name'],
            'email' => strtolower(trim($validated['email'])),
            'password' => User::hashPassword($validated['password']),
            'role' => $validated['role'],
            'department' => $validated['department'] ?? 'MIS',
            'scope' => $validated['scope'] ?? 'All',
            'status' => $validated['status'] ?? 'Active',
            'permissions' => $validated['permissions'] ?? [],
        ]);

        AuditLog::record(
            'users-permissions',
            'CREATE',
            "Created user {$user->email} with role {$user->role}",
            $currentUser
        );

        return response()->json([
            'success' => true,
            'message' => 'User created successfully',
            'user' => $user,
        ], 201);
    }

    /**
     * Update user details and permissions
     */
    public function update(Request $request, $id)
    {
        $currentUser = AuthManager::user();
        if (!$currentUser || (!$currentUser->isSuperAdmin() && !$currentUser->hasPermission('users-permissions', 'edit') && !$currentUser->hasPermission('users-permissions', 'update'))) {
            AuditLog::record('users-permissions', 'UNAUTHORIZED_ATTEMPT', "Denied edit user #{$id}", $currentUser);
            return response()->json(['error' => 'Unauthorized to update users'], 403);
        }

        $user = User::findOrFail($id);

        $data = $request->all();
        if (!empty($data['name'])) $user->name = $data['name'];
        if (!empty($data['email'])) $user->email = strtolower(trim($data['email']));
        if (!empty($data['role'])) $user->role = $data['role'];
        if (isset($data['department'])) $user->department = $data['department'];
        if (isset($data['scope'])) $user->scope = $data['scope'];
        if (!empty($data['status'])) $user->status = $data['status'];
        if (!empty($data['password'])) $user->password = User::hashPassword($data['password']);
        if (isset($data['permissions'])) $user->permissions = $data['permissions'];

        $user->save();

        AuditLog::record(
            'users-permissions',
            'UPDATE',
            "Updated user {$user->email} (Role: {$user->role}, Status: {$user->status})",
            $currentUser
        );

        return response()->json([
            'success' => true,
            'message' => 'User updated successfully',
            'user' => $user,
        ]);
    }

    /**
     * Delete user
     */
    public function destroy($id)
    {
        $currentUser = AuthManager::user();
        if (!$currentUser || (!$currentUser->isSuperAdmin() && !$currentUser->hasPermission('users-permissions', 'delete'))) {
            AuditLog::record('users-permissions', 'UNAUTHORIZED_ATTEMPT', "Denied delete user #{$id}", $currentUser);
            return response()->json(['error' => 'Unauthorized to delete users'], 403);
        }

        $user = User::findOrFail($id);

        // Protect last Super Admin
        if ($user->isSuperAdmin()) {
            $superAdminCount = User::whereIn('role', [User::ROLE_SUPER_ADMIN, 'MIS Super Admin'])->count();
            if ($superAdminCount <= 1) {
                return response()->json([
                    'error' => 'Forbidden',
                    'message' => 'At least one Super Admin must remain in the system.'
                ], 422);
            }
        }

        $email = $user->email;
        $user->delete();

        AuditLog::record(
            'users-permissions',
            'DELETE',
            "Deleted user {$email}",
            $currentUser
        );

        return response()->json([
            'success' => true,
            'message' => 'User deleted successfully',
        ]);
    }
}
