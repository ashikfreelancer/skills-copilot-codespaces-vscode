<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Models\AuditLog;
use App\Auth\AuthManager;

class ReportController extends Controller
{
    /**
     * Display a listing of report definitions.
     */
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('reports', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        // Return catalog of supported reports
        $reports = [
            [
                'id' => 'REP-001',
                'title' => 'Monthly MIS Summary',
                'category' => 'monthly-mis',
                'period' => 'Sep 2026',
                'scope' => 'All Branches',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-002',
                'title' => 'Staff Position Report',
                'category' => 'staff-position',
                'period' => 'Sep 2026',
                'scope' => 'All Departments',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-003',
                'title' => 'Branch Summary Report',
                'category' => 'branch-summary',
                'period' => 'Sep 2026',
                'scope' => 'All Branches',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-004',
                'title' => 'Domain & Zone Head Information Report',
                'category' => 'domain-zone',
                'period' => 'Sep 2026',
                'scope' => 'All Domains & Zones',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-005',
                'title' => 'Movement Register Report',
                'category' => 'movement-register',
                'period' => 'Sep 2026',
                'scope' => 'All Field Staff',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-006',
                'title' => 'Stock Inventory & Movement Report',
                'category' => 'stock-register',
                'period' => 'Sep 2026',
                'scope' => 'All Store Locations',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-007',
                'title' => 'Department Management Report',
                'category' => 'department',
                'period' => 'Sep 2026',
                'scope' => 'All Departments',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ],
            [
                'id' => 'REP-008',
                'title' => 'System Audit & Activity Report',
                'category' => 'audit-log',
                'period' => 'Sep 2026',
                'scope' => 'System Wide',
                'status' => 'Ready',
                'report_type' => 'Monthly'
            ]
        ];

        return response()->json([
            'success' => true,
            'data' => $reports,
            'total' => count($reports)
        ]);
    }

    /**
     * Return distinct filter options for reports UI.
     */
    public function filterOptions(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'departments' => ['MIS', 'Accounts', 'HR', 'Audit', 'Operation', 'ICT'],
            'divisions' => ['Dhaka', 'Chattogram', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh'],
            'districts' => ['Dhaka', 'Gazipur', 'Narayanganj', 'Chattogram', 'Bogura', 'Rajshahi'],
            'domains' => ['Domain-1 (Dhaka North)', 'Domain-2 (Dhaka South)', 'Domain-3 (Chattogram)', 'Domain-4 (Rajshahi)'],
            'zones' => ['Zone-A (Mirpur)', 'Zone-B (Uttara)', 'Zone-C (Gulshan)', 'Zone-D (Agrabad)'],
            'stock_categories' => ['Stationery', 'IT Equipment', 'Furniture', 'Electrical'],
            'movement_types' => ['Official', 'Field Visit', 'Personal'],
            'domain_head_types' => ['Domain Head', 'Zone Head']
        ]);
    }

    /**
     * Log report action (print / export).
     */
    public function logAction(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        $action = strtoupper($request->input('action', 'ACTION'));
        $reference = $request->input('reference', 'Reports Action');

        if ($user) {
            AuditLog::record('reports', $action, $reference, $user);
        }

        return response()->json(['success' => true, 'message' => 'Action recorded']);
    }
}
