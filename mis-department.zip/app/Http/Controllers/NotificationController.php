<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class NotificationController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('notifications', 'view')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'Permission denied.'], 403);
        }

        $rows = Notification::orderBy('created_at', 'desc')->limit(100)->get();
        $unreadCount = Notification::where('status', 'Unread')->count();

        return response()->json([
            'success' => true,
            'data' => $rows,
            'unread_count' => $unreadCount,
            'total' => $rows->count(),
        ]);
    }

    public function markRead(Request $request, string $id): JsonResponse
    {
        $user = AuthManager::user();
        $notif = Notification::find($id);
        if ($notif) {
            $notif->status = 'Read';
            $notif->save();
        }

        return response()->json(['success' => true]);
    }

    public function markAllRead(Request $request): JsonResponse
    {
        Notification::where('status', 'Unread')->update(['status' => 'Read']);
        return response()->json(['success' => true]);
    }
}
