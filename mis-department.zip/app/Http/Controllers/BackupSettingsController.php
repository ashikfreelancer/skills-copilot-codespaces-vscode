<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class BackupSettingsController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('backup-settings', 'view')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'Permission denied.'], 403);
        }

        $settings = DB::table('system_settings')->get();
        $settingsMap = [];
        foreach ($settings as $s) {
            $settingsMap[$s->key] = $s->value;
        }

        $dbSize = 0;
        $dbPath = database_path('database.sqlite');
        if (file_exists($dbPath)) {
            $dbSize = filesize($dbPath);
        }

        return response()->json([
            'success' => true,
            'settings' => $settingsMap,
            'meta' => [
                'database_type' => config('database.default', 'sqlite'),
                'database_size_bytes' => $dbSize,
                'database_size_formatted' => $dbSize > 0 ? round($dbSize / (1024 * 1024), 2) . ' MB' : 'N/A (MySQL)',
                'last_backup' => $settingsMap['last_backup_time'] ?? '2026-09-20 02:00:00',
                'auto_backup_status' => $settingsMap['auto_backup_enabled'] ?? 'Active'
            ]
        ]);
    }

    public function triggerBackup(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('backup-settings', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $now = date('Y-m-d H:i:s');
        DB::table('system_settings')->updateOrInsert(
            ['key' => 'last_backup_time'],
            ['value' => $now, 'updated_at' => $now]
        );

        AuditLog::record('backup-settings', 'CREATE', "Triggered manual database backup snapshot", $user);
        return response()->json(['success' => true, 'message' => 'Backup created successfully at ' . $now]);
    }

    public function getBranding(): JsonResponse
    {
        $rows = DB::table('system_settings')
            ->whereIn('key', ['login_title', 'login_subtitle', 'login_hero_image', 'login_logo', 'brand_color', 'app_name'])
            ->get();

        $branding = [
            'login_title' => 'Welcome to Management Information System',
            'login_subtitle' => 'Manage your management information system efficiently and effectively.',
            'login_hero_image' => '/assets/images/login-hero.jpg',
            'login_logo' => '/assets/images/tmss-logo.png',
            'brand_color' => '#2ecc71',
            'app_name' => 'Management Information System'
        ];

        foreach ($rows as $r) {
            $branding[$r->key] = $r->value;
        }

        return response()->json(['success' => true, 'branding' => $branding]);
    }

    public function updateBranding(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if (!$user || (!$user->isSuperAdmin() && $user->role !== 'admin')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'Only Super Administrators can update branding.'], 403);
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $items = [
            'login_title' => $input['login_title'] ?? 'Welcome to Management Information System',
            'login_subtitle' => $input['login_subtitle'] ?? 'Manage your management information system efficiently and effectively.',
            'login_hero_image' => $input['login_hero_image'] ?? '/assets/images/login-hero.jpg',
            'login_logo' => $input['login_logo'] ?? '/assets/images/tmss-logo.png',
            'brand_color' => $input['brand_color'] ?? '#2ecc71',
            'app_name' => $input['app_name'] ?? 'Management Information System',
        ];

        $now = date('Y-m-d H:i:s');
        foreach ($items as $k => $v) {
            DB::table('system_settings')->updateOrInsert(
                ['key' => $k],
                ['value' => (string) $v, 'updated_at' => $now]
            );
        }

        AuditLog::record('backup-settings', 'BRANDING_UPDATE', 'Updated login page branding, title, logo and hero image', $user);
        return response()->json(['success' => true, 'message' => 'Branding settings updated successfully.', 'branding' => $items]);
    }

    public function uploadBrandingAsset(): JsonResponse
    {
        $user = AuthManager::user();
        if (!$user || (!$user->isSuperAdmin() && $user->role !== 'admin')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $file = $_FILES['asset_file'] ?? null;
        if (!$file || empty($file['tmp_name'])) {
            return response()->json(['error' => 'No image uploaded.'], 422);
        }

        $orig = basename($file['name']);
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (!in_array($ext, ['png', 'jpg', 'jpeg', 'svg', 'webp'])) {
            return response()->json(['error' => 'Only PNG, JPG, JPEG, SVG and WebP images are allowed.'], 422);
        }

        $type = $_POST['type'] ?? 'asset';
        $prefix = $type === 'logo' ? 'custom-logo' : 'custom-hero';
        $filename = "{$prefix}-" . time() . '.' . $ext;

        $destDir = public_path('assets/images');
        if (!is_dir($destDir)) mkdir($destDir, 0777, true);
        move_uploaded_file($file['tmp_name'], "{$destDir}/{$filename}");

        // Also copy to MIS_Department_HTML_Frontend
        $feDir = base_path('MIS_Department_HTML_Frontend/assets/images');
        if (is_dir($feDir)) {
            @copy("{$destDir}/{$filename}", "{$feDir}/{$filename}");
        }

        AuditLog::record('backup-settings', 'ASSET_UPLOAD', "Uploaded branding image: {$filename}", $user);
        return response()->json([
            'success' => true,
            'message' => 'Image uploaded successfully.',
            'url' => "/assets/images/{$filename}",
            'filename' => $filename
        ]);
    }
}
