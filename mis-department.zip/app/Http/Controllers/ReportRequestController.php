<?php

namespace App\Http\Controllers;

use App\Models\ReportRequest;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ReportRequestController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('report-requests', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $rows = ReportRequest::orderBy('created_at', 'desc')->get();
        return response()->json(['success' => true, 'data' => $rows]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('report-requests', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $id = $request->input('id') ?: 'REQ-' . time() . '-' . rand(100, 999);
        $record = ReportRequest::create([
            'id' => $id,
            'requester' => $request->input('requester', $user ? $user->name : 'Staff'),
            'department' => $request->input('department', $user ? $user->department : 'MIS'),
            'report' => $request->input('report', ''),
            'request_date' => $request->input('request_date', date('Y-m-d')),
            'deadline' => $request->input('deadline', date('Y-m-d', strtotime('+7 days'))),
            'priority' => $request->input('priority', 'Normal'),
            'assigned' => $request->input('assigned', ''),
            'status' => 'Pending',
            'remarks' => $request->input('remarks', ''),
        ]);

        AuditLog::record('report-requests', 'CREATE', "Requested report: {$record->report}", $user);
        return response()->json(['success' => true, 'data' => $record], 201);
    }
}
