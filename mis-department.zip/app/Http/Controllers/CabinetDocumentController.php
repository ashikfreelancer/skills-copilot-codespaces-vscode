<?php

namespace App\Http\Controllers;

use App\Models\CabinetDocument;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class CabinetDocumentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('note-document-cabinet', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $rows = CabinetDocument::orderBy('created_at', 'desc')->get();
        $formatted = $rows->map(function ($r) {
            return [
                'id' => $r->id,
                'title' => $r->title,
                'category' => $r->category,
                'docType' => $r->doc_type,
                'memo' => $r->memo_no,
                'date' => $r->doc_date,
                'department' => $r->department,
                'version' => $r->version,
                'description' => $r->description,
                'remarks' => $r->remarks,
                'attachments' => json_decode($r->attachments ?: '[]', true),
                'history' => json_decode($r->history ?: '[]', true),
            ];
        });

        return response()->json(['success' => true, 'data' => $formatted]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('note-document-cabinet', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $id = $request->input('id') ?: 'DOC-' . time() . '-' . rand(100, 999);
        $doc = CabinetDocument::create([
            'id' => $id,
            'title' => $request->input('title', 'Untitled Document'),
            'category' => $request->input('category', 'General'),
            'doc_type' => $request->input('docType', 'document'),
            'memo_no' => $request->input('memo', ''),
            'doc_date' => $request->input('date', date('Y-m-d')),
            'department' => $request->input('department', 'MIS'),
            'version' => $request->input('version', '1.0'),
            'description' => $request->input('description', ''),
            'remarks' => $request->input('remarks', ''),
            'attachments' => json_encode($request->input('attachments', [])),
            'history' => json_encode([[
                'action' => 'Created',
                'user' => $user ? $user->name : 'Staff',
                'date' => date('Y-m-d H:i')
            ]]),
        ]);

        AuditLog::record('note-document-cabinet', 'CREATE', "Uploaded Document {$id}: {$doc->title}", $user);
        return response()->json(['success' => true, 'data' => $doc], 201);
    }

    public function upload(): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('note-document-cabinet', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $uploadsDir = function_exists('storage_path') ? storage_path('app/uploads') : (dirname(__DIR__, 3) . '/storage/app/uploads');
        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0777, true);
        }

        $files = $_FILES['files'] ?? null;
        if (!$files || empty($files['name'])) {
            return response()->json(['error' => 'No files uploaded or file validation failed.'], 422);
        }

        $names = is_array($files['name']) ? $files['name'] : [$files['name']];
        $tmps = is_array($files['tmp_name']) ? $files['tmp_name'] : [$files['tmp_name']];
        $sizes = is_array($files['size']) ? $files['size'] : [$files['size']];
        $types = is_array($files['type']) ? $files['type'] : [$files['type']];

        $uploadedFiles = [];
        for ($i = 0; $i < count($names); $i++) {
            if (empty($tmps[$i]) || !is_uploaded_file($tmps[$i])) {
                continue;
            }

            $origName = basename($names[$i]);
            $ext = pathinfo($origName, PATHINFO_EXTENSION);
            $cleanBase = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', pathinfo($origName, PATHINFO_FILENAME));
            $safeName = $cleanBase . '-' . time() . '-' . bin2hex(random_bytes(4)) . ($ext ? '.' . $ext : '');
            $dest = $uploadsDir . '/' . $safeName;

            if (move_uploaded_file($tmps[$i], $dest)) {
                $uploadedFiles[] = [
                    'id' => 'DOC-' . time() . '-' . bin2hex(random_bytes(4)),
                    'name' => $origName,
                    'server_filename' => $safeName,
                    'size' => (int) $sizes[$i],
                    'type' => $types[$i] ?: 'application/octet-stream',
                    'uploaded_at' => date('c'),
                ];
            }
        }

        AuditLog::record('note-document-cabinet', 'FILE_UPLOAD', 'Uploaded ' . count($uploadedFiles) . ' file(s)', $user);

        return response()->json([
            'success' => true,
            'message' => 'Successfully validated and uploaded ' . count($uploadedFiles) . ' file(s).',
            'files' => $uploadedFiles,
        ]);
    }

    public function download(string $filename)
    {
        $safeFilename = basename($filename);
        $uploadsDir = function_exists('storage_path') ? storage_path('app/uploads') : (dirname(__DIR__, 3) . '/storage/app/uploads');
        $filePath = $uploadsDir . '/' . $safeFilename;

        if (!file_exists($filePath) || is_dir($filePath)) {
            http_response_code(404);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'File not found.']);
            exit;
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $filePath) ?: 'application/octet-stream';
        finfo_close($finfo);

        header('Content-Description: File Transfer');
        header('Content-Type: ' . $mimeType);
        header('Content-Disposition: attachment; filename="' . $safeFilename . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }
}
