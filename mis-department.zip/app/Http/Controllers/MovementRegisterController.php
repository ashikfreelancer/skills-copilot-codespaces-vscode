<?php

namespace App\Http\Controllers;

use App\Models\MovementRegister;
use App\Models\AuditLog;
use App\Http\Requests\MovementRegisterRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class MovementRegisterController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', MovementRegister::class);

        $query = MovementRegister::query();

        if ($search = $request->input('search')) {
            $query->search($search);
        }

        $filters = $request->only(['status', 'type', 'department', 'domain', 'zone', 'location', 'employee_id', 'from', 'to']);
        $query->filter($filters);

        $sortBy = $request->input('sort_by', 'date');
        $sortOrder = strtolower($request->input('sort_order', 'desc')) === 'asc' ? 'asc' : 'desc';
        $query->orderBy($sortBy, $sortOrder);

        $total = MovementRegister::count();
        $out = MovementRegister::where('status', 'Out')->count();
        $returned = MovementRegister::where('status', 'Returned')->count();
        $lateReturn = MovementRegister::where('status', 'Late Return')->count();
        $today = MovementRegister::where('date', date('Y-m-d'))->count();

        $results = $query->get();

        return response()->json([
            'success' => true,
            'data' => $results,
            'total' => $results->count(),
            'meta' => [
                'total' => $total,
                'out' => $out,
                'returned' => $returned,
                'late_return' => $lateReturn,
                'today' => $today,
            ]
        ]);
    }

    public function show(string $id): JsonResponse
    {
        $movement = MovementRegister::findOrFail($id);
        $this->authorize('view', $movement);

        AuditLog::record('movement-register', 'VIEW', "Viewed Movement: {$movement->id} ({$movement->employee_name})");

        return response()->json([
            'success' => true,
            'data' => $movement
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', MovementRegister::class);

        $data = $request->all();
        if (empty($data['id'])) {
            $data['id'] = 'MR-' . str_pad((string)(MovementRegister::count() + 1), 4, '0', STR_PAD_LEFT);
        }

        $movement = MovementRegister::create($data);
        AuditLog::record('movement-register', 'CREATE', "Created Movement: {$movement->id} ({$movement->employee_name})");

        return response()->json([
            'success' => true,
            'message' => 'Movement entry created successfully.',
            'data' => $movement
        ], 201);
    }

    public function update(Request $request, string $id): JsonResponse
    {
        $movement = MovementRegister::findOrFail($id);
        $this->authorize('update', $movement);

        $data = $request->all();
        $movement->update($data);

        AuditLog::record('movement-register', 'UPDATE', "Updated Movement: {$movement->id} ({$movement->employee_name})");

        return response()->json([
            'success' => true,
            'message' => 'Movement entry updated successfully.',
            'data' => $movement
        ]);
    }

    public function destroy(string $id): JsonResponse
    {
        $movement = MovementRegister::findOrFail($id);
        $this->authorize('delete', $movement);

        $name = $movement->employee_name;
        $movement->delete();

        AuditLog::record('movement-register', 'DELETE', "Deleted Movement: {$id} ({$name})");

        return response()->json([
            'success' => true,
            'message' => 'Movement entry deleted successfully.'
        ]);
    }

    public function markReturn(Request $request, string $id): JsonResponse
    {
        $movement = MovementRegister::findOrFail($id);
        $this->authorize('update', $movement);

        $actualReturn = $request->input('actual_return', date('H:i'));
        $status = 'Returned';
        if (!empty($movement->expected_return) && $actualReturn > $movement->expected_return) {
            $status = 'Late Return';
        }

        $movement->update([
            'actual_return' => $actualReturn,
            'status' => $status
        ]);

        AuditLog::record('movement-register', 'RETURN', "Marked Return for: {$movement->id} ({$movement->employee_name}) at {$actualReturn}");

        return response()->json([
            'success' => true,
            'message' => "Movement marked as {$status}.",
            'data' => $movement
        ]);
    }

    public function approve(Request $request, string $id): JsonResponse
    {
        $movement = MovementRegister::findOrFail($id);
        $this->authorize('approve', MovementRegister::class);

        $approver = $request->input('approved_by', auth()->user()?->name ?? 'Admin');
        $movement->update([
            'approved_by' => $approver,
        ]);

        AuditLog::record('movement-register', 'APPROVE', "Approved Movement: {$movement->id} by {$approver}");

        return response()->json([
            'success' => true,
            'message' => 'Movement approved.',
            'data' => $movement
        ]);
    }

    public function logAction(Request $request): JsonResponse
    {
        $action = $request->input('action', 'ACTION');
        $reference = $request->input('reference', 'Movement Register Action');

        if ($action === 'print') {
            $this->authorize('print', MovementRegister::class);
        } elseif ($action === 'export') {
            $this->authorize('export', MovementRegister::class);
        }

        AuditLog::record('movement-register', strtoupper($action), $reference);

        return response()->json([
            'success' => true,
            'message' => 'Action logged successfully.'
        ]);
    }
}
