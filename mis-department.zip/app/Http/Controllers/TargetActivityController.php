<?php

namespace App\Http\Controllers;

use App\Models\TargetActivity;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class TargetActivityController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('target-activity', 'view')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'Permission denied.'], 403);
        }

        $rows = TargetActivity::orderBy('created_at', 'desc')->get();
        return response()->json(['success' => true, 'data' => $rows]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('target-activity', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $id = $request->input('id') ?: 'TGT-' . time() . '-' . rand(100, 999);
        $record = TargetActivity::create([
            'id' => $id,
            'period' => $request->input('period', 'Q3 2026'),
            'area' => $request->input('area', ''),
            'indicator' => $request->input('indicator', ''),
            'target' => (float)$request->input('target', 0),
            'achieved' => (float)$request->input('achieved', 0),
            'description' => $request->input('description', ''),
        ]);

        AuditLog::record('target-activity', 'CREATE', "Added target for {$record->indicator}", $user);
        return response()->json(['success' => true, 'data' => $record], 201);
    }
}
