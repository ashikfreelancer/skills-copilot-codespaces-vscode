<?php

namespace App\Http\Controllers;

use App\Auth\AuthManager;
use App\Http\Middleware\Authenticate;
use App\Http\Middleware\CheckUserStatus;

class PageController
{
    private static array $moduleViews = [
        'dashboard' => 'dashboard.index',
        'location-branch' => 'location-branch.index',
        'domain-zone-management' => 'domain-zone-management.index',
        'domain-zone' => 'domain-zone-management.index',
        'department-management' => 'department-management.index',
        'department' => 'department-management.index',
        'staff-position-list' => 'staff-position-list.index',
        'staff' => 'staff-position-list.index',
        'leave-management' => 'leave-management.index',
        'leave' => 'leave-management.index',
        'mis-data-entry' => 'mis-data-entry.index',
        'mis-entry' => 'mis-data-entry.index',
        'reports' => 'reports.index',
        'data-quality' => 'data-quality.index',
        'analytics' => 'analytics.index',
        'note-document-cabinet' => 'note-document-cabinet.index',
        'documents' => 'note-document-cabinet.index',
        'advance-management' => 'advance-management.index',
        'advances' => 'advance-management.index',
        'target-activity' => 'target-activity.index',
        'targets' => 'target-activity.index',
        'monitoring' => 'monitoring.index',
        'report-requests' => 'report-requests.index',
        'excel-import-export' => 'excel-import-export.index',
        'excel' => 'excel-import-export.index',
        'movement-register' => 'movement-register.index',
        'movement' => 'movement-register.index',
        'stock-register' => 'stock-register.index',
        'stock' => 'stock-register.index',
        'notifications' => 'notifications.index',
        'users-permissions' => 'users-permissions.index',
        'users' => 'users-permissions.index',
        'audit-log' => 'audit-log.index',
        'audit' => 'audit-log.index',
        'backup-settings' => 'backup-settings.index',
        'settings' => 'backup-settings.index',
    ];

    public function show(string $slug)
    {
        // 1. Authenticate Middleware
        Authenticate::handle();

        // 2. Check User Status Middleware
        CheckUserStatus::handle();

        $slug = trim($slug, '/');
        $viewName = self::$moduleViews[$slug] ?? null;

        if (!$viewName) {
            http_response_code(404);
            echo "404 Page Not Found";
            exit;
        }

        $user = AuthManager::user();
        $csrfToken = AuthManager::csrfToken();

        return view($viewName, [
            'authUser' => $user,
            'csrf_token' => $csrfToken,
        ]);
    }
}
