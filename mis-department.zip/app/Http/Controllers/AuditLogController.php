<?php

namespace App\Http\Controllers;

use App\Auth\AuthManager;
use App\Models\AuditLog;
use Illuminate\Http\Request;

class AuditLogController
{
    /**
     * Display a listing of the audit logs
     */
    public function index(Request $request)
    {
        $currentUser = AuthManager::user();
        if (!$currentUser || (!$currentUser->isSuperAdmin() && !$currentUser->hasPermission('audit-log', 'view'))) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $query = AuditLog::orderBy('created_at', 'desc');

        if ($request->has('module')) {
            $query->where('module', $request->input('module'));
        }

        if ($request->has('action')) {
            $query->where('action', strtoupper($request->input('action')));
        }

        if ($request->has('search')) {
            $s = $request->input('search');
            $query->where(function ($q) use ($s) {
                $q->where('username', 'like', "%{$s}%")
                  ->orWhere('module', 'like', "%{$s}%")
                  ->orWhere('action', 'like', "%{$s}%")
                  ->orWhere('reference', 'like', "%{$s}%");
            });
        }

        $logs = $query->limit(200)->get();

        return response()->json([
            'success' => true,
            'logs' => $logs,
        ]);
    }

    /**
     * Record an action directly from an authorized client request
     */
    public function store(Request $request)
    {
        $currentUser = AuthManager::user();
        $validated = $request->validate([
            'module' => 'required|string',
            'action' => 'required|string',
            'reference' => 'nullable|string',
        ]);

        $log = AuditLog::record(
            $validated['module'],
            $validated['action'],
            $validated['reference'] ?? null,
            $currentUser,
            $request->ip(),
            $request->userAgent()
        );

        return response()->json([
            'success' => true,
            'log' => $log,
        ], 201);
    }
}
