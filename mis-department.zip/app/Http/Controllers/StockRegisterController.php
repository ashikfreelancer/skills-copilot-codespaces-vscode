<?php

namespace App\Http\Controllers;

use App\Models\StockItem;
use App\Models\StockTransaction;
use App\Models\AuditLog;
use App\Http\Requests\StockItemRequest;
use App\Http\Requests\StockTransactionRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class StockRegisterController extends Controller
{
    /**
     * Get stock items list with calculated balances, received, issued, and warning status.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', StockItem::class);

        $query = StockItem::query();

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('code', 'like', "%{$search}%")
                  ->orWhere('name', 'like', "%{$search}%")
                  ->orWhere('category', 'like', "%{$search}%")
                  ->orWhere('location', 'like', "%{$search}%");
            });
        }

        if ($cat = $request->input('category')) {
            $query->where('category', $cat);
        }

        if ($loc = $request->input('location')) {
            $query->where('location', $loc);
        }

        $items = $query->orderBy('code', 'asc')->get();

        $rows = [];
        $totalItems = $items->count();
        $totalQty = 0;
        $lowCount = 0;
        $outCount = 0;

        foreach ($items as $item) {
            $calc = $item->calculateStock();
            $balance = $calc['balance'];

            // Status filter
            $statusFilter = $request->input('status');
            if ($statusFilter) {
                if ($statusFilter === 'Available' && $balance <= 0) continue;
                if ($statusFilter === 'Low' && ($balance > $item->min || $balance <= 0)) continue;
                if ($statusFilter === 'Out' && $balance > 0) continue;
            }

            if ($balance <= 0) {
                $outCount++;
            } elseif ($balance <= $item->min) {
                $lowCount++;
            }
            $totalQty += $balance;

            $rows[] = [
                'id' => $item->id,
                'code' => $item->code,
                'name' => $item->name,
                'category' => $item->category,
                'unit' => $item->unit,
                'opening' => $item->opening,
                'min' => $item->min,
                'location' => $item->location,
                'supplier' => $item->supplier,
                'status' => $item->status,
                'received' => $calc['received'],
                'issued' => $calc['issued'],
                'balance' => $balance,
                'warning' => $calc['statusBadge'],
            ];
        }

        $allTxs = StockTransaction::all();
        $totalReceived = 0;
        $totalIssued = 0;
        foreach ($allTxs as $t) {
            if (in_array($t->type, ['Receive', 'Return', 'Transfer In'])) $totalReceived += (float)$t->qty;
            if (in_array($t->type, ['Issue', 'Transfer Out'])) $totalIssued += (float)$t->qty;
        }

        return response()->json([
            'success' => true,
            'data' => $rows,
            'meta' => [
                'total_items' => $totalItems,
                'total_qty' => $totalQty,
                'low_stock' => $lowCount,
                'out_of_stock' => $outCount,
                'total_received' => $totalReceived,
                'total_issued' => $totalIssued,
            ]
        ]);
    }

    /**
     * Ledger / Transaction history
     */
    public function transactions(Request $request): JsonResponse
    {
        $this->authorize('viewAny', StockItem::class);

        $query = StockTransaction::with('item');

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('reference', 'like', "%{$search}%")
                  ->orWhere('party', 'like', "%{$search}%")
                  ->orWhere('purpose', 'like', "%{$search}%")
                  ->orWhere('location', 'like', "%{$search}%")
                  ->orWhere('type', 'like', "%{$search}%");
            });
        }

        if ($from = $request->input('from')) {
            $query->where('date', '>=', $from);
        }
        if ($to = $request->input('to')) {
            $query->where('date', '<=', $to);
        }

        $txs = $query->orderBy('date', 'desc')->orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'data' => $txs
        ]);
    }

    /**
     * Store Item Master
     */
    public function storeItem(Request $request): JsonResponse
    {
        $this->authorize('create', StockItem::class);

        $data = $request->all();
        if (empty($data['id'])) {
            $data['id'] = 'IT-' . str_pad((string)(StockItem::count() + 1), 3, '0', STR_PAD_LEFT);
        }

        $item = StockItem::create($data);
        AuditLog::record('stock-register', 'CREATE', "Created Stock Item: {$item->code} - {$item->name}");

        return response()->json([
            'success' => true,
            'message' => 'Stock item master created successfully.',
            'data' => $item
        ], 201);
    }

    /**
     * View Single Item Master
     */
    public function showItem(string $id): JsonResponse
    {
        $item = StockItem::findOrFail($id);
        $this->authorize('view', $item);

        $calc = $item->calculateStock();

        AuditLog::record('stock-register', 'VIEW', "Viewed Stock Item: {$item->code}");

        return response()->json([
            'success' => true,
            'data' => array_merge($item->toArray(), $calc)
        ]);
    }

    /**
     * Update Item Master
     */
    public function updateItem(Request $request, string $id): JsonResponse
    {
        $item = StockItem::findOrFail($id);
        $this->authorize('update', $item);

        $data = $request->all();
        $item->update($data);

        AuditLog::record('stock-register', 'UPDATE', "Updated Stock Item: {$item->code} - {$item->name}");

        return response()->json([
            'success' => true,
            'message' => 'Stock item master updated successfully.',
            'data' => $item
        ]);
    }

    /**
     * Delete Item Master
     */
    public function destroyItem(string $id): JsonResponse
    {
        $item = StockItem::findOrFail($id);
        $this->authorize('delete', $item);

        // Check if item has transactions
        if ($item->transactions()->count() > 0) {
            return response()->json([
                'error' => 'Cannot delete stock item because transactions exist for this item.'
            ], 422);
        }

        $code = $item->code;
        $name = $item->name;
        $item->delete();

        AuditLog::record('stock-register', 'DELETE', "Deleted Stock Item: {$code} ({$name})");

        return response()->json([
            'success' => true,
            'message' => 'Stock item deleted successfully.'
        ]);
    }

    /**
     * Store Transaction with Database Transaction and Stock Prevention
     */
    public function storeTransaction(Request $request): JsonResponse
    {
        $this->authorize('transaction', StockItem::class);

        return DB::transaction(function () use ($request) {
            $data = $request->all();
            $item = StockItem::findOrFail($data['item_id']);

            $type = $data['type'];
            $qty = (float)$data['qty'];

            // Prevent invalid stock operations: check current balance for outgoing operations
            if (in_array($type, ['Issue', 'Transfer Out'])) {
                $currentStock = $item->calculateStock($data['location'] ?? null);
                if ($qty > $currentStock['balance']) {
                    return response()->json([
                        'error' => 'Insufficient stock.',
                        'message' => "Available stock is {$currentStock['balance']}, cannot issue or transfer {$qty} units."
                    ], 422);
                }
            }

            if (empty($data['id'])) {
                $data['id'] = 'TX-' . date('Ymd') . '-' . str_pad((string)(StockTransaction::count() + 1), 4, '0', STR_PAD_LEFT);
            }

            $tx = StockTransaction::create($data);
            AuditLog::record('stock-register', 'CREATE', "Stock Transaction {$tx->type}: {$item->code} Qty: {$tx->qty} Ref: {$tx->reference}");

            return response()->json([
                'success' => true,
                'message' => 'Stock transaction saved successfully.',
                'data' => $tx
            ], 201);
        });
    }

    /**
     * Delete Transaction with Database Transaction
     */
    public function destroyTransaction(string $id): JsonResponse
    {
        $this->authorize('delete', StockItem::class);

        return DB::transaction(function () use ($id) {
            $tx = StockTransaction::findOrFail($id);
            $ref = "{$tx->id} ({$tx->type} - {$tx->qty})";
            $tx->delete();

            AuditLog::record('stock-register', 'DELETE', "Deleted Stock Transaction: {$ref}");

            return response()->json([
                'success' => true,
                'message' => 'Stock transaction deleted successfully.'
            ]);
        });
    }

    /**
     * Action logger
     */
    public function logAction(Request $request): JsonResponse
    {
        $action = $request->input('action', 'ACTION');
        $reference = $request->input('reference', 'Stock Register');

        if ($action === 'print') {
            $this->authorize('print', StockItem::class);
        } elseif ($action === 'export') {
            $this->authorize('export', StockItem::class);
        }

        AuditLog::record('stock-register', strtoupper($action), $reference);

        return response()->json([
            'success' => true,
            'message' => 'Action logged successfully.'
        ]);
    }
}
