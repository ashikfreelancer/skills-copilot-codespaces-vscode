<?php

namespace App\Http\Controllers;

use App\Auth\AuthManager;
use App\Models\User;

class AuthController
{
    public function showLogin()
    {
        AuthManager::startSession();

        // If already authenticated and active, redirect directly to dashboard
        if (AuthManager::check()) {
            header('Location: /dashboard');
            exit;
        }

        $error = AuthManager::getFlash('error');
        $status = AuthManager::getFlash('status');
        $csrfToken = AuthManager::csrfToken();

        $branding = [
            'login_title' => 'Welcome to Management Information System',
            'login_subtitle' => 'Manage your management information system efficiently and effectively.',
            'login_hero_image' => '/assets/images/login-hero.jpg',
            'login_logo' => '/assets/images/tmss-logo.png',
            'brand_color' => '#2ecc71',
            'app_name' => 'Management Information System'
        ];

        try {
            $rows = \App\Database::fetchAll("SELECT key, value FROM system_settings WHERE key IN ('login_title', 'login_subtitle', 'login_hero_image', 'login_logo', 'brand_color', 'app_name')");
            foreach ($rows as $r) {
                if (!empty($r['key'])) {
                    $branding[$r['key']] = $r['value'];
                }
            }
        } catch (\Throwable $e) {}

        return view('auth.login', [
            'error' => $error,
            'status' => $status,
            'csrf_token' => $csrfToken,
            'branding' => $branding,
        ]);
    }

    public function login()
    {
        AuthManager::startSession();

        $isJson = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))
            || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
            || (str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json'));

        // Handle JSON or Form-encoded body
        $data = $_POST;
        if (empty($data)) {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true) ?: [];
        }

        $login = $data['username'] ?? $data['email'] ?? '';
        $password = $data['password'] ?? '';
        $remember = !empty($data['remember']);

        if (empty($login) || empty($password)) {
            $msg = 'User ID / Email and Password are required.';
            if ($isJson) {
                http_response_code(422);
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => $msg]);
                exit;
            }
            AuthManager::setFlash('error', $msg);
            header('Location: /login');
            exit;
        }

        $result = AuthManager::attempt($login, $password, $remember);

        if (!$result['success']) {
            if ($isJson) {
                http_response_code(401);
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => false,
                    'message' => $result['message'],
                    'csrf_token' => AuthManager::csrfToken()
                ]);
                exit;
            }
            AuthManager::setFlash('error', $result['message']);
            header('Location: /login');
            exit;
        }

        /** @var User $user */
        $user = $result['user'];

        if ($isJson) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Signed in successfully.',
                'redirect' => '/dashboard',
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                    'status' => $user->status,
                    'department' => $user->department,
                    'scope' => $user->scope,
                ]
            ]);
            exit;
        }

        header('Location: /dashboard');
        exit;
    }

    public function logout()
    {
        AuthManager::logout();

        $isJson = (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))
            || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

        if ($isJson) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Logged out successfully.',
                'redirect' => '/login'
            ]);
            exit;
        }

        header('Location: /login');
        exit;
    }

    public function me()
    {
        AuthManager::startSession();
        header('Content-Type: application/json');

        if (!AuthManager::check()) {
            http_response_code(401);
            echo json_encode([
                'authenticated' => false,
                'user' => null,
                'csrf_token' => AuthManager::csrfToken()
            ]);
            exit;
        }

        $user = AuthManager::user();
        echo json_encode([
            'authenticated' => true,
            'csrf_token' => AuthManager::csrfToken(),
            'user' => [
                'id' => $user->id,
                'user_code' => $user->user_code,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
                'status' => $user->status,
                'department' => $user->department,
                'scope' => $user->scope,
            ]
        ]);
        exit;
    }

    public function forgotPassword()
    {
        AuthManager::startSession();

        $data = $_POST;
        if (empty($data)) {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true) ?: [];
        }

        $login = $data['username'] ?? $data['email'] ?? '';
        if (empty($login)) {
            header('Content-Type: application/json');
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Please provide your User ID or Email.']);
            exit;
        }

        $result = AuthManager::requestPasswordReset($login);

        header('Content-Type: application/json');
        if (!$result['success']) {
            http_response_code(400);
        }
        echo json_encode($result);
        exit;
    }

    public function resetPassword()
    {
        AuthManager::startSession();

        $data = $_POST;
        if (empty($data)) {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true) ?: [];
        }

        $email = $data['email'] ?? '';
        $token = $data['token'] ?? '';
        $password = $data['password'] ?? '';
        $confirm = $data['password_confirmation'] ?? $data['confirm_password'] ?? '';

        if (empty($email) || empty($token) || empty($password)) {
            header('Content-Type: application/json');
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Email, reset token, and new password are required.']);
            exit;
        }

        if ($password !== $confirm) {
            header('Content-Type: application/json');
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Password confirmation does not match.']);
            exit;
        }

        $result = AuthManager::resetPassword($email, $token, $password);

        header('Content-Type: application/json');
        if (!$result['success']) {
            http_response_code(400);
        }
        echo json_encode($result);
        exit;
    }
}
