<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\AuditLog;
use App\Http\Requests\DepartmentRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;

class DepartmentController extends Controller
{
    /**
     * Display a listing of departments with search, filter, sort, and pagination.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Department::class);

        $query = Department::query();

        // Search
        if ($search = $request->input('search')) {
            $query->search($search);
        }

        // Filters
        $filters = $request->only(['status']);
        $query->filter($filters);

        // Sorting
        $sortBy = $request->input('sort_by', 'created_at');
        $sortOrder = strtolower($request->input('sort_order', 'desc')) === 'asc' ? 'asc' : 'desc';
        $allowedSorts = ['name', 'code', 'status', 'created_at', 'updated_at'];

        if (in_array($sortBy, $allowedSorts)) {
            $query->orderBy($sortBy, $sortOrder);
        } else {
            $query->orderBy('created_at', 'desc');
        }

        // Pagination
        $perPage = (int) $request->input('per_page', 100);
        $total = Department::count();
        $active = Department::where('status', 'Active')->count();
        $inactive = Department::where('status', 'Inactive')->count();

        if ($perPage <= 0) {
            $results = $query->get();
            return response()->json([
                'success' => true,
                'data' => $results,
                'total' => $results->count(),
                'meta' => [
                    'total' => $total,
                    'active' => $active,
                    'inactive' => $inactive,
                ]
            ]);
        }

        $paginated = $query->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => $paginated->items(),
            'pagination' => [
                'total' => $paginated->total(),
                'per_page' => $paginated->perPage(),
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
            ],
            'meta' => [
                'total' => $total,
                'active' => $active,
                'inactive' => $inactive,
            ]
        ]);
    }

    /**
     * Store a newly created department.
     */
    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', Department::class);

        $name = trim($request->input('name', ''));
        $code = trim($request->input('code', ''));
        $description = trim($request->input('description', ''));
        $status = $request->input('status', 'Active');

        if (!$name) {
            return response()->json(['error' => 'Validation Error', 'message' => 'Department name is required.', 'errors' => ['name' => ['Department name is required.']]], 422);
        }
        if (!$code) {
            return response()->json(['error' => 'Validation Error', 'message' => 'Department code is required.', 'errors' => ['code' => ['Department code is required.']]], 422);
        }

        // Check unique code
        $exists = Department::where('code', $code)->first();
        if ($exists) {
            return response()->json(['error' => 'Validation Error', 'message' => 'Department code already exists.', 'errors' => ['code' => ['Department code already exists.']]], 422);
        }

        $id = $request->input('id') ?: ('DEP-' . round(microtime(true) * 1000) . '-' . mt_rand(100, 999));
        $department = Department::create([
            'id' => $id,
            'name' => $name,
            'code' => $code,
            'description' => $description,
            'status' => in_array($status, ['Active', 'Inactive']) ? $status : 'Active'
        ]);

        AuditLog::record('department-management', 'CREATE', "Created Department: {$department->name} ({$department->code})", auth());

        return response()->json([
            'success' => true,
            'message' => 'Department created successfully.',
            'data' => $department
        ], 201);
    }

    /**
     * Display the specified department.
     */
    public function show(string $id): JsonResponse
    {
        $department = Department::findOrFail($id);
        $this->authorize('view', $department);

        return response()->json([
            'success' => true,
            'data' => $department
        ]);
    }

    /**
     * Update the specified department.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $department = Department::findOrFail($id);
        $this->authorize('update', $department);

        $name = trim($request->input('name', $department->name));
        $code = trim($request->input('code', $department->code));
        $description = trim($request->input('description', $department->description));
        $status = $request->input('status', $department->status);

        if (!$name) {
            return response()->json(['error' => 'Validation Error', 'message' => 'Department name is required.'], 422);
        }
        if (!$code) {
            return response()->json(['error' => 'Validation Error', 'message' => 'Department code is required.'], 422);
        }

        // Check unique code excluding current
        $exists = Department::where('code', $code)->where('id', '!=', $id)->first();
        if ($exists) {
            return response()->json(['error' => 'Validation Error', 'message' => 'Department code already exists.'], 422);
        }

        $department->update([
            'name' => $name,
            'code' => $code,
            'description' => $description,
            'status' => in_array($status, ['Active', 'Inactive']) ? $status : 'Active'
        ]);

        AuditLog::record('department-management', 'UPDATE', "Updated Department: {$department->name} ({$department->code})", auth());

        return response()->json([
            'success' => true,
            'message' => 'Department updated successfully.',
            'data' => $department
        ]);
    }

    /**
     * Remove the specified department from storage.
     */
    public function destroy(string $id): JsonResponse
    {
        $department = Department::findOrFail($id);
        $this->authorize('delete', $department);

        // Check if any users or staff are assigned
        if ($department->users()->exists()) {
            return response()->json([
                'error' => 'Dependency Error',
                'message' => 'Cannot delete department: users are assigned to this department.'
            ], 422);
        }

        $name = $department->name;
        $code = $department->code;
        $department->delete();

        AuditLog::record('department-management', 'DELETE', "Deleted Department: {$name} ({$code})", auth()->user());

        return response()->json([
            'success' => true,
            'message' => 'Department deleted successfully.'
        ]);
    }

    /**
     * Update department status (Activate / Deactivate approval).
     */
    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $department = Department::findOrFail($id);
        $this->authorize('approve', $department);

        $status = $request->input('status');
        if (!in_array($status, ['Active', 'Inactive'])) {
            return response()->json(['error' => 'Status must be Active or Inactive.'], 422);
        }

        $department->status = $status;
        $department->save();

        AuditLog::record('department-management', 'APPROVE', "Status for department {$department->name} changed to {$status}", auth()->user());

        return response()->json([
            'success' => true,
            'message' => "Status updated to {$status}",
            'status' => $status,
            'data' => $department
        ]);
    }

    /**
     * Record action in audit log (Print / Export).
     */
    public function logAction(Request $request): JsonResponse
    {
        $action = strtoupper($request->input('action', 'VIEW'));
        $reference = $request->input('reference', 'Department Action');

        if (in_array($action, ['PRINT'])) {
            $this->authorize('print', Department::class);
        } elseif (in_array($action, ['EXPORT'])) {
            $this->authorize('export', Department::class);
        }

        AuditLog::record('department-management', $action, $reference, auth()->user());

        return response()->json([
            'success' => true,
            'message' => "Action {$action} logged successfully."
        ]);
    }
}
