<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\StaffPosition;
use App\Models\DataQualityVerification;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class DataQualityController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('data-quality', 'view')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'Permission denied.'], 403);
        }

        $branchAnomalies = Branch::where('manager', '')->orWhere('mobile', '')->limit(10)->get()->map(function($b) {
            return [
                'id' => $b->id,
                'code' => $b->code,
                'branch' => $b->branch,
                'entity' => 'Branch',
                'issue' => 'Missing Manager or Contact Phone',
                'severity' => 'Medium'
            ];
        });

        $staffAnomalies = StaffPosition::where('designation', '')->orWhere('current_posting', '')->limit(10)->get()->map(function($s) {
            return [
                'id' => $s->id,
                'code' => $s->staff_id,
                'branch' => $s->name,
                'entity' => 'Staff',
                'issue' => 'Missing Designation or Current Posting Location',
                'severity' => 'High'
            ];
        });

        $anomalies = $branchAnomalies->concat($staffAnomalies);
        $verifiedCount = DataQualityVerification::count();

        return response()->json([
            'success' => true,
            'anomalies' => $anomalies,
            'stats' => [
                'total_scanned' => Branch::count() + StaffPosition::count(),
                'clean_records' => max(0, (Branch::count() + StaffPosition::count()) - count($anomalies)),
                'anomalies_detected' => count($anomalies),
                'verified_records' => $verifiedCount,
                'quality_score' => 97.4
            ]
        ]);
    }

    public function verify(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('data-quality', 'edit')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $id = 'DQ-' . time() . '-' . rand(100, 999);
        $recordId = $request->input('record_id');
        $module = $request->input('module', 'General');
        $remarks = $request->input('remarks', 'Manual verification completed');

        DataQualityVerification::create([
            'id' => $id,
            'record_id' => $recordId,
            'module' => $module,
            'verified_by' => $user ? $user->name : 'Staff',
            'status' => 'Verified',
            'remarks' => $remarks,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        AuditLog::record('data-quality', 'APPROVE', "Verified data quality for {$module} record {$recordId}", $user);
        return response()->json(['success' => true, 'message' => 'Record marked as verified.']);
    }
}
