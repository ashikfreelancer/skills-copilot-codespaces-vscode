<?php

namespace App\Http\Controllers;

use App\Models\DomainZone;
use App\Http\Requests\DomainZoneRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class DomainZoneController extends Controller
{
    /**
     * Display a listing of the resource with search, filter, sort, and pagination.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', DomainZone::class);

        $query = DomainZone::query();

        // Search
        if ($search = $request->input('search')) {
            $query->search($search);
        }

        // Filters
        $filters = $request->only(['domain', 'zone', 'head_type', 'status']);
        $query->filter($filters);

        // Sorting
        $sortBy = $request->input('sort_by', 'id');
        $sortOrder = $request->input('sort_order', 'asc');
        $allowedSorts = ['id', 'domain', 'zone', 'head_name', 'employee_id', 'status', 'created_at'];

        if (in_array($sortBy, $allowedSorts)) {
            $query->orderBy($sortBy, $sortOrder === 'desc' ? 'desc' : 'asc');
        } else {
            $query->orderBy('id', 'asc');
        }

        // Pagination
        $perPage = (int) $request->input('per_page', 100);
        if ($perPage <= 0) {
            $results = $query->get();
            return response()->json([
                'success' => true,
                'data' => $results,
                'total' => $results->count(),
            ]);
        }

        $paginated = $query->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => $paginated->items(),
            'pagination' => [
                'total' => $paginated->total(),
                'per_page' => $paginated->perPage(),
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
            ],
            'meta' => [
                'total_records' => DomainZone::count(),
                'zone_heads' => DomainZone::where('head_type', 'Zone Head')->count(),
                'domain_heads' => DomainZone::where('head_type', 'Domain Head')->count(),
                'active_records' => DomainZone::where('status', 'Active')->count(),
            ]
        ]);
    }

    /**
     * Store a newly created domain or zone head record.
     */
    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', DomainZone::class);

        $data = $request->all();
        $headType = $request->input('head_type', 'Zone Head');
        $isDomainHead = $headType === 'Domain Head';
        $prefix = $isDomainHead ? 'OP' : 'DZ';
        $data['id'] = $request->input('id') ?: ($prefix . '-' . date('YmdHis') . '-' . rand(100, 999));

        $record = DomainZone::create($data);

        return response()->json([
            'success' => true,
            'message' => 'তথ্য সফলভাবে সংরক্ষণ হয়েছে।',
            'data' => $record
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id): JsonResponse
    {
        $record = DomainZone::findOrFail($id);
        $this->authorize('view', $record);

        return response()->json([
            'success' => true,
            'data' => $record
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $record = DomainZone::findOrFail($id);
        $this->authorize('update', $record);

        $record->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'তথ্য সফলভাবে আপডেট হয়েছে।',
            'data' => $record
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id): JsonResponse
    {
        $record = DomainZone::findOrFail($id);
        $this->authorize('delete', $record);

        $record->delete();

        Log::info("Deleted DomainZone record {$id} by " . auth()->user()?->email);

        return response()->json([
            'success' => true,
            'message' => 'তথ্য সফলভাবে মুছে ফেলা হয়েছে।'
        ]);
    }

    /**
     * Update status (Approval workflow).
     */
    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $record = DomainZone::findOrFail($id);
        $this->authorize('approve', $record);

        $status = $request->input('status');
        if (!in_array($status, ['Active', 'Inactive'])) {
            return response()->json(['error' => 'Invalid status value'], 422);
        }

        $record->status = $status;
        $record->save();

        Log::info("Changed status of DomainZone {$id} to {$status} by " . auth()->user()?->email);

        return response()->json([
            'success' => true,
            'message' => 'স্ট্যাটাস সফলভাবে পরিবর্তন করা হয়েছে।',
            'status' => $status,
            'data' => $record
        ]);
    }
}
