<?php

namespace App\Http\Controllers;

use App\Models\StaffTransfer;
use App\Models\StaffPosition;
use App\Models\Branch;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class StaffTransferController extends Controller
{
    /**
     * Get branches for transfer selection.
     */
    public function branches(Request $request): JsonResponse
    {
        $this->authorize('view', StaffPosition::class);
        $branches = Branch::orderBy('branch')->get();
        return response()->json([
            'success' => true,
            'data' => $branches
        ]);
    }

    /**
     * Get staff members for transfer selection.
     */
    public function staff(Request $request): JsonResponse
    {
        $this->authorize('view', StaffPosition::class);
        $staff = StaffPosition::orderBy('name')->get();
        return response()->json([
            'success' => true,
            'data' => $staff
        ]);
    }

    /**
     * List all transfers and branch closures with search, filter, sort & pagination.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('view', StaffPosition::class);

        $query = StaffTransfer::query();

        if ($search = $request->input('search')) {
            $s = '%' . strtolower($search) . '%';
            $query->where(function ($q) use ($s) {
                $q->whereRaw('LOWER(staff_name) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(staff_id) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(order_number) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(from_branch) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(to_branch) LIKE ?', [$s]);
            });
        }

        if ($type = $request->input('type')) {
            $query->where('type', $type);
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }
        if ($staffId = $request->input('staff_id')) {
            $query->where('staff_id', $staffId);
        }

        $perPage = (int) $request->input('per_page', 50);
        $total = $query->count();
        $page = (int) $request->input('page', 1);

        $items = $query->orderBy('transfer_date', 'desc')
                      ->skip(($page - 1) * $perPage)
                      ->take($perPage)
                      ->get();

        $allTransfers = StaffTransfer::all();
        $stats = [
            'total_transfers' => $allTransfers->where('type', 'Transfer')->count(),
            'total_closures' => $allTransfers->where('type', 'Close')->count(),
            'pending_clearance' => $allTransfers->where('handover_status', 'Pending Clearance')->count(),
            'active_in_transit' => $allTransfers->where('handover_status', 'In Progress')->count(),
            'total_records' => $allTransfers->count()
        ];

        return response()->json([
            'success' => true,
            'data' => $items,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'last_page' => (int) ceil($total / max(1, $perPage))
            ],
            'stats' => $stats
        ]);
    }

    /**
     * Get career timeline for a specific staff member.
     */
    public function timeline(Request $request, string $staffId): JsonResponse
    {
        $this->authorize('view', StaffPosition::class);

        $staff = StaffPosition::where('id', $staffId)->orWhere('staff_id', $staffId)->first();
        $transfers = StaffTransfer::where('staff_id', $staff ? $staff->staff_id : $staffId)
                                  ->orderBy('transfer_date', 'asc')
                                  ->get();

        return response()->json([
            'success' => true,
            'staff' => $staff,
            'data' => $transfers,
            'timeline' => $transfers
        ]);
    }

    /**
     * Store new staff transfer or branch closure.
     */
    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', StaffPosition::class);

        $data = $request->all();
        $type = $request->input('type', 'Transfer');
        $prefix = $type === 'Close' ? 'CLO' : 'TRF';
        $id = $request->input('id') ?: ($prefix . '-' . date('YmdHis') . '-' . rand(100, 999));
        $data['id'] = $id;

        // Auto-fill staff details if staff_id is provided
        if (!empty($data['staff_id'])) {
            $staff = StaffPosition::where('staff_id', $data['staff_id'])->orWhere('id', $data['staff_id'])->first();
            if ($staff) {
                $data['staff_name'] = $data['staff_name'] ?? $staff->name;
                $data['designation'] = $data['designation'] ?? $staff->designation;
                $data['department'] = $data['department'] ?? $staff->department;
            }
        }

        $record = StaffTransfer::create($data);

        AuditLog::record('staff-position-list', 'CREATE', "Recorded staff transfer/closure {$record->id} for {$record->staff_name}");

        return response()->json([
            'success' => true,
            'message' => 'Transfer record saved successfully.',
            'data' => $record
        ], 201);
    }

    /**
     * Delete transfer record.
     */
    public function destroy(string $id): JsonResponse
    {
        $this->authorize('delete', StaffPosition::class);

        $record = StaffTransfer::findOrFail($id);
        $record->delete();

        AuditLog::record('staff-position-list', 'DELETE', "Deleted transfer record {$id}");

        return response()->json([
            'success' => true,
            'message' => 'Transfer record deleted successfully.'
        ]);
    }
}
