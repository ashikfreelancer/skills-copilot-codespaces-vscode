<?php

namespace App\Http\Controllers;

use App\Models\Leave;
use App\Models\StaffPosition;
use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class LeaveController extends Controller
{
    /**
     * List leave requests with staff joins, filtering, and balance summaries.
     */
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('leave-management', 'view')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $query = Leave::query()->with('staff');

        if ($staffId = $request->input('staff_id')) {
            $query->where('staff_id', $staffId);
        }
        if ($dept = $request->input('department')) {
            $query->where('department', $dept);
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }
        if ($year = $request->input('year')) {
            $query->where('from_date', 'like', "{$year}%");
        }
        if ($search = $request->input('search')) {
            $s = '%' . strtolower($search) . '%';
            $query->where(function ($q) use ($s) {
                $q->whereRaw('LOWER(staff_name) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(staff_id) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(leave_type) LIKE ?', [$s])
                  ->orWhereRaw('LOWER(reason) LIKE ?', [$s]);
            });
        }

        $query->orderBy('from_date', 'desc');
        $rows = $query->get();

        $totalStaff = StaffPosition::count();
        $totalAllocated = $totalStaff * 44;
        $totalTaken = (int) Leave::where('status', 'Approved')->sum('days');
        $pending = Leave::where('status', 'Pending')->count();
        $approved = Leave::where('status', 'Approved')->count();
        $rejected = Leave::where('status', 'Rejected')->count();

        return response()->json([
            'success' => true,
            'data' => $rows,
            'summary' => [
                'total_allocated' => $totalAllocated,
                'total_taken' => $totalTaken,
                'balance' => max(0, $totalAllocated - $totalTaken),
                'pending' => $pending,
                'approved' => $approved,
                'rejected' => $rejected,
            ]
        ]);
    }

    /**
     * Get staff quota and balance summaries.
     */
    public function staffSummary(Request $request): JsonResponse
    {
        $staff = StaffPosition::orderBy('name', 'asc')->get();
        $data = $staff->map(function ($s) {
            $allocated = 44;
            $taken = (int) Leave::where('staff_id', $s->staff_id)->where('status', 'Approved')->sum('days');
            $pending = Leave::where('staff_id', $s->staff_id)->where('status', 'Pending')->count();
            $approved = Leave::where('staff_id', $s->staff_id)->where('status', 'Approved')->count();
            $rejected = Leave::where('staff_id', $s->staff_id)->where('status', 'Rejected')->count();

            return [
                'id' => $s->staff_id,
                'staff_id' => $s->staff_id,
                'name' => $s->name,
                'department' => $s->department,
                'designation' => $s->designation,
                'branch' => $s->current_posting,
                'allocated' => $allocated,
                'taken' => $taken,
                'pending' => $pending,
                'approved' => $approved,
                'rejected' => $rejected,
                'balance' => max(0, $allocated - $taken)
            ];
        });

        return response()->json(['success' => true, 'data' => $data]);
    }

    /**
     * Store new leave request.
     */
    public function store(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('leave-management', 'create')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $staffId = $request->input('staff_id');
        $staff = StaffPosition::where('staff_id', $staffId)->first();
        if (!$staff) {
            return response()->json(['success' => false, 'error' => 'Staff not found.'], 404);
        }

        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');
        $days = (int) $request->input('days', 1);
        $leaveType = $request->input('leave_type', 'Casual Leave');
        $id = $request->input('id') ?: 'LV-' . time() . '-' . rand(100, 999);

        $leave = Leave::create([
            'id' => $id,
            'staff_id' => $staff->staff_id,
            'staff_name' => $staff->name,
            'department' => $staff->department,
            'leave_type' => $leaveType,
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'days' => $days,
            'status' => $request->input('status', 'Pending'),
            'reason' => $request->input('reason', ''),
            'approved_by' => $request->input('approved_by', null),
        ]);

        AuditLog::record('leave-management', 'CREATE', "Created Leave Request {$id} for {$staff->name}", $user);

        return response()->json([
            'success' => true,
            'message' => 'Leave application created successfully.',
            'data' => $leave
        ], 201);
    }

    /**
     * Update leave request or status.
     */
    public function update(Request $request, string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('leave-management', 'edit')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $leave = Leave::where('id', $id)->first();
        if (!$leave) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $leave->update($request->only(['leave_type', 'from_date', 'to_date', 'days', 'status', 'reason', 'approved_by']));

        AuditLog::record('leave-management', 'UPDATE', "Updated Leave {$id} status to {$leave->status}", $user);

        return response()->json([
            'success' => true,
            'message' => 'Leave updated successfully.',
            'data' => $leave
        ]);
    }

    /**
     * Delete leave record.
     */
    public function destroy(string $id): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('leave-management', 'delete')) {
            return response()->json(['error' => 'Forbidden'], 403);
        }

        $leave = Leave::where('id', $id)->first();
        if (!$leave) {
            return response()->json(['error' => 'Not Found'], 404);
        }

        $leave->delete();
        AuditLog::record('leave-management', 'DELETE', "Deleted leave {$id}", $user);

        return response()->json([
            'success' => true,
            'message' => 'Leave deleted successfully.'
        ]);
    }
}
