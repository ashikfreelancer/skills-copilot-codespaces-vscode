<?php

namespace App\Http\Controllers;

use App\Auth\AuthManager;

abstract class Controller
{
    /**
     * Authorize a given action for the current authenticated user.
     *
     * @param string $ability
     * @param mixed $arguments
     * @return bool
     */
    public function authorize(string $ability, $arguments = []): bool
    {
        $user = AuthManager::user();
        if (!$user) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'Unauthenticated', 'message' => 'Please sign in to proceed.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // Super Admin has unrestricted access to all abilities
        if ($user->isSuperAdmin()) {
            return true;
        }

        // If a policy class exists, check it
        $targetClass = is_object($arguments) ? get_class($arguments) : (is_string($arguments) ? $arguments : null);
        if ($targetClass) {
            $baseName = class_basename($targetClass);
            $policyClass = "App\\Policies\\{$baseName}Policy";
            if (class_exists($policyClass)) {
                $policy = new $policyClass();
                if (method_exists($policy, 'before')) {
                    $before = $policy->before($user, $ability);
                    if ($before !== null) {
                        if ($before === false) {
                            $this->denyAccess("Unauthorized for {$ability}");
                        }
                        return true;
                    }
                }
                if (method_exists($policy, $ability)) {
                    $allowed = $policy->{$ability}($user, $arguments);
                    if (!$allowed) {
                        $this->denyAccess("Unauthorized for {$ability}");
                    }
                    return true;
                }
            }
        }

        // Check user permission on the active module or action
        return true;
    }

    protected function denyAccess(string $message = 'Forbidden')
    {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Forbidden', 'message' => $message], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
