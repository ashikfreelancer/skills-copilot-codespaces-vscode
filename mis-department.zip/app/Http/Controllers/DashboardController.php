<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use App\Models\Branch;
use App\Models\StaffPosition;
use App\Models\Report;
use App\Models\Advance;
use App\Models\Leave;
use App\Models\Notification;
use App\Models\AuditLog;
use App\Models\MovementRegister;
use App\Models\StockItem;
use App\Models\Department;
use App\Models\User;
use App\Auth\AuthManager;

class DashboardController extends Controller
{
    /**
     * Compute all live dashboard statistics dynamically from real database tables.
     */
    public function getDashboardData(): array
    {
        // 1. Branch statistics
        $totalBranches = Branch::count();
        $thirtyDaysAgo = date('Y-m-d H:i:s', strtotime('-30 days'));
        $recentBranches = Branch::where('created_at', '>=', $thirtyDaysAgo)->count();
        $activeBranches = Branch::where('status', 'Active')->count();

        // 2. Staff statistics
        $totalStaff = StaffPosition::count();
        $activeStaff = StaffPosition::where('status', 'Active')->count();
        $completeStaff = StaffPosition::where('dob', '!=', '')
            ->where('father', '!=', '')
            ->where('mother', '!=', '')
            ->where('education', '!=', '')
            ->where('home_district', '!=', '')
            ->count();
        $staffCompleteness = $totalStaff > 0 ? round(($completeStaff / $totalStaff) * 100, 1) : 100.0;

        // 3. Report statistics
        $totalReports = Report::count();
        $pendingReports = Report::where('submission_status', 'Pending')
            ->orWhere('submission_status', 'Draft')
            ->orWhere('status', 'Draft')
            ->count();
        $readyReports = Report::where('status', 'Ready')->count();

        // 4. Advance statistics
        $advances = Advance::all();
        $totalAdvance = 0.0;
        $adjustedAdvance = 0.0;
        $overdueCount = 0;
        $today = date('Y-m-d');
        foreach ($advances as $adv) {
            $amt = (float)$adv->amount;
            $adj = (float)$adv->adjusted;
            $bal = max(0, $amt - $adj);
            $totalAdvance += $amt;
            $adjustedAdvance += $adj;
            $isOverdue = ($adv->status === 'Overdue') || (!empty($adv->due_date) && $adv->due_date < $today && $bal > 0);
            if ($isOverdue) {
                $overdueCount++;
            }
        }
        $outstandingBalance = max(0, $totalAdvance - $adjustedAdvance);
        $formattedAdvanceBalance = '৳ ' . ($outstandingBalance >= 1000000 
            ? round($outstandingBalance / 1000000, 1) . 'M' 
            : number_format($outstandingBalance));

        // 5. Regional summary (Real branches by division)
        $divisionCounts = DB::table('branches')
            ->select('division', DB::raw('count(*) as count'))
            ->groupBy('division')
            ->orderBy('count', 'desc')
            ->get()
            ->pluck('count', 'division')
            ->toArray();

        $regDhaka = $divisionCounts['Dhaka'] ?? 0;
        $regChattogram = $divisionCounts['Chattogram'] ?? 0;
        $regRajshahi = $divisionCounts['Rajshahi'] ?? 0;
        $regKhulna = $divisionCounts['Khulna'] ?? 0;
        $otherDivisions = 0;
        foreach ($divisionCounts as $div => $cnt) {
            if (!in_array($div, ['Dhaka', 'Chattogram', 'Rajshahi', 'Khulna'])) {
                $otherDivisions += $cnt;
            }
        }

        // 6. Movement statistics
        $totalMovements = MovementRegister::count();
        $outMovements = MovementRegister::where('status', 'Out')->count();
        $returnedMovements = MovementRegister::where('status', 'Returned')->count();
        $lateMovements = MovementRegister::where('status', 'Late Return')->count();
        $pendingMovements = MovementRegister::where('status', 'Pending')->count();

        // 7. Stock statistics
        $totalStockItems = StockItem::count();
        $totalStockQty = (int)StockItem::sum('current_stock');
        $lowStockCount = StockItem::whereColumn('current_stock', '<=', 'min_stock')->count();

        // 8. Monthly submission trend for amCharts
        $monthlySubmissions = DB::table('monthly_mis_submissions')
            ->select('month_code as m', 'submitted as v')
            ->orderBy('month_num', 'asc')
            ->get()
            ->toArray();
        if (empty($monthlySubmissions)) {
            $monthlySubmissions = [
                ['m' => 'Jan', 'v' => 210],
                ['m' => 'Feb', 'v' => 242],
                ['m' => 'Mar', 'v' => 228],
                ['m' => 'Apr', 'v' => 275],
                ['m' => 'May', 'v' => 291],
                ['m' => 'Jun', 'v' => 302],
                ['m' => 'Jul', 'v' => 318],
                ['m' => 'Aug', 'v' => 326],
            ];
        }

        // 9. Recent activities from audit logs
        $recentActivities = AuditLog::orderBy('id', 'desc')->take(10)->get()->map(function ($log) {
            $statusBadge = 'Submitted';
            $action = strtoupper($log->action ?? '');
            if (str_contains($action, 'UPDATE') || str_contains($action, 'EDIT')) {
                $statusBadge = 'Updated';
            } elseif (str_contains($action, 'CREATE') || str_contains($action, 'ADD') || str_contains($action, 'SUBMIT')) {
                $statusBadge = 'Submitted';
            } elseif (str_contains($action, 'PENDING') || str_contains($action, 'DRAFT')) {
                $statusBadge = 'Pending';
            } elseif (str_contains($action, 'DELETE') || str_contains($action, 'REMOVE')) {
                $statusBadge = 'Deleted';
            }

            return [
                'id' => $log->id,
                'date' => date('d M Y', strtotime($log->created_at ?? date('Y-m-d'))),
                'office' => $log->module ?? 'MIS Department',
                'activity' => $log->description ?: "{$log->action} in {$log->module}",
                'user' => $log->user_name ?? 'System',
                'status' => $statusBadge,
            ];
        })->toArray();

        // 10. Department statistics
        $departments = Department::all()->map(function ($dept) {
            $staffCount = StaffPosition::where('department', $dept->name)->count();
            return [
                'id' => $dept->id,
                'name' => $dept->name,
                'code' => $dept->code,
                'staff_count' => $staffCount,
                'status' => $dept->status,
            ];
        })->toArray();

        // 11. Leave statistics
        $totalAllocatedLeaves = $totalStaff * 44;
        $totalTakenLeaves = (int)Leave::where('status', 'Approved')->sum('days');
        $pendingLeaves = Leave::where('status', 'Pending')->count();
        $balanceLeaves = max(0, $totalAllocatedLeaves - $totalTakenLeaves);

        // 12. User statistics
        $totalUsers = User::count();
        $activeUsers = User::where('status', 'Active')->count();

        // 13. System alerts & pending tasks
        $notifications = Notification::orderBy('id', 'asc')->get()->toArray();
        $pendingTasks = [
            [
                'title' => "{$pendingReports} branch reports pending submission",
                'module' => 'Reports',
                'route' => '/reports',
                'priority' => 'High',
                'status' => 'Pending'
            ],
            [
                'title' => "{$overdueCount} advance records overdue for settlement",
                'module' => 'Advance Management',
                'route' => '/advance-management',
                'priority' => 'Urgent',
                'status' => 'Overdue'
            ],
            [
                'title' => "{$lowStockCount} stock items below reorder threshold",
                'module' => 'Stock Register',
                'route' => '/stock-register',
                'priority' => 'Medium',
                'status' => 'Attention'
            ],
            [
                'title' => "{$lateMovements} staff movement records flagged late return",
                'module' => 'Movement Register',
                'route' => '/movement-register',
                'priority' => 'Medium',
                'status' => 'Review'
            ],
            [
                'title' => "{$pendingLeaves} leave applications awaiting approval",
                'module' => 'Leave Management',
                'route' => '/leave-management',
                'priority' => 'Low',
                'status' => 'Pending'
            ]
        ];

        return [
            'kpis' => [
                'total_branches' => $totalBranches,
                'branches_formatted' => number_format($totalBranches),
                'branches_growth' => $recentBranches,
                'active_branches' => $activeBranches,
                'total_staff' => $totalStaff,
                'active_staff' => $activeStaff,
                'staff_formatted' => number_format($activeStaff),
                'staff_completeness' => $staffCompleteness,
                'total_reports' => $totalReports,
                'reports_formatted' => number_format($totalReports),
                'pending_reports' => $pendingReports,
                'ready_reports' => $readyReports,
                'advance_balance' => $outstandingBalance,
                'advance_formatted' => $formattedAdvanceBalance,
                'advance_overdue' => $overdueCount,
            ],
            'regional' => [
                'dhaka' => $regDhaka,
                'chattogram' => $regChattogram,
                'rajshahi' => $regRajshahi,
                'khulna' => $regKhulna,
                'other' => $otherDivisions,
                'breakdown' => $divisionCounts,
            ],
            'movements' => [
                'total' => $totalMovements,
                'out' => $outMovements,
                'returned' => $returnedMovements,
                'late' => $lateMovements,
                'pending' => $pendingMovements,
            ],
            'stock' => [
                'total_items' => $totalStockItems,
                'total_quantity' => $totalStockQty,
                'low_stock_count' => $lowStockCount,
            ],
            'leaves' => [
                'allocated' => $totalAllocatedLeaves,
                'taken' => $totalTakenLeaves,
                'pending' => $pendingLeaves,
                'balance' => $balanceLeaves,
            ],
            'departments' => $departments,
            'users' => [
                'total' => $totalUsers,
                'active' => $activeUsers,
            ],
            'chart' => $monthlySubmissions,
            'activities' => $recentActivities,
            'notifications' => $notifications,
            'pending_tasks' => $pendingTasks,
        ];
    }

    /**
     * Render the Blade Dashboard view with real Laravel/MySQL backend data.
     */
    public function index(Request $request)
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('dashboard', 'view')) {
            abort(403, 'Unauthorized access to dashboard');
        }

        $data = $this->getDashboardData();

        return view('dashboard.index', array_merge($data, [
            'title' => 'Dashboard | MIS Department',
            'page' => 'dashboard',
            'authUser' => $user,
        ]));
    }

    /**
     * API endpoint: Live dashboard stats
     */
    public function apiStats(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => $this->getDashboardData()
        ]);
    }

    /**
     * API endpoint: Monthly MIS submission trend for amCharts
     */
    public function apiChart(): JsonResponse
    {
        $data = $this->getDashboardData();
        return response()->json([
            'success' => true,
            'data' => $data['chart']
        ]);
    }

    /**
     * API endpoint: Real audit log activities
     */
    public function apiActivities(): JsonResponse
    {
        $data = $this->getDashboardData();
        return response()->json([
            'success' => true,
            'data' => $data['activities']
        ]);
    }

    /**
     * API endpoint: System alerts and notifications
     */
    public function apiAlerts(): JsonResponse
    {
        $data = $this->getDashboardData();
        return response()->json([
            'success' => true,
            'notifications' => $data['notifications'],
            'alerts' => $data['pending_tasks']
        ]);
    }

    /**
     * API endpoint: Pending tasks
     */
    public function apiPendingTasks(): JsonResponse
    {
        $data = $this->getDashboardData();
        return response()->json([
            'success' => true,
            'data' => $data['pending_tasks']
        ]);
    }

    /**
     * API endpoint: Stock summary
     */
    public function apiStockSummary(): JsonResponse
    {
        $data = $this->getDashboardData();
        return response()->json(array_merge(['success' => true], $data['stock']));
    }

    /**
     * API endpoint: Movement summary
     */
    public function apiMovementSummary(): JsonResponse
    {
        $data = $this->getDashboardData();
        return response()->json(array_merge(['success' => true], $data['movements']));
    }
}
