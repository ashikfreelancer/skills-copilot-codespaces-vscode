<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Auth\AuthManager;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class AnalyticsController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = AuthManager::user();
        if ($user && !$user->isSuperAdmin() && !$user->hasPermission('analytics', 'view')) {
            return response()->json(['error' => 'Forbidden', 'message' => 'Permission denied.'], 403);
        }

        $submissions = DB::table('monthly_mis_submissions')
            ->selectRaw('month_code as m, ROUND((CAST(submitted AS FLOAT) / CAST(target AS FLOAT)) * 100, 1) as v, submitted, target, pending')
            ->where('year', 2026)
            ->orderBy('month_num', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'compliance_trend' => $submissions,
            'kpis' => [
                'annual_compliance' => 96.8,
                'reporting_speed_days' => 2.4,
                'data_accuracy' => 99.1,
                'active_audits' => 12
            ]
        ]);
    }
}
