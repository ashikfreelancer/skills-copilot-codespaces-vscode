<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MovementRegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'date' => 'required|date',
            'employee_name' => 'required|string|max:150',
            'designation' => 'required|string|max:100',
            'domain' => 'required|string|max:100',
            'purpose' => 'required|string|max:255',
            'destination' => 'required|string|max:255',
            'out_time' => 'required|string|max:20',
            'department' => 'nullable|string|max:100',
            'zone' => 'nullable|string|max:100',
            'location' => 'nullable|string|max:150',
            'type' => 'nullable|string|in:Official,Field Visit,Personal,Training,Other',
            'expected_return' => 'nullable|string|max:20',
            'actual_return' => 'nullable|string|max:20',
            'contact' => 'nullable|string|max:50',
            'vehicle' => 'nullable|string|max:100',
            'accompanied_by' => 'nullable|string|max:150',
            'approved_by' => 'nullable|string|max:150',
            'status' => 'nullable|string|in:Out,Returned,Late Return,Pending,Cancelled',
            'remarks' => 'nullable|string',
        ];
    }
}
