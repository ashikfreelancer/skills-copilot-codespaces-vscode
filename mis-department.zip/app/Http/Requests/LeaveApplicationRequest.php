<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LeaveApplicationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'employee_id' => 'required|integer',
            'employee_name' => 'required|string|max:150',
            'leave_type' => 'required|string|in:Casual Leave,Sick Leave,Earned Leave,Maternity Leave,Special Leave',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'required|string|min:5|max:500',
            'contact_address' => 'nullable|string|max:255',
            'emergency_contact' => 'nullable|string|max:50',
        ];
    }

    public function messages(): array
    {
        return [
            'end_date.after_or_equal' => 'End date must be greater than or equal to start date.',
            'reason.min' => 'Please provide a sufficient reason of at least 5 characters.',
        ];
    }
}
