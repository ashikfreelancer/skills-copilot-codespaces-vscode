<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TargetActivityRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'department_id' => 'required|integer',
            'activity_name' => 'required|string|max:200',
            'target_value' => 'required|numeric|min:1',
            'actual_value' => 'nullable|numeric|min:0',
            'unit' => 'required|string|max:50',
            'fiscal_year' => 'required|string|max:10',
            'quarter' => 'required|string|in:Q1,Q2,Q3,Q4,Annual',
            'status' => 'nullable|string|in:Not Started,In Progress,Completed,Overdue'
        ];
    }
}
