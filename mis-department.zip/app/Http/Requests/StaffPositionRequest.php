<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StaffPositionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'staff_name' => 'required|string|max:150',
            'employee_code' => 'required|string|max:50',
            'designation' => 'required|string|max:100',
            'department_id' => 'required|integer',
            'grade_rank' => 'required|string|max:20',
            'basic_salary' => 'required|numeric|min:0',
            'email' => 'required|email|max:100',
            'phone' => 'required|string|max:30',
            'joining_date' => 'required|date',
            'status' => 'required|in:Active,On Leave,Transferred,Resigned'
        ];
    }
}
