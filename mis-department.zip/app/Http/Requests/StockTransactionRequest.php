<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StockTransactionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'date' => 'required|date',
            'item_id' => 'required|string|exists:stock_items,id',
            'type' => 'required|string|in:Receive,Issue,Return,Transfer In,Transfer Out,Adjustment',
            'qty' => 'required|numeric|gt:0',
            'unit_price' => 'nullable|numeric|min:0',
            'location' => 'required|string|max:100',
            'reference' => 'nullable|string|max:100',
            'party' => 'nullable|string|max:150',
            'staff_id' => 'nullable|string|max:50',
            'purpose' => 'nullable|string|max:255',
            'approved_by' => 'nullable|string|max:150',
            'remarks' => 'nullable|string',
        ];
    }
}
