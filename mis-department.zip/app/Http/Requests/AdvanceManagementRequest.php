<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AdvanceManagementRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'employee_name' => 'required|string|max:150',
            'amount' => 'required|numeric|min:500|max:500000',
            'purpose' => 'required|string|max:255',
            'disbursement_date' => 'required|date',
            'installments' => 'required|integer|min:1|max:60',
            'notes' => 'nullable|string|max:1000'
        ];
    }

    public function messages(): array
    {
        return [
            'amount.min' => 'Advance amount must be at least 500 BDT.',
            'amount.max' => 'Advance amount exceeds policy limit of 500,000 BDT.',
            'installments.max' => 'Installments cannot exceed 60 months.'
        ];
    }
}
