<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DomainZoneRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'domain'       => 'required|string|max:100',
            'zone'         => 'nullable|string|max:100',
            'head_type'    => 'required|in:Domain Head,Zone Head',
            'head_name'    => 'required|string|max:150',
            'designation'  => 'required|string|max:50',
            'employee_id'  => 'required|string|max:50',
            'mobile'       => 'required|string|max:50',
            'email'        => 'nullable|email|max:100',
            'address'      => 'nullable|string|max:255',
            'status'       => 'required|in:Active,Inactive',
            'remarks'      => 'nullable|string|max:500',
        ];
    }

    /**
     * Custom messages for validation errors.
     */
    public function messages(): array
    {
        return [
            'domain.required'      => 'ডোমেইনের নাম আবশ্যক।',
            'head_name.required'   => 'প্রধানের নাম আবশ্যক।',
            'designation.required' => 'পদবী আবশ্যক।',
            'employee_id.required' => 'কর্মকর্তার আইডি নম্বর আবশ্যক।',
            'mobile.required'      => 'মোবাইল নম্বর আবশ্যক।',
            'email.email'          => 'সঠিক ই-মেইল ঠিকানা প্রদান করুন।',
            'head_type.in'         => 'প্রধানের ধরন জোন প্রধান অথবা ডোমেইন প্রধান হতে হবে।',
        ];
    }
}
