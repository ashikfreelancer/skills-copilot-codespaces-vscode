<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BranchRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $id = $this->route('id') ?? $this->input('id');

        return [
            'division' => 'required|string|max:100',
            'district' => 'required|string|max:100',
            'thana' => 'required|string|max:100',
            'upazila' => 'required|string|max:100',
            'branch' => 'required|string|max:150',
            'code' => 'required|string|max:50|unique:branches,code,' . $id . ',id',
            'union_name' => 'nullable|string|max:150',
            'ward' => 'nullable|string|max:50',
            'manager' => 'nullable|string|max:150',
            'mobile' => 'nullable|string|max:30',
            'personal_mobile' => 'nullable|string|max:30',
            'email' => 'nullable|email|max:150',
            'status' => 'required|in:Active,Inactive,Review',
            'address' => 'nullable|string|max:500',
        ];
    }

    public function messages(): array
    {
        return [
            'division.required' => 'Division is required.',
            'district.required' => 'District is required.',
            'thana.required' => 'Thana is required.',
            'upazila.required' => 'Upazila is required.',
            'branch.required' => 'Branch name is required.',
            'code.required' => 'Branch code is required.',
            'code.unique' => 'This branch code already exists.',
        ];
    }
}
