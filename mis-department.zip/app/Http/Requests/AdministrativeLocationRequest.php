<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AdministrativeLocationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $id = $this->route('id') ?? $this->input('id');

        return [
            'type' => 'required|in:Division,District,Thana,Upazila',
            'name' => 'required|string|max:150',
            'division' => 'nullable|string|max:100',
            'district' => 'nullable|string|max:100',
            'thana' => 'nullable|string|max:100',
            'status' => 'required|in:Active,Inactive',
        ];
    }

    public function messages(): array
    {
        return [
            'type.required' => 'Location type is required.',
            'name.required' => 'Location name is required.',
            'status.in' => 'Status must be either Active or Inactive.',
        ];
    }
}
