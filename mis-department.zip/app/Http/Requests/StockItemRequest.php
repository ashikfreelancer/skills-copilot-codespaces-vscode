<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StockItemRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $id = $this->route('id') ?? $this->input('id');

        return [
            'code' => 'required|string|max:50|unique:stock_items,code,' . $id,
            'name' => 'required|string|max:150',
            'category' => 'required|string|max:100',
            'unit' => 'required|string|max:50',
            'opening' => 'required|numeric|min:0',
            'min' => 'required|numeric|min:0',
            'location' => 'required|string|max:100',
            'supplier' => 'nullable|string|max:150',
            'status' => 'nullable|string|in:Active,Inactive',
        ];
    }
}
