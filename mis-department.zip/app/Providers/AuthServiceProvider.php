<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        // Global Gate rule: The Super Admin must have full system access
        Gate::before(function (User $user, string $ability) {
            if ($user->isSuperAdmin()) {
                return true;
            }

            if (!$user->isActive()) {
                return false;
            }
        });

        // General module-action permission gate: Gate::allows('permission', [$module, $action])
        Gate::define('permission', function (User $user, string $module, string $action) {
            return $user->hasPermission($module, $action);
        });

        // Dedicated gates for each of the 10 supported actions
        Gate::define('view-module', function (User $user, string $module) {
            return $user->hasPermission($module, 'view');
        });

        Gate::define('create-record', function (User $user, string $module) {
            return $user->hasPermission($module, 'create');
        });

        Gate::define('edit-record', function (User $user, string $module) {
            return $user->hasPermission($module, 'edit');
        });

        Gate::define('update-record', function (User $user, string $module) {
            return $user->hasPermission($module, 'update');
        });

        Gate::define('delete-record', function (User $user, string $module) {
            return $user->hasPermission($module, 'delete');
        });

        Gate::define('approve-record', function (User $user, string $module) {
            return $user->hasPermission($module, 'approve');
        });

        Gate::define('reject-record', function (User $user, string $module) {
            return $user->hasPermission($module, 'reject');
        });

        Gate::define('print-report', function (User $user, string $module) {
            return $user->hasPermission($module, 'print');
        });

        Gate::define('export-data', function (User $user, string $module) {
            return $user->hasPermission($module, 'export');
        });

        Gate::define('import-data', function (User $user, string $module) {
            return $user->hasPermission($module, 'import');
        });
    }
}
