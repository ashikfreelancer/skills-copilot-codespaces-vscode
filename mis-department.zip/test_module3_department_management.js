// test_module3_department_management.js
// Automated verification for Module 3: Department Management
import http from 'http';

function request(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        let parsed = null;
        try {
          parsed = JSON.parse(body);
        } catch (e) {
          parsed = body;
        }
        resolve({ status: res.statusCode, headers: res.headers, body: parsed });
      });
    });
    req.on('error', reject);
    if (data) {
      req.write(typeof data === 'string' ? data : JSON.stringify(data));
    }
    req.end();
  });
}

async function runTests() {
  console.log('================================================================');
  console.log('TEST SUITE: MODULE 3 - DEPARTMENT MANAGEMENT');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${message}`);
      failed++;
    }
  }

  // 1. Test routes
  console.log('Step 1: Test routes');
  const routeGet = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/department-management',
    method: 'GET'
  });
  assert(routeGet.status === 200, 'GET /department-management returns 200 OK');
  assert(routeGet.body.includes('Department Management'), 'Blade view rendered successfully');

  // 2. Test controller & initial data query
  console.log('\nStep 2: Test controller & initial data query');
  const listRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management',
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(listRes.status === 200, 'GET /api/department-management returns 200');
  assert(listRes.body.success === true, 'API returns success: true');
  assert(Array.isArray(listRes.body.data) && listRes.body.data.length >= 6, `Initial seed loaded in SQLite (found ${listRes.body.data?.length} departments)`);
  assert(listRes.body.meta?.total >= 6, `Meta total count correct (${listRes.body.meta?.total})`);
  assert(listRes.body.meta?.active >= 6, `Meta active count correct (${listRes.body.meta?.active})`);

  // 3. Test validation
  console.log('\nStep 3: Test validation');
  const missingFields = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { name: '', code: '' });
  assert(missingFields.status === 422, 'POST with empty name/code returns 422 Unprocessable Entity');
  assert(missingFields.body.error === 'Validation Error', 'Validation error object returned');

  const dupCodeRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, {
    name: 'Unique Test Name ' + Date.now(),
    code: 'MIS-01' // Existing code from seed
  });
  assert(dupCodeRes.status === 422, 'POST with duplicate department code returns 422');

  // 4 & 5. Test Database & CRUD
  console.log('\nStep 4 & 5: Test Database & CRUD (CREATE, READ, VIEW, EDIT, UPDATE, DELETE)');
  const testCode = 'TST-' + Date.now().toString().slice(-4);
  const testName = 'Research & Development ' + Date.now().toString().slice(-4);

  const createRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, {
    name: testName,
    code: testCode,
    description: 'R&D Department for AI and Software Initiatives',
    status: 'Active'
  });

  assert(createRes.status === 201, 'POST /api/department-management creates record with 201');
  const createdId = createRes.body.data?.id;
  assert(createdId && createdId.startsWith('DEP-'), `Record ID generated correctly: ${createdId}`);

  // READ & VIEW
  const viewRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management/${createdId}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(viewRes.status === 200, 'GET /api/department-management/:id returns 200');
  assert(viewRes.body.data?.name === testName, 'Read exact created department name');
  assert(viewRes.body.data?.code === testCode, 'Read exact created department code');

  // SEARCH & FILTER
  const searchRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management?search=${encodeURIComponent(testCode)}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(searchRes.status === 200 && searchRes.body.data?.length === 1, 'Search by code returns exact 1 match');

  const filterRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management?status=Active`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(filterRes.status === 200 && filterRes.body.data?.length >= 7, 'Filter by Active status works');

  // SORT
  const sortRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management?sort_by=name&sort_order=desc`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(sortRes.status === 200, 'Sort by name DESC works');

  // UPDATE
  const updateRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management/${createdId}`,
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, {
    name: testName + ' (Updated)',
    code: testCode,
    description: 'Updated R&D Department description',
    status: 'Active'
  });
  assert(updateRes.status === 200, 'PUT /api/department-management/:id returns 200');
  assert(updateRes.body.data?.name === testName + ' (Updated)', 'Updated name verified');
  assert(updateRes.body.data?.description === 'Updated R&D Department description', 'Updated description verified');

  // STATUS & APPROVAL
  const statusRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management/${createdId}/status`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { status: 'Inactive' });
  assert(statusRes.status === 200, 'POST /api/department-management/:id/status updates status');
  assert(statusRes.body.status === 'Inactive', 'Status toggled to Inactive');

  // DELETE
  const deleteRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management/${createdId}`,
    method: 'DELETE',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(deleteRes.status === 200, 'DELETE /api/department-management/:id returns 200');

  const afterDeleteView = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management/${createdId}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(afterDeleteView.status === 404, 'Deleted record no longer exists (404)');

  // 6. Test permissions & authorization
  console.log('\nStep 6: Test Permissions & Authorization');
  const accountantDenied = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Accountant'
    }
  }, { name: 'Unauthorized Dept', code: 'UNAUTH-1' });
  assert(accountantDenied.status === 403, 'Accountant denied CREATE (403 Forbidden)');

  const operatorDenied = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/department-management/DEP-001`,
    method: 'DELETE',
    headers: { 'x-user-role': 'Computer Operator' }
  });
  assert(operatorDenied.status === 403, 'Computer Operator denied DELETE (403 Forbidden)');

  // 7. Test UI & HTML Elements
  console.log('\nStep 7: Test UI Elements');
  assert(routeGet.body.includes('id="depSearch"'), 'depSearch input present');
  assert(routeGet.body.includes('id="depStatus"'), 'depStatus dropdown present');
  assert(routeGet.body.includes('id="kTotal"'), 'kTotal counter present');
  assert(routeGet.body.includes('id="kActive"'), 'kActive counter present');
  assert(routeGet.body.includes('id="kInactive"'), 'kInactive counter present');
  assert(routeGet.body.includes('id="tableBody"'), 'tableBody present');
  assert(routeGet.body.includes('id="depModal"'), 'depModal present');
  assert(routeGet.body.includes('id="viewDepModal"'), 'viewDepModal present');
  assert(routeGet.body.includes('exportDepartments'), 'exportDepartments handler wired');
  assert(routeGet.body.includes('printPage'), 'printPage handler wired');

  // 8. Test JavaScript & Audit actions
  console.log('\nStep 8: Test JavaScript & Audit Actions (PRINT, EXPORT, AUDIT LOG)');
  const printActionRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management/action',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { action: 'print', reference: 'Department Master Records Report' });
  assert(printActionRes.status === 200, 'Print action logged successfully');

  const exportActionRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/department-management/action',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { action: 'export', reference: 'Department Master CSV Export' });
  assert(exportActionRes.status === 200, 'Export action logged successfully');

  // Check audit log contains entries for department-management
  const auditRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/audit-logs',
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  const auditLogs = auditRes.body.logs || auditRes.body.data || (Array.isArray(auditRes.body) ? auditRes.body : []);
  const hasDeptAudit = auditLogs.some(l => l.module === 'department-management' || l.reference?.includes('Department'));
  assert(hasDeptAudit, 'Audit log contains department-management activity records');

  // 9. Test related modules
  console.log('\nStep 9: Test Related Modules');
  const locRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(locRes.status === 200 && locRes.body.success === true, 'Module 1 (Location & Branch) operational');

  const dzRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management',
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(dzRes.status === 200 && dzRes.body.success === true, 'Module 2 (Domain & Zone) operational');

  const dashRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/dashboard',
    method: 'GET'
  });
  assert(dashRes.status === 200, 'Dashboard route operational');

  console.log('\n================================================================');
  console.log(`SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests().catch(err => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
