import http from 'http';

function request(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        let parsed = null;
        try {
          parsed = JSON.parse(body);
        } catch (e) {
          parsed = body;
        }
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data: parsed
        });
      });
    });

    req.on('error', reject);
    if (data) {
      req.write(typeof data === 'string' ? data : JSON.stringify(data));
    }
    req.end();
  });
}

const PORT = 3000;
const superAdminHeaders = {
  'Content-Type': 'application/json',
  'x-user-role': 'Super Admin',
  'x-user-name': 'Super Admin User'
};

async function run() {
  console.log('================================================================');
  console.log('TEST SUITE: MOVEMENT REGISTER & STOCK REGISTER (MYSQL/SQLITE)');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${message}`);
      failed++;
    }
  }

  // ==========================================
  // SECTION 1: BLADE PAGE VIEWS
  // ==========================================
  console.log('--- 1. Blade Views Accessibility ---');
  const mrViewRes = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/movement-register',
    method: 'GET'
  });
  assert(mrViewRes.statusCode === 200, 'GET /movement-register returns 200');
  assert(typeof mrViewRes.data === 'string' && mrViewRes.data.includes('Movement Register'), 'Movement Register Blade view renders');

  const stViewRes = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/stock-register',
    method: 'GET'
  });
  assert(stViewRes.statusCode === 200, 'GET /stock-register returns 200');
  assert(typeof stViewRes.data === 'string' && stViewRes.data.includes('Stock Register'), 'Stock Register Blade view renders');

  // ==========================================
  // SECTION 2: MOVEMENT REGISTER
  // ==========================================
  console.log('\n--- 2. Movement Register CRUD & Workflows ---');

  // 2.1 List & Metadata
  const mrList = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register',
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(mrList.statusCode === 200, 'GET /api/movement-register returns 200');
  assert(Array.isArray(mrList.data?.data) && mrList.data.data.length >= 3, `Initial movement seed records exist (${mrList.data?.data?.length} records)`);
  assert(mrList.data?.meta?.total >= 3, `Movement meta total is correct (${mrList.data?.meta?.total})`);

  // 2.2 Search & Filter
  const mrSearch = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register?search=' + encodeURIComponent('ইসহাক'),
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(mrSearch.statusCode === 200 && mrSearch.data?.data?.length >= 1, 'Search query filters correctly for employee');
  assert(mrSearch.data?.data?.[0]?.employee_name.includes('ইসহাক'), 'Matched employee name correctly');

  const mrFilterOut = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register?status=Out',
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(mrFilterOut.data?.data?.every(x => x.status === 'Out'), 'Filter by status="Out" works accurately');

  // 2.3 Form Validation
  const mrInvalidCreate = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register',
    method: 'POST',
    headers: superAdminHeaders
  }, { date: '', employee_id: '' });
  assert(mrInvalidCreate.statusCode === 422, 'Empty required fields rejected with 422 Unprocessable Entity');

  // 2.4 Create
  const testEmpId = '101-' + Math.floor(1000 + Math.random() * 9000);
  const newMovementPayload = {
    date: '2026-09-19',
    employee_id: testEmpId,
    employee_name: 'আহমেদ কবির',
    designation: 'Senior Officer (IT)',
    department: 'MIS Department',
    domain: 'অপারেশন-01',
    zone: 'ঢাকা কেন্দ্রীয়',
    location: 'প্রধান কার্যালয়',
    type: 'Official',
    out_time: '10:30',
    expected_return: '16:00',
    purpose: 'ডাটা সেন্টার নেটওয়ার্ক মেরামত',
    destination: 'মিরপুর জোন',
    contact: '01711-223344',
    vehicle: 'Pool Car',
    accompanied_by: 'কামাল হোসেন',
    approved_by: 'Super Admin',
    status: 'Out',
    remarks: 'জরুরী হার্ডওয়্যার প্রতিস্থাপন'
  };

  const createMr = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register',
    method: 'POST',
    headers: superAdminHeaders
  }, newMovementPayload);
  assert(createMr.statusCode === 201, 'POST /api/movement-register creates record with 201');
  const createdMrId = createMr.data?.data?.id;
  assert(!!createdMrId, `Created movement ID: ${createdMrId}`);

  // 2.5 View
  const viewMr = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/movement-register/${createdMrId}`,
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(viewMr.statusCode === 200 && viewMr.data?.data?.employee_name === 'আহমেদ কবির', 'GET single movement retrieves exact details');

  // 2.6 Update
  const updateMr = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/movement-register/${createdMrId}`,
    method: 'PUT',
    headers: superAdminHeaders
  }, {
    ...newMovementPayload,
    remarks: 'মেরামত সফলভাবে সম্পন্ন'
  });
  assert(updateMr.statusCode === 200 && updateMr.data?.data?.remarks === 'মেরামত সফলভাবে সম্পন্ন', 'PUT /api/movement-register updates movement fields');

  // 2.7 Return Tracking Workflow
  const returnMr = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/movement-register/${createdMrId}/return`,
    method: 'POST',
    headers: superAdminHeaders
  }, { actual_return: '16:45' }); // Expected was 16:00, actual is 16:45 -> should be Late Return!
  assert(returnMr.statusCode === 200, 'POST /return returns 200');
  assert(returnMr.data?.status === 'Late Return', 'Automatic Return Tracking marks overdue return as "Late Return"');
  assert(returnMr.data?.data?.actual_return === '16:45', 'Actual return timestamp recorded');

  // 2.8 Approval Workflow
  const approveMr = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/movement-register/${createdMrId}/approve`,
    method: 'POST',
    headers: superAdminHeaders
  }, { approved_by: 'Admin Approver' });
  assert(approveMr.statusCode === 200 && approveMr.data?.approved_by === 'Admin Approver', 'POST /approve updates approved_by and records approval');

  // 2.9 Print & Export Action Logging
  const logPrint = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register/action',
    method: 'POST',
    headers: superAdminHeaders
  }, { action: 'print', reference: 'Printed Movement List' });
  assert(logPrint.statusCode === 200, 'Movement print action logged');

  const logExport = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/movement-register/action',
    method: 'POST',
    headers: superAdminHeaders
  }, { action: 'export', reference: 'Exported Movement CSV' });
  assert(logExport.statusCode === 200, 'Movement export action logged');

  // 2.10 Delete
  const deleteMr = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/movement-register/${createdMrId}`,
    method: 'DELETE',
    headers: superAdminHeaders
  });
  assert(deleteMr.statusCode === 200, 'DELETE /api/movement-register removes record');

  // ==========================================
  // SECTION 3: STOCK REGISTER
  // ==========================================
  console.log('\n--- 3. Stock Register Item Master & Transactions ---');

  // 3.1 List Items with Live Balances & Metadata
  const stItemsRes = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/items',
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(stItemsRes.statusCode === 200, 'GET /api/stock-register/items returns 200');
  assert(Array.isArray(stItemsRes.data?.data) && stItemsRes.data.data.length >= 4, `Initial Stock Items loaded (${stItemsRes.data?.data?.length} items)`);
  assert(stItemsRes.data?.meta?.total_items >= 4, 'Stock item meta count correct');
  assert(stItemsRes.data?.meta?.total_qty > 0, `Total stock quantity calculated: ${stItemsRes.data?.meta?.total_qty}`);

  // 3.2 Create Item Master
  const testItemCode = 'IT-TEST-' + Math.floor(100 + Math.random() * 900);
  const newItem = {
    code: testItemCode,
    name: 'Dell Optical Mouse',
    category: 'IT Equipment',
    unit: 'Piece',
    opening: 40,
    min: 10,
    location: 'IT Store',
    supplier: 'Dell Authorized Supplier',
    status: 'Active'
  };

  const createItem = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/items',
    method: 'POST',
    headers: superAdminHeaders
  }, newItem);
  assert(createItem.statusCode === 201, 'POST /api/stock-register/items creates item with 201');
  const createdItemId = createItem.data?.data?.id;
  assert(!!createdItemId, `Created item ID: ${createdItemId}`);

  // 3.3 Prevent Duplicate Item Code
  const dupCode = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/items',
    method: 'POST',
    headers: superAdminHeaders
  }, newItem);
  assert(dupCode.statusCode === 422, 'Duplicate item code prevented with 422');

  // 3.4 View Item & Verify Initial Balance
  const viewItem = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/stock-register/items/${createdItemId}`,
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(viewItem.statusCode === 200 && viewItem.data?.data?.balance === 40, 'Initial balance equals opening stock (40)');
  assert(viewItem.data?.data?.warning === 'Available', 'Stock status is Available (40 > min 10)');

  // 3.5 Stock In (Receive)
  const txReceive = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/transactions',
    method: 'POST',
    headers: superAdminHeaders
  }, {
    date: '2026-09-19',
    item_id: createdItemId,
    type: 'Receive',
    qty: 20,
    unit_price: 650,
    location: 'IT Store',
    reference: 'GRN-2026-01',
    party: 'Dell Authorized Supplier',
    purpose: 'New shipment stock-in',
    approved_by: 'Super Admin'
  });
  assert(txReceive.statusCode === 201, 'Stock Receive (In) processed with 201');
  assert(txReceive.data?.data?.balance === 60, 'Stock balance incremented to 60 (40 + 20)');
  const rxId = txReceive.data?.data?.id;

  // 3.6 Prevent Invalid Stock Out (Exceeding Available Stock)
  const txExcessIssue = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/transactions',
    method: 'POST',
    headers: superAdminHeaders
  }, {
    date: '2026-09-19',
    item_id: createdItemId,
    type: 'Issue',
    qty: 100, // Available is 60!
    location: 'IT Store',
    reference: 'ISS-OVER',
    party: 'Test'
  });
  assert(txExcessIssue.statusCode === 422, 'Invalid stock issue (> available) blocked with 422');
  assert(txExcessIssue.data?.error?.toLowerCase().includes('insufficient stock'), 'Insufficient stock error message returned');

  // 3.7 Valid Stock Out (Issue) -> Triggers Minimum Stock Warning
  const txValidIssue = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/transactions',
    method: 'POST',
    headers: superAdminHeaders
  }, {
    date: '2026-09-19',
    item_id: createdItemId,
    type: 'Issue',
    qty: 52, // 60 - 52 = 8 <= min 10 -> Low stock warning!
    location: 'IT Store',
    reference: 'ISS-2026-02',
    party: 'MIS Zone Office',
    purpose: 'Distributed for workstations',
    approved_by: 'Super Admin'
  });
  assert(txValidIssue.statusCode === 201, 'Valid Stock Issue processed with 201');
  assert(txValidIssue.data?.data?.balance === 8, 'Balance decremented to 8 (60 - 52)');
  const issueId = txValidIssue.data?.data?.id;

  // Check Item Warning Status
  const checkWarning = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/stock-register/items/${createdItemId}`,
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(checkWarning.data?.data?.warning === 'Low', 'Minimum Stock Warning automatically triggered as "Low"');

  // 3.8 Stock Return Transaction
  const txReturn = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/stock-register/transactions',
    method: 'POST',
    headers: superAdminHeaders
  }, {
    date: '2026-09-19',
    item_id: createdItemId,
    type: 'Return',
    qty: 4, // 8 + 4 = 12
    location: 'IT Store',
    reference: 'RET-2026-01',
    party: 'MIS Zone Office',
    purpose: 'Surplus returned'
  });
  assert(txReturn.statusCode === 201 && txReturn.data?.data?.balance === 12, 'Stock Return processed, balance increased to 12');
  const retId = txReturn.data?.data?.id;

  // 3.9 Ledger Query
  const ledgerRes = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/stock-register/transactions?itemId=${createdItemId}`,
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(ledgerRes.statusCode === 200 && ledgerRes.data?.data?.length === 3, 'Ledger returns all 3 transactions for item');

  // 3.10 Integrity Protection: Prohibit Item Deletion while transactions exist
  const deleteBlocked = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/stock-register/items/${createdItemId}`,
    method: 'DELETE',
    headers: superAdminHeaders
  });
  assert(deleteBlocked.statusCode === 422, 'Deleting item with existing transactions blocked with 422');

  // Clean up transactions
  await request({ hostname: '127.0.0.1', port: PORT, path: `/api/stock-register/transactions/${rxId}`, method: 'DELETE', headers: superAdminHeaders });
  await request({ hostname: '127.0.0.1', port: PORT, path: `/api/stock-register/transactions/${issueId}`, method: 'DELETE', headers: superAdminHeaders });
  await request({ hostname: '127.0.0.1', port: PORT, path: `/api/stock-register/transactions/${retId}`, method: 'DELETE', headers: superAdminHeaders });

  // Delete item
  const deleteClean = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: `/api/stock-register/items/${createdItemId}`,
    method: 'DELETE',
    headers: superAdminHeaders
  });
  assert(deleteClean.statusCode === 200, 'Item deleted cleanly after transactions cleared');

  // ==========================================
  // SECTION 4: DASHBOARD STOCK FROM MYSQL/DB
  // ==========================================
  console.log('\n--- 4. Dashboard Stock Values from Database ---');
  const dashStock = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/dashboard/stock-summary',
    method: 'GET',
    headers: superAdminHeaders
  });
  assert(dashStock.statusCode === 200 && dashStock.data?.success === true, 'GET /api/dashboard/stock-summary returns 200');
  assert(typeof dashStock.data?.total_items === 'number' && dashStock.data.total_items >= 4, `Dashboard total items from DB: ${dashStock.data?.total_items}`);
  assert(typeof dashStock.data?.total_quantity === 'number' && dashStock.data.total_quantity > 0, `Dashboard total stock quantity from DB: ${dashStock.data?.total_quantity}`);

  // ==========================================
  // SECTION 5: AUDIT LOG VERIFICATION
  // ==========================================
  console.log('\n--- 5. Audit Log Persistence ---');
  const auditRes = await request({
    hostname: '127.0.0.1',
    port: PORT,
    path: '/api/audit-logs?limit=20',
    method: 'GET',
    headers: superAdminHeaders
  });
  const logs = auditRes.data?.data || [];
  const mrAudits = logs.filter(l => l.module === 'movement-register');
  const stockAudits = logs.filter(l => l.module === 'stock-register');
  assert(mrAudits.length > 0, `Movement Register audit logs captured (${mrAudits.length} entries)`);
  assert(stockAudits.length > 0, `Stock Register audit logs captured (${stockAudits.length} entries)`);

  // ==========================================
  // SUMMARY
  // ==========================================
  console.log('\n================================================================');
  console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

run().catch(err => {
  console.error('\nUNEXPECTED TEST ERROR:', err);
  process.exit(1);
});
