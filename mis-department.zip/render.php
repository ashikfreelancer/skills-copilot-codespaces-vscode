<?php
require __DIR__ . '/vendor/autoload.php';

use Illuminate\Container\Container;
use Illuminate\Events\Dispatcher;
use Illuminate\Filesystem\Filesystem;
use Illuminate\View\Compilers\BladeCompiler;
use Illuminate\View\Engines\CompilerEngine;
use Illuminate\View\Engines\EngineResolver;
use Illuminate\View\FileViewFinder;
use Illuminate\View\Factory;

$view = $argv[1] ?? 'index';
$dataJson = $argv[2] ?? '{}';
$data = json_decode($dataJson, true) ?: [];

$container = new Container();
$filesystem = new Filesystem();
$events = new Dispatcher($container);

$cachePath = __DIR__ . '/storage/framework/views';
if (!is_dir($cachePath)) {
    mkdir($cachePath, 0777, true);
}

$bladeCompiler = new BladeCompiler($filesystem, $cachePath);
$container->instance('blade.compiler', $bladeCompiler);
$container->instance(BladeCompiler::class, $bladeCompiler);

$resolver = new EngineResolver();
$resolver->register('blade', fn() => new CompilerEngine($bladeCompiler));

$finder = new FileViewFinder($filesystem, [__DIR__ . '/resources/views']);
$factory = new Factory($resolver, $finder, $events);
$factory->setContainer($container);

if (!function_exists('asset')) {
    function asset($path) {
        return '/' . ltrim($path, '/');
    }
}

if (!function_exists('url')) {
    function url($path = '') {
        return '/' . ltrim($path, '/');
    }
}

try {
    echo $factory->make($view, $data)->render();
} catch (\Throwable $e) {
    http_response_code(500);
    fwrite(STDERR, "Blade Render Error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    exit(1);
}
