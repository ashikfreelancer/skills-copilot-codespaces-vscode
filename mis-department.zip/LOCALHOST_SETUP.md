# Localhost Setup Guide (Windows 10 / XAMPP / PHP 8.2+ / MySQL)

This guide provides step-by-step instructions for deploying and running the **TMSS MIS Department Enterprise System** on your local machine using Windows 10, XAMPP (Apache + MySQL), and PHP 8.2+.

---

## 🛠 Prerequisites

1. **XAMPP for Windows** installed (default path: `C:\xampp`).
   - Start **Apache** and **MySQL** modules from the XAMPP Control Panel.
2. **PHP Version:** PHP 8.2.12 or higher (`C:\xampp\php\php.exe -v`).
3. **Composer:** Installed globally or via `composer.phar`.
4. **Git / PowerShell** installed.

---

## 🚀 Step-by-Step Setup Commands

Open **PowerShell** (no Administrator privileges required):

### Step 1: Navigate to Project Directory
```powershell
cd C:\xampp\htdocs\mis-department
```

### Step 2: Configure Environment
Copy `.env.example` to `.env`:
```powershell
Copy-Item .env.example .env
```
Open `.env` in Notepad and verify MySQL settings:
```ini
APP_NAME="MIS Department"
APP_ENV=local
APP_KEY=base64:c29tZXJhbmRvbXNlY3JldGtleWZvcm1pc2RlcHQyMDI2=
APP_DEBUG=true
APP_URL=http://127.0.0.1:8000

# Database Configuration
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=mis_department
DB_USERNAME=root
DB_PASSWORD=
```

### Step 3: Install PHP Dependencies
```powershell
composer install --optimize-autoloader
```

### Step 4: Create Empty Database & Import Schema
1. Open phpMyAdmin (`http://localhost/phpmyadmin`) or run via MySQL CLI:
```powershell
C:\xampp\mysql\bin\mysql.exe -u root -e "CREATE DATABASE IF NOT EXISTS mis_department DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```
2. Import the complete master schema & initial data:
```powershell
C:\xampp\mysql\bin\mysql.exe -u root mis_department < database\mysql_schema.sql
```

### Step 5: Clear and Verify Cache
```powershell
C:\xampp\php\php.exe artisan optimize:clear
C:\xampp\php\php.exe artisan migrate:status
C:\xampp\php\php.exe artisan route:list
```

### Step 6: Start Local Development Server
```powershell
C:\xampp\php\php.exe artisan serve --host=127.0.0.1 --port=8000
```
Open your browser and navigate to:  
👉 **`http://127.0.0.1:8000`** (or `http://localhost:8000`)

---

## 🔑 Default User Credentials

| Role | Username / Email | Password | Access Scope |
|---|---|---|---|
| **Super Admin** | `admin@mis.org` | `password123` | Full system access to all 22 modules & branding |
| **Branch Manager** | `manager@mis.org` | `password123` | Operational data entry, approvals, reports |
| **Accountant** | `accountant@mis.org` | `password123` | Advances, stocks, financial reports |
| **Computer Operator** | `operator@mis.org` | `password123` | Data entry & daily registers |

---

## 🔧 Troubleshooting Guide

| Issue | Root Cause | Solution |
|---|---|---|
| **1045 Access Denied for user 'root'@'localhost'** | MySQL password in `.env` doesn't match local XAMPP root password | If root has no password in XAMPP, keep `DB_PASSWORD=` blank. If a password was set, update `.env`. |
| **419 Page Expired** | CSRF token mismatch on form submission | Click back, refresh the page, or ensure cookies/sessions are enabled in the browser. |
| **Blank charts in Analytics / Dashboard** | amCharts CDN script blocked or offline | Ensure internet access is available on first load to fetch amCharts CDN resources. |
| **Images not loading** | Asset directory permissions | Ensure `public/assets/images/` is readable by the web server. |
