<?php

return [
    /*
    |--------------------------------------------------------------------------
    | MIS Enterprise Configuration
    |--------------------------------------------------------------------------
    */
    'organization_name' => 'TMSS Management Information System',
    'system_code' => 'MIS-ERP-2026',
    'fiscal_year' => '2026-2027',

    'limits' => [
        'max_advance_amount' => 500000,
        'max_advance_installments' => 60,
        'default_reorder_level' => 15,
        'audit_log_retention_days' => 365,
    ],

    'leave_defaults' => [
        'casual_days' => 14,
        'sick_days' => 14,
        'earned_days' => 20,
        'maternity_days' => 120,
        'special_days' => 10,
    ],

    'supported_roles' => [
        'admin' => 'System Administrator',
        'manager' => 'Operations Manager',
        'officer' => 'MIS Field Officer',
        'viewer' => 'Auditor / Viewer',
    ],

    'modules' => [
        'dashboard',
        'location-branch',
        'domain-zone-management',
        'department-management',
        'staff-position-list',
        'leave-management',
        'movement-register',
        'stock-register',
        'mis-data-entry',
        'advance-management',
        'target-activity',
        'monitoring',
        'reports',
        'report-requests',
        'analytics',
        'notifications',
        'users-permissions',
        'note-document-cabinet',
        'excel-import-export',
        'backup-settings',
        'data-quality',
        'audit-log',
    ],
];
