<?php

return [

    'name' => env('APP_NAME', 'MIS Department'),

    'env' => env('APP_ENV', 'production'),

    'debug' => (bool) env('APP_DEBUG', false),

    'url' => env('APP_URL', 'http://localhost:3000'),

    'timezone' => 'Asia/Dhaka',

    'locale' => 'en',

    'fallback_locale' => 'en',

    'faker_locale' => 'en_US',

    'cipher' => 'AES-256-CBC',

    'key' => env('APP_KEY', 'base64:c29tZXJhbmRvbXNlY3JldGtleWZvcm1pc2RlcHQyMDI2='),

    'previous_keys' => [
        ...array_filter(
            explode(',', env('APP_PREVIOUS_KEYS', ''))
        ),
    ],

    'maintenance' => [
        'driver' => 'file',
    ],

];
