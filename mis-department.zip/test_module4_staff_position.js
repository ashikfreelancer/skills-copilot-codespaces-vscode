import http from 'http';

function makeRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        let parsed = null;
        try {
          parsed = JSON.parse(body);
        } catch (e) {
          parsed = body;
        }
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data: parsed
        });
      });
    });

    req.on('error', (e) => reject(e));

    if (postData) {
      const dataStr = typeof postData === 'string' ? postData : JSON.stringify(postData);
      req.setHeader('Content-Type', 'application/json');
      req.setHeader('Content-Length', Buffer.byteLength(dataStr));
      req.write(dataStr);
    }
    req.end();
  });
}

async function runTests() {
  console.log('--- STARTING MODULE 4: STAFF POSITION LIST 9-STEP TEST SUITE ---');
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${message}`);
      failed++;
    }
  }

  try {
    // -------------------------------------------------------------
    // 1. Test routes
    // -------------------------------------------------------------
    console.log('\nStep 1: Testing Routes...');
    const htmlRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/staff-position-list',
      method: 'GET'
    });
    assert(htmlRes.statusCode === 200, 'GET /staff-position-list returns status 200');
    assert(typeof htmlRes.data === 'string' && htmlRes.data.includes('Staff Position List'), 'HTML response contains page title');
    assert(!htmlRes.data.includes('MIS_SHARED_KEYS.staff'), 'HTML view has NO legacy localStorage staff keys');

    const apiListRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list',
      method: 'GET'
    });
    assert(apiListRes.statusCode === 200, 'GET /api/staff-position-list returns 200');
    assert(apiListRes.data.success === true, 'API returns success: true');
    assert(Array.isArray(apiListRes.data.data), 'API returns an array of staff positions');

    // -------------------------------------------------------------
    // 2. Test controller & pagination
    // -------------------------------------------------------------
    console.log('\nStep 2: Testing Controller & Metadata...');
    assert(apiListRes.data.pagination && typeof apiListRes.data.pagination.total === 'number', 'Response has pagination metadata');
    assert(apiListRes.data.meta && Array.isArray(apiListRes.data.meta.departments), 'Response returns departments list');
    assert(apiListRes.data.meta && Array.isArray(apiListRes.data.meta.positions), 'Response returns positions list');
    assert(apiListRes.data.meta && Array.isArray(apiListRes.data.meta.districts), 'Response returns districts list');

    // -------------------------------------------------------------
    // 3. Test validation
    // -------------------------------------------------------------
    console.log('\nStep 3: Testing Validation...');
    const emptyCreate = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list',
      method: 'POST'
    }, {});
    assert(emptyCreate.statusCode === 422, 'Empty POST returns 422 Unprocessable Entity');
    assert(emptyCreate.data.errors && emptyCreate.data.errors.name, 'Validation catches missing name');
    assert(emptyCreate.data.errors && emptyCreate.data.errors.staff_id, 'Validation catches missing staff_id');
    assert(emptyCreate.data.errors && emptyCreate.data.errors.designation, 'Validation catches missing designation');
    assert(emptyCreate.data.errors && emptyCreate.data.errors.department, 'Validation catches missing department');

    // Duplicate staff_id test
    const dupTest = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list',
      method: 'POST'
    }, {
      name: 'Duplicate Staff',
      staff_id: 'TMSS-001',
      designation: 'Officer',
      department: 'MIS'
    });
    assert(dupTest.statusCode === 422, 'Duplicate staff_id returns 422');
    assert(dupTest.data.errors && dupTest.data.errors.staff_id.includes('already exists'), 'Validation error message specifies duplicate ID');

    // -------------------------------------------------------------
    // 4. Test CRUD (Create, Read, Update, Delete)
    // -------------------------------------------------------------
    console.log('\nStep 4: Testing CRUD Operations...');
    const uniqueStaffId = 'TMSS-' + Date.now().toString().slice(-4);
    const createRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list',
      method: 'POST'
    }, {
      serial: '99',
      name: 'Test Automation Officer',
      gender: 'Male',
      dob: '1991-04-12',
      father: 'Md. Automation Father',
      mother: 'Mrs. Automation Mother',
      staff_id: uniqueStaffId,
      designation: 'Senior Quality Officer',
      department: 'MIS',
      join_date: '2021-01-10',
      posting_date: '2024-05-01',
      promotion_date: '2025-01-01',
      education: 'MSc in Software Engineering',
      home_district: 'Bogura',
      previous_posting: 'Bogura Zone',
      current_posting: 'Head Office',
      status: 'Active'
    });

    assert(createRes.statusCode === 201, 'POST /api/staff-position-list returns 201 Created');
    assert(createRes.data.success === true, 'Create response success is true');
    assert(createRes.data.data.name === 'Test Automation Officer', 'Created record contains matching name');
    const createdId = createRes.data.data.id;

    // Read single
    const readRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}`,
      method: 'GET'
    });
    assert(readRes.statusCode === 200, 'GET /api/staff-position-list/:id returns 200');
    assert(readRes.data.data.id === createdId, 'Read record matches created ID');

    // Update single
    const updateRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}`,
      method: 'PUT'
    }, {
      name: 'Updated Automation Officer',
      staff_id: uniqueStaffId,
      designation: 'Lead Quality Specialist',
      department: 'IT',
      status: 'Active'
    });
    assert(updateRes.statusCode === 200, 'PUT /api/staff-position-list/:id returns 200');
    assert(updateRes.data.data.name === 'Updated Automation Officer', 'Record updated with new name');
    assert(updateRes.data.data.designation === 'Lead Quality Specialist', 'Record updated with new designation');
    assert(updateRes.data.data.department === 'IT', 'Record updated with new department');

    // -------------------------------------------------------------
    // 5. Test status / approval workflow
    // -------------------------------------------------------------
    console.log('\nStep 5: Testing Status / Approval Workflow...');
    const statusRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}/status`,
      method: 'POST'
    }, { status: 'On Leave' });
    assert(statusRes.statusCode === 200, 'POST /api/staff-position-list/:id/status returns 200');
    assert(statusRes.data.status === 'On Leave', 'Status successfully changed to On Leave');

    // Verify in database
    const verifyStatus = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}`,
      method: 'GET'
    });
    assert(verifyStatus.data.data.status === 'On Leave', 'Verified status in DB is On Leave');

    // -------------------------------------------------------------
    // 6. Test permissions & RBAC
    // -------------------------------------------------------------
    console.log('\nStep 6: Testing Permissions & RBAC...');
    // Computer Operator should have view, create, edit, print, BUT NOT DELETE or APPROVE
    const opView = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list',
      method: 'GET',
      headers: { 'x-user-role': 'Computer Operator' }
    });
    assert(opView.statusCode === 200, 'Computer Operator CAN view staff positions (200)');

    const opDelete = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}`,
      method: 'DELETE',
      headers: { 'x-user-role': 'Computer Operator' }
    });
    assert(opDelete.statusCode === 403, 'Computer Operator CANNOT delete staff positions (403 Forbidden)');

    const opApprove = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}/status`,
      method: 'POST',
      headers: { 'x-user-role': 'Computer Operator' }
    }, { status: 'Inactive' });
    assert(opApprove.statusCode === 403, 'Computer Operator CANNOT approve/change status (403 Forbidden)');

    // Accountant should have NO access to staff-position-list
    const accView = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list',
      method: 'GET',
      headers: { 'x-user-role': 'Accountant' }
    });
    assert(accView.statusCode === 403, 'Accountant CANNOT view staff positions (403 Forbidden)');

    // -------------------------------------------------------------
    // 7. Test Search, Filter, Sort
    // -------------------------------------------------------------
    console.log('\nStep 7: Testing Search, Filter, and Sort...');
    // Search
    const searchRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list?search=${encodeURIComponent('Updated Automation')}`,
      method: 'GET'
    });
    assert(searchRes.data.data.length >= 1, 'Search query correctly found the record');

    // Department filter
    const deptFilterRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list?department=IT`,
      method: 'GET'
    });
    assert(deptFilterRes.data.data.every(r => r.department === 'IT'), 'Department filter returns only IT staff');

    // Status filter
    const statusFilterRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list?status=On%20Leave`,
      method: 'GET'
    });
    assert(statusFilterRes.data.data.every(r => r.status === 'On Leave'), 'Status filter returns only On Leave staff');

    // Sorting
    const sortRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list?sort_by=name&sort_order=asc`,
      method: 'GET'
    });
    const names = sortRes.data.data.map(r => r.name);
    const sortedNames = [...names].sort();
    assert(JSON.stringify(names) === JSON.stringify(sortedNames), 'Records are correctly sorted by name ASC');

    // -------------------------------------------------------------
    // 8. Test Action Logger (Print & Export)
    // -------------------------------------------------------------
    console.log('\nStep 8: Testing Print & Export Action Auditing...');
    const printRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list/action',
      method: 'POST'
    }, {
      action: 'print',
      reference: 'Automated Print Audit Test'
    });
    assert(printRes.statusCode === 200, 'Print action returns 200');

    const exportRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/staff-position-list/action',
      method: 'POST'
    }, {
      action: 'export',
      reference: 'Automated Export Audit Test'
    });
    assert(exportRes.statusCode === 200, 'Export action returns 200');

    // -------------------------------------------------------------
    // 9. Test Delete & Audit Log Verification
    // -------------------------------------------------------------
    console.log('\nStep 9: Testing Delete and Audit Logs...');
    const deleteRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}`,
      method: 'DELETE'
    });
    assert(deleteRes.statusCode === 200, 'DELETE /api/staff-position-list/:id returns 200');

    // Verify record is gone
    const verifyDeleted = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/staff-position-list/${createdId}`,
      method: 'GET'
    });
    assert(verifyDeleted.statusCode === 404, 'Verified deleted record returns 404 Not Found');

    // Verify audit logs captured the events
    const auditRes = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/audit-log',
      method: 'GET'
    });
    assert(auditRes.statusCode === 200, 'Audit log endpoint returns 200');
    const logs = auditRes.data.logs || [];
    const staffLogs = logs.filter(l => l.module === 'staff-position-list');
    assert(staffLogs.length >= 4, `Staff position actions logged in audit log (found ${staffLogs.length})`);
    assert(staffLogs.some(l => l.action === 'CREATE'), 'Audit log contains staff CREATE');
    assert(staffLogs.some(l => l.action === 'UPDATE'), 'Audit log contains staff UPDATE');
    assert(staffLogs.some(l => l.action === 'APPROVE'), 'Audit log contains staff APPROVE');
    assert(staffLogs.some(l => l.action === 'DELETE'), 'Audit log contains staff DELETE');

  } catch (err) {
    console.error('Unexpected error during tests:', err);
    failed++;
  }

  console.log(`\n========================================`);
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log(`========================================\n`);

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests();
