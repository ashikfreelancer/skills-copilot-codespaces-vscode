import http from 'http';
import { getDb } from './database/db.js';

function request(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve({ status: res.statusCode, headers: res.headers, body: parsed, raw: body });
        } catch (e) {
          resolve({ status: res.statusCode, headers: res.headers, body, raw: body });
        }
      });
    });
    req.on('error', reject);
    if (data) {
      req.write(typeof data === 'string' ? data : JSON.stringify(data));
    }
    req.end();
  });
}

async function runTests() {
  console.log('=== STARTING TESTS: MODULE 1 (LOCATION & BRANCH) ===\n');
  let passed = 0;
  let failed = 0;

  function assert(cond, desc) {
    if (cond) {
      console.log(`✅ PASS: ${desc}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${desc}`);
      failed++;
    }
  }

  // 1. Test routes
  console.log('\n--- 1. Testing Routes ---');
  const pageRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/location-branch',
    method: 'GET'
  });
  assert(pageRes.status === 200, 'GET /location-branch returns HTTP 200');
  assert(pageRes.raw.includes('Location &amp; Branch') || pageRes.raw.includes('Location & Branch'), 'Page HTML contains module title');
  assert(pageRes.raw.includes('locationModal'), 'Page contains #locationModal for branch management');
  assert(pageRes.raw.includes('masterLocationModal'), 'Page contains #masterLocationModal for administrative hierarchy');

  // 2. Test Controller & Read
  console.log('\n--- 2. Testing Controller & Read ---');
  const branchesRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'GET'
  });
  assert(branchesRes.status === 200, 'GET /api/location-branch/branches returns HTTP 200');
  assert(branchesRes.body.success === true, 'Response indicates success: true');
  assert(Array.isArray(branchesRes.body.data), 'Returns an array of branches');
  assert(branchesRes.body.pagination && branchesRes.body.pagination.total >= 3, 'Pagination metadata exists with records');

  const adminLocRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/administrative',
    method: 'GET'
  });
  assert(adminLocRes.status === 200, 'GET /api/location-branch/administrative returns HTTP 200');
  assert(adminLocRes.body.data.length >= 10, 'Default administrative locations seeded properly');

  // 3. Test Validation
  console.log('\n--- 3. Testing Validation ---');
  const invalidBranchRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, { division: 'Dhaka' }); // missing required fields
  assert(invalidBranchRes.status === 422, 'POST with missing required fields returns HTTP 422');
  assert(invalidBranchRes.body.error === 'Validation Error', 'Validation error message returned');

  // Test duplicate code validation
  const duplicateBranchRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {
    division: 'Dhaka',
    district: 'Dhaka',
    thana: 'Savar',
    upazila: 'Savar',
    branch: 'Duplicate Test Branch',
    code: 'DHK-001' // already exists
  });
  assert(duplicateBranchRes.status === 422, 'POST with existing branch code returns HTTP 422 (Unique constraint)');

  // 4. Test Database
  console.log('\n--- 4. Testing Database (SQL queries directly) ---');
  const db = await getDb();
  const dbBranchCount = db.query("SELECT count(*) as count FROM branches");
  assert(dbBranchCount[0].count >= 3, `SQL database contains ${dbBranchCount[0].count} branch rows`);

  const dbAdminCount = db.query("SELECT count(*) as count FROM administrative_locations");
  assert(dbAdminCount[0].count >= 13, `SQL database contains ${dbAdminCount[0].count} administrative location rows`);

  // 5. Test CRUD
  console.log('\n--- 5. Testing CRUD (Create, Read, View, Update, Delete, Status Approval) ---');
  const testCode = 'TEST-' + Date.now();
  const createRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {
    division: 'Dhaka',
    district: 'Dhaka',
    thana: 'Savar',
    upazila: 'Savar',
    union_name: 'Dhamsona',
    ward: '05',
    branch: 'Automated Test Branch',
    code: testCode,
    manager: 'Test Manager',
    mobile: '01711-999888',
    personal_mobile: '01811-999888',
    email: 'testbranch@mis.gov.bd',
    status: 'Active',
    address: 'Test Plot 42, Baipail, Savar'
  });
  assert(createRes.status === 201, 'CREATE: Successfully created new branch (HTTP 201)');
  const createdId = createRes.body.data.id;
  assert(createdId && createdId.startsWith('LOC-'), `Created branch ID generated: ${createdId}`);

  // READ / VIEW Single
  const viewRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/location-branch/branches/${createdId}`,
    method: 'GET'
  });
  assert(viewRes.status === 200, 'VIEW: Single branch endpoint returns HTTP 200');
  assert(viewRes.body.data.branch === 'Automated Test Branch', 'Branch name verified correctly');

  // UPDATE
  const updateRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/location-branch/branches/${createdId}`,
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' }
  }, {
    branch: 'Automated Test Branch (Updated)',
    manager: 'Updated Manager Name'
  });
  assert(updateRes.status === 200, 'UPDATE: Updated branch details successfully (HTTP 200)');
  assert(updateRes.body.data.branch === 'Automated Test Branch (Updated)', 'Updated branch name confirmed');

  // STATUS / APPROVAL
  const statusRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/location-branch/branches/${createdId}/status`,
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, { status: 'Review' });
  assert(statusRes.status === 200, 'STATUS/APPROVAL: Status change to Review succeeded');
  assert(statusRes.body.status === 'Review', 'Status change confirmed in response');

  // SEARCH & FILTER
  const searchRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/location-branch/branches?search=${encodeURIComponent('Updated Manager Name')}`,
    method: 'GET'
  });
  assert(searchRes.status === 200 && searchRes.body.data.length >= 1, 'SEARCH: Branch found via manager name search query');

  // DELETE
  const deleteRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/location-branch/branches/${createdId}`,
    method: 'DELETE'
  });
  assert(deleteRes.status === 200, 'DELETE: Branch deleted successfully (HTTP 200)');

  const verifyDeleted = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/location-branch/branches/${createdId}`,
    method: 'GET'
  });
  assert(verifyDeleted.status === 404, 'Branch is no longer accessible (HTTP 404)');

  // 6. Test Permissions
  console.log('\n--- 6. Testing Permissions & Role Authorization ---');
  // Request with non-existent or unauthorized user header
  const unauthorizedRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-email': 'unauthorized_user@example.com'
    }
  }, { division: 'Dhaka', code: 'UNAUTH-01', branch: 'Unauth Branch' });
  // The system checks permissions for unauthorized user and rejects with 403 or falls back
  console.log(`Unauthorized attempt response status: ${unauthorizedRes.status}`);
  assert([403, 422].includes(unauthorizedRes.status), 'Unauthorized user prevented or validated');

  // 7. Test UI & 8. JavaScript
  console.log('\n--- 7 & 8. Testing UI & JavaScript Integration ---');
  assert(pageRes.raw.includes('masterFetch'), 'Blade contains masterFetch() for async API sync');
  assert(pageRes.raw.includes('locFetch'), 'Blade contains locFetch() for async API sync');
  assert(pageRes.raw.includes('printLocationReport'), 'Blade contains printLocationReport()');
  assert(pageRes.raw.includes('downloadLocationPDF'), 'Blade contains downloadLocationPDF()');
  assert(pageRes.raw.includes('downloadLocationExcel'), 'Blade contains downloadLocationExcel()');

  // 9. Test Related Modules (Audit Log Traceability)
  console.log('\n--- 9. Testing Related Modules (Audit Logs) ---');
  const auditRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/audit-logs',
    method: 'GET'
  });
  assert(auditRes.status === 200, 'GET /api/audit-logs returns HTTP 200');
  const logs = auditRes.body.data || [];
  const moduleLogs = logs.filter(l => l.module === 'location-branch');
  assert(moduleLogs.length > 0, `Found ${moduleLogs.length} audit log entries for location-branch module`);
  const actionsLogged = moduleLogs.map(l => l.action);
  console.log('Logged actions for location-branch:', actionsLogged);
  assert(actionsLogged.includes('CREATE'), 'CREATE action recorded in audit log');
  assert(actionsLogged.includes('UPDATE'), 'UPDATE action recorded in audit log');
  assert(actionsLogged.includes('APPROVE'), 'APPROVE action recorded in audit log');
  assert(actionsLogged.includes('DELETE'), 'DELETE action recorded in audit log');

  console.log(`\n=== SUMMARY: ${passed} PASSED, ${failed} FAILED ===\n`);
  process.exit(failed === 0 ? 0 : 1);
}

runTests().catch(err => {
  console.error('Test execution error:', err);
  process.exit(1);
});
