# TMSS MIS Department Enterprise Software
### টিএমএসএস এমআইএস ডিপার্টমেন্ট এন্টারপ্রাইজ সিস্টেম

---

## 📋 সূচিপত্র (Table of Contents)
1. [প্রজেক্ট পরিচিতি (Overview)](#-প্রজেক্ট-পরিচিতি-overview)
2. [সিস্টেম রিকোয়ারমেন্টস (System Requirements)](#-সিস্টেম-রিকোয়ারমেন্টস-system-requirements)
3. [লোকালহোস্টে চালানোর সহজ ধাপসমূহ (Run on Localhost - Quick Start)](#-লোকালহোস্টে-চালানোর-সহজ-ধাপসমূহ-run-on-localhost---quick-start)
4. [MySQL ডাটাবেজ সেটআপ ও ইমপোর্ট গাইড (MySQL / phpMyAdmin Setup)](#-mysql-ডাটাবেজ-সেটআপ-ও-ইমপোর্ট-গাইড-mysql--phpmyadmin-setup)
5. [ডিফল্ট লগইন ইউজার তথ্য (Default Login Credentials)](#-ডিফল্ট-লগইন-ইউজার-তথ্য-default-login-credentials)
6. [প্রজেক্টের মূল ফিচারসমূহ (Key Features & Modules)](#-প্রজেক্টের-মূল-ফিচারসমূহ-key-features--modules)
7. [সমস্যা ও সমাধান (Troubleshooting / FAQ)](#-সমস্যা-ও-সমাধান-troubleshooting--faq)

---

## 🌟 প্রজেক্ট পরিচিতি (Overview)
টিএমএসএস (TMSS) এমআইএস ডিপার্টমেন্টের জন্য তৈরি এটি একটি পূর্ণাঙ্গ, স্বয়ংসম্পূর্ণ এন্টারপ্রাইজ ম্যানেজমেন্ট সফটওয়্যার। এতে রয়েছে শাখা নেটওয়ার্ক (১,২৮৭+ শাখা), ডিপার্টমেন্ট ব্যবস্থাপনা, কর্মকর্তা-কর্মচারী ডাটাবেজ (৮,৬৪৭+ কর্মী), স্টক ও ইনভেন্টরি কন্ট্রোল, মুভমেন্ট রেজিস্টার, ছুটি ব্যবস্থাপনা, অগ্রিম প্রদান, ডাইনামিক ফিল্টারযোগ্য রিপোর্ট জেনারেটর এবং রোল-বেসড এক্সেস কন্ট্রোল (RBAC)।

---

## 💻 সিস্টেম রিকোয়ারমেন্টস (System Requirements)
আপনার কম্পিউটারে নিচের সফটওয়্যারগুলো ইনস্টল করা থাকতে হবে:
- **Node.js**: সংস্করণ 18.x বা তার বেশি (LTS ভার্সন রিকমেন্ডেড) — [Node.js ডাউনলোড করুন](https://nodejs.org)
- **NPM**: Node.js ইনস্টল করলে স্বয়ংক্রিয়ভাবে ইনস্টল হয়ে যায়
- **ব্রাউজার**: Google Chrome, Mozilla Firefox, Microsoft Edge বা Brave
- *(ঐচ্ছিক / Optional)* **MySQL / phpMyAdmin / XAMPP / Laragon**: যদি MySQL ডাটাবেজ ব্রাউজ বা ইমপোর্ট করতে চান

---

## 🚀 লোকালহোস্টে চালানোর সহজ ধাপসমূহ (Run on Localhost - Quick Start)

প্রজেক্টটি সরাসরি Node.js এবং বিল্ট-ইন ডাটাবেজ দিয়ে কয়েক সেকেন্ডে চালু করা যায়:

### ধাপ ১: প্রজেক্ট ফোল্ডারটি ওপেন করুন
টার্মিনাল (Terminal), কমান্ড প্রম্পট (CMD) অথবা VS Code-এর টার্মিনালে প্রজেক্টের রুট ফোল্ডারে যান:
```bash
cd mis-department
```

### ধাপ ২: ডিপেন্ডেন্সি ইনস্টল করুন
প্রজেক্টে ব্যবহৃত প্যাকেজগুলো ইনস্টল করতে টার্মিনালে লিখুন:
```bash
npm install
```

### ধাপ ৩: লোকাল সার্ভার রান করুন
ডেভেলপমেন্ট সার্ভার চালু করতে নিচের কমান্ডটি দিন:
```bash
npm run dev
```
অথবা:
```bash
node server.js
```

### ধাপ ৪: ব্রাউজারে অ্যাপটি চালু করুন
সার্ভার চালু হলে টার্মিনালে মেসেজ দেখতে পাবেন:
```text
TMSS MIS Department Enterprise System running on http://localhost:3000
```
এখন আপনার ব্রাউজার খুলে অ্যাড্রেস বারে যান:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 🗄️ MySQL ডাটাবেজ সেটআপ ও ইমপোর্ট গাইড (MySQL / phpMyAdmin Setup)

প্রজেক্টের `database/mysql_schema.sql` ফাইলে সম্পূর্ণ ডাটাবেজ স্কিমা এবং প্রাথমিক ডাটা সুন্দরভাবে সাজিয়ে রাখা হয়েছে।

### পদ্ধতি ১: phpMyAdmin দিয়ে ইমপোর্ট (XAMPP / WAMP / Laragon)
1. **XAMPP / Laragon** চালু করে **Apache** এবং **MySQL** স্টার্ট করুন।
2. ব্রাউজারে যান: `http://localhost/phpmyadmin`
3. উপরে থাকা **"Import"** ট্যাবে ক্লিক করুন।
4. **"Choose File"** এ ক্লিক করে আপনার প্রজেক্টের `database/mysql_schema.sql` ফাইলটি নির্বাচন করুন।
5. স্ক্রিনের নিচে থাকা **"Import"** বা **"Go"** বাটনে ক্লিক করুন।
6. SQL ফাইলটিতে স্বয়ংক্রিয়ভাবে `CREATE DATABASE IF NOT EXISTS mis_department;` এবং `USE mis_department;` কমান্ড দেওয়া আছে, তাই আলাদা করে ডাটাবেজ তৈরি না করলেও নিজে থেকেই ডাটাবেজ ও সব টেবিল ডাটা সহ তৈরি হয়ে যাবে।

### পদ্ধতি ২: MySQL কমান্ড লাইনে সরাসরি ইমপোর্ট (Command Line)
```bash
mysql -u root -p < database/mysql_schema.sql
```
*(পাসওয়ার্ড থাকলে পাসওয়ার্ড দিন, নতুবা Enter চাপুন)*

### ডাটাবেজ কনফিগারেশন (.env)
প্রজেক্টের `.env.example` ফাইলের কপি করে `.env` ফাইল তৈরি করে প্রয়োজনমতো কনফিগার করতে পারেন:
```env
DB_CONNECTION=sqlite
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=mis_department
DB_USERNAME=root
DB_PASSWORD=
```

---

## 🔑 ডিফল্ট লগইন ইউজার তথ্য (Default Login Credentials)

সফটওয়্যারে বিভিন্ন রোলের জন্য নিচের যেকোনো একাউন্ট দিয়ে তাৎক্ষণিক লগইন করতে পারবেন:

| রোল (Role) | ইমেইল (Email) | পাসওয়ার্ড (Password) | সুবিধা / পারমিশন |
| :--- | :--- | :--- | :--- |
| **Super Admin** | `superadmin@mis.local` | `password` (বা `123456`) | সকল ২৩টি মডিউলের সম্পূর্ণ এক্সেস ও কন্ট্রোল |
| **TMSS Admin** | `admin@tmss.org` | `password` | সিস্টেম অ্যাডমিনিস্ট্রেশন ও কনফিগারেশন |
| **Computer Operator** | `operator@mis.local` | `password` | ডাটা এন্ট্রি, ভিউ এবং প্রিন্ট |
| **Accountant** | `accountant@mis.local` | `password` | অ্যাকাউন্টস, অগ্রিম ও ফিনান্সিয়াল রিপোর্ট |
| **MIS Reviewer** | `reviewer@mis.local` | `password` | পর্যবেক্ষণ, অনুমোদন ও এক্সপোর্ট |
| **Data Entry Officer** | `zone.officer@mis.local` | `password` | জোন ওয়াইজ এমআইএস ডাটা সাবমিশন |

---

## 📁 প্রজেক্ট স্ট্রাকচার (Project Structure)

```text
├── assets/
│   ├── css/app.css           # মূল সিএসএস ও থিমিং
│   ├── js/app.js             # ফ্রন্টএন্ড কোর ডাইনামিক ইঞ্জিন
│   ├── js/stock-register.js  # স্টক রেজিস্টার ক্লায়েন্ট লজিক
│   └── images/tmss-logo.png  # টিএমএসএস অফিসিয়াল ব্র্যান্ড লোগো
├── database/
│   ├── database.sqlite       # প্রস্তুতকৃত সম্পূর্ণ লোকাল ডাটাবেজ
│   ├── db.js                 # ডাটাবেজ কানেক্টর ও হেল্পার ফাংশন
│   └── mysql_schema.sql      # পূর্ণাঙ্গ ক্লিন MySQL স্কিমা ও সীড ফাইল
├── resources/
│   └── views/                # ব্লেড টেমপ্লেট ভিউ ফাইলসমূহ
├── server.js                 # নোড.জেএস ব্যাকএন্ড সার্ভার ও রেস্ট এপিআই (REST API)
├── package.json              # এনপিএম প্যাকেজ কনফিগারেশন
└── README.md                 # এই বিস্তারিত ইনস্টলেশন গাইড
```

---

## 🛠️ সমস্যা ও সমাধান (Troubleshooting / FAQ)

### ১. Port 3000 Already in Use (পোর্ট ৩০১০ বা অন্য পোর্টে চালাতে চাইলে):
যদি আপনার কম্পিউটারে আগে থেকেই পোর্ট ৩০০০ অন্য কোনো কাজে ব্যবহৃত থাকে:
```bash
PORT=3001 npm run dev
```
(Windows PowerShell এ: `$env:PORT=3001; npm run dev`)

### ২. `no such column: min_level` সমাধান:
আমরা ইতিমধ্যে `server.js` এবং `mysql_schema.sql`-এ `min` এবং `min_level` উভয় ফিল্ডই সাপোর্ট করিয়ে সমাধান করে দিয়েছি। কোনো অতিরিক্ত কোডিং পরিবর্তন করতে হবে না।

### ৩. নোড মডিউল রি-ইনস্টল করতে চাইলে:
```bash
rm -rf node_modules package-lock.json
npm install
npm run dev
```

---
**TMSS MIS Department Enterprise Application — All Rights Reserved.**
