<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $hash = password_hash('password123', PASSWORD_BCRYPT);
        $users = [
            [
                'name' => 'System Administrator',
                'email' => 'admin@mis.org',
                'password' => $hash,
                'role' => 'admin',
                'status' => 'active'
            ],
            [
                'name' => 'Operations Manager',
                'email' => 'manager@mis.org',
                'password' => $hash,
                'role' => 'manager',
                'status' => 'active'
            ],
            [
                'name' => 'MIS Field Officer',
                'email' => 'officer@mis.org',
                'password' => $hash,
                'role' => 'officer',
                'status' => 'active'
            ],
            [
                'name' => 'Auditor / Viewer',
                'email' => 'viewer@mis.org',
                'password' => $hash,
                'role' => 'viewer',
                'status' => 'active'
            ],
        ];

        foreach ($users as $u) {
            User::updateOrCreate(['email' => $u['email']], $u);
        }
    }
}
