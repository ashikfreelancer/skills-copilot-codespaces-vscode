<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Department;

class DepartmentSeeder extends Seeder
{
    public function run(): void
    {
        $departments = [
            [
                'name' => 'Management Information Systems',
                'code' => 'MIS',
                'head_of_department' => 'Dr. Rafiqul Islam',
                'allocated_budget' => 5000000.00,
                'status' => 'Active'
            ],
            [
                'name' => 'Human Resources & Administration',
                'code' => 'HRA',
                'head_of_department' => 'Nasrin Akhter',
                'allocated_budget' => 3500000.00,
                'status' => 'Active'
            ],
            [
                'name' => 'Finance & Accounts',
                'code' => 'FIN',
                'head_of_department' => 'Kamal Hossain, FCA',
                'allocated_budget' => 8000000.00,
                'status' => 'Active'
            ],
            [
                'name' => 'Monitoring & Quality Assurance',
                'code' => 'MQA',
                'head_of_department' => 'Tariq Anam',
                'allocated_budget' => 2500000.00,
                'status' => 'Active'
            ],
            [
                'name' => 'Logistics & Inventory Management',
                'code' => 'LOG',
                'head_of_department' => 'Mahbubur Rahman',
                'allocated_budget' => 4200000.00,
                'status' => 'Active'
            ]
        ];

        foreach ($departments as $dept) {
            Department::updateOrCreate(['code' => $dept['code']], $dept);
        }
    }
}
