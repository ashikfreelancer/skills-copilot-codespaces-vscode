import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbDir = path.join(__dirname);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}
const DB_FILE = path.join(dbDir, 'database.sqlite');

let SQL = null;
let db = null;

export async function getDb() {
  if (db) return db;

  SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    try {
      const filebuffer = fs.readFileSync(DB_FILE);
      db = new SQL.Database(filebuffer);
    } catch (e) {
      console.warn('Error reading database file, creating fresh DB:', e);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  // Save to disk helper
  db.persist = () => {
    try {
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_FILE, buffer);
    } catch (err) {
      console.error('Failed to persist database:', err);
    }
  };

  db.query = (sql, params = []) => {
    try {
      const stmt = db.prepare(sql);
      stmt.bind(params);
      const rows = [];
      while (stmt.step()) {
        rows.push(stmt.getAsObject());
      }
      stmt.free();
      return rows;
    } catch (e) {
      console.error('SQL Query Error:', sql, params, e);
      throw e;
    }
  };

  db.queryOne = (sql, params = []) => {
    const rows = db.query(sql, params);
    return rows.length > 0 ? rows[0] : null;
  };

  db.execute = (sql, params = []) => {
    try {
      db.run(sql, params);
      db.persist();
      return true;
    } catch (e) {
      console.error('SQL Execute Error:', sql, params, e);
      throw e;
    }
  };

  db.transaction = (callback) => {
    db.run("BEGIN TRANSACTION;");
    try {
      const result = callback(db);
      db.run("COMMIT;");
      db.persist();
      return result;
    } catch (err) {
      try {
        db.run("ROLLBACK;");
      } catch (rollbackErr) {
        console.error('Rollback error:', rollbackErr);
      }
      throw err;
    }
  };

  // Run schema initializations
  initSchema(db);

  return db;
}

function initSchema(database) {
  database.run(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      username TEXT,
      module TEXT NOT NULL,
      action TEXT NOT NULL,
      reference TEXT,
      ip_address TEXT,
      user_agent TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS administrative_locations (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      name TEXT NOT NULL,
      division TEXT DEFAULT '',
      district TEXT DEFAULT '',
      thana TEXT DEFAULT '',
      status TEXT DEFAULT 'Active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS branches (
      id TEXT PRIMARY KEY,
      division TEXT NOT NULL,
      district TEXT NOT NULL,
      thana TEXT NOT NULL,
      upazila TEXT NOT NULL,
      union_name TEXT DEFAULT '',
      ward TEXT DEFAULT '',
      branch TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      manager TEXT DEFAULT '',
      mobile TEXT DEFAULT '',
      personal_mobile TEXT DEFAULT '',
      email TEXT DEFAULT '',
      status TEXT DEFAULT 'Active',
      address TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS domain_zones (
      id TEXT PRIMARY KEY,
      domain TEXT NOT NULL,
      zone TEXT DEFAULT '',
      head_type TEXT NOT NULL DEFAULT 'Zone Head',
      head_name TEXT NOT NULL,
      designation TEXT NOT NULL,
      employee_id TEXT NOT NULL,
      mobile TEXT NOT NULL,
      email TEXT DEFAULT '',
      address TEXT DEFAULT '',
      status TEXT DEFAULT 'Active',
      remarks TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS departments (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      description TEXT DEFAULT '',
      status TEXT DEFAULT 'Active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS staff_positions (
      id TEXT PRIMARY KEY,
      serial TEXT DEFAULT '',
      name TEXT NOT NULL,
      gender TEXT DEFAULT 'Male',
      dob TEXT DEFAULT '',
      father TEXT DEFAULT '',
      mother TEXT DEFAULT '',
      staff_id TEXT NOT NULL UNIQUE,
      designation TEXT NOT NULL,
      join_date TEXT DEFAULT '',
      posting_date TEXT DEFAULT '',
      promotion_date TEXT DEFAULT '',
      education TEXT DEFAULT '',
      home_district TEXT DEFAULT '',
      previous_posting TEXT DEFAULT '',
      current_posting TEXT DEFAULT '',
      department TEXT NOT NULL,
      status TEXT DEFAULT 'Active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS movement_registers (
      id TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      employee_id TEXT NOT NULL,
      employee_name TEXT NOT NULL,
      designation TEXT NOT NULL,
      department TEXT NOT NULL DEFAULT 'MIS',
      domain TEXT NOT NULL,
      zone TEXT DEFAULT '',
      location TEXT DEFAULT '',
      type TEXT NOT NULL DEFAULT 'Official',
      out_time TEXT NOT NULL,
      expected_return TEXT DEFAULT '',
      actual_return TEXT DEFAULT '',
      purpose TEXT NOT NULL,
      destination TEXT NOT NULL,
      contact TEXT DEFAULT '',
      vehicle TEXT DEFAULT '',
      accompanied_by TEXT DEFAULT '',
      approved_by TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Out',
      remarks TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS stock_items (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      unit TEXT NOT NULL,
      opening REAL DEFAULT 0,
      min REAL DEFAULT 0,
      location TEXT NOT NULL,
      supplier TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS stock_transactions (
      id TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      item_id TEXT NOT NULL,
      type TEXT NOT NULL,
      qty REAL NOT NULL,
      unit_price REAL DEFAULT 0,
      location TEXT NOT NULL,
      reference TEXT DEFAULT '',
      party TEXT DEFAULT '',
      staff_id TEXT DEFAULT '',
      purpose TEXT DEFAULT '',
      approved_by TEXT DEFAULT '',
      remarks TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      period TEXT NOT NULL,
      scope TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Ready',
      report_type TEXT DEFAULT 'Monthly',
      template TEXT DEFAULT '',
      branch_office TEXT DEFAULT '',
      submission_status TEXT DEFAULT 'Submitted',
      remarks TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS advances (
      id TEXT PRIMARY KEY,
      employee TEXT NOT NULL,
      employee_id TEXT NOT NULL,
      department TEXT NOT NULL,
      designation TEXT DEFAULT '',
      purpose TEXT NOT NULL,
      request_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      amount REAL NOT NULL,
      adjusted REAL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Open',
      approval TEXT DEFAULT 'Approved',
      notes TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS leaves (
      id TEXT PRIMARY KEY,
      staff_id TEXT NOT NULL,
      staff_name TEXT NOT NULL,
      department TEXT NOT NULL,
      leave_type TEXT NOT NULL,
      from_date TEXT NOT NULL,
      to_date TEXT NOT NULL,
      days INTEGER DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'Pending',
      reason TEXT DEFAULT '',
      approved_by TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info',
      target_module TEXT DEFAULT '',
      time_label TEXT DEFAULT 'Today',
      status TEXT NOT NULL DEFAULT 'Unread',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS monthly_mis_submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      year INTEGER NOT NULL,
      month_code TEXT NOT NULL,
      month_num INTEGER NOT NULL,
      target INTEGER NOT NULL DEFAULT 0,
      submitted INTEGER NOT NULL DEFAULT 0,
      pending INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS staff_transfers (
      id TEXT PRIMARY KEY,
      staff_id TEXT NOT NULL,
      staff_name TEXT NOT NULL,
      designation TEXT NOT NULL,
      department TEXT NOT NULL,
      type TEXT NOT NULL, -- 'Transfer' or 'Close'
      from_branch TEXT NOT NULL,
      to_branch TEXT NOT NULL,
      transfer_date TEXT NOT NULL,
      order_number TEXT DEFAULT '',
      approved_by TEXT DEFAULT '',
      handover_status TEXT DEFAULT 'Completed',
      charge_handed_to TEXT DEFAULT '',
      reason TEXT DEFAULT '',
      remarks TEXT DEFAULT '',
      status TEXT DEFAULT 'Approved',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS report_requests (
      id TEXT PRIMARY KEY,
      requester TEXT NOT NULL,
      department TEXT NOT NULL,
      report TEXT NOT NULL,
      request_date TEXT NOT NULL,
      deadline TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Normal',
      assigned TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending',
      remarks TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS target_activities (
      id TEXT PRIMARY KEY,
      period TEXT NOT NULL,
      area TEXT NOT NULL,
      indicator TEXT NOT NULL,
      target REAL NOT NULL DEFAULT 0,
      achieved REAL DEFAULT 0,
      description TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS cabinet_documents (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      doc_type TEXT DEFAULT 'document',
      memo_no TEXT DEFAULT '',
      doc_date TEXT NOT NULL,
      department TEXT DEFAULT 'MIS',
      version TEXT DEFAULT '1.0',
      description TEXT DEFAULT '',
      remarks TEXT DEFAULT '',
      attachments TEXT DEFAULT '[]',
      history TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS mis_forms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      period TEXT NOT NULL,
      type TEXT NOT NULL,
      department TEXT NOT NULL,
      branch TEXT DEFAULT 'All',
      status TEXT NOT NULL DEFAULT 'Active',
      indicators TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS data_quality_verifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      record_id TEXT NOT NULL UNIQUE,
      module TEXT NOT NULL,
      verified_by TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Verified',
      remarks TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  try {
    database.exec("ALTER TABLE notifications ADD COLUMN user_id TEXT DEFAULT ''");
  } catch (e) {}
  try {
    database.exec("ALTER TABLE notifications ADD COLUMN action_url TEXT DEFAULT ''");
  } catch (e) {}

  // Seed default administrative locations if empty
  const countRes = database.query("SELECT count(*) as count FROM administrative_locations");
  if (countRes[0].count === 0) {
    const locations = [
      ['DIV-001', 'Division', 'Dhaka', '', '', '', 'Active'],
      ['DIV-002', 'Division', 'Chattogram', '', '', '', 'Active'],
      ['DIV-003', 'Division', 'Rajshahi', '', '', '', 'Active'],
      ['DIV-004', 'Division', 'Khulna', '', '', '', 'Active'],
      ['DIST-001', 'District', 'Dhaka', 'Dhaka', '', '', 'Active'],
      ['DIST-002', 'District', 'Chattogram', 'Chattogram', '', '', 'Active'],
      ['DIST-003', 'District', 'Rajshahi', 'Rajshahi', '', '', 'Active'],
      ['THA-001', 'Thana', 'Savar', 'Dhaka', 'Dhaka', '', 'Active'],
      ['THA-002', 'Thana', 'Keraniganj', 'Dhaka', 'Dhaka', '', 'Active'],
      ['THA-003', 'Thana', 'Mirsharai', 'Chattogram', 'Chattogram', '', 'Active'],
      ['UPA-001', 'Upazila', 'Savar', 'Dhaka', 'Dhaka', 'Savar', 'Active'],
      ['UPA-002', 'Upazila', 'Keraniganj', 'Dhaka', 'Dhaka', 'Keraniganj', 'Active'],
      ['UPA-003', 'Upazila', 'Mirsharai', 'Chattogram', 'Chattogram', 'Mirsharai', 'Active']
    ];

    locations.forEach(loc => {
      database.run(
        "INSERT INTO administrative_locations (id, type, name, division, district, thana, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
        loc
      );
    });

    // Seed default branches if empty
    const branches = [
      ['LOC-001', 'Dhaka', 'Dhaka', 'Savar', 'Savar', 'Ashulia', '', 'Ashulia-01', 'DHK-001', 'Kamrul Hasan', '01700-000001', '01800-000001', 'ashulia01@mis.gov.bd', 'Active', 'Ashulia Bazar, Savar, Dhaka'],
      ['LOC-002', 'Dhaka', 'Dhaka', 'Savar', 'Savar', 'Savar Municipality', '01', 'Savar-01', 'DHK-002', 'Md. Rafiqul Islam', '01700-000002', '01800-000002', 'savar01@mis.gov.bd', 'Active', 'Savar Bus Stand, Dhaka'],
      ['LOC-003', 'Dhaka', 'Dhaka', 'Keraniganj', 'Keraniganj', 'Kalatiya', '', 'Keraniganj-01', 'DHK-003', 'Shahidul Alam', '01700-000003', '01800-000003', 'keraniganj01@mis.gov.bd', 'Review', 'Kalatiya Main Road, Keraniganj']
    ];

    branches.forEach(b => {
      database.run(
        "INSERT INTO branches (id, division, district, thana, upazila, union_name, ward, branch, code, manager, mobile, personal_mobile, email, status, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        b
      );
    });

    database.persist();
  }

  // Seed default domain & zone head information if empty
  const dzCountRes = database.query("SELECT count(*) as count FROM domain_zones");
  if (dzCountRes[0].count === 0) {
    const domainZones = [
      ['OP-001','অপারেশন-০১','','Domain Head','মোঃ সাজ্জাদুর রহমান','JD','101-0141','01713-377266','hemop1@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-001','অপারেশন-০১','বগুড়া কেন্দ্রীয়','Zone Head','মোঃ ইসহাক আলী','ZM','101-04678','01713-377178','zhbogcentral@tmss-bd.org','','Active',''],
      ['DZ-002','অপারেশন-০১','বগুড়া উত্তর','Zone Head','মোঃ মোয়াজ্জেম হোসেন','ZM','101-352','01713-377250','zhbognorth@tmss-bd.org','','Active',''],
      ['DZ-003','অপারেশন-০১','বগুড়া দক্ষিণ','Zone Head','মোঃ সাজ্জাদ হোসেন','AD','101-7937','01713-377032','zhbograsouth@tmss-bd.org','','Active',''],
      ['DZ-004','অপারেশন-০১','দরগাহাট','Zone Head','সেলিম আহমেদ ফকির','ZM','101-02990','01711-436657','zhdorgahat@tmss-bd.org','','Active',''],
      ['OP-002','অপারেশন-০২','','Domain Head','এস এম বাবুল','AD','101-00301','01777-798043','hemop2@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-005','অপারেশন-০২','ঢাকা','Zone Head','মোঃ কামরুল ইসলাম','AM','101-8468','01713-377185','tmssdhakazone@gmail.com','','Active',''],
      ['DZ-006','অপারেশন-০২','নারায়ণগঞ্জ','Zone Head','মোঃ জাহাঙ্গীর আলম','ZM','101-40236','01730-006938','tmssdhakasouthzone1234@gmail.com','','Active',''],
      ['DZ-007','অপারেশন-০২','সাভার','Zone Head','মোঃ ইব্রাহীম খলিল','ZM','101-3216','01313-092837','tmsssavarzone@gmail.com','','Active',''],
      ['DZ-008','অপারেশন-০২','নরসিংদী','Zone Head','মোঃ আল আমিন','AM','101-02877','01713-377169','narsingdizone@tmss-bd.org','','Active',''],
      ['OP-003','অপারেশন-০৩','','Domain Head','মোঃ ওসমান গনি','DD','101-15276','01708-491238','hemop3@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-009','অপারেশন-০৩','রাজশাহী','Zone Head','মোঃ চারোয়ার জাহান','ZM','101-4722','01713-377258','zhrajshahi@tmss-bd.org','','Active',''],
      ['DZ-010','অপারেশন-০৩','চাঁপাইনবাবগঞ্জ','Zone Head','নিখিল চন্দ্র চক্রবর্তী','ZM','101-3688','01713-377241','zhchapai@tmss-bd.org','','Active',''],
      ['DZ-011','অপারেশন-০৩','নওগাঁ জোন','Zone Head','মোঃ ইউনুছ আলী','ZM','101-01941','01713-377171','zhnaogaon@tmss-bd.org','','Active',''],
      ['DZ-012','অপারেশন-০৩','পুঠিয়া','Zone Head','মোঃ আজিজুল হক (আজিজ)','ZM','101-2685','01713-377352','zhputhia@tmss-bd.org','','Active',''],
      ['OP-004','অপারেশন-০৪','','Domain Head','মোহাম্মদ শাহীন মিয়া','AD','101-21036','01730-735953','hemop4@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-013','অপারেশন-০৪','গাইবান্ধা','Zone Head','মোঃ মাকসুদুর রহমান','SZM','101-968','01713-377159','zhgaibandha@tmss-bd.org','','Active',''],
      ['DZ-014','অপারেশন-০৪','রংপুর জোন','Zone Head','মোঃ ময়নুল হক প্রধান','ZM','101-3681','01713-377157','zhrangpur@tmss-bd.org','','Active',''],
      ['DZ-015','অপারেশন-০৪','কুড়িগ্রাম','Zone Head','মোঃ আব্দুর রশিদ','ZM','101-2367','01713-377257','zhkurigram@tmss-bd.org','','Active',''],
      ['DZ-016','অপারেশন-০৪','লালমনিরহাট','Zone Head','মোঃ সাইদুর রহমান','ZM','101-1408','01713-377210','zhlalmoni@tmss-bd.org','','Active',''],
      ['OP-005','অপারেশন-০৫','','Domain Head','মোঃ আব্দুর রাজ্জাক','DD','101-00747','01713-377195','hemop5@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-017','অপারেশন-০৫','চট্টগ্রাম উত্তর','Zone Head','মোঃ মোক্তাদিয়ার রহমান','AM','101-2305','01709-646514','ctgnorthzone@tmss-bd.org','','Active',''],
      ['DZ-018','অপারেশন-০৫','চট্টগ্রাম দক্ষিণ','Zone Head','মোঃ মামুনুর রশিদ','ZM','101-3307','01713-377189','tmssctgsouthzone@gmail.com','','Active',''],
      ['DZ-019','অপারেশন-০৫','সাতকানিয়া','Zone Head','মোঃ আল মামুন সরকার','ZM','101-1689','01704-124104','tmsssatkaniazone@gmail.com','','Active',''],
      ['DZ-020','অপারেশন-০৫','ফেনী','Zone Head','মোঃ গোলাম মোস্তফা','ZM','101-02398','01755-588923','tmssfenizone@gmail.com','','Active',''],
      ['DZ-021','অপারেশন-০৫','নোয়াখালী','Zone Head','মোঃ মজিবুর রহমান','AM','101-12672','01713-377279','tmssnoakhalizone@gmail.com','','Active',''],
      ['OP-006','অপারেশন-০৬','','Domain Head','মনিরুল গনি চৌধুরী','DD','101-40237','01313-377092','hemop6@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-022','অপারেশন-০৬','সাতক্ষীরা','Zone Head','মোঃ আব্দুল বারিক','AM','101-0344','01708-491200','satkhirazone2016@gmail.com','','Active',''],
      ['DZ-023','অপারেশন-০৬','যশোর','Zone Head','মোঃ হারুনুর রশিদ','ZM','101-5285','01713-377190','tmssjessorezone@gmail.com','','Active',''],
      ['DZ-024','অপারেশন-০৬','খুলনা','Zone Head','মোঃ ইকবাল হোসেন','SZM','101-00644','01713-377275','zhkhulnazone@gmail.com','','Active',''],
      ['DZ-025','অপারেশন-০৬','কুষ্টিয়া','Zone Head','মোঃ মাহবুবুর রহমান','ZM','101-314','01709-646565','tmsskustiazone@gmail.com','','Active',''],
      ['OP-007','অপারেশন-০৭','','Domain Head','ওয়াকিল আহমেদ','AD','101-10567','01713-377303','hemop7@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-026','অপারেশন-০৭','মৌলভীবাজার','Zone Head','মোঃ রফিকুল ইসলাম','ZM','101-1656','01730-735950','moulvibazarzone@tmss-bd.org','','Active',''],
      ['DZ-027','অপারেশন-০৭','সিলেট','Zone Head','মোঃ সেলিম রেজা','ZM','101-26985','01713-377198','sylhetzone@tmss-bd.org','','Active',''],
      ['DZ-028','অপারেশন-০৭','বিয়ানীবাজার','Zone Head','মোঃ আজিজুল হক','ZM','101-02974','01755-588999','beanibazarzone@tmss-bd.org','','Active',''],
      ['DZ-029','অপারেশন-০৭','হবিগঞ্জ','Zone Head','মোঃ শাহানুর আলম','AM','101-05094','01730-316078','habiganjzone@tmss-bd.org','','Active',''],
      ['DZ-030','অপারেশন-০৭','সুনামগঞ্জ','Zone Head','মোঃ আবুল হাসেম','ZM','101-5302','01713-377123','sunamganjzone@tmss-bd.org','','Active',''],
      ['OP-008','অপারেশন-০৮','','Domain Head','মোঃ গোলাম মোস্তফা','AD','101-1088','01713-377219','hemop8@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-031','অপারেশন-০৮','ফরিদপুর','Zone Head','আবু বকর সিদ্দিক','ZM','101-13084','01730-735949','faridpurzone@tmss-bd.org','','Active',''],
      ['DZ-032','অপারেশন-০৮','বরিশাল','Zone Head','মোঃ আবুল কালাম আজাদ','ZM','101-0376','01755-545692','zhbarisaltmss@gmail.com','','Active',''],
      ['DZ-033','অপারেশন-০৮','মাদারীপুর','Zone Head','মোঃ মিজানুর রহমান','ZM','101-11242','01725-698957','madaripurzone@tmss-bd.org','','Active',''],
      ['OP-009','অপারেশন-০৯','','Domain Head','সাগর কুমার বড়ুয়া','DD','101-03089','01713-377316','hemop9@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-034','অপারেশন-০৯','দিনাজপুর','Zone Head','মোঃ আহসান হাবিব','ZM','101-10851','01713-377267','dinajpurtmss@yahoo.com','','Active',''],
      ['DZ-035','অপারেশন-০৯','সৈয়দপুর','Zone Head','মোঃ রুহুল আমিন','AD','101-02503','01730-735937','zhsyedpur@tmss-bd.org','','Active',''],
      ['DZ-036','অপারেশন-০৯','ঠাকুরগাঁও','Zone Head','মোঃ মাসুদ জাহেদী','ZM','101-1761','01713-377208','zhthakurgaon@tmss-bd.org','','Active',''],
      ['DZ-037','অপারেশন-০৯','পঞ্চগড়','Zone Head','মোঃ আব্দুল আলীম','ZM','101-5364','01713-377367','zhpancho@tmss-bd.org','','Active',''],
      ['OP-010','অপারেশন-১০','','Domain Head','মোঃ মাহবুবুল হাসান','DD','101-21478','01709-642961','hemop10@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-038','অপারেশন-১০','লক্ষ্মীপুর','Zone Head','কুমুদ কুমার ধর','ZM','101-8586','01709-642990','tmsslaxmipurzone@gmail.com','','Active',''],
      ['DZ-039','অপারーション-১০','কুমিল্লা পূর্ব','Zone Head','মোঃ আতাউর রহমান','ZM','101-8592','01713-377317','tmsscomillaeast@gmail.com','','Active',''],
      ['DZ-040','অপারেশন-১০','কুমিল্লা পশ্চিম','Zone Head','মোঃ নজরুল ইসলাম','ZM','101-20824','01704-124183','tmsscomillawestzone@gmail.com','','Active',''],
      ['DZ-041','অপারেশন-১০','চাঁদপুর','Zone Head','খ.আ.হে মোঃ ছায়েম','ZM','101-1733','01755-588940','tmsschadpur@gmail.com','','Active',''],
      ['OP-011','অপারেশন-১১','','Domain Head','মোঃ রফিকুল ইসলাম','AD','101-18522','01713-377107','hemop11@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-042','অপারেশন-১১','পাবনা','Zone Head','আরিফুল ইসলাম','ZM','101-22155','01713-377235','zhpabna@tmss-bd.org','','Active',''],
      ['DZ-043','অপারেশন-১১','চাটমোহর','Zone Head','মোঃ হানজালাল রহমান','ZM','101-05047','01709-646557','zhchatmohortmss@yahoo.com','','Active',''],
      ['DZ-044','অপারেশন-১১','সিরাজগঞ্জ','Zone Head','মামুনুর রশিদ মামুন','ZM','101-2179','01713-377172','zhsirajganj@tmss-bd.org','','Active',''],
      ['DZ-045','অপারেশন-১১','নাটোর','Zone Head','দেব নারায়ণ সাহা','ZM','101-8874','01713-377182','zhnatoretmss@yahoo.com','','Active',''],
      ['OP-012','অপারেশন-১২','','Domain Head','মোঃ আনোয়ার হোসেন','AD','101-0247','01713-377281','hemop12@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-046','অপারেশন-১২','গাজীপুর','Zone Head','মোঃ আব্দুল কাদের','ZM','101-5943','01713-377179','gazipurzone@gmail.com','','Active',''],
      ['DZ-047','অপারেশন-১২','টাঙ্গাইল','Zone Head','মোঃ কাছেদুল জান্নাত','ZM','101-09388','01713-377013','tmsstangailzone@gmail.com','','Active',''],
      ['DZ-048','অপারেশন-১২','নেত্রকোনা','Zone Head','মোঃ জিয়াউর রহমান','ZM','101-0593','01713-377019','netrokonazonetmss@gmail.com','','Active',''],
      ['DZ-049','অপারেশন-১২','জামালপুর','Zone Head','মোঃ মাসুদ রানা','AM','101-05769','01709-631075','jamalpurzonetmss@gmail.com','','Active',''],
      ['DZ-050','অপারেশন-১২','ময়মনসিংহ','Zone Head','মোঃ জাহিদুর রহমান','AZM','101-3131','01713-377158','tmssmymensinghzone@gmail.com','','Active',''],
      ['OP-013','অপারেশন-১৩','','Domain Head','মোঃ ইসমাইল হোসেন','AD','101-0858','01708-491270','hemop13@tmss-bd.org','প্রধান কার্যালয়, ঢাকা','Active',''],
      ['DZ-051','অপারেশন-১৩','জয়পুরহাট','Zone Head','মোঃ শহিদুল হাসান','ZM','101-02863','01713-377201','zhjoypur@tmss-bd.org','','Active',''],
      ['DZ-052','অপারেশন-১৩','বিরামপুর','Zone Head','মোঃ জুয়েল হোসেন','ZM','101-7772','01713-377351','zhbirampur@tmss-bd.org','','Active',''],
      ['DZ-053','অপারেশন-১৩','নওজপুর','Zone Head','মোঃ মাহবুবুল আলম','ZM','101-13736','01711-869844','zhnozipurtmss@gmail.com','','Active',''],
      ['DZ-054','অপারেশন-১৩','পলাশবাড়ী','Zone Head','মোঃ দেলোয়ার হোসেন','ZM','101-399','01708-491242','zhpolashbari@tmss-bd.org','','Active','']
    ];

    domainZones.forEach(dz => {
      database.run(
        "INSERT INTO domain_zones (id, domain, zone, head_type, head_name, designation, employee_id, mobile, email, address, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        dz
      );
    });

    database.persist();
  }

  // Seed default departments if empty
  const countDeptRes = database.query("SELECT count(*) as count FROM departments");
  if (countDeptRes[0].count === 0) {
    const depts = [
      ['DEP-001', 'MIS', 'MIS-01', 'Management Information System', 'Active', '2026-09-14 00:00:00', '2026-09-14 00:00:00'],
      ['DEP-002', 'IT', 'IT-01', 'Information Technology', 'Active', '2026-09-14 00:00:00', '2026-09-14 00:00:00'],
      ['DEP-003', 'Accounts', 'ACC-01', 'Accounts & Finance', 'Active', '2026-09-14 00:00:00', '2026-09-14 00:00:00'],
      ['DEP-004', 'Audit', 'AUD-01', 'Internal Audit & Compliance', 'Active', '2026-09-14 00:00:00', '2026-09-14 00:00:00'],
      ['DEP-005', 'HR & Admin', 'HR-01', 'Human Resources & Administration', 'Active', '2026-09-14 00:00:00', '2026-09-14 00:00:00'],
      ['DEP-006', 'Operations', 'OPS-01', 'Operations & Program Management', 'Active', '2026-09-14 00:00:00', '2026-09-14 00:00:00']
    ];

    depts.forEach(d => {
      database.run(
        "INSERT INTO departments (id, name, code, description, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        d
      );
    });

    database.persist();
  }

  // Seed default staff positions if empty
  const countStaffRes = database.query("SELECT count(*) as count FROM staff_positions");
  if (countStaffRes[0].count === 0) {
    const staffList = [
      ['ST-001', '01', 'Md. Example', 'Male', '1995-05-15', 'Md. Father', 'Mrs. Mother', 'TMSS-001', 'Officer', '2020-01-01', '2025-02-10', '2025-01-01', 'MBA', 'Bogura', 'Head Office', 'Dhaka Branch', 'MIS', 'Active'],
      ['ST-002', '02', 'Example Staff', 'Female', '1993-08-22', 'Md. Parent', 'Mrs. Parent', 'TMSS-002', 'Senior Officer', '2019-03-15', '2024-03-05', '2024-03-15', 'BSc in CSE', 'Rajshahi', 'Rajshahi Zone', 'Savar Branch', 'IT', 'Active'],
      ['ST-003', '03', 'Md. Tariqul Islam', 'Male', '1990-11-12', 'Md. Abdul Haque', 'Amena Begum', 'TMSS-003', 'Assistant Manager', '2018-07-01', '2023-01-15', '2024-01-01', 'M.Com in Accounting', 'Dhaka', 'Dhaka South Zone', 'Mirpur Branch', 'Accounts', 'Active'],
      ['ST-004', '04', 'Nusrat Jahan', 'Female', '1996-03-18', 'Kazi Anwar Hossain', 'Salma Khatun', 'TMSS-004', 'Program Officer', '2021-04-10', '2024-06-01', '2024-04-10', 'MSS in Sociology', 'Chattogram', 'Agrabad Branch', 'Feni Zone', 'Operations', 'Active'],
      ['ST-005', '05', 'Md. Shahadat Hossain', 'Male', '1992-09-05', 'Md. Abul Kalam', 'Fatema Begum', 'TMSS-005', 'Audit Officer', '2020-09-15', '2023-11-20', '2023-09-15', 'BBA in Finance', 'Khulna', 'Jashore Zone', 'Khulna Regional Office', 'Audit', 'Active'],
      ['ST-006', '06', 'Rashedul Hasan', 'Male', '1988-12-30', 'Nurul Islam', 'Rashida Begum', 'TMSS-006', 'HR Executive', '2017-02-01', '2022-05-10', '2023-02-01', 'MBA in HRM', 'Rangpur', 'Rangpur Zone', 'Head Office', 'HR & Admin', 'Active']
    ];

    staffList.forEach(s => {
      database.run(
        `INSERT INTO staff_positions (id, serial, name, gender, dob, father, mother, staff_id, designation, join_date, posting_date, promotion_date, education, home_district, previous_posting, current_posting, department, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        s
      );
    });

    database.persist();
  }

  // Seed default movement registers if empty
  const countMrRes = database.query("SELECT count(*) as count FROM movement_registers");
  if (countMrRes[0].count === 0) {
    const mrList = [
      ['MR-0001', '2026-09-13', '101-04678', 'মোঃ ইসহাক আলী', 'ZM', 'MIS', 'অপারেশন-01', 'বগুড়া কেন্দ্রীয়', 'প্রধান কার্যালয়', 'Official', '09:15', '17:00', '', 'ফিল্ড মনিটরিং', 'বগুড়া', '01713-377178', 'Office', '', 'Admin', 'Out', ''],
      ['MR-0002', '2026-09-13', '101-352', 'মোঃ মোয়াজ্জেম হোসেন', 'ZM', 'MIS', 'অপারেশন-02', 'বগুড়া উত্তর', 'জোন অফিস', 'Field Visit', '10:00', '15:00', '14:40', 'জোন ভিজিট', 'শিবগঞ্জ', '01713-377250', 'Motorcycle', '', 'Principal', 'Returned', ''],
      ['MR-0003', '2026-09-12', '101-8468', 'মোঃ কামরুল ইসলাম', 'AM', 'MIS', 'অপারেশন-05', 'ঢাকা', 'ঢাকা জোন', 'Official', '11:20', '14:00', '', 'সভায় অংশগ্রহণ', 'প্রধান কার্যালয়', '01713-377185', 'Office', '', 'Admin', 'Late Return', 'ফেরার সময় আপডেট প্রয়োজন']
    ];

    mrList.forEach(m => {
      database.run(
        `INSERT INTO movement_registers (id, date, employee_id, employee_name, designation, department, domain, zone, location, type, out_time, expected_return, actual_return, purpose, destination, contact, vehicle, accompanied_by, approved_by, status, remarks)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        m
      );
    });

    database.persist();
  }

  // Seed default stock items if empty
  const countStRes = database.query("SELECT count(*) as count FROM stock_items");
  if (countStRes[0].count === 0) {
    const items = [
      ['IT-001', 'IT-001', 'A4 Paper', 'Stationery', 'Ream', 120, 30, 'Main Store', 'ABC Stationery', 'Active'],
      ['IT-002', 'IT-002', 'Ball Pen', 'Stationery', 'Box', 80, 20, 'Main Store', 'ABC Stationery', 'Active'],
      ['IT-003', 'IT-003', 'Keyboard', 'IT Equipment', 'Piece', 35, 5, 'IT Store', 'Tech Supplier', 'Active'],
      ['IT-004', 'IT-004', 'Mouse', 'IT Equipment', 'Piece', 28, 5, 'IT Store', 'Tech Supplier', 'Active']
    ];

    items.forEach(i => {
      database.run(
        `INSERT INTO stock_items (id, code, name, category, unit, opening, min, location, supplier, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        i
      );
    });

    database.persist();
  }

  // Seed default stock transactions if empty
  const countTxRes = database.query("SELECT count(*) as count FROM stock_transactions");
  if (countTxRes[0].count === 0) {
    const txList = [
      ['TX-001', '2026-09-10', 'IT-001', 'Receive', 50, 350, 'Main Store', 'GRN-1001', 'ABC Stationery', '', 'Stock Receive', 'Admin', ''],
      ['TX-002', '2026-09-11', 'IT-001', 'Issue', 20, 350, 'Main Store', 'ISS-1001', 'MIS Department', '', 'Office Use', 'Admin', ''],
      ['TX-003', '2026-09-12', 'IT-003', 'Issue', 4, 2800, 'IT Store', 'ISS-1002', 'Dhaka Zone', '', 'Branch Requirement', 'Principal', '']
    ];

    txList.forEach(t => {
      database.run(
        `INSERT INTO stock_transactions (id, date, item_id, type, qty, unit_price, location, reference, party, staff_id, purpose, approved_by, remarks)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        t
      );
    });

    database.persist();
  }

  // Seed default reports if empty
  const countRepRes = database.query("SELECT count(*) as count FROM reports");
  if (countRepRes[0].count === 0) {
    const reportList = [
      ['REP-001', 'Monthly MIS Summary', 'monthly-mis', 'Sep 2026', 'All Branches', 'Ready', 'Monthly', 'Standard MIS', 'All Branches', 'Submitted', 'Consolidated monthly MIS branch data'],
      ['REP-002', 'Staff Position Report', 'staff-position', 'Sep 2026', 'All Departments', 'Ready', 'Monthly', 'Staff Details', 'Head Office', 'Submitted', 'Employee designation, posting and department breakdown'],
      ['REP-003', 'Branch Summary Report', 'branch-summary', 'Sep 2026', 'All Branches', 'Ready', 'Monthly', 'Branch Master', 'All Divisions', 'Submitted', 'Division, district, thana and branch management hierarchy'],
      ['REP-004', 'Domain & Zone Head Information Report', 'domain-zone', 'Sep 2026', 'All Domains & Zones', 'Ready', 'Monthly', 'Domain Master', 'All Operations', 'Submitted', 'Domain heads, zone heads and contact directories'],
      ['REP-005', 'Movement Register Report', 'movement-register', 'Sep 2026', 'All Field Staff', 'Ready', 'Monthly', 'Movement Register', 'All Zones', 'Submitted', 'Staff field visits, official movements and return tracking'],
      ['REP-006', 'Stock Inventory & Movement Report', 'stock-register', 'Sep 2026', 'All Store Locations', 'Ready', 'Monthly', 'Stock Ledger', 'Central Store', 'Submitted', 'Inventory balance, receipts, issues and minimum stock alerts'],
      ['REP-007', 'Department Management Report', 'department', 'Sep 2026', 'All Departments', 'Ready', 'Monthly', 'Department Master', 'Head Office', 'Submitted', 'Department codes, descriptions and active status list'],
      ['REP-008', 'System Audit & Activity Report', 'audit-log', 'Sep 2026', 'System Wide', 'Ready', 'Monthly', 'Security Audit', 'System', 'Submitted', 'User access, permissions, logins and data operations']
    ];

    reportList.forEach(r => {
      database.run(
        `INSERT INTO reports (id, title, category, period, scope, status, report_type, template, branch_office, submission_status, remarks)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        r
      );
    });

    database.persist();
  }

  // Seed monthly MIS submissions for amCharts trend if empty
  const countMMSRes = database.query("SELECT count(*) as count FROM monthly_mis_submissions");
  if (countMMSRes[0].count === 0) {
    const monthlyData = [
      [2026, 'Jan', 1, 250, 210, 40],
      [2026, 'Feb', 2, 260, 242, 18],
      [2026, 'Mar', 3, 260, 228, 32],
      [2026, 'Apr', 4, 290, 275, 15],
      [2026, 'May', 5, 310, 291, 19],
      [2026, 'Jun', 6, 320, 302, 18],
      [2026, 'Jul', 7, 330, 318, 12],
      [2026, 'Aug', 8, 350, 326, 24],
      [2026, 'Sep', 9, 360, 342, 18],
      [2026, 'Oct', 10, 370, 355, 15],
      [2026, 'Nov', 11, 380, 368, 12],
      [2026, 'Dec', 12, 390, 380, 10]
    ];

    monthlyData.forEach(m => {
      database.run(
        `INSERT INTO monthly_mis_submissions (year, month_code, month_num, target, submitted, pending)
         VALUES (?, ?, ?, ?, ?, ?)`,
        m
      );
    });
    database.persist();
  }

  // Seed staff transfer & branch close timeline records if empty
  const countTransfersRes = database.query("SELECT count(*) as count FROM staff_transfers");
  if (countTransfersRes[0].count === 0) {
    const seedTransfers = [
      ['TR-001', 'TMSS-001', 'Md. Example', 'Officer', 'MIS', 'Transfer', 'Head Office', 'Ashulia-01', '2021-02-15', 'TMSS/TR/2021/0142', 'Executive Director', 'Completed', 'Md. Kabir', 'Initial Field Operations Deployment', 'Handover of MIS central documentation verified.', 'Approved'],
      ['TR-002', 'TMSS-001', 'Md. Example', 'Officer', 'MIS', 'Transfer', 'Ashulia-01', 'Savar-01', '2023-08-01', 'TMSS/TR/2023/0890', 'Zonal Manager', 'Completed', 'Shahidul Alam', 'Routine 2-Year Branch Rotation', 'Smooth transition of branch MIS reports.', 'Approved'],
      ['TR-003', 'TMSS-001', 'Md. Example', 'Officer', 'MIS', 'Transfer', 'Savar-01', 'Dhaka Branch', '2025-02-10', 'TMSS/TR/2025/0211', 'Director HR', 'Completed', 'Md. Rafiqul Islam', 'Promotion & Posting to Dhaka Branch', 'Took full charge of Dhaka Branch reporting desk.', 'Approved'],
      ['TR-004', 'TMSS-002', 'Example Staff', 'Senior Officer', 'IT', 'Transfer', 'Rajshahi Zone', 'Ashulia-01', '2022-04-10', 'TMSS/TR/2022/0451', 'IT Director', 'Completed', 'Nurul Huda', 'MIS Automation & Network Setup', 'Network and server infrastructure deployed successfully.', 'Approved'],
      ['TR-005', 'TMSS-002', 'Example Staff', 'Senior Officer', 'IT', 'Transfer', 'Ashulia-01', 'Savar Branch', '2024-03-05', 'TMSS/TR/2024/0305', 'Zonal Manager', 'Completed', 'Kamrul Hasan', 'Branch Core Software Upgrade & Rotation', 'Completed IT inventory audit before handover.', 'Approved'],
      ['TR-006', 'TMSS-003', 'Md. Tariqul Islam', 'Assistant Manager', 'Accounts', 'Transfer', 'Bogura Central', 'Dhaka South Zone', '2020-05-18', 'TMSS/TR/2020/0518', 'Finance Director', 'Completed', 'Mizanur Rahman', 'Zonal Accounts Supervision', 'Reconciled branch ledger sheets.', 'Approved'],
      ['TR-007', 'TMSS-003', 'Md. Tariqul Islam', 'Assistant Manager', 'Accounts', 'Transfer', 'Dhaka South Zone', 'Mirpur Branch', '2023-01-15', 'TMSS/TR/2023/0115', 'Executive Director', 'Completed', 'Tania Akter', 'Branch Financial Control & Internal Audit', 'Cash registers and bank books verified.', 'Approved'],
      ['TR-008', 'TMSS-004', 'Nusrat Jahan', 'Program Officer', 'Operations', 'Transfer', 'Agrabad Branch', 'Keraniganj-01', '2022-01-10', 'TMSS/TR/2022/0110', 'Operations Head', 'Completed', 'Faruk Hossain', 'Micro-enterprise Program Expansion', 'Assumed field group portfolios.', 'Approved'],
      ['TR-009', 'TMSS-004', 'Nusrat Jahan', 'Program Officer', 'Operations', 'Close', 'Keraniganj-01', 'Feni Zone', '2024-06-01', 'TMSS/CL/2024/0601', 'Regional Director', 'Completed', 'Shahidul Alam', 'Branch Restructuring & Staff Clearance', 'Branch accounts closed and loan ledgers handed over to zone.', 'Approved'],
      ['TR-010', 'TMSS-005', 'Md. Shahadat Hossain', 'Audit Officer', 'Audit', 'Transfer', 'Jashore Zone', 'Khulna Regional Office', '2023-11-20', 'TMSS/TR/2023/1120', 'Audit Director', 'Completed', 'Al-Amin Sheikh', 'Zonal Audit Completion & Reallocation', 'Audit dossiers handed over to regional team.', 'Approved'],
      ['TR-011', 'TMSS-006', 'Rashedul Hasan', 'HR Executive', 'HR & Admin', 'Transfer', 'Rangpur Zone', 'Head Office', '2022-05-10', 'TMSS/TR/2022/0510', 'Director HR', 'Completed', 'Anisur Rahman', 'Head Office Administration Transfer', 'Promoted to central HR desk.', 'Approved'],
      ['TR-012', 'TMSS-007', 'Farhana Akter', 'Branch Accountant', 'Accounts', 'Close', 'Keraniganj-01', 'Ashulia-01', '2025-06-15', 'TMSS/CL/2025/0615', 'Accounts Head', 'Completed', 'Shahidul Alam', 'Branch Station Closed & Accountabilities Cleared', 'Petty cash, advance register, and vouchers reconciled 100%.', 'Approved'],
      ['TR-013', 'TMSS-008', 'Moshiur Rahman', 'Field Supervisor', 'Operations', 'Close', 'Savar-01', 'Dhaka Branch 1', '2025-08-01', 'TMSS/CL/2025/0801', 'ZM Operations', 'Completed', 'Kamrul Hasan', 'Branch Sub-unit Closure & Member Migration', 'All member savings books and center records migrated to main branch.', 'Approved'],
      ['TR-014', 'TMSS-009', 'Ayesha Siddiqua', 'Data Specialist', 'MIS', 'Transfer', 'Dhaka Branch 1', 'Ashulia-01', '2025-11-12', 'TMSS/TR/2025/1112', 'MIS Head', 'Completed', 'Manager 4', 'Core Banking Data Migration Support', 'Branch MIS data validation completed prior to release.', 'Approved'],
      ['TR-015', 'TMSS-010', 'Kazi Arif', 'Senior Program Manager', 'Operations', 'Transfer', 'Bogura Central', 'Savar-01', '2026-01-10', 'TMSS/TR/2026/0110', 'Executive Director', 'Completed', 'Manager 5', 'Operational Leadership Realignment', 'Took over branch management responsibilities.', 'Approved'],
      ['TR-016', 'TMSS-011', 'Salma Khatun', 'Credit Officer', 'Operations', 'Close', 'Keraniganj-01', 'Mirpur Branch', '2026-04-20', 'TMSS/CL/2026/0420', 'Zonal Manager', 'Completed', 'Shahidul Alam', 'Branch Staff Release upon Restructuring', 'Clearance certificate issued with asset handover verified.', 'Approved'],
      ['TR-017', 'TMSS-012', 'Tanvir Ahmed', 'Data Specialist', 'IT', 'Transfer', 'Head Office', 'Dhaka Branch 2', '2026-07-05', 'TMSS/TR/2026/0705', 'Director IT', 'Completed', 'Admin Officer', 'Local IT Infrastructure & Branch Activation', 'Workstations, network rack and UPS setup complete.', 'Approved']
    ];

    seedTransfers.forEach(t => {
      database.run(
        `INSERT INTO staff_transfers (id, staff_id, staff_name, designation, department, type, from_branch, to_branch, transfer_date, order_number, approved_by, handover_status, charge_handed_to, reason, remarks, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        t
      );
    });

    database.persist();
  }

  // Seed advances if empty (৳ 18.7M total balance, 12 overdue records)
  const countAdvRes = database.query("SELECT count(*) as count FROM advances");
  if (countAdvRes[0].count === 0) {
    database.run("BEGIN TRANSACTION");
    // Overdue advances (12 records)
    const overdueDepts = ['MIS', 'Operations', 'Accounts', 'IT', 'Audit', 'HR'];
    for (let i = 1; i <= 12; i++) {
      const amount = 350000 + (i * 25000);
      const adjusted = 100000;
      database.run(
        `INSERT INTO advances (id, employee, employee_id, department, designation, purpose, request_date, due_date, amount, adjusted, status, approval, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'ADV-OD-' + String(i).padStart(3, '0'),
          'Overdue Staff ' + i,
          'EMP-' + (2000 + i),
          overdueDepts[i % overdueDepts.length],
          'Field Officer',
          'Field Operations and Logistical Advance',
          '2026-06-15',
          '2026-08-15',
          amount,
          adjusted,
          'Overdue',
          'Approved',
          'Settlement notice issued'
        ]
      );
    }
    // Active open advances bringing total outstanding balance to 18,700,000 (৳ 18.7M)
    const currentOverdueOut = 12 * 250000 + (12 * 13 * 25000) / 2; // total overdue balance
    const targetTotalOut = 18700000;
    const remainingOut = targetTotalOut - currentOverdueOut;
    const normalCount = 40;
    const perAdvance = remainingOut / normalCount;
    for (let i = 1; i <= normalCount; i++) {
      database.run(
        `INSERT INTO advances (id, employee, employee_id, department, designation, purpose, request_date, due_date, amount, adjusted, status, approval, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'ADV-' + String(i).padStart(4, '0'),
          'Officer ' + i,
          'EMP-' + (1000 + i),
          overdueDepts[i % overdueDepts.length],
          'Branch Staff',
          'Monthly MIS Operational Expense',
          '2026-09-01',
          '2026-10-15',
          perAdvance + 50000,
          50000,
          'Open',
          'Approved',
          'Under regular settlement cycle'
        ]
      );
    }
    database.run("COMMIT");
    database.persist();
  }

  // Seed notifications if empty
  const countNotifRes = database.query("SELECT count(*) as count FROM notifications");
  if (countNotifRes[0].count === 0) {
    const defaultNotifs = [
      ['NOTIF-001', 'Monthly MIS submission deadline', '24 branch reports are still pending submission.', 'warning', 'reports', 'Today', 'Unread'],
      ['NOTIF-002', 'Data quality alert', '82 records require correction.', 'warning', 'staff-position-list', 'Yesterday', 'Unread'],
      ['NOTIF-003', 'Advance adjustment reminder', '12 advance records are overdue.', 'danger', 'advance-management', '2 days ago', 'Unread'],
      ['NOTIF-004', 'Low stock alert', 'Toner Cartridge HP 85A and A4 Paper below minimum stock threshold.', 'warning', 'stock-register', '3 days ago', 'Unread'],
      ['NOTIF-005', 'Staff movement alert', 'Field visits scheduled for audit review in Dhaka and Rajshahi zones.', 'info', 'movement-register', 'This week', 'Unread']
    ];
    defaultNotifs.forEach(n => {
      database.run(
        `INSERT INTO notifications (id, title, message, type, target_module, time_label, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        n
      );
    });
    database.persist();
  }

  // Seed leaves if empty
  const countLeavesRes = database.query("SELECT count(*) as count FROM leaves");
  if (countLeavesRes[0].count === 0) {
    const sampleLeaves = [
      ['LV-001', 'EMP-1001', 'Kamrul Hasan', 'MIS', 'Casual Leave', '2026-09-05', '2026-09-07', 2, 'Approved', 'Family function', 'Super Admin'],
      ['LV-002', 'EMP-1002', 'Md. Rafiqul Islam', 'MIS', 'Medical Leave', '2026-09-08', '2026-09-10', 3, 'Approved', 'Health recovery', 'Super Admin'],
      ['LV-003', 'EMP-1003', 'Shahidul Alam', 'Operations', 'Annual Leave', '2026-09-15', '2026-09-20', 5, 'Pending', 'Personal leave', ''],
      ['LV-004', 'EMP-1004', 'Nasreen Sultana', 'Accounts', 'Casual Leave', '2026-09-18', '2026-09-19', 1, 'Pending', 'Personal work', '']
    ];
    sampleLeaves.forEach(l => {
      database.run(
        `INSERT INTO leaves (id, staff_id, staff_name, department, leave_type, from_date, to_date, days, status, reason, approved_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        l
      );
    });
    database.persist();
  }

  // Ensure 1,284 branches across divisions for real database calculations
  const branchCount = database.query("SELECT count(*) as count FROM branches")[0].count;
  if (branchCount < 1284) {
    database.run("BEGIN TRANSACTION");
    const divTargets = [
      { div: 'Dhaka', dist: 'Dhaka', thana: 'Dhanmondi', target: 312 },
      { div: 'Chattogram', dist: 'Chattogram', thana: 'Agrabad', target: 241 },
      { div: 'Rajshahi', dist: 'Rajshahi', thana: 'Boalia', target: 184 },
      { div: 'Khulna', dist: 'Khulna', thana: 'Khalishpur', target: 167 },
      { div: 'Barishal', dist: 'Barishal', thana: 'Kotwali', target: 110 },
      { div: 'Rangpur', dist: 'Rangpur', thana: 'Kotwali', target: 105 },
      { div: 'Sylhet', dist: 'Sylhet', thana: 'Kotwali', target: 95 },
      { div: 'Mymensingh', dist: 'Mymensingh', thana: 'Kotwali', target: 70 }
    ];
    let bIdx = branchCount + 1;
    for (const p of divTargets) {
      const existingInDiv = database.query("SELECT count(*) as count FROM branches WHERE division = ?", [p.div])[0].count;
      const need = p.target - existingInDiv;
      for (let i = 0; i < need; i++) {
        // Ensure exactly 18 branches created in recent 30 days (+18 this month)
        const isRecent = bIdx > (1284 - 18);
        const createdAt = isRecent ? '2026-09-10 09:30:00' : '2026-02-10 09:30:00';
        database.run(
          `INSERT INTO branches (id, division, district, thana, upazila, union_name, ward, branch, code, manager, mobile, personal_mobile, email, status, address, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            'BR-' + String(bIdx).padStart(4, '0'),
            p.div,
            p.dist,
            p.thana,
            p.thana,
            'Ward-0' + ((i % 9) + 1),
            '0' + ((i % 9) + 1),
            p.div + ' Branch ' + (i + 1),
            p.div.slice(0, 3).toUpperCase() + '-' + String(bIdx).padStart(3, '0'),
            'Manager ' + bIdx,
            '01700-' + String(bIdx).padStart(6, '0'),
            '01800-' + String(bIdx).padStart(6, '0'),
            'branch' + bIdx + '@tmss-mis.org',
            'Active',
            p.dist + ', ' + p.div,
            createdAt
          ]
        );
        bIdx++;
      }
    }
    database.run("COMMIT");
    database.persist();
  }

  // Ensure 8,642 staff positions for real database calculations
  const staffCount = database.query("SELECT count(*) as count FROM staff_positions")[0].count;
  if (staffCount < 8642) {
    database.run("BEGIN TRANSACTION");
    const depts = ['MIS', 'Operations', 'Accounts', 'IT', 'Audit', 'HR'];
    const designations = ['Officer', 'Senior Officer', 'Manager', 'Assistant Manager', 'Field Officer', 'Data Specialist'];
    const stmt = `INSERT INTO staff_positions (id, serial, name, gender, dob, father, mother, staff_id, designation, join_date, posting_date, promotion_date, education, home_district, previous_posting, current_posting, department, status)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    for (let s = staffCount + 1; s <= 8642; s++) {
      const dept = depts[s % depts.length];
      const desig = designations[s % designations.length];
      // 98.4% records complete
      const isComplete = (s % 62) !== 0;
      database.run(stmt, [
        'STF-' + String(s).padStart(5, '0'),
        String(s),
        'Staff Member ' + s,
        s % 2 === 0 ? 'Male' : 'Female',
        isComplete ? '1992-05-12' : '',
        isComplete ? 'Father ' + s : '',
        isComplete ? 'Mother ' + s : '',
        'EMP-' + String(s).padStart(4, '0'),
        desig,
        '2021-03-01',
        '2024-01-01',
        '',
        isComplete ? 'Masters' : '',
        isComplete ? 'Dhaka' : '',
        'Field Office',
        'Head Office',
        dept,
        'Active'
      ]);
    }
    database.run("COMMIT");
    database.persist();
  }

  // Ensure 326 reports with 24 pending for real database calculations
  const repCount = database.query("SELECT count(*) as count FROM reports")[0].count;
  if (repCount < 326) {
    database.run("BEGIN TRANSACTION");
    const stmt = `INSERT INTO reports (id, title, category, period, scope, status, report_type, template, branch_office, submission_status, remarks)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    for (let r = repCount + 1; r <= 326; r++) {
      const isPending = r > (326 - 24);
      database.run(stmt, [
        'REP-' + String(r).padStart(4, '0'),
        'Monthly MIS Report #' + r,
        'monthly-mis',
        'Sep 2026',
        'Branch-' + r,
        isPending ? 'Draft' : 'Ready',
        'Monthly',
        'Standard MIS',
        'Branch ' + r,
        isPending ? 'Pending' : 'Submitted',
        'Operational reporting dataset'
      ]);
    }
    database.run("COMMIT");
    database.persist();
  }

  // Seed default report_requests if empty
  const reqCount = database.query("SELECT count(*) as count FROM report_requests")[0].count;
  if (reqCount === 0) {
    database.run("BEGIN TRANSACTION");
    const insReq = `INSERT INTO report_requests (id, requester, department, report, request_date, deadline, priority, assigned, status, remarks)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    database.run(insReq, [
      'REQ-2026-0912', 'Management', 'Executive', 'District-wise Branch Summary', '2026-09-08', '2026-09-13', 'High', 'MIS Officer', 'Processing', 'Need updated figures for Bogura and Dhaka.'
    ]);
    database.run(insReq, [
      'REQ-2026-0911', 'HR Department', 'Human Resources', 'Staff Position List', '2026-09-09', '2026-09-15', 'Normal', 'MIS Senior Analyst', 'Completed', 'Include home districts and current posting.'
    ]);
    database.run("COMMIT");
    database.persist();
  }

  // Seed default target_activities if empty
  const tgtCount = database.query("SELECT count(*) as count FROM target_activities")[0].count;
  if (tgtCount === 0) {
    database.run("BEGIN TRANSACTION");
    const insTgt = `INSERT INTO target_activities (id, period, area, indicator, target, achieved, description)
                    VALUES (?, ?, ?, ?, ?, ?, ?)`;
    database.run(insTgt, [
      'TGT-1', 'September 2026', 'Dhaka Division', 'Loan Disbursement Rate', 95, 92, 'Target 95% recovery and timely branch disbursement verification.'
    ]);
    database.run(insTgt, [
      'TGT-2', 'September 2026', 'Rajshahi Division', 'Monthly MIS Data Entry Compliance', 100, 98, 'All field branch offices to finalize report entries before cutoff date.'
    ]);
    database.run("COMMIT");
    database.persist();
  }

  // Seed default cabinet_documents if empty
  const docCount = database.query("SELECT count(*) as count FROM cabinet_documents")[0].count;
  if (docCount === 0) {
    database.run("BEGIN TRANSACTION");
    const insDoc = `INSERT INTO cabinet_documents (id, title, category, doc_type, memo_no, doc_date, department, version, description, remarks, attachments, history)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    database.run(insDoc, [
      'NOTE-1001', 'Official MIS Circular 2026', 'Circular', 'note', 'MEMO/MIS/2026/08', '2026-09-01', 'MIS', '1.0',
      'Operational guidelines for field branch monthly data submission and validation.', 'Standard operational circular',
      JSON.stringify([{ id: 'ATT-1', name: 'MIS_Guidelines_2026.pdf', size: 1048576, uploadedAt: '2026-09-01T09:00:00.000Z' }]),
      JSON.stringify([{ action: 'Uploaded', name: 'MIS_Guidelines_2026.pdf', at: '2026-09-01T09:00:00.000Z', by: 'Super Admin' }])
    ]);
    database.run("COMMIT");
    database.persist();
  }

  // Seed default mis_forms if empty
  const formCount = database.query("SELECT count(*) as count FROM mis_forms")[0].count;
  if (formCount === 0) {
    database.run("BEGIN TRANSACTION");
    const insForm = `INSERT INTO mis_forms (id, name, period, type, department, branch, status, indicators)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    database.run(insForm, [
      'MIS-1001', 'Standard Monthly Branch Submission', '2026-09', 'Monthly', 'MIS', 'All', 'Active',
      JSON.stringify([
        { name: 'Total Loan Outstanding', type: 'Number', required: 'Yes' },
        { name: 'Disbursement Target', type: 'Number', required: 'Yes' },
        { name: 'Recovery Rate (%)', type: 'Percentage', required: 'Yes' },
        { name: 'Active Borrowers', type: 'Number', required: 'Yes' }
      ])
    ]);
    database.run("COMMIT");
    database.persist();
  }

  // Seed default system_settings if empty
  const setCheck = database.query("SELECT count(*) as count FROM system_settings")[0].count;
  if (setCheck === 0) {
    database.run("BEGIN TRANSACTION");
    const insSet = `INSERT INTO system_settings (key, value) VALUES (?, ?)`;
    database.run(insSet, ['backup_frequency', 'Daily']);
    database.run(insSet, ['backup_retention', '30 Days']);
    database.run(insSet, ['notification_alerts', 'true']);
    database.run(insSet, ['require_approval', 'true']);
    database.run(insSet, ['last_backup', new Date().toISOString()]);
    database.run(insSet, ['login_title', 'Welcome to Management Information System']);
    database.run(insSet, ['login_subtitle', 'Manage your management information system efficiently and effectively.']);
    database.run(insSet, ['login_hero_image', '/assets/images/login-hero.jpg']);
    database.run(insSet, ['login_logo', '/assets/images/tmss-logo.png']);
    database.run(insSet, ['brand_color', '#2ecc71']);
    database.run(insSet, ['app_name', 'Management Information System']);
    database.run("COMMIT");
    database.persist();
  } else {
    // Ensure branding keys exist
    const insIfMissing = `INSERT OR IGNORE INTO system_settings (key, value) VALUES (?, ?)`;
    database.run(insIfMissing, ['login_title', 'Welcome to Management Information System']);
    database.run(insIfMissing, ['login_subtitle', 'Manage your management information system efficiently and effectively.']);
    database.run(insIfMissing, ['login_hero_image', '/assets/images/login-hero.jpg']);
    database.run(insIfMissing, ['login_logo', '/assets/images/tmss-logo.png']);
    database.run(insIfMissing, ['brand_color', '#2ecc71']);
    database.run(insIfMissing, ['app_name', 'Management Information System']);
    database.persist();
  }
}

