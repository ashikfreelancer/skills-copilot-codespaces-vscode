<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('branches', function (Blueprint $table) {
            $table->id();
            $table->string('code', 50)->unique();
            $table->string('name', 150);
            $table->string('division', 100);
            $table->string('district', 100);
            $table->string('thana', 100);
            $table->string('upazila', 100);
            $table->string('union_name', 150)->nullable();
            $table->string('ward', 50)->nullable();
            $table->string('manager', 150)->nullable();
            $table->string('mobile', 50)->nullable();
            $table->string('personal_mobile', 50)->nullable();
            $table->string('email', 150)->nullable();
            $table->enum('status', ['Active', 'Inactive', 'Review'])->default('Active');
            $table->text('full_address')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('code');
            $table->index('name');
            $table->index(['division', 'district', 'upazila']);
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('branches');
    }
};
