<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('excel_import_export_logs', function (Blueprint $table) {
            $table->id();
            $table->enum('operation_type', ['Import', 'Export']);
            $table->enum('module_name', [
                'Staff Position List',
                'Branch Directory',
                'Monthly MIS',
                'Advance Register',
                'Stock Register',
                'Movement Register'
            ]);
            $table->string('file_name', 255);
            $table->integer('total_records')->default(0);
            $table->integer('successful_records')->default(0);
            $table->integer('failed_records')->default(0);
            $table->enum('status', ['Pending', 'Processing', 'Completed', 'Failed'])->default('Pending');
            $table->text('error_log')->nullable();
            $table->foreignId('performed_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['operation_type', 'module_name']);
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('excel_import_export_logs');
    }
};
