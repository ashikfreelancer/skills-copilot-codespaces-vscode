<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name', 150);
            $table->string('email', 150)->unique(); // User ID or Email
            $table->string('password');
            $table->enum('role', [
                'MIS Super Admin',
                'MIS Manager',
                'MIS Officer',
                'MIS Data Entry',
                'MIS Reviewer',
                'MIS Viewer',
                'Management Viewer'
            ])->default('MIS Viewer');
            $table->string('department', 100)->default('MIS');
            $table->enum('status', ['Active', 'Inactive', 'Suspended'])->default('Active');
            $table->string('division', 100)->nullable()->default('All');
            $table->string('district', 100)->nullable()->default('All');
            $table->string('upazila', 100)->nullable()->default('All');
            $table->string('scope_department', 100)->nullable()->default('All');
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['status', 'role']);
            $table->index('email');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
