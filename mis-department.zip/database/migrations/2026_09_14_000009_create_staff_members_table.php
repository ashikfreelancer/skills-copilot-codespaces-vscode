<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('staff_members', function (Blueprint $table) {
            $table->id();
            $table->string('staff_id', 50)->unique();
            $table->string('serial', 20)->nullable();
            $table->string('name', 150);
            $table->enum('gender', ['Male', 'Female', 'Other']);
            $table->date('dob')->nullable();
            $table->string('father_name', 150)->nullable();
            $table->string('mother_name', 150)->nullable();
            $table->string('designation', 100);
            $table->date('join_date')->nullable();
            $table->date('posting_date')->nullable();
            $table->date('promotion_date')->nullable();
            $table->string('education', 150)->nullable();
            $table->string('home_district', 100)->nullable();
            $table->string('previous_posting', 150)->nullable();
            $table->string('current_posting', 150)->nullable();
            $table->foreignId('department_id')->nullable()->constrained('departments')->restrictOnDelete();
            $table->string('department_name', 100)->nullable();
            $table->enum('status', ['Active', 'Inactive', 'On Leave'])->default('Active');
            $table->integer('allocated_leave')->default(44);
            $table->timestamps();
            $table->softDeletes();

            $table->index('staff_id');
            $table->index('name');
            $table->index('designation');
            $table->index('department_id');
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('staff_members');
    }
};
