<?php

namespace Database\Migrations;

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations for domain & zone head information.
     */
    public function up(): void
    {
        Schema::create('domain_zones', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('domain');
            $table->string('zone')->default('');
            $table->enum('head_type', ['Domain Head', 'Zone Head'])->default('Zone Head');
            $table->string('head_name');
            $table->string('designation');
            $table->string('employee_id');
            $table->string('mobile');
            $table->string('email')->nullable();
            $table->text('address')->nullable();
            $table->enum('status', ['Active', 'Inactive'])->default('Active');
            $table->text('remarks')->nullable();
            $table->timestamps();

            $table->index(['domain', 'zone']);
            $table->index('employee_id');
            $table->index('head_type');
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('domain_zones');
    }
};
