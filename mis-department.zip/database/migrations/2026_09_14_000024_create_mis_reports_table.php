<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mis_reports', function (Blueprint $table) {
            $table->id();
            $table->string('report_title', 255);
            $table->string('reporting_period', 50);
            $table->string('template_name', 100)->nullable();
            $table->foreignId('branch_id')->nullable()->constrained('branches')->nullOnDelete();
            $table->enum('report_type', ['Daily', 'Weekly', 'Monthly', 'Quarterly', 'Annual'])->default('Monthly');
            $table->enum('submission_status', ['Draft', 'Submitted', 'Approved', 'Rejected'])->default('Draft');
            $table->text('attachment_path')->nullable();
            $table->text('remarks')->nullable();
            $table->foreignId('submitted_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('approved_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index('report_title');
            $table->index('reporting_period');
            $table->index('submission_status');
            $table->index('branch_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mis_reports');
    }
};
