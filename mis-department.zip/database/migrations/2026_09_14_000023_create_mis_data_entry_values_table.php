<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mis_data_entry_values', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mis_data_entry_id')->constrained('mis_data_entries')->cascadeOnDelete();
            $table->foreignId('mis_form_indicator_id')->constrained('mis_form_indicators')->cascadeOnDelete();
            $table->text('indicator_value')->nullable();
            $table->timestamps();

            $table->unique(['mis_data_entry_id', 'mis_form_indicator_id'], 'uq_entry_indicator');
            $table->index('mis_data_entry_id');
            $table->index('mis_form_indicator_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mis_data_entry_values');
    }
};
