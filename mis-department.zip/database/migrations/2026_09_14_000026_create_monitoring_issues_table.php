<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('monitoring_issues', function (Blueprint $table) {
            $table->id();
            $table->enum('issue_type', ['Data Issue', 'Report Issue', 'System Issue', 'Other'])->default('Data Issue');
            $table->foreignId('branch_id')->nullable()->constrained('branches')->nullOnDelete();
            $table->text('issue_description');
            $table->string('reported_by', 150);
            $table->foreignId('assigned_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('deadline')->nullable();
            $table->enum('resolution_status', ['Open', 'In Progress', 'Resolved', 'Closed'])->default('Open');
            $table->timestamps();
            $table->softDeletes();

            $table->index('issue_type');
            $table->index('branch_id');
            $table->index('resolution_status');
            $table->index('deadline');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('monitoring_issues');
    }
};
