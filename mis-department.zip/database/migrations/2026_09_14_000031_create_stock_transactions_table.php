<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stock_transactions', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_number', 50)->unique();
            $table->date('transaction_date');
            $table->foreignId('stock_item_id')->constrained('stock_items')->cascadeOnDelete();
            $table->enum('type', ['Receive', 'Issue', 'Return', 'Transfer In', 'Transfer Out']);
            $table->decimal('quantity', 12, 2);
            $table->decimal('unit_price', 12, 2)->default(0.00);
            $table->string('location', 100);
            $table->string('reference', 100)->nullable();
            $table->string('party', 150)->nullable();
            $table->string('staff_id', 50)->nullable();
            $table->string('purpose', 255)->nullable();
            $table->string('approved_by', 150)->nullable();
            $table->text('remarks')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('transaction_number');
            $table->index('transaction_date');
            $table->index(['stock_item_id', 'type']);
            $table->index('location');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stock_transactions');
    }
};
