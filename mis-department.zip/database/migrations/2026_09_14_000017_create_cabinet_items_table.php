<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cabinet_items', function (Blueprint $table) {
            $table->id();
            $table->enum('item_type', ['Note', 'Document']);
            $table->string('title', 255);
            $table->string('memo_no', 100)->nullable();
            $table->string('category', 100);
            $table->date('item_date');
            $table->string('department', 100)->nullable();
            $table->string('version', 50)->nullable();
            $table->text('description')->nullable();
            $table->string('created_by', 150)->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('item_type');
            $table->index('category');
            $table->index('item_date');
            $table->index('title');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cabinet_items');
    }
};
