<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('administrative_locations', function (Blueprint $table) {
            $table->string('id')->primary(); // DIV-xxx, DIST-xxx, THA-xxx, UPA-xxx
            $table->enum('type', ['Division', 'District', 'Thana', 'Upazila']);
            $table->string('name');
            $table->string('division')->nullable()->default('');
            $table->string('district')->nullable()->default('');
            $table->string('thana')->nullable()->default('');
            $table->enum('status', ['Active', 'Inactive'])->default('Active');
            $table->timestamps();

            $table->index(['type', 'status']);
            $table->index(['division', 'district', 'thana']);
        });

        Schema::create('branches', function (Blueprint $table) {
            $table->string('id')->primary(); // LOC-xxx
            $table->string('division');
            $table->string('district');
            $table->string('thana');
            $table->string('upazila');
            $table->string('union_name')->nullable()->default('');
            $table->string('ward')->nullable()->default('');
            $table->string('branch');
            $table->string('code')->unique();
            $table->string('manager')->nullable()->default('');
            $table->string('mobile')->nullable()->default('');
            $table->string('personal_mobile')->nullable()->default('');
            $table->string('email')->nullable()->default('');
            $table->enum('status', ['Active', 'Inactive', 'Review'])->default('Active');
            $table->text('address')->nullable();
            $table->timestamps();

            $table->index(['division', 'district', 'upazila']);
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('branches');
        Schema::dropIfExists('administrative_locations');
    }
};
