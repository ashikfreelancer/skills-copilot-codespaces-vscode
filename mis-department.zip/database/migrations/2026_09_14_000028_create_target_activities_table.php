<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('target_activities', function (Blueprint $table) {
            $table->id();
            $table->string('period', 50); // e.g. September 2026
            $table->string('area_scope', 150)->nullable()->default('All Areas');
            $table->foreignId('branch_id')->nullable()->constrained('branches')->nullOnDelete();
            $table->string('indicator_kpi', 150);
            $table->decimal('target_value', 15, 2)->default(0.00);
            $table->text('activity_description')->nullable();
            $table->foreignId('created_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index('period');
            $table->index('indicator_kpi');
            $table->index('branch_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('target_activities');
    }
};
