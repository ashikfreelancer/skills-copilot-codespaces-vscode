<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cabinet_attachments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cabinet_item_id')->constrained('cabinet_items')->cascadeOnDelete();
            $table->string('file_name', 255);
            $table->text('file_path');
            $table->string('file_type', 100)->nullable();
            $table->unsignedBigInteger('file_size')->default(0);
            $table->timestamp('uploaded_at')->useCurrent();
            $table->timestamps();

            $table->index('cabinet_item_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cabinet_attachments');
    }
};
