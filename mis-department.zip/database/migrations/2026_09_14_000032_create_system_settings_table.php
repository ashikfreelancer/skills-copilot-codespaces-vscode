<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('system_settings', function (Blueprint $table) {
            $table->id();
            $table->enum('backup_frequency', ['Daily', 'Weekly', 'Monthly'])->default('Daily');
            $table->enum('retention_period', ['30 Days', '90 Days', '180 Days', '365 Days'])->default('30 Days');
            $table->boolean('notification_alerts_enabled')->default(true);
            $table->boolean('report_approval_required')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('system_settings');
    }
};
