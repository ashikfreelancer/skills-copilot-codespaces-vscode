<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('movement_registers', function (Blueprint $table) {
            $table->id();
            $table->string('movement_number', 50)->unique();
            $table->date('movement_date');
            $table->string('employee_id', 50);
            $table->string('employee_name', 150);
            $table->string('designation', 100);
            $table->string('department', 100)->default('MIS');
            $table->string('domain', 100);
            $table->string('zone', 100);
            $table->string('location', 150);
            $table->enum('movement_type', ['Official', 'Field Visit', 'Personal', 'Training', 'Other'])->default('Official');
            $table->string('out_time', 20);
            $table->string('expected_return_time', 20)->nullable();
            $table->string('actual_return_time', 20)->nullable();
            $table->string('purpose', 255);
            $table->string('destination', 255);
            $table->string('contact_number', 50)->nullable();
            $table->string('vehicle', 100)->nullable();
            $table->string('accompanied_by', 150)->nullable();
            $table->string('approved_by', 150)->nullable();
            $table->enum('status', ['Out', 'Returned', 'Late Return', 'Pending'])->default('Out');
            $table->text('remarks')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index('movement_number');
            $table->index('movement_date');
            $table->index('employee_id');
            $table->index(['domain', 'zone']);
            $table->index('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('movement_registers');
    }
};
