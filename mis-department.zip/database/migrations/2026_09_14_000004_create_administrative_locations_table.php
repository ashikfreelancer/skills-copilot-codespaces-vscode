<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('administrative_locations', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['Division', 'District', 'Thana', 'Upazila']);
            $table->string('name', 150);
            $table->string('division', 150)->nullable();
            $table->string('district', 150)->nullable();
            $table->string('thana', 150)->nullable();
            $table->foreignId('parent_id')->nullable()->constrained('administrative_locations')->restrictOnDelete();
            $table->enum('status', ['Active', 'Inactive'])->default('Active');
            $table->timestamps();
            $table->softDeletes();

            $table->index(['type', 'status']);
            $table->index('division');
            $table->index('district');
            $table->index('thana');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('administrative_locations');
    }
};
