<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mis_form_indicators', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mis_form_id')->constrained('mis_forms')->cascadeOnDelete();
            $table->string('name', 255);
            $table->enum('data_type', ['Number', 'Text', 'Date', 'Percentage'])->default('Number');
            $table->boolean('is_required')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            $table->index('mis_form_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mis_form_indicators');
    }
};
