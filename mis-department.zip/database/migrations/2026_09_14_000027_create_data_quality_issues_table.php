<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('data_quality_issues', function (Blueprint $table) {
            $table->id();
            $table->string('record_identifier', 100)->nullable();
            $table->text('validation_error');
            $table->string('related_module', 100);
            $table->string('field_name', 100)->nullable();
            $table->text('previous_value')->nullable();
            $table->text('new_correct_value')->nullable();
            $table->text('correction_reason')->nullable();
            $table->date('correction_date')->nullable();
            $table->enum('priority', ['Low', 'Medium', 'High'])->default('Medium');
            $table->enum('status', ['Pending', 'Corrected', 'Verified'])->default('Pending');
            $table->text('action_taken')->nullable();
            $table->foreignId('resolved_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index('related_module');
            $table->index('status');
            $table->index('priority');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('data_quality_issues');
    }
};
