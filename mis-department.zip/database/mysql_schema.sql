-- =====================================================================
-- TMSS MIS Department Enterprise System - MySQL Database Dump & Schema
-- ডাটাবেজ নাম: mis_department
-- তৈরি তারিখ: 2026-09-23T03:30:01.602Z
-- Target Engine: MySQL 8.0+ / MariaDB 10.4+ / XAMPP / WAMP / Laragon
-- Charset: utf8mb4 / Collation: utf8mb4_unicode_ci
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `mis_department` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `mis_department`;

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- ---------------------------------------------------------------------
-- ১. ইউজার টেবিল (Users & Authentication)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_code` VARCHAR(50) UNIQUE DEFAULT NULL,
  `login` VARCHAR(100) DEFAULT NULL,
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'MIS Viewer',
  `department` VARCHAR(100) NOT NULL DEFAULT 'MIS',
  `scope` VARCHAR(100) NOT NULL DEFAULT 'All',
  `status` VARCHAR(50) NOT NULL DEFAULT 'Active',
  `permissions` TEXT DEFAULT NULL,
  `remember_token` VARCHAR(100) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ২. পাসওয়ার্ড রিসেট টেবিল (Password Resets)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` VARCHAR(150) NOT NULL,
  `token` VARCHAR(255) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_password_resets_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৩. সেশন টেবিল (Sessions)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` VARCHAR(191) PRIMARY KEY,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `payload` LONGTEXT NOT NULL,
  `last_activity` INT NOT NULL,
  INDEX `idx_sessions_user_id` (`user_id`),
  INDEX `idx_sessions_last_activity` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৪. অডিট লগ টেবিল (Audit Logs)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` VARCHAR(50) DEFAULT NULL,
  `username` VARCHAR(150) DEFAULT 'System / Guest',
  `module` VARCHAR(100) NOT NULL,
  `action` VARCHAR(50) NOT NULL,
  `reference` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT '127.0.0.1',
  `user_agent` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_audit_module_time` (`module`, `created_at`),
  INDEX `idx_audit_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৫. প্রশাসনিক লোকেশন টেবিল (Administrative Locations)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `administrative_locations`;
CREATE TABLE `administrative_locations` (
  `id` VARCHAR(50) PRIMARY KEY,
  `type` VARCHAR(50) DEFAULT 'Division',
  `name` VARCHAR(150) NOT NULL,
  `division` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) DEFAULT '',
  `thana` VARCHAR(100) DEFAULT '',
  `status` VARCHAR(50) DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_admin_loc_div_dist` (`division`, `district`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৬. ব্রাঞ্চ / শাখা টেবিল (Branches)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` VARCHAR(50) PRIMARY KEY,
  `division` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `thana` VARCHAR(100) NOT NULL,
  `upazila` VARCHAR(100) DEFAULT '',
  `union_name` VARCHAR(100) DEFAULT '',
  `ward` VARCHAR(50) DEFAULT '',
  `branch` VARCHAR(150) NOT NULL,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `manager` VARCHAR(150) DEFAULT '',
  `mobile` VARCHAR(50) DEFAULT '',
  `personal_mobile` VARCHAR(50) DEFAULT '',
  `email` VARCHAR(150) DEFAULT '',
  `status` VARCHAR(50) DEFAULT 'Active',
  `address` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_branch_division` (`division`),
  INDEX `idx_branch_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৭. ডোমেন ও জোন টেবিল (Domain & Zones)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `domain_zones`;
CREATE TABLE `domain_zones` (
  `id` VARCHAR(50) PRIMARY KEY,
  `domain` VARCHAR(100) NOT NULL,
  `zone` VARCHAR(100) DEFAULT '',
  `head_type` VARCHAR(50) NOT NULL DEFAULT 'Zone Head',
  `head_name` VARCHAR(150) NOT NULL,
  `designation` VARCHAR(100) NOT NULL,
  `employee_id` VARCHAR(50) NOT NULL,
  `mobile` VARCHAR(50) NOT NULL,
  `email` VARCHAR(150) DEFAULT '',
  `address` TEXT DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'Active',
  `remarks` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_domain_zone` (`domain`, `zone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৮. ডিপার্টমেন্ট টেবিল (Departments)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL UNIQUE,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `description` TEXT DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ৯. কর্মকর্তা ও কর্মচারী টেবিল (Staff Positions)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `staff_positions`;
CREATE TABLE `staff_positions` (
  `id` VARCHAR(50) PRIMARY KEY,
  `serial` VARCHAR(20) DEFAULT '',
  `name` VARCHAR(150) NOT NULL,
  `gender` VARCHAR(20) DEFAULT 'Male',
  `dob` VARCHAR(30) DEFAULT '',
  `father` VARCHAR(150) DEFAULT '',
  `mother` VARCHAR(150) DEFAULT '',
  `staff_id` VARCHAR(50) NOT NULL UNIQUE,
  `designation` VARCHAR(150) NOT NULL,
  `join_date` VARCHAR(30) DEFAULT '',
  `posting_date` VARCHAR(30) DEFAULT '',
  `promotion_date` VARCHAR(30) DEFAULT '',
  `education` VARCHAR(150) DEFAULT '',
  `home_district` VARCHAR(100) DEFAULT '',
  `previous_posting` VARCHAR(150) DEFAULT '',
  `current_posting` VARCHAR(150) DEFAULT '',
  `department` VARCHAR(100) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_staff_department` (`department`),
  INDEX `idx_staff_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১০. বদলি টেবিল (Staff Transfers)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `staff_transfers`;
CREATE TABLE `staff_transfers` (
  `id` VARCHAR(50) PRIMARY KEY,
  `staff_id` VARCHAR(50) NOT NULL,
  `staff_name` VARCHAR(150) NOT NULL,
  `designation` VARCHAR(150) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `from_branch` VARCHAR(150) NOT NULL,
  `to_branch` VARCHAR(150) NOT NULL,
  `transfer_date` VARCHAR(30) NOT NULL,
  `order_number` VARCHAR(100) DEFAULT '',
  `approved_by` VARCHAR(150) DEFAULT '',
  `handover_status` VARCHAR(50) DEFAULT 'Completed',
  `charge_handed_to` VARCHAR(150) DEFAULT '',
  `reason` TEXT DEFAULT NULL,
  `remarks` TEXT DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'Approved',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_transfer_staff` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১১. ছুটি টেবিল (Leaves)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `leaves`;
CREATE TABLE `leaves` (
  `id` VARCHAR(50) PRIMARY KEY,
  `staff_id` VARCHAR(50) NOT NULL,
  `staff_name` VARCHAR(150) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `leave_type` VARCHAR(100) NOT NULL,
  `from_date` VARCHAR(30) NOT NULL,
  `to_date` VARCHAR(30) NOT NULL,
  `days` INT NOT NULL DEFAULT 1,
  `status` VARCHAR(50) NOT NULL DEFAULT 'Pending',
  `reason` TEXT DEFAULT NULL,
  `approved_by` VARCHAR(150) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_leaves_staff` (`staff_id`),
  INDEX `idx_leaves_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১২. অগ্রিম গ্রহণ টেবিল (Advances)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `advances`;
CREATE TABLE `advances` (
  `id` VARCHAR(50) PRIMARY KEY,
  `employee` VARCHAR(150) NOT NULL,
  `employee_id` VARCHAR(50) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `designation` VARCHAR(150) NOT NULL,
  `purpose` VARCHAR(255) NOT NULL,
  `request_date` VARCHAR(30) NOT NULL,
  `due_date` VARCHAR(30) NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `adjusted` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(50) NOT NULL DEFAULT 'Open',
  `approval` VARCHAR(50) NOT NULL DEFAULT 'Pending',
  `notes` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_advances_emp` (`employee_id`),
  INDEX `idx_advances_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৩. মুভমেন্ট রেজিস্টার টেবিল (Movement Registers)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `movement_registers`;
CREATE TABLE `movement_registers` (
  `id` VARCHAR(50) PRIMARY KEY,
  `date` VARCHAR(30) NOT NULL,
  `employee_id` VARCHAR(50) NOT NULL,
  `employee_name` VARCHAR(150) NOT NULL,
  `designation` VARCHAR(150) NOT NULL,
  `department` VARCHAR(100) NOT NULL DEFAULT 'MIS',
  `domain` VARCHAR(100) NOT NULL,
  `zone` VARCHAR(100) DEFAULT '',
  `location` VARCHAR(150) DEFAULT '',
  `type` VARCHAR(50) NOT NULL DEFAULT 'Official',
  `out_time` VARCHAR(30) NOT NULL,
  `expected_return` VARCHAR(30) DEFAULT '',
  `actual_return` VARCHAR(30) DEFAULT '',
  `purpose` TEXT NOT NULL,
  `destination` VARCHAR(255) NOT NULL,
  `contact` VARCHAR(50) DEFAULT '',
  `vehicle` VARCHAR(100) DEFAULT '',
  `accompanied_by` VARCHAR(150) DEFAULT '',
  `approved_by` VARCHAR(150) DEFAULT '',
  `status` VARCHAR(50) NOT NULL DEFAULT 'Out',
  `remarks` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_movement_emp` (`employee_id`),
  INDEX `idx_movement_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৪. স্টক আইটেম টেবিল (Stock Items - supports both min & min_level)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `stock_items`;
CREATE TABLE `stock_items` (
  `id` VARCHAR(50) PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `unit` VARCHAR(50) NOT NULL,
  `opening` DECIMAL(12,2) DEFAULT 0.00,
  `min` DECIMAL(12,2) DEFAULT 0.00,
  `min_level` DECIMAL(12,2) DEFAULT 0.00,
  `location` VARCHAR(150) NOT NULL,
  `supplier` VARCHAR(150) DEFAULT '',
  `status` VARCHAR(50) NOT NULL DEFAULT 'Active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_stock_code` (`code`),
  INDEX `idx_stock_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৫. স্টক লেনদেন টেবিল (Stock Transactions)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `stock_transactions`;
CREATE TABLE `stock_transactions` (
  `id` VARCHAR(50) PRIMARY KEY,
  `date` VARCHAR(30) NOT NULL,
  `item_id` VARCHAR(50) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `qty` DECIMAL(12,2) NOT NULL,
  `unit_price` DECIMAL(12,2) DEFAULT 0.00,
  `location` VARCHAR(150) NOT NULL,
  `reference` VARCHAR(100) DEFAULT '',
  `party` VARCHAR(150) DEFAULT '',
  `staff_id` VARCHAR(50) DEFAULT '',
  `purpose` VARCHAR(255) DEFAULT '',
  `approved_by` VARCHAR(150) DEFAULT '',
  `remarks` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_stock_tx_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৬. MIS ফরম টেবিল (MIS Forms)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `mis_forms`;
CREATE TABLE `mis_forms` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `period` VARCHAR(30) NOT NULL,
  `type` VARCHAR(50) NOT NULL DEFAULT 'Monthly',
  `department` VARCHAR(100) NOT NULL DEFAULT 'MIS',
  `branch` VARCHAR(150) DEFAULT 'All',
  `status` VARCHAR(50) NOT NULL DEFAULT 'Active',
  `indicators` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৭. মাসিক MIS সাবমিশন টেবিল (Monthly MIS Submissions)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `monthly_mis_submissions`;
CREATE TABLE `monthly_mis_submissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `year` INT NOT NULL,
  `month_code` VARCHAR(20) NOT NULL,
  `month_num` INT NOT NULL,
  `target` INT NOT NULL DEFAULT 0,
  `submitted` INT NOT NULL DEFAULT 0,
  `pending` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_monthly_period` (`year`, `month_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৮. রিপোর্টস টেবিল (Reports Registry)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `reports`;
CREATE TABLE `reports` (
  `id` VARCHAR(50) PRIMARY KEY,
  `title` VARCHAR(200) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `period` VARCHAR(50) NOT NULL,
  `scope` VARCHAR(100) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `generated_by` VARCHAR(150) NOT NULL,
  `file_type` VARCHAR(30) DEFAULT 'PDF',
  `file_size` VARCHAR(30) DEFAULT '1.2 MB',
  `status` VARCHAR(50) NOT NULL DEFAULT 'Ready',
  `remarks` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_reports_category` (`category`),
  INDEX `idx_reports_period` (`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ১৯. রিপোর্ট রিকোয়েস্ট টেবিল (Report Requests)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `report_requests`;
CREATE TABLE `report_requests` (
  `id` VARCHAR(50) PRIMARY KEY,
  `requester` VARCHAR(150) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `report` VARCHAR(200) NOT NULL,
  `request_date` VARCHAR(30) NOT NULL,
  `deadline` VARCHAR(30) NOT NULL,
  `format` VARCHAR(30) DEFAULT 'Excel',
  `priority` VARCHAR(30) DEFAULT 'Medium',
  `status` VARCHAR(50) DEFAULT 'Pending',
  `remarks` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ২০. টার্গেট ও অ্যাক্টিভিটি টেবিল (Target & Activities)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `target_activities`;
CREATE TABLE `target_activities` (
  `id` VARCHAR(50) PRIMARY KEY,
  `period` VARCHAR(50) NOT NULL,
  `area` VARCHAR(150) NOT NULL,
  `indicator` VARCHAR(200) NOT NULL,
  `target` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `achieved` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `description` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ২১. নথি ও ডকুমেন্ট ক্যাবিনেট (Cabinet Documents)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `cabinet_documents`;
CREATE TABLE `cabinet_documents` (
  `id` VARCHAR(50) PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `doc_type` VARCHAR(50) DEFAULT 'document',
  `memo_no` VARCHAR(100) DEFAULT '',
  `branch_tag` VARCHAR(150) DEFAULT '',
  `shelf_no` VARCHAR(50) DEFAULT '',
  `file_no` VARCHAR(50) DEFAULT '',
  `tags` TEXT DEFAULT NULL,
  `history` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ২২. ডাটা কোয়ালিটি ভেরিফিকেশন (Data Quality Verifications)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `data_quality_verifications`;
CREATE TABLE `data_quality_verifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `record_id` VARCHAR(100) NOT NULL UNIQUE,
  `module` VARCHAR(100) NOT NULL,
  `verified_by` VARCHAR(150) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Verified',
  `remarks` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ২৩. নোটিফিকেশন টেবিল (Notifications)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` VARCHAR(50) PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `type` VARCHAR(50) NOT NULL DEFAULT 'info',
  `target_module` VARCHAR(100) DEFAULT '',
  `time_label` VARCHAR(50) DEFAULT 'Today',
  `status` VARCHAR(50) NOT NULL DEFAULT 'Unread',
  `user_id` VARCHAR(50) DEFAULT '',
  `action_url` VARCHAR(255) DEFAULT '',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- ২৪. সিস্টেম সেটিংস টেবিল (System Settings)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `key` VARCHAR(100) PRIMARY KEY,
  `value` TEXT NOT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------
-- প্রাথমিক ব্যবহারকারী ডাটা (Default Users)
-- লগইন তথ্য:
-- ১. Super Admin: superadmin@mis.local / পাসওয়ার্ড: password অথবা 123456
-- ২. Data Entry: zone.officer@mis.local / পাসওয়ার্ড: password
-- ৩. Reviewer: reviewer@mis.local / পাসওয়ার্ড: password
-- ৪. Operator: operator@mis.local / পাসওয়ার্ড: password
-- ৫. Accountant: accountant@mis.local / পাসওয়ার্ড: password
-- ৬. TMSS Admin: admin@tmss.org / পাসওয়ার্ড: password
-- ---------------------------------------------------------------------

-- Seed Data: `users` (6 records)
INSERT INTO `users` (`user_code`, `login`, `name`, `email`, `password`, `role`, `department`, `scope`, `status`, `permissions`) VALUES
('U-001', 'U-001', 'MIS Super Admin', 'superadmin@mis.local', '$2y$12$wpETvfyQMGv2ePxF0xd.ged2A05r69ZB7qMJiQggRnT99mVHc9H5K', 'MIS Super Admin', 'MIS', 'All', 'Active', '["*"]'),
('U-002', 'U-002', 'Zone Officer', 'zone.officer@mis.local', '$2y$12$R4YsxaVg87O6IQA6Jb6YBuJhSsLi5TfjAHAEF8INhvjqNZQK7aN0W', 'MIS Data Entry', 'MIS', 'Dhaka Zone', 'Active', '["view","create","edit"]'),
('U-003', 'U-003', 'MIS Reviewer', 'reviewer@mis.local', '$2y$12$dYsiKHOnwykg81sFmXYu6u0A7S4H2gMzuJrXiFn3KPiU7jR7u9Aoq', 'MIS Reviewer', 'MIS', 'All', 'Active', '["view","approve","print","export"]'),
('U-004', 'U-004', 'Inactive User', 'inactive.user@mis.local', '$2y$12$y8Ye46rmERDgdJrXSLm.4.v8V8bociZqfGQM9wqBq.xv0G3/d30Da', 'MIS Viewer', 'MIS', 'All', 'Inactive', '["view"]'),
('U-005', 'U-005', 'Suspended User', 'suspended.user@mis.local', '$2y$12$IdAJu7qX0X09isJdBpPiV.1H3INfeQ6o3wBmbcF6aL8MRuPbu3PJe', 'MIS Viewer', 'MIS', 'All', 'Suspended', '["view"]'),
('U-006', 'U-006', 'TMSS MIS Administrator', 'admin@tmss.org', '$2y$12$Vte8qGhUyA.QJN6S9XCO0.9fRmRxCn0PxOsilvDiWYTQTf13ECbcu', 'MIS Super Admin', 'MIS', 'All', 'Active', '["*"]');

-- Seed Data: `departments` (13 records)
INSERT INTO `departments` (`id`, `name`, `code`, `description`, `status`) VALUES
('DEP-001', 'MIS', 'MIS-01', 'Management Information System', 'Active'),
('DEP-002', 'IT', 'IT-01', 'Information Technology', 'Active'),
('DEP-003', 'Accounts', 'ACC-01', 'Accounts & Finance', 'Active'),
('DEP-004', 'Audit', 'AUD-01', 'Internal Audit & Compliance', 'Active'),
('DEP-005', 'HR & Admin', 'HR-01', 'Human Resources & Administration', 'Active'),
('DEP-006', 'Operations', 'OPS-01', 'Operations & Program Management', 'Active'),
('DEP-1790091998708-271', 'Duplicate Dept Test', 'DEP-01', '', 'Active'),
('DEP-1790092413789-186', 'Master Test Dept DPT-40785', 'DPT-40785', 'Department for master test', 'Active'),
('DEP-1790092526648-355', 'Master Test Dept DPT-9000', 'DPT-9000', 'Department for master test', 'Active'),
('DEP-1790092537971-950', 'Master Test Dept DPT-99582', 'DPT-99582', 'Department for master test', 'Active'),
('DEP-1790092674774-190', 'Master Test Dept DPT-47962', 'DPT-47962', 'Department for master test', 'Active'),
('DEP-1790096114519-903', 'Dept DP-WF-4517', 'DP-WF-4517', 'Workflow testing dept', 'Active'),
('DEP-1790096128358-890', 'Dept DP-WF-8355', 'DP-WF-8355', 'Workflow testing dept', 'Active');

-- Seed Data: `administrative_locations` (14 records)
INSERT INTO `administrative_locations` (`id`, `type`, `name`, `division`, `district`, `thana`, `status`) VALUES
('DIV-001', 'Division', 'Dhaka', '', '', '', 'Active'),
('DIV-002', 'Division', 'Chattogram', '', '', '', 'Active'),
('DIV-003', 'Division', 'Rajshahi', '', '', '', 'Active'),
('DIV-004', 'Division', 'Khulna', '', '', '', 'Active'),
('DIST-001', 'District', 'Dhaka', 'Dhaka', '', '', 'Active'),
('DIST-002', 'District', 'Chattogram', 'Chattogram', '', '', 'Active'),
('DIST-003', 'District', 'Rajshahi', 'Rajshahi', '', '', 'Active'),
('THA-001', 'Thana', 'Savar', 'Dhaka', 'Dhaka', '', 'Active'),
('THA-002', 'Thana', 'Keraniganj', 'Dhaka', 'Dhaka', '', 'Active'),
('THA-003', 'Thana', 'Mirsharai', 'Chattogram', 'Chattogram', '', 'Active'),
('UPA-001', 'Upazila', 'Savar', 'Dhaka', 'Dhaka', 'Savar', 'Active'),
('UPA-002', 'Upazila', 'Keraniganj', 'Dhaka', 'Dhaka', 'Keraniganj', 'Active'),
('UPA-003', 'Upazila', 'Mirsharai', 'Chattogram', 'Chattogram', 'Mirsharai', 'Active'),
('DIV-1789465365354', 'Division', 'Barishal Test', '', '', '', 'Active');

-- Seed Data: `domain_zones` (68 records)
INSERT INTO `domain_zones` (`id`, `domain`, `zone`, `head_type`, `head_name`, `designation`, `employee_id`, `mobile`, `email`, `address`, `status`, `remarks`) VALUES
('OP-001', 'অপারেশন-০১', '', 'Domain Head', 'মোঃ সাজ্জাদুর রহমান', 'JD', '101-0141', '01713-377266', 'hemop1@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-002', 'অপারেশন-০১', 'বগুড়া উত্তর', 'Zone Head', 'মোঃ মোয়াজ্জেম হোসেন', 'ZM', '101-352', '01713-377250', 'zhbognorth@tmss-bd.org', '', 'Active', ''),
('DZ-003', 'অপারেশন-০১', 'বগুড়া দক্ষিণ', 'Zone Head', 'মোঃ সাজ্জাদ হোসেন', 'AD', '101-7937', '01713-377032', 'zhbograsouth@tmss-bd.org', '', 'Active', ''),
('DZ-004', 'অপারেশন-০১', 'দরগাহাট', 'Zone Head', 'সেলিম আহমেদ ফকির', 'ZM', '101-02990', '01711-436657', 'zhdorgahat@tmss-bd.org', '', 'Active', ''),
('OP-002', 'অপারেশন-০২', '', 'Domain Head', 'এস এম বাবুল', 'AD', '101-00301', '01777-798043', 'hemop2@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-005', 'অপারেশন-০২', 'ঢাকা', 'Zone Head', 'মোঃ কামরুল ইসলাম', 'AM', '101-8468', '01713-377185', 'tmssdhakazone@gmail.com', '', 'Active', ''),
('DZ-006', 'অপারেশন-০২', 'নারায়ণগঞ্জ', 'Zone Head', 'মোঃ জাহাঙ্গীর আলম', 'ZM', '101-40236', '01730-006938', 'tmssdhakasouthzone1234@gmail.com', '', 'Active', ''),
('DZ-007', 'অপারেশন-০২', 'সাভার', 'Zone Head', 'মোঃ ইব্রাহীম খলিল', 'ZM', '101-3216', '01313-092837', 'tmsssavarzone@gmail.com', '', 'Active', ''),
('DZ-008', 'অপারেশন-০২', 'নরসিংদী', 'Zone Head', 'মোঃ আল আমিন', 'AM', '101-02877', '01713-377169', 'narsingdizone@tmss-bd.org', '', 'Active', ''),
('OP-003', 'অপারেশন-০৩', '', 'Domain Head', 'মোঃ ওসমান গনি', 'DD', '101-15276', '01708-491238', 'hemop3@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-009', 'অপারেশন-০৩', 'রাজশাহী', 'Zone Head', 'মোঃ চারোয়ার জাহান', 'ZM', '101-4722', '01713-377258', 'zhrajshahi@tmss-bd.org', '', 'Active', ''),
('DZ-010', 'অপারেশন-০৩', 'চাঁপাইনবাবগঞ্জ', 'Zone Head', 'নিখিল চন্দ্র চক্রবর্তী', 'ZM', '101-3688', '01713-377241', 'zhchapai@tmss-bd.org', '', 'Active', ''),
('DZ-011', 'অপারেশন-০৩', 'নওগাঁ জোন', 'Zone Head', 'মোঃ ইউনুছ আলী', 'ZM', '101-01941', '01713-377171', 'zhnaogaon@tmss-bd.org', '', 'Active', ''),
('DZ-012', 'অপারেশন-০৩', 'পুঠিয়া', 'Zone Head', 'মোঃ আজিজুল হক (আজিজ)', 'ZM', '101-2685', '01713-377352', 'zhputhia@tmss-bd.org', '', 'Active', ''),
('OP-004', 'অপারেশন-০৪', '', 'Domain Head', 'মোহাম্মদ শাহীন মিয়া', 'AD', '101-21036', '01730-735953', 'hemop4@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-013', 'অপারেশন-০৪', 'গাইবান্ধা', 'Zone Head', 'মোঃ মাকসুদুর রহমান', 'SZM', '101-968', '01713-377159', 'zhgaibandha@tmss-bd.org', '', 'Active', ''),
('DZ-014', 'অপারেশন-০৪', 'রংপুর জোন', 'Zone Head', 'মোঃ ময়নুল হক প্রধান', 'ZM', '101-3681', '01713-377157', 'zhrangpur@tmss-bd.org', '', 'Active', ''),
('DZ-015', 'অপারেশন-০৪', 'কুড়িগ্রাম', 'Zone Head', 'মোঃ আব্দুর রশিদ', 'ZM', '101-2367', '01713-377257', 'zhkurigram@tmss-bd.org', '', 'Active', ''),
('DZ-016', 'অপারেশন-০৪', 'লালমনিরহাট', 'Zone Head', 'মোঃ সাইদুর রহমান', 'ZM', '101-1408', '01713-377210', 'zhlalmoni@tmss-bd.org', '', 'Active', ''),
('OP-005', 'অপারেশন-০৫', '', 'Domain Head', 'মোঃ আব্দুর রাজ্জাক', 'DD', '101-00747', '01713-377195', 'hemop5@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-017', 'অপারেশন-০৫', 'চট্টগ্রাম উত্তর', 'Zone Head', 'মোঃ মোক্তাদিয়ার রহমান', 'AM', '101-2305', '01709-646514', 'ctgnorthzone@tmss-bd.org', '', 'Active', ''),
('DZ-018', 'অপারেশন-০৫', 'চট্টগ্রাম দক্ষিণ', 'Zone Head', 'মোঃ মামুনুর রশিদ', 'ZM', '101-3307', '01713-377189', 'tmssctgsouthzone@gmail.com', '', 'Active', ''),
('DZ-019', 'অপারেশন-০৫', 'সাতকানিয়া', 'Zone Head', 'মোঃ আল মামুন সরকার', 'ZM', '101-1689', '01704-124104', 'tmsssatkaniazone@gmail.com', '', 'Active', ''),
('DZ-020', 'অপারেশন-০৫', 'ফেনী', 'Zone Head', 'মোঃ গোলাম মোস্তফা', 'ZM', '101-02398', '01755-588923', 'tmssfenizone@gmail.com', '', 'Active', ''),
('DZ-021', 'অপারেশন-০৫', 'নোয়াখালী', 'Zone Head', 'মোঃ মজিবুর রহমান', 'AM', '101-12672', '01713-377279', 'tmssnoakhalizone@gmail.com', '', 'Active', ''),
('OP-006', 'অপারেশন-০৬', '', 'Domain Head', 'মনিরুল গনি চৌধুরী', 'DD', '101-40237', '01313-377092', 'hemop6@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-022', 'অপারেশন-০৬', 'সাতক্ষীরা', 'Zone Head', 'মোঃ আব্দুল বারিক', 'AM', '101-0344', '01708-491200', 'satkhirazone2016@gmail.com', '', 'Active', ''),
('DZ-023', 'অপারেশন-০৬', 'যশোর', 'Zone Head', 'মোঃ হারুনুর রশিদ', 'ZM', '101-5285', '01713-377190', 'tmssjessorezone@gmail.com', '', 'Active', ''),
('DZ-024', 'অপারেশন-০৬', 'খুলনা', 'Zone Head', 'মোঃ ইকবাল হোসেন', 'SZM', '101-00644', '01713-377275', 'zhkhulnazone@gmail.com', '', 'Active', ''),
('DZ-025', 'অপারেশন-০৬', 'কুষ্টিয়া', 'Zone Head', 'মোঃ মাহবুবুর রহমান', 'ZM', '101-314', '01709-646565', 'tmsskustiazone@gmail.com', '', 'Active', ''),
('OP-007', 'অপারেশন-০৭', '', 'Domain Head', 'ওয়াকিল আহমেদ', 'AD', '101-10567', '01713-377303', 'hemop7@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-026', 'অপারেশন-০৭', 'মৌলভীবাজার', 'Zone Head', 'মোঃ রফিকুল ইসলাম', 'ZM', '101-1656', '01730-735950', 'moulvibazarzone@tmss-bd.org', '', 'Active', ''),
('DZ-027', 'অপারেশন-০৭', 'সিলেট', 'Zone Head', 'মোঃ সেলিম রেজা', 'ZM', '101-26985', '01713-377198', 'sylhetzone@tmss-bd.org', '', 'Active', ''),
('DZ-028', 'অপারেশন-০৭', 'বিয়ানীবাজার', 'Zone Head', 'মোঃ আজিজুল হক', 'ZM', '101-02974', '01755-588999', 'beanibazarzone@tmss-bd.org', '', 'Active', ''),
('DZ-029', 'অপারেশন-০৭', 'হবিগঞ্জ', 'Zone Head', 'মোঃ শাহানুর আলম', 'AM', '101-05094', '01730-316078', 'habiganjzone@tmss-bd.org', '', 'Active', ''),
('DZ-030', 'অপারেশন-০৭', 'সুনামগঞ্জ', 'Zone Head', 'মোঃ আবুল হাসেম', 'ZM', '101-5302', '01713-377123', 'sunamganjzone@tmss-bd.org', '', 'Active', ''),
('OP-008', 'অপারেশন-০৮', '', 'Domain Head', 'মোঃ গোলাম মোস্তফা', 'AD', '101-1088', '01713-377219', 'hemop8@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-031', 'অপারেশন-০৮', 'ফরিদপুর', 'Zone Head', 'আবু বকর সিদ্দিক', 'ZM', '101-13084', '01730-735949', 'faridpurzone@tmss-bd.org', '', 'Active', ''),
('DZ-032', 'অপারেশন-০৮', 'বরিশাল', 'Zone Head', 'মোঃ আবুল কালাম আজাদ', 'ZM', '101-0376', '01755-545692', 'zhbarisaltmss@gmail.com', '', 'Active', ''),
('DZ-033', 'অপারেশন-০৮', 'মাদারীপুর', 'Zone Head', 'মোঃ মিজানুর রহমান', 'ZM', '101-11242', '01725-698957', 'madaripurzone@tmss-bd.org', '', 'Active', ''),
('OP-009', 'অপারেশন-০৯', '', 'Domain Head', 'সাগর কুমার বড়ুয়া', 'DD', '101-03089', '01713-377316', 'hemop9@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-034', 'অপারেশন-০৯', 'দিনাজপুর', 'Zone Head', 'মোঃ আহসান হাবিব', 'ZM', '101-10851', '01713-377267', 'dinajpurtmss@yahoo.com', '', 'Active', ''),
('DZ-035', 'অপারেশন-০৯', 'সৈয়দপুর', 'Zone Head', 'মোঃ রুহুল আমিন', 'AD', '101-02503', '01730-735937', 'zhsyedpur@tmss-bd.org', '', 'Active', ''),
('DZ-036', 'অপারেশন-০৯', 'ঠাকুরগাঁও', 'Zone Head', 'মোঃ মাসুদ জাহেদী', 'ZM', '101-1761', '01713-377208', 'zhthakurgaon@tmss-bd.org', '', 'Active', ''),
('DZ-037', 'অপারেশন-০৯', 'পঞ্চগড়', 'Zone Head', 'মোঃ আব্দুল আলীম', 'ZM', '101-5364', '01713-377367', 'zhpancho@tmss-bd.org', '', 'Active', ''),
('OP-010', 'অপারেশন-১০', '', 'Domain Head', 'মোঃ মাহবুবুল হাসান', 'DD', '101-21478', '01709-642961', 'hemop10@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-038', 'অপারেশন-১০', 'লক্ষ্মীপুর', 'Zone Head', 'কুমুদ কুমার ধর', 'ZM', '101-8586', '01709-642990', 'tmsslaxmipurzone@gmail.com', '', 'Active', ''),
('DZ-039', 'অপারーション-১০', 'কুমিল্লা পূর্ব', 'Zone Head', 'মোঃ আতাউর রহমান', 'ZM', '101-8592', '01713-377317', 'tmsscomillaeast@gmail.com', '', 'Active', ''),
('DZ-040', 'অপারেশন-১০', 'কুমিল্লা পশ্চিম', 'Zone Head', 'মোঃ নজরুল ইসলাম', 'ZM', '101-20824', '01704-124183', 'tmsscomillawestzone@gmail.com', '', 'Active', ''),
('DZ-041', 'অপারেশন-১০', 'চাঁদপুর', 'Zone Head', 'খ.আ.হে মোঃ ছায়েম', 'ZM', '101-1733', '01755-588940', 'tmsschadpur@gmail.com', '', 'Active', ''),
('OP-011', 'অপারেশন-১১', '', 'Domain Head', 'মোঃ রফিকুল ইসলাম', 'AD', '101-18522', '01713-377107', 'hemop11@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-042', 'অপারেশন-১১', 'পাবনা', 'Zone Head', 'আরিফুল ইসলাম', 'ZM', '101-22155', '01713-377235', 'zhpabna@tmss-bd.org', '', 'Active', ''),
('DZ-043', 'অপারেশন-১১', 'চাটমোহর', 'Zone Head', 'মোঃ হানজালাল রহমান', 'ZM', '101-05047', '01709-646557', 'zhchatmohortmss@yahoo.com', '', 'Active', ''),
('DZ-044', 'অপারেশন-১১', 'সিরাজগঞ্জ', 'Zone Head', 'মামুনুর রশিদ মামুন', 'ZM', '101-2179', '01713-377172', 'zhsirajganj@tmss-bd.org', '', 'Active', ''),
('DZ-045', 'অপারেশন-১১', 'নাটোর', 'Zone Head', 'দেব নারায়ণ সাহা', 'ZM', '101-8874', '01713-377182', 'zhnatoretmss@yahoo.com', '', 'Active', ''),
('OP-012', 'অপারেশন-১২', '', 'Domain Head', 'মোঃ আনোয়ার হোসেন', 'AD', '101-0247', '01713-377281', 'hemop12@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-046', 'অপারেশন-১২', 'গাজীপুর', 'Zone Head', 'মোঃ আব্দুল কাদের', 'ZM', '101-5943', '01713-377179', 'gazipurzone@gmail.com', '', 'Active', ''),
('DZ-047', 'অপারেশন-১২', 'টাঙ্গাইল', 'Zone Head', 'মোঃ কাছেদুল জান্নাত', 'ZM', '101-09388', '01713-377013', 'tmsstangailzone@gmail.com', '', 'Active', ''),
('DZ-048', 'অপারেশন-১২', 'নেত্রকোনা', 'Zone Head', 'মোঃ জিয়াউর রহমান', 'ZM', '101-0593', '01713-377019', 'netrokonazonetmss@gmail.com', '', 'Active', ''),
('DZ-049', 'অপারেশন-১২', 'জামালপুর', 'Zone Head', 'মোঃ মাসুদ রানা', 'AM', '101-05769', '01709-631075', 'jamalpurzonetmss@gmail.com', '', 'Active', ''),
('DZ-050', 'অপারেশন-১২', 'ময়মনসিংহ', 'Zone Head', 'মোঃ জাহিদুর রহমান', 'AZM', '101-3131', '01713-377158', 'tmssmymensinghzone@gmail.com', '', 'Active', ''),
('OP-013', 'অপারেশন-১৩', '', 'Domain Head', 'মোঃ ইসমাইল হোসেন', 'AD', '101-0858', '01708-491270', 'hemop13@tmss-bd.org', 'প্রধান কার্যালয়, ঢাকা', 'Active', ''),
('DZ-051', 'অপারেশন-১৩', 'জয়পুরহাট', 'Zone Head', 'মোঃ শহিদুল হাসান', 'ZM', '101-02863', '01713-377201', 'zhjoypur@tmss-bd.org', '', 'Active', ''),
('DZ-052', 'অপারেশন-১৩', 'বিরামপুর', 'Zone Head', 'মোঃ জুয়েল হোসেন', 'ZM', '101-7772', '01713-377351', 'zhbirampur@tmss-bd.org', '', 'Active', ''),
('DZ-053', 'অপারেশন-১৩', 'নওজপুর', 'Zone Head', 'মোঃ মাহবুবুল আলম', 'ZM', '101-13736', '01711-869844', 'zhnozipurtmss@gmail.com', '', 'Active', ''),
('DZ-054', 'অপারেশন-১৩', 'পলাশবাড়ী', 'Zone Head', 'মোঃ দেলোয়ার হোসেন', 'ZM', '101-399', '01708-491242', 'zhpolashbari@tmss-bd.org', '', 'Active', ''),
('DZ-1789463801963-906', 'অপারেশন-০২', 'সাভার টেস্ট জোন', 'Zone Head', 'টেস্ট কর্মকর্তা', 'ZM', '101-99999', '01799-999999', 'testzh@tmss-bd.org', 'সাভার, ঢাকা', 'Active', 'Automated test created entry'),
('DZ-1789463807283-14', 'অপারেশন-০২', 'সাভার টেস্ট জোন', 'Zone Head', 'টেস্ট কর্মকর্তা', 'ZM', '101-99999', '01799-999999', 'testzh@tmss-bd.org', 'সাভার, ঢাকা', 'Active', 'Automated test created entry');

-- Seed Data: `stock_items` (10 records)
INSERT INTO `stock_items` (`id`, `code`, `name`, `category`, `unit`, `opening`, `min`, `min_level`, `location`, `supplier`, `status`) VALUES
('IT-001', 'IT-001', 'A4 Paper', 'Stationery', 'Ream', 120, 30, 30, 'Main Store', 'ABC Stationery', 'Active'),
('IT-002', 'IT-002', 'Ball Pen', 'Stationery', 'Box', 80, 20, 20, 'Main Store', 'ABC Stationery', 'Active'),
('IT-003', 'IT-003', 'Keyboard', 'IT Equipment', 'Piece', 35, 5, 5, 'IT Store', 'Tech Supplier', 'Active'),
('IT-004', 'IT-004', 'Mouse', 'IT Equipment', 'Piece', 28, 5, 5, 'IT Store', 'Tech Supplier', 'Active'),
('IT-AUDIT-8299', 'IT-AUDIT-8299', 'Wireless Barcode Scanner', 'IT Equipment', 'Piece', 50, 10, 10, 'Central Store Room 2', '', 'Active'),
('IT-AUDIT-820', 'IT-AUDIT-820', 'Wireless Barcode Scanner', 'IT Equipment', 'Piece', 50, 10, 10, 'Central Store Room 2', '', 'Active'),
('IT-AUDIT-2672', 'IT-AUDIT-2672', 'Wireless Barcode Scanner', 'IT Equipment', 'Piece', 50, 10, 10, 'Central Store Room 2', '', 'Active'),
('IT-AUDIT-2593', 'IT-AUDIT-2593', 'Wireless Barcode Scanner', 'IT Equipment', 'Piece', 50, 10, 10, 'Central Store Room 2', '', 'Active'),
('IT-TEST-6540', 'IT-TEST-6540', 'Audit A4 Paper Ream', 'Stationery', 'Ream', 100, 20, 20, 'Main Store', '', 'Active'),
('IT-TEST-2781', 'IT-TEST-2781', 'Audit A4 Paper Ream', 'Stationery', 'Ream', 100, 20, 20, 'Main Store', '', 'Active');

-- Seed Data: `stock_transactions` (13 records)
INSERT INTO `stock_transactions` (`id`, `date`, `item_id`, `type`, `qty`, `unit_price`, `location`, `reference`, `party`, `staff_id`, `purpose`, `approved_by`, `remarks`) VALUES
('TX-001', '2026-09-10', 'IT-001', 'Receive', 50, 350, 'Main Store', 'GRN-1001', 'ABC Stationery', '', 'Stock Receive', 'Admin', ''),
('TX-002', '2026-09-11', 'IT-001', 'Issue', 20, 350, 'Main Store', 'ISS-1001', 'MIS Department', '', 'Office Use', 'Admin', ''),
('TX-003', '2026-09-12', 'IT-003', 'Issue', 4, 2800, 'IT Store', 'ISS-1002', 'Dhaka Zone', '', 'Branch Requirement', 'Principal', ''),
('TX-2416041', '2026-09-22', 'IT-AUDIT-8299', 'Receive', 20, 1500, 'Central Store Room 2', 'INV-2026-99', 'Tech Supplier Ltd', '', '', 'MIS Super Admin', ''),
('TX-2416057', '2026-09-22', 'IT-AUDIT-8299', 'Issue', 15, 1500, 'Central Store Room 2', '', '', 'STF-44609', 'Audit assignment', 'MIS Super Admin', ''),
('TX-2528773', '2026-09-22', 'IT-AUDIT-820', 'Receive', 20, 1500, 'Central Store Room 2', 'INV-2026-99', 'Tech Supplier Ltd', '', '', 'MIS Super Admin', ''),
('TX-2528789', '2026-09-22', 'IT-AUDIT-820', 'Issue', 15, 1500, 'Central Store Room 2', '', '', 'STF-28800', 'Audit assignment', 'MIS Super Admin', ''),
('TX-2540197', '2026-09-22', 'IT-AUDIT-2672', 'Receive', 20, 1500, 'Central Store Room 2', 'INV-2026-99', 'Tech Supplier Ltd', '', '', 'MIS Super Admin', ''),
('TX-2540238', '2026-09-22', 'IT-AUDIT-2672', 'Issue', 15, 1500, 'Central Store Room 2', '', '', 'STF-92250', 'Audit assignment', 'MIS Super Admin', ''),
('TX-2677092', '2026-09-22', 'IT-AUDIT-2593', 'Receive', 20, 1500, 'Central Store Room 2', 'INV-2026-99', 'Tech Supplier Ltd', '', '', 'MIS Super Admin', ''),
('TX-2677112', '2026-09-22', 'IT-AUDIT-2593', 'Issue', 15, 1500, 'Central Store Room 2', '', '', 'STF-261', 'Audit assignment', 'MIS Super Admin', ''),
('TX-6072859', '2026-09-22', 'IT-TEST-2781', 'Receive', 50, 0, 'Main Store', 'PO-2026-001', '', '', '', 'MIS Super Admin', 'Stock In verification'),
('TX-6072904', '2026-09-22', 'IT-TEST-2781', 'Issue', 30, 0, 'Main Store', 'REQ-2026-001', '', '', 'Office printing', 'MIS Super Admin', 'Stock Out verification');

-- Seed Data: `leaves` (9 records)
INSERT INTO `leaves` (`id`, `staff_id`, `staff_name`, `department`, `leave_type`, `from_date`, `to_date`, `days`, `status`, `reason`, `approved_by`) VALUES
('LV-001', 'EMP-1001', 'Kamrul Hasan', 'MIS', 'Casual Leave', '2026-09-05', '2026-09-07', 2, 'Approved', 'Family function', 'Super Admin'),
('LV-002', 'EMP-1002', 'Md. Rafiqul Islam', 'MIS', 'Medical Leave', '2026-09-08', '2026-09-10', 3, 'Approved', 'Health recovery', 'Super Admin'),
('LV-003', 'EMP-1003', 'Shahidul Alam', 'Operations', 'Annual Leave', '2026-09-15', '2026-09-20', 5, 'Pending', 'Personal leave', ''),
('LV-004', 'EMP-1004', 'Nasreen Sultana', 'Accounts', 'Casual Leave', '2026-09-18', '2026-09-19', 1, 'Pending', 'Personal work', ''),
('LV-1790092415836-153', 'STF-44609', 'Audit QA Staff Member', 'MIS', 'Casual Leave', '2026-10-01', '2026-10-03', 3, 'Approved', 'Personal affairs', ''),
('LV-1790092528668-15', 'STF-28800', 'Audit QA Staff Member', 'MIS', 'Casual Leave', '2026-10-01', '2026-10-03', 3, 'Approved', 'Personal affairs', ''),
('LV-1790092539992-853', 'STF-92250', 'Audit QA Staff Member', 'MIS', 'Casual Leave', '2026-10-01', '2026-10-03', 3, 'Approved', 'Personal affairs', ''),
('LV-1790092676922-510', 'STF-261', 'Audit QA Staff Member', 'MIS', 'Casual Leave', '2026-10-01', '2026-10-03', 3, 'Approved', 'Personal affairs', ''),
('LV-1790096139673-640', 'EMP-WF-8411', 'Workflow Engineer', 'Dept DP-WF-8355', 'Casual Leave', '2026-10-01', '2026-10-03', 3, 'Pending', 'Family urgent event', '');

-- Seed Data: `advances` (57 records)
INSERT INTO `advances` (`id`, `employee`, `employee_id`, `department`, `designation`, `purpose`, `request_date`, `due_date`, `amount`, `adjusted`, `status`, `approval`, `notes`) VALUES
('ADV-OD-001', 'Overdue Staff 1', 'EMP-2001', 'Operations', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 375000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-002', 'Overdue Staff 2', 'EMP-2002', 'Accounts', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 400000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-003', 'Overdue Staff 3', 'EMP-2003', 'IT', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 425000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-004', 'Overdue Staff 4', 'EMP-2004', 'Audit', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 450000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-005', 'Overdue Staff 5', 'EMP-2005', 'HR', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 475000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-006', 'Overdue Staff 6', 'EMP-2006', 'MIS', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 500000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-007', 'Overdue Staff 7', 'EMP-2007', 'Operations', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 525000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-008', 'Overdue Staff 8', 'EMP-2008', 'Accounts', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 550000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-009', 'Overdue Staff 9', 'EMP-2009', 'IT', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 575000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-010', 'Overdue Staff 10', 'EMP-2010', 'Audit', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 600000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-011', 'Overdue Staff 11', 'EMP-2011', 'HR', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 625000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-OD-012', 'Overdue Staff 12', 'EMP-2012', 'MIS', 'Field Officer', 'Field Operations and Logistical Advance', '2026-06-15', '2026-08-15', 650000, 100000, 'Overdue', 'Approved', 'Settlement notice issued'),
('ADV-0001', 'Officer 1', 'EMP-1001', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0002', 'Officer 2', 'EMP-1002', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0003', 'Officer 3', 'EMP-1003', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0004', 'Officer 4', 'EMP-1004', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0005', 'Officer 5', 'EMP-1005', 'HR', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0006', 'Officer 6', 'EMP-1006', 'MIS', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0007', 'Officer 7', 'EMP-1007', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0008', 'Officer 8', 'EMP-1008', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0009', 'Officer 9', 'EMP-1009', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0010', 'Officer 10', 'EMP-1010', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0011', 'Officer 11', 'EMP-1011', 'HR', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0012', 'Officer 12', 'EMP-1012', 'MIS', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0013', 'Officer 13', 'EMP-1013', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0014', 'Officer 14', 'EMP-1014', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0015', 'Officer 15', 'EMP-1015', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0016', 'Officer 16', 'EMP-1016', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0017', 'Officer 17', 'EMP-1017', 'HR', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0018', 'Officer 18', 'EMP-1018', 'MIS', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0019', 'Officer 19', 'EMP-1019', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0020', 'Officer 20', 'EMP-1020', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0021', 'Officer 21', 'EMP-1021', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0022', 'Officer 22', 'EMP-1022', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0023', 'Officer 23', 'EMP-1023', 'HR', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0024', 'Officer 24', 'EMP-1024', 'MIS', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0025', 'Officer 25', 'EMP-1025', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0026', 'Officer 26', 'EMP-1026', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0027', 'Officer 27', 'EMP-1027', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0028', 'Officer 28', 'EMP-1028', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0029', 'Officer 29', 'EMP-1029', 'HR', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0030', 'Officer 30', 'EMP-1030', 'MIS', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0031', 'Officer 31', 'EMP-1031', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0032', 'Officer 32', 'EMP-1032', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0033', 'Officer 33', 'EMP-1033', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0034', 'Officer 34', 'EMP-1034', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0035', 'Officer 35', 'EMP-1035', 'HR', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0036', 'Officer 36', 'EMP-1036', 'MIS', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0037', 'Officer 37', 'EMP-1037', 'Operations', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0038', 'Officer 38', 'EMP-1038', 'Accounts', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0039', 'Officer 39', 'EMP-1039', 'IT', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-0040', 'Officer 40', 'EMP-1040', 'Audit', 'Branch Staff', 'Monthly MIS Operational Expense', '2026-09-01', '2026-10-15', 393750, 50000, 'Open', 'Approved', 'Under regular settlement cycle'),
('ADV-6095-493', 'Audit QA Staff Member', 'STF-44609', 'MIS', 'Senior QA Engineer', 'Field travel allowance', '2026-09-22', '2026-10-15', 5000, 0, 'Open', 'Approved', ''),
('ADV-8818-515', 'Audit QA Staff Member', 'STF-28800', 'MIS', 'Senior QA Engineer', 'Field travel allowance', '2026-09-22', '2026-10-15', 5000, 0, 'Open', 'Approved', ''),
('ADV-0268-353', 'Audit QA Staff Member', 'STF-92250', 'MIS', 'Senior QA Engineer', 'Field travel allowance', '2026-09-22', '2026-10-15', 5000, 0, 'Open', 'Approved', ''),
('ADV-7144-567', 'Audit QA Staff Member', 'STF-261', 'MIS', 'Senior QA Engineer', 'Field travel allowance', '2026-09-22', '2026-10-15', 5000, 0, 'Open', 'Approved', ''),
('ADV-3975-153', 'Md. Ashikur Rahman', 'EMP-001', 'MIS', 'MIS Officer', 'Travel Advance for Bogura Inspection', '2026-09-01', '2026-10-01', 50000, 20000, 'Open', 'Approved', 'Approved by MIS Director');

-- Seed Data: `monthly_mis_submissions` (12 records)
INSERT INTO `monthly_mis_submissions` (`year`, `month_code`, `month_num`, `target`, `submitted`, `pending`) VALUES
(2026, 'Jan', 1, 250, 210, 40),
(2026, 'Feb', 2, 260, 242, 18),
(2026, 'Mar', 3, 260, 228, 32),
(2026, 'Apr', 4, 290, 275, 15),
(2026, 'May', 5, 310, 291, 19),
(2026, 'Jun', 6, 320, 302, 18),
(2026, 'Jul', 7, 330, 318, 12),
(2026, 'Aug', 8, 350, 326, 24),
(2026, 'Sep', 9, 360, 342, 18),
(2026, 'Oct', 10, 370, 355, 15),
(2026, 'Nov', 11, 380, 368, 12),
(2026, 'Dec', 12, 390, 380, 10);

-- Seed Data: `system_settings` (6 records)
INSERT INTO `system_settings` (`key`, `value`) VALUES
('backup_retention', '30 Days'),
('notification_alerts', 'true'),
('require_approval', 'true'),
('last_backup', '2026-09-21T08:39:57.837Z'),
('backup_frequency', 'Daily'),
('retention', '90 Days');

-- Seed Data: `notifications` (20 records)
INSERT INTO `notifications` (`id`, `title`, `message`, `type`, `target_module`, `time_label`, `status`, `action_url`) VALUES
('NOTIF-001', 'Monthly MIS submission deadline', '24 branch reports are still pending submission.', 'warning', 'reports', 'Today', 'Unread', ''),
('NOTIF-002', 'Data quality alert', '82 records require correction.', 'warning', 'staff-position-list', 'Yesterday', 'Unread', ''),
('NOTIF-003', 'Advance adjustment reminder', '12 advance records are overdue.', 'danger', 'advance-management', '2 days ago', 'Unread', ''),
('NOTIF-004', 'Low stock alert', 'Toner Cartridge HP 85A and A4 Paper below minimum stock threshold.', 'warning', 'stock-register', '3 days ago', 'Unread', ''),
('NOTIF-005', 'Staff movement alert', 'Field visits scheduled for audit review in Dhaka and Rajshahi zones.', 'info', 'movement-register', 'This week', 'Unread', ''),
('NOTIF-1789893193678', 'Staff Transfer: Example Staff', 'Example Staff (TMSS-002) transferred from Savar Branch to Ashulia-01. Effective: 2026-09-20', 'info', 'staff-position-list', 'Just now', 'Unread', ''),
('NOTIF-1789893600173', 'New Department: Supply Chain & Logistics', 'Department "Supply Chain & Logistics" (SCL-01) has been created by MIS Super Admin and is now available in Staff, Position, and Movement registers.', 'info', 'department-management', 'Just now', 'Unread', '/department-management'),
('NOTIF-1789979053014', 'New Branch: Automated Test Branch', 'Branch "Automated Test Branch" (TEST-1789979052918) in Savar was created by MIS Super Admin and is now available in all branch dropdowns.', 'info', 'location-branch', 'Just now', 'Unread', '/location-branch'),
('NOTIF-1789979063317', 'New Department: Research & Development 3304', 'Department "Research & Development 3304" (TST-3304) has been created by MIS Super Admin and is now available in Staff, Position, and Movement registers.', 'info', 'department-management', 'Just now', 'Unread', '/department-management'),
('NOTIF-1789979064878', 'Low Stock Alert: Dell Optical Mouse', 'Stock item "Dell Optical Mouse" (IT-TEST-357) is at or below threshold: 8 Piece remaining.', 'warning', 'stock-register', 'Just now', 'Unread', '/stock-register'),
('NOTIF-1789979649324-192', 'Test', 'Test', 'info', '', 'Just now', 'Unread', ''),
('NOTIF-1789979649334-650', 'Security Test Notif', 'Audit complete', 'info', '', 'Just now', 'Unread', ''),
('NOTIF-1789979661977-466', 'Security Test Notif', 'Audit complete', 'info', '', 'Just now', 'Unread', ''),
('NOTIF-1789979828713', 'New Branch: Automated Test Branch', 'Branch "Automated Test Branch" (TEST-1789979828639) in Savar was created by MIS Super Admin and is now available in all branch dropdowns.', 'info', 'location-branch', 'Just now', 'Unread', '/location-branch'),
('NOTIF-1789979846190', 'New Department: Research & Development 6174', 'Department "Research & Development 6174" (TST-6174) has been created by MIS Super Admin and is now available in Staff, Position, and Movement registers.', 'info', 'department-management', 'Just now', 'Unread', '/department-management'),
('NOTIF-1789979863582', 'Low Stock Alert: Dell Optical Mouse', 'Stock item "Dell Optical Mouse" (IT-TEST-535) is at or below threshold: 8 Piece remaining.', 'warning', 'stock-register', 'Just now', 'Unread', '/stock-register'),
('NOTIF-1789980115485', 'New Branch: Automated Test Branch', 'Branch "Automated Test Branch" (TEST-1789980115440) in Savar was created by MIS Super Admin and is now available in all branch dropdowns.', 'info', 'location-branch', 'Just now', 'Unread', '/location-branch'),
('NOTIF-1789980116673', 'New Department: Research & Development 6638', 'Department "Research & Development 6638" (TST-6638) has been created by MIS Super Admin and is now available in Staff, Position, and Movement registers.', 'info', 'department-management', 'Just now', 'Unread', '/department-management'),
('NOTIF-1789980118357', 'Low Stock Alert: Dell Optical Mouse', 'Stock item "Dell Optical Mouse" (IT-TEST-571) is at or below threshold: 8 Piece remaining.', 'warning', 'stock-register', 'Just now', 'Unread', '/stock-register'),
('NOTIF-1789980356782', 'New Branch: Automated Test Branch', 'Branch "Automated Test Branch" (TEST-1789980356730) in Savar was created by MIS Super Admin and is now available in all branch dropdowns.', 'info', 'location-branch', 'Just now', 'Unread', '/location-branch');

-- Seed Data: `branches` (100 records)
INSERT INTO `branches` (`id`, `division`, `district`, `thana`, `upazila`, `union_name`, `ward`, `branch`, `code`, `manager`, `mobile`, `personal_mobile`, `email`, `status`, `address`) VALUES
('LOC-001', 'Dhaka', 'Dhaka', 'Savar', 'Savar', 'Ashulia', '', 'Ashulia-01', 'DHK-001', 'Kamrul Hasan', '01700-000001', '01800-000001', 'ashulia01@mis.gov.bd', 'Active', 'Ashulia Bazar, Savar, Dhaka'),
('LOC-002', 'Dhaka', 'Dhaka', 'Savar', 'Savar', 'Savar Municipality', '01', 'Savar-01', 'DHK-002', 'Md. Rafiqul Islam', '01700-000002', '01800-000002', 'savar01@mis.gov.bd', 'Active', 'Savar Bus Stand, Dhaka'),
('LOC-003', 'Dhaka', 'Dhaka', 'Keraniganj', 'Keraniganj', 'Kalatiya', '', 'Keraniganj-01', 'DHK-003', 'Shahidul Alam', '01700-000003', '01800-000003', 'keraniganj01@mis.gov.bd', 'Review', 'Kalatiya Main Road, Keraniganj'),
('BR-0004', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 1', 'DHA-004', 'Manager 4', '01700-000004', '01800-000004', 'branch4@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0005', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 2', 'DHA-005', 'Manager 5', '01700-000005', '01800-000005', 'branch5@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0006', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 3', 'DHA-006', 'Manager 6', '01700-000006', '01800-000006', 'branch6@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0007', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 4', 'DHA-007', 'Manager 7', '01700-000007', '01800-000007', 'branch7@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0008', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 5', 'DHA-008', 'Manager 8', '01700-000008', '01800-000008', 'branch8@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0009', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 6', 'DHA-009', 'Manager 9', '01700-000009', '01800-000009', 'branch9@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0010', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 7', 'DHA-010', 'Manager 10', '01700-000010', '01800-000010', 'branch10@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0011', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 8', 'DHA-011', 'Manager 11', '01700-000011', '01800-000011', 'branch11@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0012', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 9', 'DHA-012', 'Manager 12', '01700-000012', '01800-000012', 'branch12@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0013', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 10', 'DHA-013', 'Manager 13', '01700-000013', '01800-000013', 'branch13@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0014', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 11', 'DHA-014', 'Manager 14', '01700-000014', '01800-000014', 'branch14@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0015', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 12', 'DHA-015', 'Manager 15', '01700-000015', '01800-000015', 'branch15@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0016', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 13', 'DHA-016', 'Manager 16', '01700-000016', '01800-000016', 'branch16@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0017', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 14', 'DHA-017', 'Manager 17', '01700-000017', '01800-000017', 'branch17@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0018', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 15', 'DHA-018', 'Manager 18', '01700-000018', '01800-000018', 'branch18@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0019', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 16', 'DHA-019', 'Manager 19', '01700-000019', '01800-000019', 'branch19@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0020', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 17', 'DHA-020', 'Manager 20', '01700-000020', '01800-000020', 'branch20@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0021', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 18', 'DHA-021', 'Manager 21', '01700-000021', '01800-000021', 'branch21@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0022', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 19', 'DHA-022', 'Manager 22', '01700-000022', '01800-000022', 'branch22@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0023', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 20', 'DHA-023', 'Manager 23', '01700-000023', '01800-000023', 'branch23@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0024', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 21', 'DHA-024', 'Manager 24', '01700-000024', '01800-000024', 'branch24@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0025', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 22', 'DHA-025', 'Manager 25', '01700-000025', '01800-000025', 'branch25@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0026', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 23', 'DHA-026', 'Manager 26', '01700-000026', '01800-000026', 'branch26@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0027', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 24', 'DHA-027', 'Manager 27', '01700-000027', '01800-000027', 'branch27@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0028', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 25', 'DHA-028', 'Manager 28', '01700-000028', '01800-000028', 'branch28@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0029', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 26', 'DHA-029', 'Manager 29', '01700-000029', '01800-000029', 'branch29@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0030', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 27', 'DHA-030', 'Manager 30', '01700-000030', '01800-000030', 'branch30@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0031', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 28', 'DHA-031', 'Manager 31', '01700-000031', '01800-000031', 'branch31@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0032', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 29', 'DHA-032', 'Manager 32', '01700-000032', '01800-000032', 'branch32@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0033', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 30', 'DHA-033', 'Manager 33', '01700-000033', '01800-000033', 'branch33@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0034', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 31', 'DHA-034', 'Manager 34', '01700-000034', '01800-000034', 'branch34@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0035', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 32', 'DHA-035', 'Manager 35', '01700-000035', '01800-000035', 'branch35@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0036', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 33', 'DHA-036', 'Manager 36', '01700-000036', '01800-000036', 'branch36@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0037', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 34', 'DHA-037', 'Manager 37', '01700-000037', '01800-000037', 'branch37@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0038', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 35', 'DHA-038', 'Manager 38', '01700-000038', '01800-000038', 'branch38@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0039', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 36', 'DHA-039', 'Manager 39', '01700-000039', '01800-000039', 'branch39@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0040', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 37', 'DHA-040', 'Manager 40', '01700-000040', '01800-000040', 'branch40@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0041', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 38', 'DHA-041', 'Manager 41', '01700-000041', '01800-000041', 'branch41@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0042', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 39', 'DHA-042', 'Manager 42', '01700-000042', '01800-000042', 'branch42@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0043', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 40', 'DHA-043', 'Manager 43', '01700-000043', '01800-000043', 'branch43@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0044', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 41', 'DHA-044', 'Manager 44', '01700-000044', '01800-000044', 'branch44@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0045', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 42', 'DHA-045', 'Manager 45', '01700-000045', '01800-000045', 'branch45@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0046', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 43', 'DHA-046', 'Manager 46', '01700-000046', '01800-000046', 'branch46@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0047', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 44', 'DHA-047', 'Manager 47', '01700-000047', '01800-000047', 'branch47@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0048', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 45', 'DHA-048', 'Manager 48', '01700-000048', '01800-000048', 'branch48@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0049', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 46', 'DHA-049', 'Manager 49', '01700-000049', '01800-000049', 'branch49@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0050', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 47', 'DHA-050', 'Manager 50', '01700-000050', '01800-000050', 'branch50@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0051', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 48', 'DHA-051', 'Manager 51', '01700-000051', '01800-000051', 'branch51@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0052', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 49', 'DHA-052', 'Manager 52', '01700-000052', '01800-000052', 'branch52@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0053', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 50', 'DHA-053', 'Manager 53', '01700-000053', '01800-000053', 'branch53@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0054', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 51', 'DHA-054', 'Manager 54', '01700-000054', '01800-000054', 'branch54@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0055', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 52', 'DHA-055', 'Manager 55', '01700-000055', '01800-000055', 'branch55@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0056', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 53', 'DHA-056', 'Manager 56', '01700-000056', '01800-000056', 'branch56@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0057', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 54', 'DHA-057', 'Manager 57', '01700-000057', '01800-000057', 'branch57@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0058', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 55', 'DHA-058', 'Manager 58', '01700-000058', '01800-000058', 'branch58@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0059', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 56', 'DHA-059', 'Manager 59', '01700-000059', '01800-000059', 'branch59@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0060', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 57', 'DHA-060', 'Manager 60', '01700-000060', '01800-000060', 'branch60@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0061', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 58', 'DHA-061', 'Manager 61', '01700-000061', '01800-000061', 'branch61@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0062', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 59', 'DHA-062', 'Manager 62', '01700-000062', '01800-000062', 'branch62@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0063', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 60', 'DHA-063', 'Manager 63', '01700-000063', '01800-000063', 'branch63@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0064', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 61', 'DHA-064', 'Manager 64', '01700-000064', '01800-000064', 'branch64@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0065', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 62', 'DHA-065', 'Manager 65', '01700-000065', '01800-000065', 'branch65@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0066', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 63', 'DHA-066', 'Manager 66', '01700-000066', '01800-000066', 'branch66@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0067', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 64', 'DHA-067', 'Manager 67', '01700-000067', '01800-000067', 'branch67@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0068', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 65', 'DHA-068', 'Manager 68', '01700-000068', '01800-000068', 'branch68@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0069', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 66', 'DHA-069', 'Manager 69', '01700-000069', '01800-000069', 'branch69@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0070', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 67', 'DHA-070', 'Manager 70', '01700-000070', '01800-000070', 'branch70@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0071', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 68', 'DHA-071', 'Manager 71', '01700-000071', '01800-000071', 'branch71@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0072', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 69', 'DHA-072', 'Manager 72', '01700-000072', '01800-000072', 'branch72@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0073', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 70', 'DHA-073', 'Manager 73', '01700-000073', '01800-000073', 'branch73@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0074', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 71', 'DHA-074', 'Manager 74', '01700-000074', '01800-000074', 'branch74@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0075', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 72', 'DHA-075', 'Manager 75', '01700-000075', '01800-000075', 'branch75@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0076', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 73', 'DHA-076', 'Manager 76', '01700-000076', '01800-000076', 'branch76@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0077', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 74', 'DHA-077', 'Manager 77', '01700-000077', '01800-000077', 'branch77@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0078', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 75', 'DHA-078', 'Manager 78', '01700-000078', '01800-000078', 'branch78@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0079', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 76', 'DHA-079', 'Manager 79', '01700-000079', '01800-000079', 'branch79@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0080', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 77', 'DHA-080', 'Manager 80', '01700-000080', '01800-000080', 'branch80@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0081', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 78', 'DHA-081', 'Manager 81', '01700-000081', '01800-000081', 'branch81@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0082', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 79', 'DHA-082', 'Manager 82', '01700-000082', '01800-000082', 'branch82@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0083', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 80', 'DHA-083', 'Manager 83', '01700-000083', '01800-000083', 'branch83@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0084', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 81', 'DHA-084', 'Manager 84', '01700-000084', '01800-000084', 'branch84@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0085', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 82', 'DHA-085', 'Manager 85', '01700-000085', '01800-000085', 'branch85@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0086', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 83', 'DHA-086', 'Manager 86', '01700-000086', '01800-000086', 'branch86@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0087', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 84', 'DHA-087', 'Manager 87', '01700-000087', '01800-000087', 'branch87@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0088', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 85', 'DHA-088', 'Manager 88', '01700-000088', '01800-000088', 'branch88@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0089', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 86', 'DHA-089', 'Manager 89', '01700-000089', '01800-000089', 'branch89@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0090', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 87', 'DHA-090', 'Manager 90', '01700-000090', '01800-000090', 'branch90@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0091', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 88', 'DHA-091', 'Manager 91', '01700-000091', '01800-000091', 'branch91@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0092', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-08', '08', 'Dhaka Branch 89', 'DHA-092', 'Manager 92', '01700-000092', '01800-000092', 'branch92@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0093', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-09', '09', 'Dhaka Branch 90', 'DHA-093', 'Manager 93', '01700-000093', '01800-000093', 'branch93@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0094', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-01', '01', 'Dhaka Branch 91', 'DHA-094', 'Manager 94', '01700-000094', '01800-000094', 'branch94@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0095', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-02', '02', 'Dhaka Branch 92', 'DHA-095', 'Manager 95', '01700-000095', '01800-000095', 'branch95@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0096', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-03', '03', 'Dhaka Branch 93', 'DHA-096', 'Manager 96', '01700-000096', '01800-000096', 'branch96@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0097', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-04', '04', 'Dhaka Branch 94', 'DHA-097', 'Manager 97', '01700-000097', '01800-000097', 'branch97@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0098', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-05', '05', 'Dhaka Branch 95', 'DHA-098', 'Manager 98', '01700-000098', '01800-000098', 'branch98@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0099', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-06', '06', 'Dhaka Branch 96', 'DHA-099', 'Manager 99', '01700-000099', '01800-000099', 'branch99@tmss-mis.org', 'Active', 'Dhaka, Dhaka'),
('BR-0100', 'Dhaka', 'Dhaka', 'Dhanmondi', 'Dhanmondi', 'Ward-07', '07', 'Dhaka Branch 97', 'DHA-100', 'Manager 100', '01700-000100', '01800-000100', 'branch100@tmss-mis.org', 'Active', 'Dhaka, Dhaka');

-- Seed Data: `staff_positions` (100 records)
INSERT INTO `staff_positions` (`id`, `serial`, `name`, `gender`, `dob`, `father`, `mother`, `staff_id`, `designation`, `join_date`, `posting_date`, `promotion_date`, `education`, `home_district`, `previous_posting`, `current_posting`, `department`, `status`) VALUES
('ST-001', '01', 'Md. Example', 'Male', '1995-05-15', 'Md. Father', 'Mrs. Mother', 'TMSS-001', 'Officer', '2020-01-01', '2025-02-10', '2025-01-01', 'MBA', 'Bogura', 'Head Office', 'Dhaka Branch', 'MIS', 'Active'),
('ST-002', '02', 'Example Staff', 'Female', '1993-08-22', 'Md. Parent', 'Mrs. Parent', 'TMSS-002', 'Senior Officer', '2019-03-15', '2026-09-20', '2024-03-15', 'BSc in CSE', 'Rajshahi', 'Savar Branch', 'Ashulia-01', 'IT', 'Active'),
('ST-003', '03', 'Md. Tariqul Islam', 'Male', '1990-11-12', 'Md. Abdul Haque', 'Amena Begum', 'TMSS-003', 'Assistant Manager', '2018-07-01', '2023-01-15', '2024-01-01', 'M.Com in Accounting', 'Dhaka', 'Dhaka South Zone', 'Mirpur Branch', 'Accounts', 'Active'),
('ST-004', '04', 'Nusrat Jahan', 'Female', '1996-03-18', 'Kazi Anwar Hossain', 'Salma Khatun', 'TMSS-004', 'Program Officer', '2021-04-10', '2024-06-01', '2024-04-10', 'MSS in Sociology', 'Chattogram', 'Agrabad Branch', 'Feni Zone', 'Operations', 'Active'),
('ST-005', '05', 'Md. Shahadat Hossain', 'Male', '1992-09-05', 'Md. Abul Kalam', 'Fatema Begum', 'TMSS-005', 'Audit Officer', '2020-09-15', '2023-11-20', '2023-09-15', 'BBA in Finance', 'Khulna', 'Jashore Zone', 'Khulna Regional Office', 'Audit', 'Active'),
('ST-006', '06', 'Rashedul Hasan', 'Male', '1988-12-30', 'Nurul Islam', 'Rashida Begum', 'TMSS-006', 'HR Executive', '2017-02-01', '2022-05-10', '2023-02-01', 'MBA in HRM', 'Rangpur', 'Rangpur Zone', 'Head Office', 'HR & Admin', 'Active'),
('STF-00007', '7', 'Staff Member 7', 'Female', '1992-05-12', 'Father 7', 'Mother 7', 'EMP-0007', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00008', '8', 'Staff Member 8', 'Male', '1992-05-12', 'Father 8', 'Mother 8', 'EMP-0008', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00009', '9', 'Staff Member 9', 'Female', '1992-05-12', 'Father 9', 'Mother 9', 'EMP-0009', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00010', '10', 'Staff Member 10', 'Male', '1992-05-12', 'Father 10', 'Mother 10', 'EMP-0010', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00011', '11', 'Staff Member 11', 'Female', '1992-05-12', 'Father 11', 'Mother 11', 'EMP-0011', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00012', '12', 'Staff Member 12', 'Male', '1992-05-12', 'Father 12', 'Mother 12', 'EMP-0012', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00013', '13', 'Staff Member 13', 'Female', '1992-05-12', 'Father 13', 'Mother 13', 'EMP-0013', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00014', '14', 'Staff Member 14', 'Male', '1992-05-12', 'Father 14', 'Mother 14', 'EMP-0014', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00015', '15', 'Staff Member 15', 'Female', '1992-05-12', 'Father 15', 'Mother 15', 'EMP-0015', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00016', '16', 'Staff Member 16', 'Male', '1992-05-12', 'Father 16', 'Mother 16', 'EMP-0016', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00017', '17', 'Staff Member 17', 'Female', '1992-05-12', 'Father 17', 'Mother 17', 'EMP-0017', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00018', '18', 'Staff Member 18', 'Male', '1992-05-12', 'Father 18', 'Mother 18', 'EMP-0018', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00019', '19', 'Staff Member 19', 'Female', '1992-05-12', 'Father 19', 'Mother 19', 'EMP-0019', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00020', '20', 'Staff Member 20', 'Male', '1992-05-12', 'Father 20', 'Mother 20', 'EMP-0020', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00021', '21', 'Staff Member 21', 'Female', '1992-05-12', 'Father 21', 'Mother 21', 'EMP-0021', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00022', '22', 'Staff Member 22', 'Male', '1992-05-12', 'Father 22', 'Mother 22', 'EMP-0022', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00023', '23', 'Staff Member 23', 'Female', '1992-05-12', 'Father 23', 'Mother 23', 'EMP-0023', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00024', '24', 'Staff Member 24', 'Male', '1992-05-12', 'Father 24', 'Mother 24', 'EMP-0024', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00025', '25', 'Staff Member 25', 'Female', '1992-05-12', 'Father 25', 'Mother 25', 'EMP-0025', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00026', '26', 'Staff Member 26', 'Male', '1992-05-12', 'Father 26', 'Mother 26', 'EMP-0026', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00027', '27', 'Staff Member 27', 'Female', '1992-05-12', 'Father 27', 'Mother 27', 'EMP-0027', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00028', '28', 'Staff Member 28', 'Male', '1992-05-12', 'Father 28', 'Mother 28', 'EMP-0028', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00029', '29', 'Staff Member 29', 'Female', '1992-05-12', 'Father 29', 'Mother 29', 'EMP-0029', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00030', '30', 'Staff Member 30', 'Male', '1992-05-12', 'Father 30', 'Mother 30', 'EMP-0030', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00031', '31', 'Staff Member 31', 'Female', '1992-05-12', 'Father 31', 'Mother 31', 'EMP-0031', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00032', '32', 'Staff Member 32', 'Male', '1992-05-12', 'Father 32', 'Mother 32', 'EMP-0032', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00033', '33', 'Staff Member 33', 'Female', '1992-05-12', 'Father 33', 'Mother 33', 'EMP-0033', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00034', '34', 'Staff Member 34', 'Male', '1992-05-12', 'Father 34', 'Mother 34', 'EMP-0034', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00035', '35', 'Staff Member 35', 'Female', '1992-05-12', 'Father 35', 'Mother 35', 'EMP-0035', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00036', '36', 'Staff Member 36', 'Male', '1992-05-12', 'Father 36', 'Mother 36', 'EMP-0036', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00037', '37', 'Staff Member 37', 'Female', '1992-05-12', 'Father 37', 'Mother 37', 'EMP-0037', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00038', '38', 'Staff Member 38', 'Male', '1992-05-12', 'Father 38', 'Mother 38', 'EMP-0038', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00039', '39', 'Staff Member 39', 'Female', '1992-05-12', 'Father 39', 'Mother 39', 'EMP-0039', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00040', '40', 'Staff Member 40', 'Male', '1992-05-12', 'Father 40', 'Mother 40', 'EMP-0040', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00041', '41', 'Staff Member 41', 'Female', '1992-05-12', 'Father 41', 'Mother 41', 'EMP-0041', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00042', '42', 'Staff Member 42', 'Male', '1992-05-12', 'Father 42', 'Mother 42', 'EMP-0042', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00043', '43', 'Staff Member 43', 'Female', '1992-05-12', 'Father 43', 'Mother 43', 'EMP-0043', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00044', '44', 'Staff Member 44', 'Male', '1992-05-12', 'Father 44', 'Mother 44', 'EMP-0044', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00045', '45', 'Staff Member 45', 'Female', '1992-05-12', 'Father 45', 'Mother 45', 'EMP-0045', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00046', '46', 'Staff Member 46', 'Male', '1992-05-12', 'Father 46', 'Mother 46', 'EMP-0046', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00047', '47', 'Staff Member 47', 'Female', '1992-05-12', 'Father 47', 'Mother 47', 'EMP-0047', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00048', '48', 'Staff Member 48', 'Male', '1992-05-12', 'Father 48', 'Mother 48', 'EMP-0048', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00049', '49', 'Staff Member 49', 'Female', '1992-05-12', 'Father 49', 'Mother 49', 'EMP-0049', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00050', '50', 'Staff Member 50', 'Male', '1992-05-12', 'Father 50', 'Mother 50', 'EMP-0050', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00051', '51', 'Staff Member 51', 'Female', '1992-05-12', 'Father 51', 'Mother 51', 'EMP-0051', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00052', '52', 'Staff Member 52', 'Male', '1992-05-12', 'Father 52', 'Mother 52', 'EMP-0052', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00053', '53', 'Staff Member 53', 'Female', '1992-05-12', 'Father 53', 'Mother 53', 'EMP-0053', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00054', '54', 'Staff Member 54', 'Male', '1992-05-12', 'Father 54', 'Mother 54', 'EMP-0054', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00055', '55', 'Staff Member 55', 'Female', '1992-05-12', 'Father 55', 'Mother 55', 'EMP-0055', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00056', '56', 'Staff Member 56', 'Male', '1992-05-12', 'Father 56', 'Mother 56', 'EMP-0056', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00057', '57', 'Staff Member 57', 'Female', '1992-05-12', 'Father 57', 'Mother 57', 'EMP-0057', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00058', '58', 'Staff Member 58', 'Male', '1992-05-12', 'Father 58', 'Mother 58', 'EMP-0058', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00059', '59', 'Staff Member 59', 'Female', '1992-05-12', 'Father 59', 'Mother 59', 'EMP-0059', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00060', '60', 'Staff Member 60', 'Male', '1992-05-12', 'Father 60', 'Mother 60', 'EMP-0060', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00061', '61', 'Staff Member 61', 'Female', '1992-05-12', 'Father 61', 'Mother 61', 'EMP-0061', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00062', '62', 'Staff Member 62', 'Male', '', '', '', 'EMP-0062', 'Manager', '2021-03-01', '2024-01-01', '', '', '', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00063', '63', 'Staff Member 63', 'Female', '1992-05-12', 'Father 63', 'Mother 63', 'EMP-0063', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00064', '64', 'Staff Member 64', 'Male', '1992-05-12', 'Father 64', 'Mother 64', 'EMP-0064', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00065', '65', 'Staff Member 65', 'Female', '1992-05-12', 'Father 65', 'Mother 65', 'EMP-0065', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00066', '66', 'Staff Member 66', 'Male', '1992-05-12', 'Father 66', 'Mother 66', 'EMP-0066', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00067', '67', 'Staff Member 67', 'Female', '1992-05-12', 'Father 67', 'Mother 67', 'EMP-0067', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00068', '68', 'Staff Member 68', 'Male', '1992-05-12', 'Father 68', 'Mother 68', 'EMP-0068', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00069', '69', 'Staff Member 69', 'Female', '1992-05-12', 'Father 69', 'Mother 69', 'EMP-0069', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00070', '70', 'Staff Member 70', 'Male', '1992-05-12', 'Father 70', 'Mother 70', 'EMP-0070', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00071', '71', 'Staff Member 71', 'Female', '1992-05-12', 'Father 71', 'Mother 71', 'EMP-0071', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00072', '72', 'Staff Member 72', 'Male', '1992-05-12', 'Father 72', 'Mother 72', 'EMP-0072', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00073', '73', 'Staff Member 73', 'Female', '1992-05-12', 'Father 73', 'Mother 73', 'EMP-0073', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00074', '74', 'Staff Member 74', 'Male', '1992-05-12', 'Father 74', 'Mother 74', 'EMP-0074', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00075', '75', 'Staff Member 75', 'Female', '1992-05-12', 'Father 75', 'Mother 75', 'EMP-0075', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00076', '76', 'Staff Member 76', 'Male', '1992-05-12', 'Father 76', 'Mother 76', 'EMP-0076', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00077', '77', 'Staff Member 77', 'Female', '1992-05-12', 'Father 77', 'Mother 77', 'EMP-0077', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00078', '78', 'Staff Member 78', 'Male', '1992-05-12', 'Father 78', 'Mother 78', 'EMP-0078', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00079', '79', 'Staff Member 79', 'Female', '1992-05-12', 'Father 79', 'Mother 79', 'EMP-0079', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00080', '80', 'Staff Member 80', 'Male', '1992-05-12', 'Father 80', 'Mother 80', 'EMP-0080', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00081', '81', 'Staff Member 81', 'Female', '1992-05-12', 'Father 81', 'Mother 81', 'EMP-0081', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00082', '82', 'Staff Member 82', 'Male', '1992-05-12', 'Father 82', 'Mother 82', 'EMP-0082', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00083', '83', 'Staff Member 83', 'Female', '1992-05-12', 'Father 83', 'Mother 83', 'EMP-0083', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00084', '84', 'Staff Member 84', 'Male', '1992-05-12', 'Father 84', 'Mother 84', 'EMP-0084', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00085', '85', 'Staff Member 85', 'Female', '1992-05-12', 'Father 85', 'Mother 85', 'EMP-0085', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00086', '86', 'Staff Member 86', 'Male', '1992-05-12', 'Father 86', 'Mother 86', 'EMP-0086', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00087', '87', 'Staff Member 87', 'Female', '1992-05-12', 'Father 87', 'Mother 87', 'EMP-0087', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00088', '88', 'Staff Member 88', 'Male', '1992-05-12', 'Father 88', 'Mother 88', 'EMP-0088', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00089', '89', 'Staff Member 89', 'Female', '1992-05-12', 'Father 89', 'Mother 89', 'EMP-0089', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00090', '90', 'Staff Member 90', 'Male', '1992-05-12', 'Father 90', 'Mother 90', 'EMP-0090', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00091', '91', 'Staff Member 91', 'Female', '1992-05-12', 'Father 91', 'Mother 91', 'EMP-0091', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00092', '92', 'Staff Member 92', 'Male', '1992-05-12', 'Father 92', 'Mother 92', 'EMP-0092', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00093', '93', 'Staff Member 93', 'Female', '1992-05-12', 'Father 93', 'Mother 93', 'EMP-0093', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00094', '94', 'Staff Member 94', 'Male', '1992-05-12', 'Father 94', 'Mother 94', 'EMP-0094', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active'),
('STF-00095', '95', 'Staff Member 95', 'Female', '1992-05-12', 'Father 95', 'Mother 95', 'EMP-0095', 'Data Specialist', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'HR', 'Active'),
('STF-00096', '96', 'Staff Member 96', 'Male', '1992-05-12', 'Father 96', 'Mother 96', 'EMP-0096', 'Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'MIS', 'Active'),
('STF-00097', '97', 'Staff Member 97', 'Female', '1992-05-12', 'Father 97', 'Mother 97', 'EMP-0097', 'Senior Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Operations', 'Active'),
('STF-00098', '98', 'Staff Member 98', 'Male', '1992-05-12', 'Father 98', 'Mother 98', 'EMP-0098', 'Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Accounts', 'Active'),
('STF-00099', '99', 'Staff Member 99', 'Female', '1992-05-12', 'Father 99', 'Mother 99', 'EMP-0099', 'Assistant Manager', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'IT', 'Active'),
('STF-00100', '100', 'Staff Member 100', 'Male', '1992-05-12', 'Father 100', 'Mother 100', 'EMP-0100', 'Field Officer', '2021-03-01', '2024-01-01', '', 'Masters', 'Dhaka', 'Field Office', 'Head Office', 'Audit', 'Active');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;

-- =====================================================================
-- সফলভাবে ডাটাবেজ তৈরি এবং ডাটা ইনসার্ট সম্পন্ন হয়েছে!
-- =====================================================================
