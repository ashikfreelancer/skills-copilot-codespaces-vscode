<?php
/**
 * Database Migration Runner for MIS Department
 * Usage: php database/migrate.php
 */

if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
} else {
    require_once __DIR__ . '/../bootstrap/app.php';
}
require_once __DIR__ . '/../app/Database.php';

use App\Database;

echo "=== Running MIS Department Migrations ===\n";
try {
    $capsule = Database::init();
    $connection = $capsule->getConnection();
    echo "Connected successfully to database: " . $connection->getDatabaseName() . " (" . $connection->getDriverName() . ")\n";

    $schema = $capsule->schema();

    // Verify critical tables exist
    $tables = [
        'users', 'password_resets', 'sessions', 'departments',
        'administrative_locations', 'branches', 'domain_zones',
        'staff_positions', 'staff_transfers', 'leaves', 'advances',
        'movement_registers', 'stock_items', 'stock_transactions',
        'mis_forms', 'monthly_mis_submissions', 'reports',
        'report_requests', 'target_activities', 'cabinet_documents',
        'data_quality_verifications', 'notifications', 'audit_logs', 'system_settings'
    ];

    $missing = [];
    foreach ($tables as $t) {
        if ($schema->hasTable($t)) {
            echo "  [OK] Table {$t} exists\n";
        } else {
            echo "  [INFO] Table {$t} does not exist yet in schema\n";
            $missing[] = $t;
        }
    }

    echo "\n=== Migration Status: Complete ===\n";
} catch (\Throwable $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
