<!doctype html>
<html lang="en">
<head>
<script>
try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}
</script>
<meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ $branding['app_name'] ?? 'Management Information System' }} | Sign In</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<style>
  * { box-sizing: border-box; }
  body, html {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    background: #ffffff;
    color: #1e293b;
    overflow-x: hidden;
  }
  .login-container {
    display: flex;
    min-height: 100vh;
    width: 100vw;
  }
  /* Left Hero Illustration Section */
  .hero-panel {
    flex: 1.45;
    position: relative;
    background-color: #3b5062;
    background-image: url('/assets/images/login-hero.jpg');
    background-size: cover;
    background-position: left center;
    background-repeat: no-repeat;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 40px;
    text-align: center;
  }
  .hero-overlay {
    position: absolute;
    inset: 0;
    background: rgba(15, 23, 42, 0.38);
    pointer-events: none;
  }
  .hero-content {
    position: relative;
    z-index: 10;
    max-width: 650px;
    color: #ffffff;
    padding: 24px;
    margin: auto;
  }
  .hero-title {
    font-size: 2.25rem;
    font-weight: 800;
    line-height: 1.25;
    letter-spacing: -0.02em;
    margin-bottom: 14px;
    text-shadow: 0 3px 12px rgba(0, 0, 0, 0.65);
  }
  .hero-subtitle {
    font-size: 1.15rem;
    font-weight: 400;
    line-height: 1.5;
    opacity: 0.95;
    text-shadow: 0 2px 8px rgba(0, 0, 0, 0.6);
  }

  /* Right Form Panel */
  .form-panel {
    flex: 1;
    min-width: 380px;
    max-width: 540px;
    background: #ffffff;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 48px 56px;
    box-shadow: -10px 0 30px rgba(0,0,0,0.03);
  }
  .form-box {
    width: 100%;
    max-width: 380px;
  }
  .brand-logo-img {
    height: 110px;
    width: auto;
    object-fit: contain;
    margin: 0 auto 36px auto;
    display: block;
    transition: transform 0.2s ease;
  }
  .brand-logo-img:hover {
    transform: scale(1.02);
  }
  .field-label {
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: #64748b;
    margin-bottom: 8px;
  }
  .custom-input {
    width: 100%;
    height: 48px;
    padding: 10px 16px;
    font-size: 0.95rem;
    color: #1e293b;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    outline: none;
    transition: all 0.15s ease-in-out;
  }
  .custom-input:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
  }
  .custom-input.input-error {
    border-color: #ef4444;
  }
  .error-feedback {
    color: #ef4444;
    font-size: 0.8rem;
    margin-top: 5px;
  }
  .password-wrapper {
    position: relative;
    width: 100%;
  }
  .password-toggle-btn {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    background: transparent;
    border: none;
    color: #64748b;
    cursor: pointer;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .password-toggle-btn:hover {
    color: #1e293b;
  }
  .checkbox-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.875rem;
    color: #475569;
    font-weight: 500;
    cursor: pointer;
    user-select: none;
  }
  .checkbox-label input[type="checkbox"] {
    width: 17px;
    height: 17px;
    border-radius: 4px;
    border: 1.5px solid #94a3b8;
    accent-color: #2563eb;
    cursor: pointer;
  }
  .btn-signin {
    width: 100%;
    height: 48px;
    background-color: {{ $branding['brand_color'] ?? '#2ecc71' }};
    background: linear-gradient(180deg, #32d677 0%, #27ae60 100%);
    color: #ffffff;
    font-size: 1rem;
    font-weight: 600;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(46, 204, 113, 0.25);
  }
  .btn-signin:hover {
    background: linear-gradient(180deg, #27ae60 0%, #219653 100%);
    box-shadow: 0 6px 16px rgba(46, 204, 113, 0.35);
    transform: translateY(-1px);
  }
  .btn-signin:active {
    transform: translateY(0);
  }
  .admin-quick-badge {
    position: absolute;
    bottom: 16px;
    right: 16px;
    font-size: 11px;
    color: #94a3b8;
  }
  @media (max-width: 900px) {
    .login-container {
      flex-direction: column;
    }
    .hero-panel {
      flex: none;
      min-height: 280px;
      padding: 30px 20px;
    }
    .hero-title {
      font-size: 1.7rem;
    }
    .hero-subtitle {
      font-size: 0.95rem;
    }
    .form-panel {
      max-width: 100%;
      flex: 1;
      padding: 36px 24px;
    }
  }
</style>
</head>
<body>

<div class="login-container">
  <!-- Left Side: Custom Hero Illustration + Centered Welcome text -->
  <div class="hero-panel" id="heroPanel">
    <div class="hero-overlay"></div>
    <div class="hero-content">
      <h1 class="hero-title" id="displayHeroTitle">
        {{ $branding['login_title'] ?? 'Welcome to Management Information System' }}
      </h1>
      <p class="hero-subtitle" id="displayHeroSubtitle">
        {{ $branding['login_subtitle'] ?? 'Manage your management information system efficiently and effectively.' }}
      </p>
    </div>
  </div>

  <!-- Right Side: White Login Form -->
  <div class="form-panel">
    <div class="form-box">
      <!-- TMSS Logo -->
      <div class="text-center">
        <img 
          src="{{ $branding['login_logo'] ?? '/assets/images/tmss-logo.png' }}" 
          alt="TMSS Logo" 
          class="brand-logo-img"
          id="displayLogo"
          onerror="this.onerror=null; this.src='/assets/images/tmss-logo.png';"
        />
      </div>

      <?php if (!empty($error)): ?>
      <div id="loginAlertBox" class="alert alert-danger py-2 px-3 small rounded mb-3">
        <?php echo htmlspecialchars($error); ?>
      </div>
      <?php endif; ?>

      <?php if (!empty($status)): ?>
      <div id="loginSuccessBox" class="alert alert-success py-2 px-3 small rounded mb-3">
        <?php echo htmlspecialchars($status); ?>
      </div>
      <?php endif; ?>

      <form id="loginForm" method="POST" action="/login" onsubmit="return handleFormSubmit(event)">
        @csrf
        <input type="hidden" name="_token" id="csrf_token" value="{{ csrf_token() }}">

        <!-- USERNAME -->
        <div class="mb-4">
          <label class="field-label" for="username">USERNAME</label>
          <input 
            type="text" 
            id="username" 
            name="username" 
            class="custom-input" 
            placeholder="Enter your username" 
            autocomplete="username"
            required
          />
          <div id="usernameError" class="error-feedback d-none">Please enter username</div>
        </div>

        <!-- PASSWORD -->
        <div class="mb-4">
          <label class="field-label" for="password">PASSWORD</label>
          <div class="password-wrapper">
            <input 
              type="password" 
              id="password" 
              name="password" 
              class="custom-input" 
              placeholder="••••••••••••" 
              autocomplete="current-password"
              style="padding-right: 42px;"
              required
            />
            <button type="button" class="password-toggle-btn" id="togglePasswordBtn" aria-label="Toggle password visibility">
              <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
            </button>
          </div>
          <div id="passwordError" class="error-feedback d-none">Please enter password</div>
        </div>

        <!-- REMEMBER ME & FORGOT -->
        <div class="d-flex justify-content-between align-items-center mb-4">
          <label class="checkbox-label">
            <input type="checkbox" id="remember" name="remember" checked>
            <span>Remember Me</span>
          </label>
          <a href="#" class="text-sm text-slate-500 hover:text-slate-800 text-decoration-none" onclick="event.preventDefault();openForgotPasswordModal()">
            Forgot?
          </a>
        </div>

        <!-- SIGN IN BUTTON -->
        <button type="submit" class="btn-signin" id="btnSignIn">
          <span>Sign in</span>
        </button>
      </form>
    </div>
  </div>
</div>

<!-- Password Recovery Modal -->
<div class="modal fade" id="forgotModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg rounded-xl">
      <div class="modal-header bg-slate-900 text-white rounded-t-xl">
        <h5 class="modal-title text-sm font-semibold flex items-center gap-2">
          <i data-lucide="key" style="width: 16px; height: 16px;"></i> Password Recovery
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4">
        <div id="resetModalMsg" class="alert alert-info py-2 text-xs mb-3">
          Enter your registered username or email address.
        </div>
        <div class="mb-3">
          <label class="field-label">Username / Email</label>
          <input type="text" id="resetInput" class="custom-input text-sm" placeholder="e.g. admin@mis.org">
        </div>
        <button type="button" class="btn-signin text-sm py-2" onclick="sendResetRequest()">
          Generate Reset Link
        </button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
lucide.createIcons();

// Password Toggle
const toggleBtn = document.getElementById('togglePasswordBtn');
const passInput = document.getElementById('password');
if (toggleBtn && passInput) {
  toggleBtn.addEventListener('click', () => {
    const isPass = passInput.type === 'password';
    passInput.type = isPass ? 'text' : 'password';
    toggleBtn.innerHTML = isPass 
      ? '<i data-lucide="eye-off" style="width:18px;height:18px"></i>' 
      : '<i data-lucide="eye" style="width:18px;height:18px"></i>';
    lucide.createIcons();
  });
}

// Remembered Username
const savedUser = localStorage.getItem('mis_remember_user');
if (savedUser) {
  document.getElementById('username').value = savedUser;
}

function fillDemo(u, p) {
  document.getElementById('username').value = u;
  document.getElementById('password').value = p;
  document.getElementById('usernameError').classList.add('d-none');
  document.getElementById('passwordError').classList.add('d-none');
  document.getElementById('username').classList.remove('input-error');
  document.getElementById('password').classList.remove('input-error');
}

// Client-side Validation to match red input border in reference image
function handleFormSubmit(e) {
  const uInput = document.getElementById('username');
  const pInput = document.getElementById('password');
  const uErr = document.getElementById('usernameError');
  const pErr = document.getElementById('passwordError');
  const alertBox = document.getElementById('loginAlertBox');

  let valid = true;
  if (!uInput.value.trim()) {
    uInput.classList.add('input-error');
    uErr.classList.remove('d-none');
    valid = false;
  } else {
    uInput.classList.remove('input-error');
    uErr.classList.add('d-none');
  }

  if (!pInput.value) {
    pInput.classList.add('input-error');
    pErr.classList.remove('d-none');
    valid = false;
  } else {
    pInput.classList.remove('input-error');
    pErr.classList.add('d-none');
  }

  if (!valid) {
    e.preventDefault();
    return false;
  }

  if (document.getElementById('remember').checked) {
    localStorage.setItem('mis_remember_user', uInput.value.trim());
  } else {
    localStorage.removeItem('mis_remember_user');
  }

  try {
    sessionStorage.removeItem('mis_logged_out');
    sessionStorage.setItem('mis_authenticated', '1');
  } catch(e) {}

  const btn = document.getElementById('btnSignIn');
  btn.disabled = true;
  btn.innerHTML = '<span>Signing in...</span>';
  return true;
}

// Dynamic Branding Fetch if client-side rendered
async function loadDynamicBranding() {
  try {
    const res = await axios.get('/api/settings/branding');
    if (res.data && res.data.branding) {
      const b = res.data.branding;
      if (b.login_title) document.getElementById('displayHeroTitle').textContent = b.login_title;
      if (b.login_subtitle) document.getElementById('displayHeroSubtitle').textContent = b.login_subtitle;
      if (b.login_hero_image) {
        document.getElementById('heroPanel').style.backgroundImage = `url('${b.login_hero_image}')`;
      }
      if (b.login_logo) {
        document.getElementById('displayLogo').src = b.login_logo;
      }
      if (b.brand_color) {
        const btn = document.getElementById('btnSignIn');
        btn.style.background = b.brand_color;
      }
    }
  } catch (e) {
    console.debug('Using server-side rendered branding.');
  }
}
loadDynamicBrynamic = loadDynamicBranding;
loadDynamicBranding();

function openForgotPasswordModal() {
  const m = bootstrap.Modal.getOrCreateInstance(document.getElementById('forgotModal'));
  m.show();
}

async function sendResetRequest() {
  const val = document.getElementById('resetInput').value.trim();
  const msg = document.getElementById('resetModalMsg');
  if (!val) {
    msg.className = 'alert alert-danger py-2 text-xs mb-3';
    msg.textContent = 'Please enter your username or email.';
    return;
  }
  msg.className = 'alert alert-info py-2 text-xs mb-3';
  msg.textContent = 'Sending reset instructions...';
  try {
    const res = await axios.post('/password/email', { login: val, _token: document.getElementById('csrf_token').value });
    msg.className = 'alert alert-success py-2 text-xs mb-3';
    msg.textContent = res.data.message || 'Password reset link sent to your registered contact.';
  } catch (err) {
    msg.className = 'alert alert-danger py-2 text-xs mb-3';
    msg.textContent = err.response?.data?.message || 'Failed to process request. Please contact MIS Admin.';
  }
}
</script>
</body>
</html>
