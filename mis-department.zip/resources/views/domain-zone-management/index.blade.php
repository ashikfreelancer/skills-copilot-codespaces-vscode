<!DOCTYPE html>

<html lang="bn">
<head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script>
<meta charset="utf-8"/>
  <meta name="csrf-token" content="{{ csrf_token() }}">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<title>ডোমেইন ও জোন প্রধানের তথ্য | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link href="{{ asset('assets/css/app.css') }}" rel="stylesheet"/>
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap');
:root{--ink:#111;--grid:#333;--head:#c7c7c7}
body{background:#f3f5f7;font-family:"Noto Sans Bengali",Arial,sans-serif;color:#111}
.page-wrap{padding:24px}
.cardx{background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.05)}
.toolbar{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:14px}
.report-sheet{background:#fff;max-width:1180px;margin:0 auto;padding:28px 26px 36px;border:1px solid #ddd}
.report-header{text-align:center;position:relative;margin-bottom:10px}
.report-logo{position:absolute;left:0;top:0;width:82px;height:82px;object-fit:contain}
.report-header .org{font-size:23px;font-weight:700;line-height:1.2}
.report-header .sub{font-size:20px;font-weight:700;line-height:1.25}
.report-header .office{font-size:15px;font-weight:600;margin-top:2px}
.report-caption{font-size:17px;font-weight:600;text-align:center;margin:8px 0 12px}
.report-table{width:100%;border-collapse:collapse;table-layout:fixed}
.report-table th,.report-table td{border:1px solid var(--grid);padding:5px 6px;text-align:center;vertical-align:middle;font-size:13px;line-height:1.25}
.report-table thead th{background:var(--head);font-weight:700}
.report-table thead tr:first-child th{font-size:13px}
.report-table .operation-row td{background:#bcbcbc;font-weight:600}
.report-table .email{font-family:Georgia,"Times New Roman",serif;font-weight:700;word-break:break-word}
.report-table .comment{text-align:left;word-break:break-word}
.report-table .zone{text-align:left}
.report-table .head{text-align:left}
.report-table .sl{width:5%}.report-table .zonecol{width:12%}.report-table .namecol{width:17%}.report-table .desigcol{width:7%}.report-table .idcol{width:11%}.report-table .mobilecol{width:13%}.report-table .emailcol{width:31%}.report-table .commentcol{width:4%}
.action-cell{white-space:nowrap}
.badge-status{font-size:10px}
.print-only{display:none}
@media(max-width:991px){
 .report-sheet{padding:18px 10px}.report-logo{position:static;display:block;margin:0 auto 6px}.report-header .org{font-size:20px}.report-header .sub{font-size:18px}
 .report-table{min-width:980px}.table-scroll{overflow:auto}
}
@media print{
 @page{size:A4 portrait;margin:8mm}
 body{background:#fff!important}
 .sidebar,.topbar,.toolbar,.stats-row,.no-print,.action-cell,.print-hide{display:none!important}
 main{margin:0!important;width:100%!important}
 .page-wrap{padding:0!important}
 .report-sheet{max-width:none;border:0;box-shadow:none;padding:0;background:#fff}
 .print-only{display:block}
 .report-logo{width:72px;height:72px}
 .report-header .org{font-size:19px}.report-header .sub{font-size:18px}.report-header .office{font-size:12px}
 .report-caption{font-size:13px;margin:5px 0 8px}
 .report-table th,.report-table td{font-size:9px;padding:3px 4px}
 .report-table thead{display:table-header-group}
 tr{break-inside:avoid}
}
</style>
<script src="{{ asset('assets/js/app.js') }}"></script></head>
<body data-page="domain-zone-management">
<div class="container-fluid">
<aside class="sidebar d-none d-lg-block position-fixed top-0 bottom-0 start-0" style="width:260px;z-index:10">
<div class="p-3 text-white fw-bold fs-5">MIS Management</div>
<div class="px-2">
<div class="group-title">MAIN</div>
<a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i> Dashboard</a>
<a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="map"></i> Domain &amp; Zone Head Information</a>
<a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i> Staff Position List</a>
<a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i> Leave Management</a>
<a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line"></i> MIS Data Entry</a>
<a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i> MIS Reports</a>
<a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check"></i> Data Quality</a>
<a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined"></i> Analytics</a>
<div class="group-title">DOCUMENTS &amp; FINANCE</div>
<a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open"></i> Note &amp; Document Cabinet</a>
<a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet"></i> Advance Management</a>
<a data-nav="target-activity" href="/target-activity"><i data-lucide="target"></i> Target &amp; Activity</a>
<div class="group-title">OPERATIONS</div>
<a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor"></i> Monitoring</a>
<a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox"></i> Report Requests</a>
<a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet"></i> Excel Import / Export</a>
<div class="group-title">SYSTEM</div>
<a data-nav="notifications" href="/notifications"><i data-lucide="bell"></i> Notifications</a>
<a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i> Users &amp; Permissions</a>
<a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i> Audit Log</a>
<a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings"></i> Backup &amp; Settings</a>
</div>
</aside>
<main class="offset-lg-3 col-lg-9">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3">
<button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button>
<div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Domain &amp; Zone Management</h1></div>
</div>
<div class="d-flex align-items-center gap-2 no-print">
<button class="btn btn-light" onclick="printPage()" title="Print"><i data-lucide="printer"></i></button>
<button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button>
<div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div>
</div>
</header>
<div class="page-wrap">
<div class="d-flex justify-content-between align-items-center mb-3 no-print">
<div>
<h2 class="h4 fw-bold mb-1">ডোমেইন ও জোন প্রধানের তথ্য</h2>
<p class="text-secondary mb-0">প্রদত্ত Book1 রিপোর্টের সকল ১৩টি ডোমেইন/অপারেশন ও ৫৪টি জোনের তথ্য। Location &amp; Branch মডিউল অপরিবর্তিত।</p>
</div>
<div class="d-flex gap-2 flex-wrap">
<button class="btn btn-outline-success" onclick="downloadCSV()"><i data-lucide="download"></i> Download</button>
<button class="btn btn-outline-secondary" onclick="printPage()"><i data-lucide="printer"></i> Print</button>
<button class="btn btn-primary" onclick="openAdd()"><i data-lucide="plus"></i> Add Information</button>
</div>
</div>
<div class="row g-3 stats-row no-print mb-3">
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">মোট তথ্য</div><div class="fs-3 fw-bold" id="totalCount">0</div></div></div>
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">জোন প্রধান</div><div class="fs-3 fw-bold" id="zoneHeadCount">0</div></div></div>
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">ডোমেইন প্রধান</div><div class="fs-3 fw-bold" id="domainHeadCount">0</div></div></div>
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">Active</div><div class="fs-3 fw-bold text-success" id="activeCount">0</div></div></div>
</div>
<div class="toolbar no-print mb-3">
<div class="row g-2">
<div class="col-md-3"><label class="small fw-bold">ডোমেইন</label><select class="form-select" id="filterDomain"><option value="">সব ডোমেইন</option></select></div>
<div class="col-md-3"><label class="small fw-bold">জোন</label><select class="form-select" id="filterZone"><option value="">সব জোন</option></select></div>
<div class="col-md-2"><label class="small fw-bold">প্রধানের ধরন</label><select class="form-select" id="filterType"><option value="">সব</option><option value="Zone Head">জোন প্রধান</option><option value="Domain Head">ডোমেইন প্রধান</option></select></div>
<div class="col-md-2"><label class="small fw-bold">স্ট্যাটাস</label><select class="form-select" id="filterStatus"><option value="">সব</option><option>Active</option><option>Inactive</option></select></div>
<div class="col-md-2"><label class="small fw-bold">Search</label><input class="form-control" id="searchBox" placeholder="নাম / ID / মোবাইল / ইমেল"/></div>
</div>
</div>
<section class="report-sheet" id="reportSheet">
<div class="report-header">
<img alt="TMSS" class="report-logo" src="{{ asset('assets/images/tmss-logo.png') }}"/>
<div class="org">টিএমএসএস</div>
<div class="sub">HEM Grand Sector</div>
<div class="sub">MIS দপ্তর</div>
<div class="office">প্রধান কার্যালয়, ঢাকা।</div>
</div>
<div class="report-caption">ডোমেইনের নাম, জোনের নাম, ডোমেইন প্রধানের, জোন প্রধানের নাম ও মোবাইল নম্বর ।</div>
<div class="table-scroll">
<div class="table-responsive responsive-table"><table class="report-table" id="domainZoneTable">
<colgroup>
<col class="sl"/><col class="zonecol"/><col class="namecol"/><col class="desigcol"/><col class="idcol"/><col class="mobilecol"/><col class="emailcol"/><col class="commentcol"/>
</colgroup>
<thead>
<tr>
<th rowspan="2">ক্রঃ<br/>নং</th>
<th rowspan="2">জোনের নাম</th>
<th colspan="4">দায়িত্বপ্রাপ্ত জোন প্রধানের</th>
<th rowspan="2">জোনের ই-মেইল ঠিকানা</th>
<th rowspan="2">মন্তব্য</th>
</tr>
<tr>
<th>নাম</th><th>পদবী</th><th>আইডি নম্বর</th><th>মোবাইল নং</th>
</tr>
<tr class="print-hide no-print">
<th>১</th><th>২</th><th>৩</th><th>৪</th><th>৫</th><th>৬</th><th>৭</th><th>৮</th>
</tr>
</thead>
<tbody id="tableBody"></tbody>
</table></div>
</div>
</section>
</div>
</main>
</div>
<div class="modal fade" id="entryModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
<div class="modal-header"><div><h5 class="modal-title fw-bold" id="modalTitle">Add Domain / Zone Head</h5><div class="small text-secondary">রিপোর্টের প্রতিটি ঘরের তথ্য এখানে সংরক্ষণ করা যাবে।</div></div><button class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<form id="entryForm">
<input id="editId" type="hidden"/>
<div class="row g-3">
<div class="col-md-4"><label class="form-label fw-semibold">ডোমেইনের নাম</label><input class="form-control" id="domain" placeholder="যেমন: HEM Grand Sector" required=""/></div>
<div class="col-md-4"><label class="form-label fw-semibold">জোনের নাম</label><input class="form-control" id="zone" placeholder="যেমন: বগুড়া কেন্দ্রীয়" required=""/></div>
<div class="col-md-4"><label class="form-label fw-semibold">প্রধানের ধরন</label><select class="form-select" id="headType"><option value="Zone Head">জোন প্রধান</option><option value="Domain Head">ডোমেইন প্রধান</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">প্রধানের নাম</label><input class="form-control" id="headName" required=""/></div>
<div class="col-md-3"><label class="form-label fw-semibold">পদবী</label><input class="form-control" id="designation" placeholder="ZM / AM / AD" required=""/></div>
<div class="col-md-3"><label class="form-label fw-semibold">আইডি নম্বর</label><input class="form-control" id="employeeId" required=""/></div>
<div class="col-md-4"><label class="form-label fw-semibold">মোবাইল নং</label><input class="form-control" id="mobile" required=""/></div>
<div class="col-md-5"><label class="form-label fw-semibold">জোনের ই-মেইল ঠিকানা</label><input class="form-control" id="email" type="email"/></div>
<div class="col-md-3"><label class="form-label fw-semibold">স্ট্যাটাস</label><select class="form-select" id="status"><option>Active</option><option>Inactive</option></select></div>
<div class="col-md-8"><label class="form-label fw-semibold">ঠিকানা</label><textarea class="form-control" id="address" rows="2"></textarea></div>
<div class="col-md-4"><label class="form-label fw-semibold">মন্তব্য</label><textarea class="form-control" id="remarks" rows="2"></textarea></div>
</div>
</form>
</div>
<div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveEntry()"><i data-lucide="save"></i> <span id="saveText">Save</span></button></div>
</div></div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
  <div class="modal-dialog modal-lg"><div class="modal-content">
    <div class="modal-header bg-light">
      <div><h5 class="modal-title fw-bold" id="viewModalTitle">Domain / Zone Head Details</h5><div class="small text-secondary">বিস্তারিত তথ্য বিবরণী</div></div>
      <button class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
      <div class="row g-3" id="viewModalContent">
        <!-- Loaded dynamically -->
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button class="btn btn-primary" id="viewModalEditBtn"><i data-lucide="pencil"></i> Edit</button>
    </div>
  </div></div>
</div>

<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body">
<a href="/dashboard">Dashboard</a><a href="/domain-zone-management">Domain &amp; Zone Head Information</a><a href="/location-branch">Location &amp; Branch</a><a href="/staff-position-list">Staff Position List</a><a href="/reports">MIS Reports</a>
</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
let currentRows = [];
let allDomains = [];
let allZones = [];

function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}

async function fetchDomainZones() {
  const q = document.getElementById('searchBox').value.trim();
  const fd = document.getElementById('filterDomain').value;
  const fz = document.getElementById('filterZone').value;
  const ft = document.getElementById('filterType').value;
  const fs = document.getElementById('filterStatus').value;

  try {
    const params = new URLSearchParams();
    if (q) params.append('search', q);
    if (fd) params.append('domain', fd);
    if (fz) params.append('zone', fz);
    if (ft) params.append('head_type', ft);
    if (fs) params.append('status', fs);
    params.append('per_page', '200');

    const res = await axios.get(`/api/domain-zone-management?${params.toString()}`);
    if (res.data && res.data.success) {
      currentRows = res.data.data || [];
      const meta = res.data.meta || {};

      document.getElementById('totalCount').textContent = meta.total || currentRows.length;
      document.getElementById('zoneHeadCount').textContent = meta.zone_heads || 0;
      document.getElementById('domainHeadCount').textContent = meta.domain_heads || 0;
      document.getElementById('activeCount').textContent = meta.active_count || 0;

      // Populate filter dropdowns if first load
      if (allDomains.length === 0) {
        allDomains = [...new Set(currentRows.map(x => x.domain).filter(Boolean))].sort();
        const d = document.getElementById('filterDomain');
        d.innerHTML = '<option value="">সব ডোমেইন</option>' + allDomains.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join('');
      }
      if (allZones.length === 0) {
        allZones = [...new Set(currentRows.map(x => x.zone).filter(Boolean))].sort();
        const z = document.getElementById('filterZone');
        z.innerHTML = '<option value="">সব জোন</option>' + allZones.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join('');
      }

      renderTable();
    }
  } catch (err) {
    console.error('Error fetching domain zones:', err);
  }
}

function renderTable() {
  const tbody = document.getElementById('tableBody');
  if (currentRows.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">কোন তথ্য পাওয়া যায়নি।</td></tr>';
    return;
  }

  tbody.innerHTML = currentRows.map((x, i) => {
    const op = x.head_type === 'Domain Head';
    const isInactive = x.status === 'Inactive';
    return `<tr class="${op ? 'operation-row' : ''} ${isInactive ? 'opacity-75' : ''}">
      <td>${i + 1}</td>
      <td class="zone">
        <span class="fw-semibold">${esc(op ? x.domain : x.zone)}</span>
        ${op ? '<span class="badge bg-dark ms-1" style="font-size:9px">অপারেশন</span>' : ''}
      </td>
      <td class="head">
        <a href="javascript:void(0)" onclick="viewEntry('${x.id}')" class="text-decoration-none text-dark fw-bold hover:text-primary">
          ${esc(x.head_name)}
        </a>
      </td>
      <td>${esc(x.designation)}</td>
      <td><span class="badge bg-light text-dark border">${esc(x.employee_id)}</span></td>
      <td><a href="tel:${esc(x.mobile)}" class="text-decoration-none text-dark">${esc(x.mobile)}</a></td>
      <td class="email">${x.email ? `<a href="mailto:${esc(x.email)}" class="text-decoration-none">${esc(x.email)}</a>` : '<span class="text-muted">-</span>'}</td>
      <td class="comment">
        <div>${esc(x.remarks || '')}</div>
        <div class="no-print action-cell mt-1 d-flex gap-1 justify-content-center">
          <button class="btn btn-sm btn-outline-info py-0 px-1" onclick="viewEntry('${x.id}')" title="View Details"><i data-lucide="eye" style="width:13px"></i></button>
          <button class="btn btn-sm btn-outline-primary py-0 px-1" onclick="editEntry('${x.id}')" title="Edit"><i data-lucide="pencil" style="width:13px"></i></button>
          <button class="btn btn-sm ${x.status === 'Active' ? 'btn-outline-warning' : 'btn-outline-success'} py-0 px-1" onclick="toggleStatus('${x.id}', '${x.status}')" title="${x.status === 'Active' ? 'Deactivate' : 'Activate'}">
            <i data-lucide="${x.status === 'Active' ? 'user-x' : 'user-check'}" style="width:13px"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger py-0 px-1" onclick="deleteEntry('${x.id}')" title="Delete"><i data-lucide="trash-2" style="width:13px"></i></button>
        </div>
      </td>
    </tr>`;
  }).join('');

  lucide.createIcons();
}

function openAdd(){
  document.getElementById('entryForm').reset();
  document.getElementById('editId').value = '';
  document.getElementById('status').value = 'Active';
  document.getElementById('headType').value = 'Zone Head';
  document.getElementById('modalTitle').textContent = 'Add Domain / Zone Head';
  document.getElementById('saveText').textContent = 'Save';
  bootstrap.Modal.getOrCreateInstance(document.getElementById('entryModal')).show();
}

async function viewEntry(id) {
  try {
    const res = await axios.get(`/api/domain-zone-management/${id}`);
    if (res.data && res.data.success) {
      const x = res.data.data;
      const content = `
        <div class="col-md-6"><strong>ডোমেইন:</strong> <div>${esc(x.domain)}</div></div>
        <div class="col-md-6"><strong>জোন:</strong> <div>${esc(x.zone || 'N/A (ডোমেইন হেড)')}</div></div>
        <div class="col-md-6"><strong>প্রধানের নাম:</strong> <div class="fs-5 fw-bold text-primary">${esc(x.head_name)}</div></div>
        <div class="col-md-3"><strong>পদবী:</strong> <div><span class="badge bg-secondary">${esc(x.designation)}</span></div></div>
        <div class="col-md-3"><strong>প্রধানের ধরন:</strong> <div><span class="badge bg-info text-dark">${esc(x.head_type)}</span></div></div>
        <div class="col-md-6"><strong>আইডি নম্বর:</strong> <div>${esc(x.employee_id)}</div></div>
        <div class="col-md-6"><strong>মোবাইল নং:</strong> <div><a href="tel:${esc(x.mobile)}">${esc(x.mobile)}</a></div></div>
        <div class="col-md-6"><strong>ই-মেইল ঠিকানা:</strong> <div>${x.email ? `<a href="mailto:${esc(x.email)}">${esc(x.email)}</a>` : '-'}</div></div>
        <div class="col-md-6"><strong>স্ট্যাটাস:</strong> <div><span class="badge ${x.status === 'Active' ? 'bg-success' : 'bg-danger'}">${esc(x.status)}</span></div></div>
        <div class="col-md-12"><strong>ঠিকানা:</strong> <div>${esc(x.address || 'N/A')}</div></div>
        <div class="col-md-12"><strong>মন্তব্য:</strong> <div>${esc(x.remarks || 'N/A')}</div></div>
        <div class="col-md-12 text-muted small mt-2">সংরক্ষণ সময়: ${esc(x.created_at || '')} | সর্বশেষ আপডেট: ${esc(x.updated_at || '')}</div>
      `;
      document.getElementById('viewModalContent').innerHTML = content;
      document.getElementById('viewModalEditBtn').onclick = () => {
        bootstrap.Modal.getInstance(document.getElementById('viewModal')).hide();
        editEntry(id);
      };
      bootstrap.Modal.getOrCreateInstance(document.getElementById('viewModal')).show();
      lucide.createIcons();
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Error', text: err.response?.data?.message || 'তথ্য লোড করা যায়নি।' });
  }
}

async function editEntry(id){
  try {
    const res = await axios.get(`/api/domain-zone-management/${id}`);
    if (res.data && res.data.success) {
      const x = res.data.data;
      document.getElementById('editId').value = id;
      document.getElementById('domain').value = x.domain || '';
      document.getElementById('zone').value = x.zone || '';
      document.getElementById('headType').value = x.head_type || 'Zone Head';
      document.getElementById('headName').value = x.head_name || '';
      document.getElementById('designation').value = x.designation || '';
      document.getElementById('employeeId').value = x.employee_id || '';
      document.getElementById('mobile').value = x.mobile || '';
      document.getElementById('email').value = x.email || '';
      document.getElementById('address').value = x.address || '';
      document.getElementById('status').value = x.status || 'Active';
      document.getElementById('remarks').value = x.remarks || '';

      document.getElementById('modalTitle').textContent = 'Edit Domain / Zone Head';
      document.getElementById('saveText').textContent = 'Update';
      bootstrap.Modal.getOrCreateInstance(document.getElementById('entryModal')).show();
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Error', text: 'তথ্য পাওয়া যায়নি।' });
  }
}

async function saveEntry(){
  const form = document.getElementById('entryForm');
  if (!form.checkValidity()){
    form.reportValidity();
    return;
  }

  const id = document.getElementById('editId').value;
  const payload = {
    domain: document.getElementById('domain').value.trim(),
    zone: document.getElementById('zone').value.trim(),
    head_type: document.getElementById('headType').value,
    head_name: document.getElementById('headName').value.trim(),
    designation: document.getElementById('designation').value.trim(),
    employee_id: document.getElementById('employeeId').value.trim(),
    mobile: document.getElementById('mobile').value.trim(),
    email: document.getElementById('email').value.trim(),
    address: document.getElementById('address').value.trim(),
    status: document.getElementById('status').value,
    remarks: document.getElementById('remarks').value.trim()
  };

  try {
    let res;
    if (id) {
      res = await axios.put(`/api/domain-zone-management/${id}`, payload);
    } else {
      res = await axios.post('/api/domain-zone-management', payload);
    }

    if (res.data && res.data.success) {
      bootstrap.Modal.getInstance(document.getElementById('entryModal')).hide();
      await fetchDomainZones();
      Swal.fire({
        icon: 'success',
        title: id ? 'Updated' : 'Saved',
        text: id ? 'তথ্য সফলভাবে আপডেট হয়েছে।' : 'তথ্য সফলভাবে সংরক্ষণ হয়েছে।',
        timer: 1500,
        showConfirmButton: false
      });
    }
  } catch (err) {
    Swal.fire({
      icon: 'error',
      title: 'Validation / Save Error',
      text: err.response?.data?.message || err.message
    });
  }
}

async function toggleStatus(id, currentStatus) {
  const newStatus = currentStatus === 'Active' ? 'Inactive' : 'Active';
  const actionText = newStatus === 'Active' ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Inactive)';

  const confirm = await Swal.fire({
    title: 'স্ট্যাটাস পরিবর্তন',
    text: `আপনি কি স্ট্যাটাস ${actionText} করতে চান?`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'হ্যাঁ, পরিবর্তন করুন',
    cancelButtonText: 'বাতিল'
  });

  if (!confirm.isConfirmed) return;

  try {
    const res = await axios.post(`/api/domain-zone-management/${id}/status`, { status: newStatus });
    if (res.data && res.data.success) {
      await fetchDomainZones();
      Swal.fire({
        icon: 'success',
        title: 'Status Updated',
        text: `স্ট্যাটাস সফলভাবে ${newStatus} করা হয়েছে।`,
        timer: 1300,
        showConfirmButton: false
      });
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Action Failed', text: err.response?.data?.message || err.message });
  }
}

async function deleteEntry(id){
  const item = currentRows.find(r => r.id === id);
  const name = item ? `${item.zone || item.domain} — ${item.head_name}` : id;

  const result = await Swal.fire({
    icon: 'warning',
    title: 'তথ্য মুছে ফেলবেন?',
    text: name,
    showCancelButton: true,
    confirmButtonText: 'হ্যাঁ, Delete',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#dc2626'
  });

  if (!result.isConfirmed) return;

  try {
    const res = await axios.delete(`/api/domain-zone-management/${id}`);
    if (res.data && res.data.success) {
      await fetchDomainZones();
      Swal.fire({ icon: 'success', title: 'Deleted', text: 'তথ্য সফলভাবে মুছে ফেলা হয়েছে।', timer: 1200, showConfirmButton: false });
    }
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Delete Failed', text: err.response?.data?.message || err.message });
  }
}

async function downloadCSV(){
  try {
    await axios.post('/api/domain-zone-management/action', { action: 'export', reference: 'CSV Download' });
  } catch (e) {
    console.warn('Export audit logging note:', e);
  }

  const h = ['SL', 'Domain', 'Zone', 'Head Type', 'Head Name', 'Designation', 'ID Number', 'Mobile Number', 'Email Address', 'Address', 'Status', 'Remarks'];
  const lines = [h, ...currentRows.map((x, i) => [
    i + 1,
    x.domain,
    x.zone,
    x.head_type,
    x.head_name,
    x.designation,
    x.employee_id,
    x.mobile,
    x.email,
    x.address,
    x.status,
    x.remarks
  ])].map(a => a.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');

  const blob = new Blob(['\ufeff' + lines], { type: 'text/csv;charset=utf-8;' });
  const u = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = u;
  a.download = 'domain-zone-head-information.csv';
  a.click();
  URL.revokeObjectURL(u);
}

async function printPage(){
  try {
    await axios.post('/api/domain-zone-management/action', { action: 'print', reference: 'Domain & Zone Report' });
  } catch (e) {
    console.warn('Print audit logging note:', e);
  }
  window.print();
}

// Event Listeners for Live Search and Filter
['searchBox', 'filterDomain', 'filterZone', 'filterType', 'filterStatus'].forEach(id => {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener(id === 'searchBox' ? 'input' : 'change', () => {
      fetchDomainZones();
    });
  }
});

document.addEventListener('DOMContentLoaded', () => {
  if (typeof MIS_requireAuth === 'function') MIS_requireAuth();
  fetchDomainZones();
  lucide.createIcons();
});
</script>
</body>
</html>
