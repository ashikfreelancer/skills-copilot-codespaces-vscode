<!doctype html>
<html lang="en">
<head>
  <script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script>
  <meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Department Management | MIS Department</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <link rel="stylesheet" href="{{ asset('assets/css/app.css') }}">
  <style>
    .dep-card {
      border: 1px solid #e7edf5;
      border-radius: 14px;
      background: #fff;
      box-shadow: 0 8px 25px rgba(15,23,42,.05);
    }
    .dep-head {
      background: linear-gradient(135deg, #0d47a1, #1976d2);
      color: #fff;
      border-radius: 14px 14px 0 0;
      padding: 16px 20px;
    }
    .form-control, .form-select {
      min-height: 44px;
    }
    .table-wrap {
      overflow: auto;
    }
    .badge-active {
      background: #dcfce7;
      color: #166534;
      font-weight: 600;
      cursor: pointer;
    }
    .badge-inactive {
      background: #fee2e2;
      color: #991b1b;
      font-weight: 600;
      cursor: pointer;
    }
    .sort-header {
      cursor: pointer;
      user-select: none;
    }
    .sort-header:hover {
      background-color: #f1f5f9;
    }
    @media (max-width: 767px) {
      .content-pad { padding: 12px!important; }
      .dep-head { padding: 14px; }
      .action-group { display: flex; gap: 4px; white-space: nowrap; }
    }
    @media print {
      .desktop-sidebar, .topbar, .no-print, .btn, .search-bar-row, .pagination-row {
        display: none !important;
      }
      main {
        width: 100% !important;
      }
      .dep-card {
        box-shadow: none !important;
        border: none !important;
      }
    }
  </style>
  <script src="{{ asset('assets/js/app.js') }}"></script>
</head>
<body data-page="department-management">
<div class="container-fluid">
  <div class="row g-0">
    <!-- Sidebar -->
    <aside class="col-lg-2 desktop-sidebar sidebar p-3">
      <div class="d-flex align-items-center gap-2 px-2 py-2 mb-2">
        <div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div>
        <div class="text-white fw-bold">MIS Management</div>
      </div>
      <div class="text-slate-400 px-2 small mb-3">Management Information System</div>
      <div class="group-title">MAIN</div>
      <a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i>Dashboard</a>
      <a data-nav="location-branch" href="/location-branch"><i data-lucide="map"></i>Location & Branch</a>
      <a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="map-pin"></i>Domain & Zone</a>
      <a data-nav="department-management" href="/department-management" class="active"><i data-lucide="building-2"></i>Department Management</a>
      <a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i>Staff Position List</a>
      <a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i>Leave Management</a>
      <a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i>MIS Reports</a>
      <div class="group-title">OPERATIONS</div>
      <a data-nav="movement-register" href="/movement-register"><i data-lucide="arrow-left-right"></i>Movement Register</a>
      <a data-nav="stock-register" href="/stock-register"><i data-lucide="boxes"></i>Stock Register</a>
      <div class="group-title">SYSTEM</div>
      <a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a>
      <a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i>Audit Log</a>
    </aside>

    <!-- Main Content -->
    <main class="col-lg-10">
      <header class="topbar border-bottom bg-white px-3 px-md-4 py-3">
        <div class="d-flex align-items-center justify-content-between">
          <div>
            <div class="small text-secondary">MIS Department</div>
            <h1 class="h5 mb-0 fw-bold">Department Management</h1>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-primary" onclick="openDepModal()">
              <i data-lucide="plus" class="me-1"></i>Add Department
            </button>
          </div>
        </div>
      </header>

      <div class="content-pad p-3 p-md-4">
        <!-- KPI Cards -->
        <div class="row g-3 mb-3">
          <div class="col-sm-6 col-xl-3">
            <div class="dep-card p-3">
              <div class="small text-secondary">Total Departments</div>
              <div id="kTotal" class="fs-3 fw-bold">0</div>
            </div>
          </div>
          <div class="col-sm-6 col-xl-3">
            <div class="dep-card p-3">
              <div class="small text-secondary">Active</div>
              <div id="kActive" class="fs-3 fw-bold text-success">0</div>
            </div>
          </div>
          <div class="col-sm-6 col-xl-3">
            <div class="dep-card p-3">
              <div class="small text-secondary">Inactive</div>
              <div id="kInactive" class="fs-3 fw-bold text-danger">0</div>
            </div>
          </div>
        </div>

        <!-- Main Records Card -->
        <div class="dep-card">
          <div class="dep-head d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div>
              <h2 class="h6 mb-1 fw-bold">Department Records</h2>
              <div class="small opacity-75">Super Admin can Add, View, Edit, Update and Delete departments.</div>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-light btn-sm" onclick="printPage()">
                <i data-lucide="printer" class="me-1"></i>Print
              </button>
              <button class="btn btn-light btn-sm" onclick="exportDepartments()">
                <i data-lucide="download" class="me-1"></i>Download CSV
              </button>
            </div>
          </div>

          <div class="p-3">
            <!-- Search & Filters -->
            <div class="row g-2 mb-3 search-bar-row">
              <div class="col-md-7">
                <input id="depSearch" class="form-control" placeholder="Search department name, code or description..." oninput="debounceLoad()">
              </div>
              <div class="col-md-3">
                <select id="depStatus" class="form-select" onchange="loadDepartments()">
                  <option value="">All Status</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
              <div class="col-md-2">
                <button class="btn btn-outline-secondary w-100" onclick="clearDepFilters()">Reset</button>
              </div>
            </div>

            <!-- Table -->
            <div class="table-wrap">
              <table class="table table-hover align-middle mb-0" id="departmentTable">
                <thead class="table-light">
                  <tr>
                    <th style="width: 50px;">SL</th>
                    <th class="sort-header" onclick="changeSort('name')">Department Name <span id="sort_icon_name">↕</span></th>
                    <th class="sort-header" onclick="changeSort('code')">Department Code <span id="sort_icon_code">↕</span></th>
                    <th>Description</th>
                    <th class="sort-header" onclick="changeSort('status')">Status <span id="sort_icon_status">↕</span></th>
                    <th class="sort-header" onclick="changeSort('updated_at')">Updated <span id="sort_icon_updated_at">↕</span></th>
                    <th class="no-print text-center" style="width: 140px;">Actions</th>
                  </tr>
                </thead>
                <tbody id="tableBody">
                  <tr>
                    <td colspan="7" class="text-center py-4 text-muted">
                      <div class="spinner-border spinner-border-sm me-2" role="status"></div> Loading departments...
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- Pagination info -->
            <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top pagination-row">
              <div class="small text-muted" id="paginationInfo">Showing 0 to 0 of 0 entries</div>
              <div class="d-flex gap-1" id="paginationControls"></div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<!-- Entry / Edit Modal -->
<div class="modal fade" id="depModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-light">
        <b id="depModalTitle">Add Department</b>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="depId">
        <div class="mb-3">
          <label class="form-label fw-semibold">Department Name <span class="text-danger">*</span></label>
          <input id="depName" class="form-control" placeholder="e.g. MIS">
          <div class="invalid-feedback" id="depNameErr"></div>
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Department Code <span class="text-danger">*</span></label>
          <input id="depCode" class="form-control" placeholder="e.g. MIS-01">
          <div class="invalid-feedback" id="depCodeErr"></div>
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Description</label>
          <textarea id="depDesc" class="form-control" rows="3" placeholder="Department description"></textarea>
        </div>
        <div>
          <label class="form-label fw-semibold">Status</label>
          <select id="depStat" class="form-select">
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="saveDepBtn" onclick="saveDepartment()">
          <i data-lucide="check" class="me-1"></i>Save / Update
        </button>
      </div>
    </div>
  </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="viewDepModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-light">
        <b class="modal-title">Department Details</b>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-3" id="viewDepBody">
        <div class="text-center py-3 text-muted">Loading details...</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Toast Container -->
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3 align-items-center text-white bg-dark border-0" role="alert" aria-live="assertive" aria-atomic="true">
  <div class="d-flex">
    <div class="toast-body" id="toastMessage">Action completed successfully</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
let currentDepartments = [];
let currentSort = { column: 'name', order: 'asc' };
let currentPage = 1;
let debounceTimer = null;

function esc(x) {
  return String(x ?? '').replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  }[m]));
}

function showToast(msg, isError = false) {
  const toastEl = document.getElementById('toast');
  const msgEl = document.getElementById('toastMessage');
  if (msgEl) msgEl.textContent = msg;
  if (toastEl) {
    toastEl.className = `toast position-fixed bottom-0 end-0 m-3 align-items-center text-white ${isError ? 'bg-danger' : 'bg-success'} border-0`;
    const bsToast = bootstrap.Toast.getOrCreateInstance(toastEl);
    bsToast.show();
  }
}

function debounceLoad() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    currentPage = 1;
    loadDepartments();
  }, 300);
}

function changeSort(col) {
  if (currentSort.column === col) {
    currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
  } else {
    currentSort.column = col;
    currentSort.order = 'asc';
  }
  updateSortIcons();
  loadDepartments();
}

function updateSortIcons() {
  ['name', 'code', 'status', 'updated_at'].forEach(c => {
    const el = document.getElementById(`sort_icon_${c}`);
    if (el) {
      if (currentSort.column === c) {
        el.textContent = currentSort.order === 'asc' ? '↑' : '↓';
        el.className = 'text-primary fw-bold';
      } else {
        el.textContent = '↕';
        el.className = 'text-muted';
      }
    }
  });
}

async function loadDepartments() {
  const search = document.getElementById('depSearch')?.value?.trim() || '';
  const status = document.getElementById('depStatus')?.value || '';

  const tableBody = document.getElementById('tableBody');
  if (tableBody) {
    tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading departments...</td></tr>`;
  }

  try {
    const params = new URLSearchParams({
      search,
      status,
      sort_by: currentSort.column,
      sort_order: currentSort.order,
      page: currentPage,
      per_page: 50
    });

    const res = await axios.get(`/api/department-management?${params.toString()}`);
    const data = res.data;
    if (data) {
      if (Array.isArray(data)) {
        currentDepartments = data;
      } else if (Array.isArray(data.data)) {
        currentDepartments = data.data;
      } else {
        currentDepartments = [];
      }

      const meta = data.meta || {
        total: currentDepartments.length,
        active: currentDepartments.filter(d => (d.status || '').toLowerCase() === 'active').length,
        inactive: currentDepartments.filter(d => (d.status || '').toLowerCase() === 'inactive').length
      };

      const pagination = data.pagination || {
        total: meta.total ?? currentDepartments.length,
        page: currentPage,
        per_page: 50,
        last_page: Math.ceil((meta.total ?? currentDepartments.length) / 50) || 1
      };

      // Update KPI counters
      if (document.getElementById('kTotal')) document.getElementById('kTotal').textContent = meta.total ?? currentDepartments.length;
      if (document.getElementById('kActive')) document.getElementById('kActive').textContent = meta.active ?? 0;
      if (document.getElementById('kInactive')) document.getElementById('kInactive').textContent = meta.inactive ?? 0;

      // Cross-module sync for departments
      if (typeof MIS_write === 'function' && typeof MIS_SHARED_KEYS !== 'undefined') {
        MIS_write(MIS_SHARED_KEYS.departments, currentDepartments);
        localStorage.setItem('mis_departments', JSON.stringify(currentDepartments));
        window.dispatchEvent(new CustomEvent('mis:departments:updated', { detail: currentDepartments }));
      }

      renderDepartmentTable(currentDepartments, pagination);
    } else {
      renderDepartmentTable([], {});
    }
  } catch (err) {
    console.error('Error loading departments:', err);
    if (tableBody) {
      const errMsg = err.response?.data?.message || err.response?.data?.error || err.message || 'Server error';
      const statusCode = err.response?.status ? ` (HTTP ${err.response.status})` : '';
      tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger">
        <div class="mb-2"><i data-lucide="alert-circle" class="me-1"></i>Unable to load departments${statusCode}: ${esc(errMsg)}</div>
        <button type="button" class="btn btn-sm btn-outline-primary" onclick="loadDepartments()"><i data-lucide="refresh-cw" class="me-1"></i> Retry</button>
      </td></tr>`;
      if (window.lucide) lucide.createIcons();
    }
  }
}

function renderDepartmentTable(departments, pagination) {
  const tableBody = document.getElementById('tableBody');
  if (!tableBody) return;

  if (!departments.length) {
    tableBody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">No department records found matching your filters.</td></tr>`;
    renderPagination(pagination);
    return;
  }

  const offset = ((pagination.page || 1) - 1) * (pagination.per_page || 50);

  tableBody.innerHTML = departments.map((d, idx) => `
    <tr>
      <td>${offset + idx + 1}</td>
      <td class="fw-semibold text-primary">${esc(d.name)}</td>
      <td><span class="badge bg-light text-dark border font-monospace">${esc(d.code)}</span></td>
      <td>${esc(d.description || '-')}</td>
      <td>
        <span class="badge ${d.status === 'Active' ? 'badge-active' : 'badge-inactive'}"
              title="Click to toggle status"
              onclick="toggleDepartmentStatus('${d.id}', '${d.status === 'Active' ? 'Inactive' : 'Active'}')">
          ${esc(d.status)}
        </span>
      </td>
      <td class="small text-secondary">${esc(d.updated_at ? d.updated_at.substring(0, 10) : (d.created_at ? d.created_at.substring(0, 10) : '-'))}</td>
      <td class="no-print text-center">
        <div class="action-group justify-content-center">
          <button class="btn btn-sm btn-outline-primary" title="View Details" onclick="viewDepartment('${d.id}')">
            <i data-lucide="eye"></i>
          </button>
          <button class="btn btn-sm btn-outline-secondary" title="Edit" onclick="editDepartment('${d.id}')">
            <i data-lucide="pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" title="Delete" onclick="deleteDepartment('${d.id}', '${esc(d.name)}')">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  if (window.lucide) lucide.createIcons();
  renderPagination(pagination);
}

function renderPagination(pagination) {
  const infoEl = document.getElementById('paginationInfo');
  const controlsEl = document.getElementById('paginationControls');
  if (!infoEl || !controlsEl) return;

  const total = pagination.total || 0;
  const page = pagination.page || 1;
  const perPage = pagination.per_page || 50;
  const lastPage = pagination.last_page || 1;

  const start = total === 0 ? 0 : (page - 1) * perPage + 1;
  const end = Math.min(page * perPage, total);
  infoEl.textContent = `Showing ${start} to ${end} of ${total} entries`;

  if (lastPage <= 1) {
    controlsEl.innerHTML = '';
    return;
  }

  let html = `<button class="btn btn-sm btn-outline-secondary ${page <= 1 ? 'disabled' : ''}" onclick="goToPage(${page - 1})">Prev</button>`;
  for (let p = 1; p <= lastPage; p++) {
    html += `<button class="btn btn-sm ${p === page ? 'btn-primary' : 'btn-outline-secondary'}" onclick="goToPage(${p})">${p}</button>`;
  }
  html += `<button class="btn btn-sm btn-outline-secondary ${page >= lastPage ? 'disabled' : ''}" onclick="goToPage(${page + 1})">Next</button>`;
  controlsEl.innerHTML = html;
}

function goToPage(p) {
  currentPage = p;
  loadDepartments();
}

function openDepModal() {
  document.getElementById('depId').value = '';
  document.getElementById('depName').value = '';
  document.getElementById('depCode').value = '';
  document.getElementById('depDesc').value = '';
  document.getElementById('depStat').value = 'Active';
  document.getElementById('depModalTitle').textContent = 'Add Department';

  clearValidationErrors();
  bootstrap.Modal.getOrCreateInstance(document.getElementById('depModal')).show();
}

async function editDepartment(id) {
  clearValidationErrors();
  try {
    const res = await axios.get(`/api/department-management/${id}`);
    if (res.data.success) {
      const d = res.data.data;
      document.getElementById('depId').value = d.id;
      document.getElementById('depName').value = d.name;
      document.getElementById('depCode').value = d.code;
      document.getElementById('depDesc').value = d.description || '';
      document.getElementById('depStat').value = d.status || 'Active';
      document.getElementById('depModalTitle').textContent = 'Edit Department';

      bootstrap.Modal.getOrCreateInstance(document.getElementById('depModal')).show();
    }
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to load department details.', true);
  }
}

async function saveDepartment() {
  clearValidationErrors();
  const id = document.getElementById('depId').value.trim();
  const name = document.getElementById('depName').value.trim();
  const code = document.getElementById('depCode').value.trim();
  const description = document.getElementById('depDesc').value.trim();
  const status = document.getElementById('depStat').value;

  if (!name) {
    setFieldError('depName', 'Department Name is required.');
    return;
  }
  if (!code) {
    setFieldError('depCode', 'Department Code is required.');
    return;
  }

  const payload = { name, code, description, status };
  const saveBtn = document.getElementById('saveDepBtn');
  if (saveBtn) saveBtn.disabled = true;

  try {
    let res;
    if (id) {
      res = await axios.put(`/api/department-management/${id}`, payload);
    } else {
      res = await axios.post('/api/department-management', payload);
    }

    if (res.data && (res.data.success || res.status === 200 || res.status === 201)) {
      const modalInst = bootstrap.Modal.getInstance(document.getElementById('depModal')) || bootstrap.Modal.getOrCreateInstance(document.getElementById('depModal'));
      modalInst.hide();
      showToast(id ? 'Department updated successfully.' : 'Department added successfully.');
      loadDepartments();
    } else {
      showToast(res.data?.message || 'Failed to save department.', true);
    }
  } catch (err) {
    const resp = err.response?.data;
    if (resp?.errors) {
      if (resp.errors.name) setFieldError('depName', Array.isArray(resp.errors.name) ? resp.errors.name[0] : resp.errors.name);
      if (resp.errors.code) setFieldError('depCode', Array.isArray(resp.errors.code) ? resp.errors.code[0] : resp.errors.code);
    } else {
      showToast(resp?.message || resp?.error || err.message || 'Failed to save department.', true);
    }
  } finally {
    if (saveBtn) saveBtn.disabled = false;
  }
}

function setFieldError(fieldId, msg) {
  const input = document.getElementById(fieldId);
  const err = document.getElementById(fieldId + 'Err');
  if (input) input.classList.add('is-invalid');
  if (err) {
    err.textContent = msg;
    err.style.display = 'block';
  }
}

function clearValidationErrors() {
  ['depName', 'depCode'].forEach(id => {
    const input = document.getElementById(id);
    const err = document.getElementById(id + 'Err');
    if (input) input.classList.remove('is-invalid');
    if (err) {
      err.textContent = '';
      err.style.display = 'none';
    }
  });
}

async function viewDepartment(id) {
  const modalBody = document.getElementById('viewDepBody');
  modalBody.innerHTML = `<div class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading...</div>`;
  bootstrap.Modal.getOrCreateInstance(document.getElementById('viewDepModal')).show();

  try {
    const res = await axios.get(`/api/department-management/${id}`);
    if (res.data.success) {
      const d = res.data.data;
      modalBody.innerHTML = `
        <div class="list-group list-group-flush border rounded-3 mb-3">
          <div class="list-group-item d-flex justify-content-between">
            <span class="text-muted">Department ID</span>
            <span class="fw-bold font-monospace">${esc(d.id)}</span>
          </div>
          <div class="list-group-item d-flex justify-content-between">
            <span class="text-muted">Department Name</span>
            <span class="fw-bold text-primary">${esc(d.name)}</span>
          </div>
          <div class="list-group-item d-flex justify-content-between">
            <span class="text-muted">Department Code</span>
            <span class="badge bg-light text-dark border font-monospace">${esc(d.code)}</span>
          </div>
          <div class="list-group-item d-flex justify-content-between">
            <span class="text-muted">Status</span>
            <span class="badge ${d.status === 'Active' ? 'badge-active' : 'badge-inactive'}">${esc(d.status)}</span>
          </div>
          <div class="list-group-item">
            <span class="text-muted d-block mb-1">Description</span>
            <div class="p-2 bg-light rounded text-dark">${esc(d.description || 'No description provided.')}</div>
          </div>
          <div class="list-group-item d-flex justify-content-between">
            <span class="text-muted">Created At</span>
            <span>${esc(d.created_at || '-')}</span>
          </div>
          <div class="list-group-item d-flex justify-content-between">
            <span class="text-muted">Last Updated</span>
            <span>${esc(d.updated_at || '-')}</span>
          </div>
        </div>
        <div class="d-flex justify-content-between gap-2">
          <button class="btn btn-sm ${d.status === 'Active' ? 'btn-outline-warning' : 'btn-outline-success'} flex-fill"
                  onclick="toggleDepartmentStatus('${d.id}', '${d.status === 'Active' ? 'Inactive' : 'Active'}', true)">
            <i data-lucide="${d.status === 'Active' ? 'pause-circle' : 'play-circle'}" class="me-1"></i>
            Mark as ${d.status === 'Active' ? 'Inactive' : 'Active'}
          </button>
          <button class="btn btn-sm btn-outline-primary flex-fill" onclick="bootstrap.Modal.getInstance(document.getElementById('viewDepModal')).hide(); editDepartment('${d.id}')">
            <i data-lucide="pencil" class="me-1"></i> Edit Department
          </button>
        </div>
      `;
      if (window.lucide) lucide.createIcons();
    }
  } catch (err) {
    modalBody.innerHTML = `<div class="alert alert-danger mb-0">${err.response?.data?.message || 'Failed to load details.'}</div>`;
  }
}

async function toggleDepartmentStatus(id, newStatus, fromViewModal = false) {
  try {
    const res = await axios.post(`/api/department-management/${id}/status`, { status: newStatus });
    if (res.data.success) {
      showToast(`Status updated to ${newStatus}.`);
      if (fromViewModal) {
        bootstrap.Modal.getInstance(document.getElementById('viewDepModal'))?.hide();
      }
      loadDepartments();
    }
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to update status.', true);
  }
}

async function deleteDepartment(id, name) {
  const result = await Swal.fire({
    title: 'Delete Department?',
    html: `Are you sure you want to permanently delete <b>${name}</b>?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#64748b',
    confirmButtonText: 'Yes, Delete'
  });

  if (!result.isConfirmed) return;

  try {
    const res = await axios.delete(`/api/department-management/${id}`);
    if (res.data.success) {
      showToast('Department deleted successfully.');
      loadDepartments();
    }
  } catch (err) {
    const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to delete department.';
    Swal.fire({
      title: 'Cannot Delete',
      text: msg,
      icon: 'error'
    });
  }
}

function clearDepFilters() {
  document.getElementById('depSearch').value = '';
  document.getElementById('depStatus').value = '';
  currentPage = 1;
  loadDepartments();
}

async function printPage() {
  try {
    await axios.post('/api/department-management/action', {
      action: 'print',
      reference: 'Department Master Records Report'
    });
  } catch (e) {}
  window.print();
}

async function exportDepartments() {
  try {
    const res = await axios.get('/api/department-management?per_page=1000');
    const rows = res.data.data || [];

    await axios.post('/api/department-management/action', {
      action: 'export',
      reference: `Department Master CSV Export (${rows.length} records)`
    });

    const headers = ['SL', 'Department ID', 'Department Name', 'Department Code', 'Description', 'Status', 'Created At', 'Updated At'];
    const csvRows = [headers];

    rows.forEach((r, idx) => {
      csvRows.push([
        idx + 1,
        r.id || '',
        r.name || '',
        r.code || '',
        (r.description || '').replace(/\r?\n/g, ' '),
        r.status || '',
        r.created_at || '',
        r.updated_at || ''
      ]);
    });

    const csvContent = csvRows.map(row =>
      row.map(val => `"${String(val).replaceAll('"', '""')}"`).join(',')
    ).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `departments_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);

    showToast('CSV export downloaded successfully.');
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to export CSV.', true);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadDepartments();
  updateSortIcons();
  if (window.lucide) lucide.createIcons();
});
</script>
</body>
</html>
