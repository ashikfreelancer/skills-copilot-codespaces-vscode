<!DOCTYPE html>

<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"/>
  <meta name=\"csrf-token\" content=\"{{ csrf_token() }}\"><meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>MIS Reports | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link href="{{ asset('assets/css/app.css') }}" rel="stylesheet"/>
<style>
@media print {
  body * {
    visibility: hidden;
  }
  #reportViewerContainer, #reportViewerContainer * {
    visibility: visible;
  }
  #reportViewerContainer {
    position: absolute;
    left: 0;
    top: 0;
    width: 100% !important;
    margin: 0 !important;
    padding: 15px !important;
    border: none !important;
    box-shadow: none !important;
    background: #fff !important;
  }
  .no-print, .btn, .pagination, select, input, .offcanvas, .sidebar, .topbar {
    display: none !important;
  }
  .print-only {
    display: block !important;
  }
  .table {
    border-collapse: collapse !important;
    width: 100% !important;
  }
  .table th, .table td {
    border: 1px solid #444 !important;
    padding: 6px 8px !important;
    color: #000 !important;
    font-size: 11pt !important;
  }
  .badge {
    border: 1px solid #666 !important;
    color: #000 !important;
    background: transparent !important;
  }
}
.print-only {
  display: none;
}
</style>
<script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="reports">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i class="text-primary" data-lucide="database"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="movement-register" href="/movement-register"><i data-lucide="footprints" style="width:18px"></i>Movement Register</a><a data-nav="stock-register" href="/stock-register"><i data-lucide="boxes" style="width:18px"></i>Stock Register</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">MIS Reports</h1></div></div>
<div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printCurrentReport()" title="Print Report"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
      <h2 class="page-title h3 mb-1">MIS Reports</h2>
      <p class="muted mb-0">Generate, filter, view, print and export live MIS reports directly from database.</p>
    </div>
    <div>
      <button class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#checkedFormModal">
        <i data-lucide="plus" style="width:18px;height:18px;"></i>
        <span>Create / Update Reports</span>
      </button>
    </div>
  </div>

  <!-- Primary and Extended Filters Card -->
  <div class="cardx p-3 mb-3">
    <!-- Existing Primary Filter Row -->
    <div class="row g-2 mb-2">
      <div class="col-md-3">
        <label class="form-label small fw-semibold text-muted mb-1">Report Category</label>
        <select class="form-select" id="reportCategory">
          <option value="monthly-mis">Monthly MIS Summary</option>
          <option value="staff-position">Staff Position Report</option>
          <option value="branch-summary">Branch Summary Report</option>
          <option value="domain-zone">Domain &amp; Zone Head Information</option>
          <option value="movement-register">Movement Register Report</option>
          <option value="stock-register">Stock Inventory &amp; Movement</option>
          <option value="department">Department Management Report</option>
          <option value="audit-log">System Audit &amp; Activity</option>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label small fw-semibold text-muted mb-1">Division / Location</label>
        <select class="form-select" id="filterDivision">
          <option value="">All Divisions</option>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label small fw-semibold text-muted mb-1">From Date</label>
        <input class="form-control" type="date" id="filterDateFrom"/>
      </div>
      <div class="col-md-2">
        <label class="form-label small fw-semibold text-muted mb-1">To Date</label>
        <input class="form-control" type="date" id="filterDateTo"/>
      </div>
      <div class="col-md-2 d-flex align-items-end">
        <button class="btn btn-primary w-100 d-flex align-items-center justify-content-center gap-1" id="btnGenerate" onclick="triggerGenerate()">
          <i data-lucide="play" style="width:16px;height:16px;"></i>
          <span>Generate</span>
        </button>
      </div>
    </div>

    <!-- Secondary / Comprehensive Module Filters -->
    <div class="border-top pt-2 mt-2">
      <div class="row g-2 align-items-end">
        <div class="col-md-3">
          <label class="form-label small fw-semibold text-muted mb-1">Search Keywords</label>
          <div class="input-group">
            <span class="input-group-text bg-white border-end-0"><i data-lucide="search" style="width:14px;height:14px;" class="text-muted"></i></span>
            <input type="text" class="form-control border-start-0" id="reportSearch" placeholder="Search by name, code, keyword..."/>
          </div>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-semibold text-muted mb-1">Department</label>
          <select class="form-select" id="filterDepartment">
            <option value="">All Departments</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-semibold text-muted mb-1">District / Region</label>
          <select class="form-select" id="filterDistrict">
            <option value="">All Districts</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-semibold text-muted mb-1">Branch</label>
          <select class="form-select" id="filterBranch">
            <option value="">All Branches</option>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label small fw-semibold text-muted mb-1">Employee (ID / Name)</label>
          <input type="text" class="form-control" id="filterEmployee" placeholder="e.g. EMP-101 or Karim"/>
        </div>

        <div class="col-md-2">
          <label class="form-label small fw-semibold text-muted mb-1">Domain</label>
          <select class="form-select" id="filterDomain">
            <option value="">All Domains</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-semibold text-muted mb-1">Zone</label>
          <select class="form-select" id="filterZone">
            <option value="">All Zones</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-semibold text-muted mb-1">Status</label>
          <select class="form-select" id="filterStatus">
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
            <option value="Out">Out (Movement)</option>
            <option value="Returned">Returned</option>
            <option value="Late Return">Late Return</option>
            <option value="Review">Review</option>
          </select>
        </div>
        <div class="col-md-3" id="filterModuleSpecificContainer" style="display:none;">
          <label class="form-label small fw-semibold text-muted mb-1" id="filterModuleSpecificLabel">Module Filter</label>
          <select class="form-select" id="filterModuleSpecific">
            <option value="">All</option>
          </select>
        </div>
        <div class="col-md-3 ms-auto d-flex gap-2">
          <button class="btn btn-outline-primary flex-fill" onclick="triggerGenerate()">
            <i data-lucide="filter" style="width:14px;height:14px;" class="me-1 inline"></i>Apply Filter
          </button>
          <button class="btn btn-outline-secondary" onclick="resetReportFilters()" title="Reset Filters">
            <i data-lucide="rotate-ccw" style="width:14px;height:14px;"></i>
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Active Generated Report Viewer Section (Shown upon Generate or View) -->
  <div class="cardx p-3 mb-3 border-primary shadow-sm" id="reportViewerContainer" style="display:none;">
    <!-- Print Official TMSS Header (visible only when printing) -->
    <div class="print-only text-center pb-3 mb-3 border-bottom">
      <h3 class="fw-bold mb-0">TMSS MANAGEMENT INFORMATION SYSTEM</h3>
      <div class="text-muted small">Head Office, Bogura, Bangladesh &bull; MIS Department</div>
      <h4 class="fw-bold text-primary mt-2 mb-1" id="printReportTitle">MIS Report</h4>
      <div class="small"><b>Scope:</b> <span id="printReportScope">All</span> &bull; <b>Period:</b> <span id="printReportPeriod">Current</span> &bull; <b>Date:</b> <span id="printReportDate"></span></div>
    </div>

    <!-- Interactive Top Bar -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 pb-3 mb-3 border-bottom no-print">
      <div>
        <div class="d-flex align-items-center gap-2">
          <h3 class="h5 fw-bold mb-0 text-dark" id="activeReportTitle">MIS Report</h3>
          <span class="badge bg-primary text-white" id="activeReportCountBadge">0 Records</span>
        </div>
        <div class="small text-muted mt-1">
          <span>Scope: <strong id="activeReportScope">All</strong></span> &bull;
          <span>Period: <strong id="activeReportPeriod">Current</strong></span> &bull;
          <span>Generated: <span id="activeReportGeneratedAt">Just now</span></span>
        </div>
      </div>
      <div class="d-flex align-items-center gap-2">
        <div class="d-flex align-items-center gap-1 me-2">
          <label class="small text-muted me-1">Show:</label>
          <select class="form-select form-select-sm" style="width: auto;" onchange="changeReportPageSize(this.value)">
            <option value="10">10</option>
            <option value="25" selected>25</option>
            <option value="50">50</option>
            <option value="100">100</option>
            <option value="all">All</option>
          </select>
        </div>
        <button class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1" onclick="printCurrentReport()">
          <i data-lucide="printer" style="width:14px;height:14px;"></i>
          <span>Print</span>
        </button>
        <button class="btn btn-sm btn-outline-success d-flex align-items-center gap-1" onclick="exportCurrentReport()">
          <i data-lucide="download" style="width:14px;height:14px;"></i>
          <span>Export CSV</span>
        </button>
        <button class="btn btn-sm btn-outline-dark" onclick="document.getElementById('reportViewerContainer').style.display='none'" title="Close Report View">
          <i data-lucide="x" style="width:14px;height:14px;"></i>
        </button>
      </div>
    </div>

    <!-- Summary KPI Cards -->
    <div class="row g-2 mb-3" id="reportSummaryCardsRow"></div>

    <!-- Real Database Report Table -->
    <div class="table-responsive responsive-table">
      <table class="table table-hover table-bordered align-middle mb-0" id="activeReportTable">
        <thead class="table-light" id="activeReportTableHead">
          <tr><th>Loading...</th></tr>
        </thead>
        <tbody id="activeReportTableBody">
          <tr><td colspan="6" class="text-center py-4 text-muted">Click "Generate" or "View" to load live database records.</td></tr>
        </tbody>
        <tfoot class="table-light" id="activeReportTableFoot" style="display:none;"></tfoot>
      </table>
    </div>

    <!-- Pagination and Range Footer -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3 pt-2 border-top no-print">
      <div class="small text-muted" id="reportPaginationInfo">Showing 0 of 0 entries</div>
      <nav id="reportPaginationNav"></nav>
    </div>

    <!-- Print Signatures Footer (Visible only in print layout) -->
    <div class="print-only pt-5 mt-4">
      <div class="row text-center mt-5">
        <div class="col-4">
          <div class="border-top border-dark pt-1 fw-semibold">Prepared By</div>
          <div class="small text-muted">MIS Executive</div>
        </div>
        <div class="col-4">
          <div class="border-top border-dark pt-1 fw-semibold">Verified By</div>
          <div class="small text-muted">MIS Officer</div>
        </div>
        <div class="col-4">
          <div class="border-top border-dark pt-1 fw-semibold">Approved By</div>
          <div class="small text-muted">Head of Department</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Reports Master Catalog Table (Preserves existing layout and columns) -->
  <div class="cardx p-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <div>
        <h4 class="h6 fw-bold mb-0">Configured MIS Reports Catalog</h4>
        <small class="text-muted">Live system reports matching active MySQL/SQLite records</small>
      </div>
      <div>
        <button class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1" onclick="loadReportsCatalog()">
          <i data-lucide="refresh-cw" style="width:14px;height:14px;"></i>
          <span>Refresh</span>
        </button>
      </div>
    </div>
    <div class="table-responsive responsive-table">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th>Report</th>
            <th>Period</th>
            <th>Scope</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="reportsCatalogBody">
          <tr><td>Monthly MIS Summary</td><td>Sep 2026</td><td>All Branches</td><td><span class="badge bg-success">Ready</span></td><td><button class="btn btn-sm btn-outline-primary" onclick="viewReport('monthly-mis')">View</button></td></tr>
          <tr><td>Staff Position Report</td><td>Sep 2026</td><td>All Departments</td><td><span class="badge bg-success">Ready</span></td><td><button class="btn btn-sm btn-outline-primary" onclick="viewReport('staff-position')">View</button></td></tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="movement-register" href="/movement-register"><i data-lucide="footprints" style="width:18px"></i>Movement Register</a><a data-nav="stock-register" href="/stock-register"><i data-lucide="boxes" style="width:18px"></i>Stock Register</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a></div></div>
<div class="toast position-fixed bottom-0 end-0 m-3" id="toast"><div class="toast-body">Saved</div></div>
<script src="{{ asset('assets/js/reports.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Create / Update Reports Modal Form -->
<div aria-hidden="true" class="modal fade" id="checkedFormModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable">
<div class="modal-content border-0 shadow">
<div class="modal-header bg-primary text-white">
<div><h5 class="modal-title">Create / Update Reports</h5><small>Unique professional form</small></div>
<button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button"></button>
</div>
<form id="modalReportForm" onsubmit="saveReportDefinition(event)">
<div class="modal-body"><div class="row g-3">
<div class="col-md-6"><label class="form-label fw-semibold">Report Title <span class="text-danger">*</span></label><input class="form-control" id="modalReportTitle" placeholder="Report Title" required type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Reporting Period</label><input class="form-control" id="modalReportingPeriod" placeholder="" type="month" value="2026-09"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Template</label><select class="form-select" id="modalTemplate"><option value="">Select Template</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Branch / Office</label><select class="form-select" id="modalBranchOffice"><option value="All Branches">All Branches</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Report Type</label><select class="form-select" id="modalReportType"><option value="Monthly">Monthly</option><option value="Daily">Daily</option><option value="Weekly">Weekly</option><option value="Quarterly">Quarterly</option><option value="Annual">Annual</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Submission Status</label><select class="form-select" id="modalSubmissionStatus"><option value="Submitted">Submitted</option><option value="Draft">Draft</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Attachment</label><input class="form-control" type="file"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Remarks</label><textarea class="form-control" id="modalRemarks" placeholder="Remarks" rows="3"></textarea></div>
</div></div>
<div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal" type="button">Cancel</button><button class="btn btn-primary" type="submit">Save</button></div>
</form>
</div>
</div>
</div>
<script>document.addEventListener('shown.bs.modal',()=>{if(window.lucide) lucide.createIcons();});</script>
</body></html>