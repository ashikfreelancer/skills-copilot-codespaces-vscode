<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
  <meta name=\"csrf-token\" content=\"{{ csrf_token() }}\">
  <div class="d-flex align-items-center gap-3">
    <button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav" aria-controls="mobileNav" aria-label="Open navigation">
      <i data-lucide="menu"></i>
    </button>
    <div>
      <div class="small muted">MIS Department</div>
      <h1 class="h5 mb-0 fw-bold">{{ $title ?? "Dashboard" }}</h1>
    </div>
  </div>
  <div class="d-flex align-items-center gap-2">
    <div class="dropdown no-print">
      <button class="btn btn-sm btn-outline-primary dropdown-toggle d-flex align-items-center gap-1" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Switch role to test authorization">
        <span class="badge bg-primary" id="globalRoleBadge">Super Admin</span> <span class="d-none d-md-inline small">Switch Role</span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end shadow border-0 p-2" style="min-width: 260px;">
        <li><h6 class="dropdown-header text-uppercase small fw-bold">Test Role Authorization</h6></li>
        <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Super Admin')"><div class="fw-bold">Super Admin</div><div class="text-muted small">Full system access unconditionally</div></button></li>
        <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Admin')"><div class="fw-bold">Admin</div><div class="text-muted small">Full operations access</div></button></li>
        <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Accountant')"><div class="fw-bold">Accountant</div><div class="text-muted small">Advances, Stock, Reports (403 on Users/Settings)</div></button></li>
        <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Computer Operator')"><div class="fw-bold">Computer Operator</div><div class="text-muted small">Data Entry, Registries (403 on Advances/Users)</div></button></li>
      </ul>
    </div>
    @if(isset($topbarActions))
      {!! $topbarActions !!}
    @else
      <button class="btn btn-light" onclick="printPage()" title="Print"><i data-lucide="printer"></i></button>
      <button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button>
      <div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div>
    @endif
  </div>
</header>
