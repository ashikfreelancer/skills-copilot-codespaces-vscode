<footer class="text-center py-3 text-muted small border-top bg-white mt-auto">
  &copy; {{ date("Y") }} MIS Department — TMSS. All rights reserved.
</footer>