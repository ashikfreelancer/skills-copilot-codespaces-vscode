<nav aria-label="breadcrumb" class="mb-2">
  <ol class="breadcrumb mb-0 small">
    <li class="breadcrumb-item"><a href="/dashboard">MIS Department</a></li>
    @if(isset($parentTitle))
      <li class="breadcrumb-item"><a href="{{ $parentUrl ?? "#" }}">{{ $parentTitle }}</a></li>
    @endif
    <li class="breadcrumb-item active" aria-current="page">{{ $title ?? "Dashboard" }}</li>
  </ol>
</nav>