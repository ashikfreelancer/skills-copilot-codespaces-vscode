<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav" aria-labelledby="mobileNavLabel">
  <div class="offcanvas-header text-white">
    <div class="d-flex align-items-center gap-2">
      <div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div>
      <b class="fs-5" id="mobileNavLabel">MIS Management</b>
    </div>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div class="group-title">MAIN</div>
    <a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a>
    <a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a>
    <a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a>
    <a data-nav="department-management" href="/department-management"><i data-lucide="building-2" style="width:18px"></i>Department Management</a>
    <a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a>
    <a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a>
    <a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a>
    <a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a>
    <a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a>
    <a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a>
    
    <div class="group-title">DOCUMENTS & FINANCE</div>
    <a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a>
    <a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a>
    <a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a>
    
    <div class="group-title">OPERATIONS</div>
    <a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a>
    <a data-nav="movement-register" href="/movement-register"><i data-lucide="arrow-left-right" style="width:18px"></i>Movement Register</a>
    <a data-nav="stock-register" href="/stock-register"><i data-lucide="boxes" style="width:18px"></i>Stock Register</a>
    <a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a>
    <a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a>
    
    <div class="group-title">SYSTEM</div>
    <a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a>
    <a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a>
    <a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a>
    <a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a>
  </div>
</div>