<!doctype html>
<html lang="en">
<head>
<script>
try{if(typeof window!=="undefined"&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,"fetch")||(typeof Window!=="undefined"&&Object.getOwnPropertyDescriptor(Window.prototype,"fetch"));if(!d||d.set===undefined){try{Object.defineProperty(window,"fetch",{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}
</script>
<meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>@yield("title", "MIS Department")</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:["Inter","system-ui","sans-serif"]}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/core-js-bundle@3.37.1/minified.js"></script>
<script src="https://cdn.jsdelivr.net/npm/zone.js@0.14.7/dist/zone.umd.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.3/angular.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="{{ asset("assets/css/app.css") }}">
<script src="{{ asset("assets/js/app.js") }}"></script>
@stack("styles")
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
</head>
<body data-page="@yield("page", "dashboard")">
<div class="container-fluid"><div class="row g-0">
@include("partials.sidebar")
<main class="col-lg-10">
@include("partials.topbar", ["title" => $title ?? "Dashboard"])
<div class="p-3 p-lg-4">
@yield("content")
</div>
</main>
</div></div>
@include("partials.navbar")
@include("components.alerts")
@include("components.ai-assistant")
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@stack("scripts")
</body>
</html>