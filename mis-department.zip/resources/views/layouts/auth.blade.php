<!doctype html>
<html lang="en">
<head>
<script>
try{if(typeof window!=="undefined"&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,"fetch")||(typeof Window!=="undefined"&&Object.getOwnPropertyDescriptor(Window.prototype,"fetch"));if(!d||d.set===undefined){try{Object.defineProperty(window,"fetch",{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}
</script>
<meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield("title", "Sign In | MIS Department")</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:["Inter","system-ui","sans-serif"]}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="{{ asset("assets/css/app.css") }}">
@stack("styles")
</head>
<body>
@yield("content")
<script src="{{ asset("assets/js/app.js") }}"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@stack("scripts")
</body>
</html>