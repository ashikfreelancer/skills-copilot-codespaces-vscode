<!DOCTYPE html>

<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"/>
  <meta name=\"csrf-token\" content=\"{{ csrf_token() }}\"><meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>Note &amp; Document Cabinet | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link href="{{ asset('assets/css/app.css') }}" rel="stylesheet"/>
<style>
/* Note & Document Cabinet: reliable modal scrolling */
#uploadDocumentModal .modal-dialog{
  max-height:calc(100vh - 1rem);
  margin:.5rem auto;
}
#uploadDocumentModal .modal-content{
  max-height:calc(100vh - 1rem);
  display:flex;
  flex-direction:column;
  overflow:hidden;
}
#uploadDocumentModal form{
  min-height:0;
  display:flex;
  flex-direction:column;
  flex:1 1 auto;
}
#uploadDocumentModal .modal-body{
  min-height:0;
  flex:1 1 auto;
  overflow-y:auto !important;
  overflow-x:hidden;
  -webkit-overflow-scrolling:touch;
  overscroll-behavior:contain;
}
#uploadDocumentModal .modal-footer{
  flex:0 0 auto;
  background:#fff;
  border-top:1px solid #e5e7eb;
}
@media(max-width:575.98px){
  #uploadDocumentModal .modal-dialog{
    width:100%;
    max-width:none;
    height:100vh;
    max-height:100vh;
    margin:0;
  }
  #uploadDocumentModal .modal-content{
    height:100vh;
    max-height:100vh;
    border-radius:0 !important;
  }
}
</style><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="note-document-cabinet">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i class="text-primary" data-lucide="database"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Note &amp; Document Cabinet</h1></div></div>
<div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="mb-4"><h2 class="page-title h3">Note &amp; Document Cabinet</h2><p class="muted">Central digital cabinet for MIS notes, circulars, reports, letters and supporting documents.</p></div>
<div class="d-flex justify-content-between mb-3"><div></div><div class="d-flex gap-2">
<button class="btn btn-primary" data-bs-target="#uploadDocumentModal" data-bs-toggle="modal"><i data-lucide="upload"></i> Upload Document</button>
</div></div>
<div class="cardx p-3 mb-3"><div class="row g-2"><div class="col-md-4"><div class="position-relative"><input id="cabinetSearch" class="form-control" placeholder="Search document" autocomplete="off"/><div id="cabinetSuggestions" class="list-group position-absolute w-100 shadow-sm" style="z-index:1050;display:none;max-height:280px;overflow:auto"></div></div></div><div class="col-md-3"><select class="form-select"><option>All Categories</option><option>Note</option><option>Report</option><option>Circular</option><option>Letter</option></select></div><div class="col-md-3"><select class="form-select"><option>All Departments</option><option>MIS</option></select></div></div></div>
<div class="cardx p-3"><div class="table-responsive responsive-table"><table class="table table-hover"><thead><tr><th>Document</th><th>Category</th><th>Date</th><th>Version</th><th>Owner</th><th>Attachment</th><th>Action</th></tr></thead><tbody><tr><td>Monthly MIS Note - Sep 2026</td><td>Note</td><td>12 Sep 2026</td><td>v1.0</td><td>MIS</td><td><span class="badge text-bg-light">0 files</span></td><td><button class="btn btn-sm btn-outline-primary" onclick="openCabinetItem('Monthly MIS Note - Sep 2026')">Open</button></td></tr><tr><td>Branch Data Circular</td><td>Circular</td><td>05 Sep 2026</td><td>v2.0</td><td>MIS</td><td><span class="badge text-bg-light">0 files</span></td><td><button class="btn btn-sm btn-outline-primary" onclick="openCabinetItem('Monthly MIS Note - Sep 2026')">Open</button></td></tr></tbody></table></div></div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a></div></div>
<!-- Create Note Modal -->
<div aria-hidden="true" aria-labelledby="createNoteModalLabel" class="modal fade" id="createNoteModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable">
<div class="modal-content border-0 shadow">
<div class="modal-header bg-primary text-white">
<div>
<h5 class="modal-title" id="createNoteModalLabel">Create MIS Note</h5>
<small>নোটের সকল প্রয়োজনীয় তথ্য পূরণ করুন</small>
</div>
<button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button"></button>
</div>
<form id="createNoteForm" onsubmit="saveNote(event)">
<div class="modal-body">
<div class="row g-3">
<div class="col-md-8">
<label class="form-label fw-semibold">নোটের বিষয় <span class="text-danger">*</span></label>
<input class="form-control" name="note_subject" placeholder="নোটের বিষয় লিখুন" required="" type="text"/>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">স্মারক নং <span class="text-danger">*</span></label>
<input class="form-control" name="memo_no" placeholder="স্মারক নং লিখুন" required="" type="text"/>
</div>
<div class="col-md-6">
<label class="form-label fw-semibold">যে দপ্তর থেকে নোট এসেছে <span class="text-danger">*</span></label>
<input class="form-control" name="received_from_department" placeholder="প্রেরণকারী দপ্তরের নাম" required="" type="text"/>
</div>
<div class="col-md-6">
<label class="form-label fw-semibold">যে দপ্তরে প্রেরণ করা হয়েছে <span class="text-danger">*</span></label>
<input class="form-control" name="sent_to_department" placeholder="প্রাপক দপ্তরের নাম" required="" type="text"/>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">নোটের তারিখ <span class="text-danger">*</span></label>
<input class="form-control" name="note_date" required="" type="date"/>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">প্রাপ্তির তারিখ</label>
<input class="form-control" name="received_date" type="date"/>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">প্রেরণের তারিখ</label>
<input class="form-control" name="sent_date" type="date"/>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">নোটের ধরন</label>
<select class="form-select" name="note_type">
<option value="Note">Note</option>
<option value="Office Order">Office Order</option>
<option value="Memo">Memo</option>
<option value="Letter">Letter</option>
<option value="Circular">Circular</option>
</select>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">Priority</label>
<select class="form-select" name="priority">
<option>Normal</option><option>High</option><option>Urgent</option>
</select>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">Status</label>
<select class="form-select" name="status">
<option>Draft</option><option>Pending</option><option>Forwarded</option><option>Approved</option><option>Completed</option>
</select>
</div>
<div class="col-12">
<label class="form-label fw-semibold">নোটের বিবরণ / Remarks</label>
<textarea class="form-control" name="remarks" placeholder="প্রয়োজনীয় বিবরণ লিখুন" rows="4"></textarea>
</div>
<div class="col-12">
<div class="border rounded-4 p-3 bg-light">
<label class="form-label fw-semibold">নোট আপলোড / Attachment</label>
<input accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" class="form-control" id="note_file" multiple="" name="note_file" type="file"/>
<div class="form-text">একাধিক PDF, Word, Excel অথবা Image ফাইল আপলোড করা যাবে। সর্বোচ্চ 10 MB প্রতি ফাইল।</div>
<div class="mt-2" id="noteFilePreview"></div>
</div>
</div>
</div>
</div>
<div class="modal-footer">
<button class="btn btn-light" data-bs-dismiss="modal" type="button">Cancel</button>
<button class="btn btn-primary" type="submit"><i data-lucide="save"></i> Save Note</button>
</div>
</form>
</div>
</div>
</div>
<!-- Upload Document Modal -->
<div aria-hidden="true" aria-labelledby="uploadDocumentModalLabel" class="modal fade" id="uploadDocumentModal" tabindex="-1">
<div class="modal-dialog modal-lg modal-dialog-scrollable">
<div class="modal-content border-0 shadow">
<div class="modal-header bg-primary text-white">
<div>
<h5 class="modal-title" id="uploadDocumentModalLabel">Upload Document</h5>
<small>Document Cabinet-এ নতুন ফাইল যুক্ত করুন</small>
</div>
<button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button"></button>
</div>
<form id="uploadDocumentForm" onsubmit="saveDocument(event)">
<div class="modal-body">
<div class="row g-3">
<div class="col-md-8">
<label class="form-label fw-semibold">Document Title <span class="text-danger">*</span></label>
<input class="form-control" name="document_title" placeholder="Document-এর নাম লিখুন" required="" type="text"/>
</div>
<div class="col-md-4">
<label class="form-label fw-semibold">Category <span class="text-danger">*</span></label>
<select class="form-select" name="category" required="">
<option value="">Select Category</option>
<option>Note</option><option>Report</option><option>Circular</option><option>Notice</option>
<option>Office Order</option><option>Memo</option><option>Meeting Minutes</option>
<option>Guideline</option><option>Policy</option><option>Analysis</option><option>Other</option>
</select>
</div>
<div class="col-md-6">
<label class="form-label fw-semibold">Reference / স্মারক নং</label>
<input class="form-control" name="reference_no" placeholder="Reference number" type="text"/>
</div>
<div class="col-md-6">
<label class="form-label fw-semibold">Document Date</label>
<input class="form-control" name="document_date" type="date"/>
</div>
<div class="col-md-6">
<label class="form-label fw-semibold">Related Department</label>
<input class="form-control" name="department" placeholder="দপ্তরের নাম" type="text"/>
</div>
<div class="col-md-6">
<label class="form-label fw-semibold">Version</label>
<input class="form-control" name="version" type="text" value="v1.0"/>
</div>
<div class="col-12">
<label class="form-label fw-semibold">Upload Document <span class="text-danger">*</span></label>
<input accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.zip" class="form-control" id="document_file" multiple="" name="document_file" required="" type="file"/>
<div class="form-text">একাধিক ফাইল নির্বাচন করা যাবে। সর্বোচ্চ 10 MB প্রতি ফাইল।</div>
<div class="mt-2" id="documentFilePreview"></div>
</div>
<div class="col-12">
<label class="form-label fw-semibold">Description / Remarks</label>
<textarea class="form-control" name="description" placeholder="সংক্ষিপ্ত বিবরণ" rows="3"></textarea>
</div>
</div>
</div>
<div class="modal-footer">
<button class="btn btn-light" data-bs-dismiss="modal" type="button">Cancel</button>
<button class="btn btn-primary" type="submit"><i data-lucide="upload-cloud"></i> Upload &amp; Save</button>
</div>
</form>
</div>
</div>
</div>
<script>
const NOTE_KEY='mis_note_cabinet_v2';
function readCabinetFile(file){return new Promise((resolve,reject)=>{if(file.size>10*1024*1024)return reject(new Error(file.name+' is larger than 10 MB.'));const r=new FileReader();r.onload=()=>resolve({id:'DOC-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),name:file.name,type:file.type,size:file.size,dataUrl:r.result,uploadedAt:new Date().toISOString()});r.onerror=()=>reject(new Error('Could not read '+file.name));r.readAsDataURL(file);});}
function getNotes(){return JSON.parse(localStorage.getItem(NOTE_KEY)||'[]');}
function saveNotes(a){localStorage.setItem(NOTE_KEY,JSON.stringify(a));}
function renderFilePreview(inputId,boxId){const fs=[...(document.getElementById(inputId)?.files||[])];document.getElementById(boxId).innerHTML=fs.length?fs.map(f=>`<div class="small border rounded p-2 mb-1"><i data-lucide="paperclip"></i> ${escCab(f.name)} <span class="muted">(${(f.size/1024/1024).toFixed(2)} MB)</span></div>`).join(''):'<div class="small muted">No file selected.</div>';lucide.createIcons();}
function escCab(s){return String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));}
function fileActions(item){return (item.attachments||[]).map(f=>`<div class="d-flex align-items-center justify-content-between border rounded p-2 mb-2"><div class="text-truncate"><b>${escCab(f.name)}</b><div class="small muted">${(f.size/1024/1024).toFixed(2)} MB · ${new Date(f.uploadedAt).toLocaleString()}</div></div><div class="btn-group btn-group-sm"><button class="btn btn-outline-primary" onclick="previewCabinetFile('${escCab(item.id)}','${escCab(f.id)}')"><i data-lucide="eye"></i></button><button class="btn btn-outline-secondary" onclick="downloadCabinetFile('${escCab(item.id)}','${escCab(f.id)}')"><i data-lucide="download"></i></button><button class="btn btn-outline-danger" onclick="deleteCabinetFile('${escCab(item.id)}','${escCab(f.id)}')"><i data-lucide="trash-2"></i></button></div></div>`).join('')||'<div class="small muted">No attachments.</div>';}
async function saveNote(e){e.preventDefault();if(!MIS_hasPermission('note-document-cabinet','create')){toast('Permission denied');return;}const fd=new FormData(e.target);const files=[...(document.getElementById('note_file')?.files||[])];try{const attachments=await Promise.all(files.map(readCabinetFile));const item={id:'NOTE-'+Date.now(),title:fd.get('note_subject'),memo:fd.get('memo_no'),category:fd.get('note_type'),date:fd.get('note_date'),remarks:fd.get('remarks'),attachments,history:attachments.map(f=>({action:'Uploaded',name:f.name,at:f.uploadedAt,by:'Super Admin'}))};const arr=getNotes();arr.unshift(item);saveNotes(arr);MIS_addAudit('Note','Created',item.id);toast('Note and attachment(s) saved successfully');bootstrap.Modal.getInstance(document.getElementById('createNoteModal')).hide();e.target.reset();document.getElementById('noteFilePreview').innerHTML='';}catch(err){toast(err.message);}}
async function saveDocument(e){e.preventDefault();if(!MIS_hasPermission('note-document-cabinet','create')){toast('Permission denied');return;}const fd=new FormData(e.target);const files=[...(document.getElementById('document_file')?.files||[])];try{if(!files.length)throw new Error('Please select at least one document.');const attachments=await Promise.all(files.map(readCabinetFile));const item={id:'DOC-'+Date.now(),title:fd.get('document_title'),category:fd.get('category'),date:fd.get('document_date'),department:fd.get('department'),version:fd.get('version'),description:fd.get('description'),attachments,history:attachments.map(f=>({action:'Uploaded',name:f.name,at:f.uploadedAt,by:'Super Admin'}))};const arr=getNotes();arr.unshift(item);saveNotes(arr);MIS_addAudit('Document','Created',item.id);toast('Document(s) uploaded successfully');bootstrap.Modal.getInstance(document.getElementById('uploadDocumentModal')).hide();e.target.reset();document.getElementById('documentFilePreview').innerHTML='';}catch(err){toast(err.message);}}
function findCabinet(id){return getNotes().find(x=>x.id===id);}
function previewCabinetFile(id,fid){const item=findCabinet(id),f=item?.attachments?.find(x=>x.id===fid);if(!f)return;const w=window.open('','_blank');if(!w){toast('Please allow pop-ups for preview');return;}if(f.type?.startsWith('image/'))w.document.write(`<img src="${f.dataUrl}" style="max-width:100%;height:auto">`);else if(f.type==='application/pdf')w.document.write(`<iframe src="${f.dataUrl}" style="width:100%;height:100vh;border:0"></iframe>`);else{w.close();downloadCabinetFile(id,fid);toast('Preview is unavailable for this file type; downloaded instead.');}}
function downloadCabinetFile(id,fid){const item=findCabinet(id),f=item?.attachments?.find(x=>x.id===fid);if(!f)return;const a=document.createElement('a');a.href=f.dataUrl;a.download=f.name;a.click();}
function deleteCabinetFile(id,fid){if(!MIS_hasPermission('note-document-cabinet','delete')){toast('Permission denied');return;}const arr=getNotes(),item=arr.find(x=>x.id===id);if(!item)return;const f=(item.attachments||[]).find(x=>x.id===fid);if(!f)return;if(!confirm('Delete '+f.name+'?'))return;item.attachments=item.attachments.filter(x=>x.id!==fid);item.history=item.history||[];item.history.push({action:'Deleted',name:f.name,at:new Date().toISOString(),by:'Super Admin'});saveNotes(arr);MIS_addAudit('Document','Deleted',id+' / '+f.name);toast('Attachment deleted');}
function openCabinetItem(idOrTitle){const item=getNotes().find(x=>x.id===idOrTitle||x.title===idOrTitle);if(!item){toast('No saved attachment found for this item.');return;}const body=`<div class="modal fade" id="cabinetViewModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escCab(item.title||'Document')}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><h6>Attachments</h6>${fileActions(item)}<hr><h6>Document History</h6>${(item.history||[]).slice().reverse().map(h=>`<div class="border rounded p-2 mb-2"><b>${escCab(h.action)}</b> — ${escCab(h.name)}<div class="small muted">${new Date(h.at).toLocaleString()} · ${escCab(h.by||'Super Admin')}</div></div>`).join('')||'<div class="small muted">No history.</div>'}</div></div></div></div>`;document.body.insertAdjacentHTML('beforeend',body);const m=document.getElementById('cabinetViewModal');m.addEventListener('hidden.bs.modal',()=>m.remove(),{once:true});bootstrap.Modal.getOrCreateInstance(m).show();lucide.createIcons();}
document.getElementById('note_file').addEventListener('change',()=>renderFilePreview('note_file','noteFilePreview'));
document.getElementById('document_file').addEventListener('change',()=>renderFilePreview('document_file','documentFilePreview'));
document.addEventListener('shown.bs.modal',function(){if(window.lucide)lucide.createIcons();});
</script>
<div class="toast position-fixed bottom-0 end-0 m-3" id="toast"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
(function(){
 const search=document.getElementById('cabinetSearch'), box=document.getElementById('cabinetSuggestions');
 if(!search||!box)return;
 function items(){return getNotes()}
 function show(){
  const q=search.value.trim().toLowerCase(); if(!q){box.style.display='none';return}
  const out=items().filter(x=>JSON.stringify(x).toLowerCase().includes(q)).slice(0,12);
  box.innerHTML=out.length?out.map(x=>`<button type="button" class="list-group-item list-group-item-action text-start" data-id="${escCab(x.id)}"><b>${escCab(x.title||x.name||x.id)}</b><div class="small text-secondary">${escCab(x.category||'Document')} · ${escCab(x.date||'')}</div></button>`).join(''):'<div class="list-group-item small text-secondary">No matching document</div>';
  box.style.display='block';
  box.querySelectorAll('[data-id]').forEach(b=>b.onclick=()=>{search.value=b.dataset.id;box.style.display='none';openCabinetItem(b.dataset.id)});
 }
 search.addEventListener('input',show);search.addEventListener('focus',show);document.addEventListener('click',e=>{if(!e.target.closest('#cabinetSearch')&&!e.target.closest('#cabinetSuggestions'))box.style.display='none'});
})();
</script>
</body></html>