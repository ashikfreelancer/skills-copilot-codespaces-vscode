<div class="table-responsive {{ $class ?? "" }}">
  <table class="table {{ $tableClass ?? "table-hover" }}" id="{{ $id ?? "" }}">
    {{ $slot }}
  </table>
</div>