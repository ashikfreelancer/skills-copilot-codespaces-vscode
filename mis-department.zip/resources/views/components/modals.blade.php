<div class="modal fade" id="{{ $id ?? "generalModal" }}" tabindex="-1" aria-labelledby="{{ $id ?? "generalModal" }}Label" aria-hidden="true">
  <div class="modal-dialog {{ $size ?? "modal-lg" }} {{ ($scrollable ?? false) ? "modal-dialog-scrollable" : "" }}">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="{{ $id ?? "generalModal" }}Label">{{ $title ?? "Modal Title" }}</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        {{ $slot ?? "" }}
      </div>
      @if(isset($footer))
        <div class="modal-footer">
          {{ $footer }}
        </div>
      @endif
    </div>
  </div>
</div>