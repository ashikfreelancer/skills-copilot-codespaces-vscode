<div class="filterbar p-3 mb-3 {{ $class ?? "" }}">
  {{ $slot }}
</div>