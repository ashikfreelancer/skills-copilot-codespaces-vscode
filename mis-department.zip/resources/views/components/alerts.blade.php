@if(!empty($success) || session('success'))
<div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2 mb-3 shadow-xs" role="alert">
    <i data-lucide="check-circle" class="text-success" style="width: 20px; height: 20px;"></i>
    <div class="flex-grow-1">{{ $success ?? session('success') }}</div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(!empty($error) || session('error'))
<div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2 mb-3 shadow-xs" role="alert">
    <i data-lucide="alert-circle" class="text-danger" style="width: 20px; height: 20px;"></i>
    <div class="flex-grow-1">{{ $error ?? session('error') }}</div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(!empty($warning) || session('warning'))
<div class="alert alert-warning alert-dismissible fade show d-flex align-items-center gap-2 mb-3 shadow-xs" role="alert">
    <i data-lucide="alert-triangle" class="text-warning" style="width: 20px; height: 20px;"></i>
    <div class="flex-grow-1">{{ $warning ?? session('warning') }}</div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(!empty($info) || session('info'))
<div class="alert alert-info alert-dismissible fade show d-flex align-items-center gap-2 mb-3 shadow-xs" role="alert">
    <i data-lucide="info" class="text-info" style="width: 20px; height: 20px;"></i>
    <div class="flex-grow-1">{{ $info ?? session('info') }}</div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1090;">
    <div id="misLiveToast" class="toast align-items-center text-white bg-dark border-0 shadow-lg" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body d-flex align-items-center gap-2" id="misToastBody">
                <i data-lucide="info" style="width: 18px; height: 18px;"></i>
                <span id="misToastMessage">Notification</span>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>
