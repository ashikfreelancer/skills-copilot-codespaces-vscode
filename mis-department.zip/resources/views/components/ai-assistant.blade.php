{{-- MIS Smart AI Assistant & Codebase File Finder Component --}}
<div id="misAiAssistantWidget" class="no-print">
  <!-- Floating Launcher Button -->
  <button id="misAiToggleBtn" 
          type="button"
          class="btn position-fixed shadow-lg d-flex align-items-center gap-2 px-3 py-2 rounded-pill text-white"
          style="bottom: 24px; right: 24px; z-index: 1080; background: linear-gradient(135deg, #1e40af 0%, #4338ca 50%, #6d28d9 100%); border: 1px solid rgba(255,255,255,0.25);"
          title="MIS AI Assistant (Ctrl+K)"
          onclick="toggleMisAiDrawer()">
    <span class="position-relative d-inline-flex">
      <i data-lucide="sparkles" style="width: 20px; height: 20px;" class="animate-pulse"></i>
      <span class="position-absolute top-0 start-100 translate-middle p-1 bg-emerald-400 border border-white rounded-circle">
        <span class="visually-hidden">Online</span>
      </span>
    </span>
    <span class="fw-semibold d-none d-sm-inline" style="font-size: 13.5px; letter-spacing: 0.2px;">AI Assistant</span>
    <span class="badge bg-white/20 text-white rounded-pill px-1.5 py-0.5 ms-1 small" style="font-size: 11px;">Ctrl+K</span>
  </button>

  <!-- AI Assistant Panel / Offcanvas Modal -->
  <div id="misAiDrawer" 
       class="position-fixed shadow-2xl bg-white d-none flex-column border-start"
       style="bottom: 0; right: 0; width: 440px; max-width: 100vw; height: 600px; max-height: 92vh; z-index: 1090; border-top-left-radius: 16px; border-bottom-left-radius: 0; overflow: hidden; transition: all 0.25s ease;">
    
    <!-- Drawer Header -->
    <div class="px-3 py-2.5 text-white d-flex align-items-center justify-content-between"
         style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);">
      <div class="d-flex align-items-center gap-2">
        <div class="p-1.5 rounded-lg bg-indigo-500/30 border border-indigo-400/40 text-indigo-300">
          <i data-lucide="bot" style="width: 20px; height: 20px;"></i>
        </div>
        <div>
          <div class="fw-bold d-flex align-items-center gap-2" style="font-size: 14.5px;">
            <span>MIS AI Assistant</span>
            <span class="badge bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 rounded-pill" style="font-size: 10px;">
              ● Online
            </span>
          </div>
          <div class="text-slate-400" style="font-size: 11px;">Gemini 3.8 Flash &bull; ১৬৩+ ফাইল ইনডেক্সড</div>
        </div>
      </div>
      <div class="d-flex align-items-center gap-1">
        <button type="button" class="btn btn-sm btn-link text-slate-400 hover:text-white p-1" onclick="clearAiChat()" title="Clear Chat">
          <i data-lucide="rotate-ccw" style="width: 16px; height: 16px;"></i>
        </button>
        <button type="button" class="btn btn-sm btn-link text-slate-400 hover:text-white p-1" onclick="toggleMisAiDrawer()" title="Close">
          <i data-lucide="x" style="width: 20px; height: 20px;"></i>
        </button>
      </div>
    </div>

    <!-- Navigation Tabs: Chat vs Quick Finder -->
    <div class="d-flex border-bottom bg-slate-50 px-2 pt-1" style="font-size: 13px;">
      <button id="aiTabChat" class="btn btn-sm py-1.5 px-3 border-bottom border-primary border-2 text-primary fw-semibold rounded-0" onclick="switchAiTab('chat')">
        <i data-lucide="message-square" style="width: 14px; height: 14px;" class="me-1 d-inline"></i> স্মার্ট চ্যাট
      </button>
      <button id="aiTabSearch" class="btn btn-sm py-1.5 px-3 text-secondary rounded-0" onclick="switchAiTab('search')">
        <i data-lucide="search" style="width: 14px; height: 14px;" class="me-1 d-inline"></i> কুইক ফাইল ফাইন্ডার
      </button>
    </div>

    <!-- TAB 1: Chat View -->
    <div id="aiChatSection" class="flex-grow-1 d-flex flex-column" style="min-height: 0;">
      <!-- Chat Messages Container -->
      <div id="aiChatMessages" class="flex-grow-1 p-3 overflow-y-auto" style="background: #f8fafc; font-size: 13.5px; line-height: 1.55;">
        <!-- Welcome Message -->
        <div class="d-flex gap-2 mb-3">
          <div class="flex-shrink-0">
            <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
              <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
            </div>
          </div>
          <div class="flex-grow-1">
            <div class="bg-white border rounded-3 p-3 shadow-xs text-slate-800">
              <div class="fw-semibold text-indigo-700 mb-1">স্বাগতম! আমি আপনার MIS স্মার্ট এআই সহকারী।</div>
              <p class="mb-2 text-slate-600">
                এই প্রজেক্টের যেকোনো ফাইল (ব্লেড ভিউ, কন্ট্রোলার, সার্ভিস, ক্যালকুলেশন বা মাইগ্রেশন) কোথায় আছে এবং কীভাবে কাজ করে জানতে আমাকে যেকোনো প্রশ্ন করতে পারেন।
              </p>
              <div class="text-muted small mb-2 fw-semibold">কুইক প্রম্পট সাজেশন:</div>
              <div class="d-flex flex-wrap gap-1.5">
                <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('ছুটি ও লিভ ব্যালেন্স হিসাবের ফাইলগুলো কোথায়?')">
                  🌴 ছুটি ও লিভ হিসাব
                </button>
                <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('স্টক রেজিস্টার ও ইনভেন্টরি ভ্যালুয়েশনের ফাইল কোনটি?')">
                  📦 স্টক ও ভ্যালুয়েশন
                </button>
                <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('অগ্রিম লোন ও কিস্তির ফাইল কোথায় আছে?')">
                  💰 অগ্রিম লোন ও কিস্তি
                </button>
                <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('ডিপার্টমেন্ট ও ব্রাঞ্চের ব্লেড ভিউ ফাইলগুলো দেখাও')">
                  🏢 ডিপার্টমেন্ট ও ব্রাঞ্চ
                </button>
                <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('ইউজার পারমিশন এবং সিকিউরিটি মিডলওয়্যার ফাইল কোনটি?')">
                  🛡️ পারমিশন ও রোল
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Chat Input Form -->
      <div class="p-2 border-top bg-white">
        <form id="aiChatForm" onsubmit="handleAiChatSubmit(event)" class="d-flex gap-2 align-items-center">
          <input type="text" 
                 id="aiChatInput" 
                 class="form-control form-control-sm rounded-pill px-3 py-2" 
                 placeholder="ফাইল বা ফিচারের নাম লিখুন... (যেমন: leave service)" 
                 autocomplete="off"
                 required />
          <button type="submit" 
                  id="aiChatSubmitBtn"
                  class="btn btn-primary btn-sm rounded-circle d-flex align-items-center justify-content-center p-2" 
                  style="width: 36px; height: 36px; flex-shrink: 0;"
                  title="Send">
            <i data-lucide="send" style="width: 16px; height: 16px;"></i>
          </button>
        </form>
      </div>
    </div>

    <!-- TAB 2: Instant File Search View -->
    <div id="aiSearchSection" class="flex-grow-1 d-none flex-column" style="min-height: 0;">
      <div class="p-2 border-bottom bg-white">
        <div class="input-group input-group-sm">
          <span class="input-group-text bg-light border-end-0"><i data-lucide="search" style="width: 14px; height: 14px;"></i></span>
          <input type="text" 
                 id="aiQuickSearchInput" 
                 class="form-control border-start-0" 
                 placeholder="সার্চ করুন (blade, controller, service, migration)..." 
                 oninput="handleQuickFileSearch(this.value)" />
        </div>
      </div>
      <div id="aiSearchResults" class="flex-grow-1 p-2 overflow-y-auto" style="font-size: 12.5px;">
        <div class="text-center text-muted p-4">
          <i data-lucide="folder-search" style="width: 36px; height: 36px;" class="mx-auto mb-2 text-slate-300"></i>
          <div>যেকোনো ফাইলের নাম বা কিওয়ার্ড টাইপ করুন</div>
        </div>
      </div>
    </div>

  </div>
</div>

<script>
// --- MIS Smart AI Assistant Client Script ---
let _aiChatHistory = [];
let _aiIsThinking = false;

function toggleMisAiDrawer() {
  const drawer = document.getElementById('misAiDrawer');
  if (!drawer) return;
  const isHidden = drawer.classList.contains('d-none');
  if (isHidden) {
    drawer.classList.remove('d-none');
    drawer.classList.add('d-flex');
    if (typeof lucide !== 'undefined') lucide.createIcons();
    setTimeout(() => {
      const activeInput = document.getElementById('aiChatSection').classList.contains('d-none')
        ? document.getElementById('aiQuickSearchInput')
        : document.getElementById('aiChatInput');
      activeInput?.focus();
    }, 100);
  } else {
    drawer.classList.add('d-none');
    drawer.classList.remove('d-flex');
  }
}

// Global keyboard shortcut: Ctrl+K / Cmd+K
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    toggleMisAiDrawer();
  }
});

function switchAiTab(tab) {
  const chatSec = document.getElementById('aiChatSection');
  const searchSec = document.getElementById('aiSearchSection');
  const chatTab = document.getElementById('aiTabChat');
  const searchTab = document.getElementById('aiTabSearch');

  if (tab === 'chat') {
    chatSec.classList.remove('d-none');
    chatSec.classList.add('d-flex');
    searchSec.classList.add('d-none');
    searchSec.classList.remove('d-flex');

    chatTab.classList.add('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    chatTab.classList.remove('text-secondary');
    searchTab.classList.remove('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    searchTab.classList.add('text-secondary');
    document.getElementById('aiChatInput')?.focus();
  } else {
    chatSec.classList.add('d-none');
    chatSec.classList.remove('d-flex');
    searchSec.classList.remove('d-none');
    searchSec.classList.add('d-flex');

    searchTab.classList.add('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    searchTab.classList.remove('text-secondary');
    chatTab.classList.remove('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    chatTab.classList.add('text-secondary');

    const sInp = document.getElementById('aiQuickSearchInput');
    sInp?.focus();
    if (sInp && !sInp.value) {
      handleQuickFileSearch('');
    }
  }
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function quickAiPrompt(text) {
  const inp = document.getElementById('aiChatInput');
  if (inp) {
    inp.value = text;
    document.getElementById('aiChatForm')?.dispatchEvent(new Event('submit', { cancelable: true }));
  }
}

function clearAiChat() {
  _aiChatHistory = [];
  const container = document.getElementById('aiChatMessages');
  if (container) {
    container.innerHTML = `
      <div class="d-flex gap-2 mb-3">
        <div class="flex-shrink-0">
          <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
            <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="flex-grow-1">
          <div class="bg-white border rounded-3 p-3 shadow-xs text-slate-800">
            <div class="fw-semibold text-indigo-700 mb-1">চ্যাট হিস্ট্রি রিসেট করা হয়েছে।</div>
            <p class="mb-0 text-slate-600">আপনি কোন ফাইল বা ফিচার খুঁজতে চান বলুন!</p>
          </div>
        </div>
      </div>
    `;
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }
}

async function handleAiChatSubmit(e) {
  e.preventDefault();
  if (_aiIsThinking) return;

  const inp = document.getElementById('aiChatInput');
  const msg = inp.value.trim();
  if (!msg) return;

  inp.value = '';
  appendUserMessage(msg);

  _aiIsThinking = true;
  const thinkId = appendThinkingIndicator();

  try {
    const res = await fetch('/api/ai/assistant', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, history: _aiChatHistory })
    });
    const data = await res.json();
    removeThinkingIndicator(thinkId);

    const reply = data.reply || 'কোনো উত্তর পাওয়া যায়নি।';
    _aiChatHistory.push({ role: 'user', content: msg });
    _aiChatHistory.push({ role: 'model', content: reply });

    appendAssistantMessage(reply, data.matchedFiles || []);
  } catch (err) {
    removeThinkingIndicator(thinkId);
    appendAssistantMessage('দুঃখিত, এআই সহকারীর সাথে সংযোগে সমস্যা হয়েছে: ' + err.message, []);
  } finally {
    _aiIsThinking = false;
  }
}

function appendUserMessage(text) {
  const container = document.getElementById('aiChatMessages');
  const wrap = document.createElement('div');
  wrap.className = 'd-flex justify-content-end mb-3';
  wrap.innerHTML = `
    <div class="bg-indigo-600 text-white rounded-3 px-3 py-2 shadow-xs" style="max-width: 85%; font-size: 13.5px;">
      ${escapeAiHtml(text)}
    </div>
  `;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
}

function appendThinkingIndicator() {
  const container = document.getElementById('aiChatMessages');
  const id = 'aiThink_' + Date.now();
  const wrap = document.createElement('div');
  wrap.id = id;
  wrap.className = 'd-flex gap-2 mb-3';
  wrap.innerHTML = `
    <div class="flex-shrink-0">
      <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
        <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
      </div>
    </div>
    <div class="flex-grow-1">
      <div class="bg-white border rounded-3 px-3 py-2.5 shadow-xs text-slate-500 d-inline-flex align-items-center gap-2">
        <span class="spinner-border spinner-border-sm text-indigo-600" role="status"></span>
        <span style="font-size: 12.5px;">ফাইল ও কোডবেজ অনুসন্ধান করা হচ্ছে...</span>
      </div>
    </div>
  `;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  if (typeof lucide !== 'undefined') lucide.createIcons();
  return id;
}

function removeThinkingIndicator(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function appendAssistantMessage(markdownText, matchedFiles) {
  const container = document.getElementById('aiChatMessages');
  const wrap = document.createElement('div');
  wrap.className = 'd-flex gap-2 mb-3';

  // Format basic Markdown into HTML
  let formatted = formatAiMarkdown(markdownText);

  // If candidate files exist, add quick action cards
  let filesHtml = '';
  if (matchedFiles && matchedFiles.length > 0) {
    filesHtml += `<div class="mt-2.5 pt-2 border-top">
      <div class="fw-semibold text-slate-700 small mb-1.5"><i data-lucide="files" style="width:13px; height:13px;" class="d-inline me-1 text-primary"></i>সংশ্লিষ্ট ফাইলসমূহ (${matchedFiles.length}টি):</div>
      <div class="d-flex flex-column gap-1.5">`;

    matchedFiles.slice(0, 5).forEach(f => {
      const isRoute = f.path.startsWith('resources/views/') && f.name === 'index.blade.php';
      const routeName = isRoute ? '/' + f.path.split('/')[2] : null;

      filesHtml += `
        <div class="p-2 rounded bg-slate-50 border d-flex align-items-center justify-content-between gap-2" style="font-size: 11.5px;">
          <div class="overflow-hidden">
            <div class="fw-semibold text-slate-800 text-truncate" title="${f.path}">
              <i data-lucide="file-code" style="width:12px;height:12px;" class="d-inline text-indigo-600 me-1"></i>${f.path}
            </div>
            <div class="text-muted text-truncate" style="font-size: 10.5px;">${f.description}</div>
          </div>
          <div class="d-flex align-items-center gap-1 flex-shrink-0">
            <button type="button" class="btn btn-xs btn-outline-secondary py-0.5 px-1.5" onclick="copyFilePath('${f.path}')" title="Copy file path">
              <i data-lucide="copy" style="width:11px;height:11px;"></i>
            </button>
            ${routeName ? `<a href="${routeName}" class="btn btn-xs btn-primary py-0.5 px-1.5 text-white text-decoration-none" title="Open Page">ওপেন</a>` : ''}
          </div>
        </div>
      `;
    });
    filesHtml += `</div></div>`;
  }

  wrap.innerHTML = `
    <div class="flex-shrink-0">
      <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
        <i data-lucide="bot" style="width: 16px; height: 16px;"></i>
      </div>
    </div>
    <div class="flex-grow-1" style="max-width: 88%;">
      <div class="bg-white border rounded-3 p-3 shadow-xs text-slate-800">
        ${formatted}
        ${filesHtml}
      </div>
    </div>
  `;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function formatAiMarkdown(txt) {
  if (!txt) return '';
  let h = escapeAiHtml(txt);
  // Bold **text**
  h = h.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // Inline code `code`
  h = h.replace(/`([^`]+)`/g, '<code class="bg-slate-100 text-indigo-700 px-1 py-0.5 rounded" style="font-size:12px;">$1</code>');
  // Bullets
  h = h.replace(/^\s*•\s+(.+)$/gm, '<li class="ms-3">$1</li>');
  h = h.replace(/^\s*\*\s+(.+)$/gm, '<li class="ms-3">$1</li>');
  // Linebreaks
  h = h.replace(/\n\n/g, '<p class="mb-2"></p>').replace(/\n/g, '<br>');
  return h;
}

function escapeAiHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function copyFilePath(path) {
  navigator.clipboard.writeText(path).then(() => {
    if (typeof Swal !== 'undefined') {
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'পাথ কপি হয়েছে: ' + path,
        showConfirmButton: false,
        timer: 2000
      });
    } else {
      alert('Copied: ' + path);
    }
  });
}

// Debounced quick search
let _searchTimeout = null;
function handleQuickFileSearch(val) {
  clearTimeout(_searchTimeout);
  _searchTimeout = setTimeout(async () => {
    const resBox = document.getElementById('aiSearchResults');
    if (!resBox) return;

    resBox.innerHTML = `
      <div class="p-3 text-center text-muted">
        <span class="spinner-border spinner-border-sm me-2"></span>ফাইলের তথ্য লোড হচ্ছে...
      </div>
    `;

    try {
      const res = await fetch('/api/ai/quick-search?q=' + encodeURIComponent(val));
      const data = await res.json();
      const files = data.results || [];

      if (files.length === 0) {
        resBox.innerHTML = `
          <div class="p-4 text-center text-muted">
            <i data-lucide="alert-circle" style="width:28px;height:28px;" class="mx-auto mb-1 text-slate-300"></i>
            <div>"${escapeAiHtml(val)}" দিয়ে কোনো ফাইল পাওয়া যায়নি।</div>
          </div>
        `;
      } else {
        let html = `<div class="text-muted small px-1 mb-2">মোট <strong>${files.length}টি</strong> ম্যাচিং ফাইল পাওয়া গেছে:</div><div class="d-flex flex-column gap-1.5">`;
        files.forEach(f => {
          const isRoute = f.path.startsWith('resources/views/') && f.name === 'index.blade.php';
          const routeName = isRoute ? '/' + f.path.split('/')[2] : null;

          html += `
            <div class="card border p-2 bg-white shadow-xs">
              <div class="d-flex align-items-start justify-content-between gap-2">
                <div>
                  <div class="fw-semibold text-slate-800" style="font-size:12.5px;">
                    <i data-lucide="file" style="width:13px;height:13px;" class="d-inline text-indigo-600 me-1"></i>${escapeAiHtml(f.name)}
                  </div>
                  <div class="text-primary font-monospace mt-0.5" style="font-size:11px;">${escapeAiHtml(f.path)}</div>
                  <div class="text-muted mt-1" style="font-size:11px;">${escapeAiHtml(f.description)}</div>
                </div>
                <div class="d-flex gap-1 flex-shrink-0">
                  <button type="button" class="btn btn-xs btn-outline-secondary py-1 px-1.5" onclick="copyFilePath('${f.path}')" title="Copy Path">
                    <i data-lucide="copy" style="width:12px;height:12px;"></i>
                  </button>
                  ${routeName ? `<a href="${routeName}" class="btn btn-xs btn-primary py-1 px-2 text-white text-decoration-none">ওপেন</a>` : ''}
                </div>
              </div>
            </div>
          `;
        });
        html += `</div>`;
        resBox.innerHTML = html;
      }
      if (typeof lucide !== 'undefined') lucide.createIcons();
    } catch (e) {
      resBox.innerHTML = `<div class="p-3 text-danger text-center">অনুসন্ধানে ব্যর্থ: ${e.message}</div>`;
    }
  }, 220);
}
</script>
