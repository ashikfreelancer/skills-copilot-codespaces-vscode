<!DOCTYPE html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"/>
  <meta name="csrf-token" content="{{ csrf_token() }}"><meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>Audit Log | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link href="{{ asset('assets/css/app.css') }}" rel="stylesheet"/><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="audit-log">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i class="text-primary" data-lucide="database"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Audit Log</h1></div></div>
<div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4"><div><h2 class="page-title h3">Audit Log</h2><p class="muted mb-0">Track data creation, update, deletion, approval, rejection, export, and security authorization events.</p></div><button class="btn btn-outline-secondary btn-sm" onclick="loadAuditLogs()"><i data-lucide="refresh-cw" style="width:14px;height:14px"></i> Refresh</button></div>
<div class="cardx p-3 mb-3">
  <div class="row g-2 mb-3">
    <div class="col-md-6"><input type="text" id="auditSearch" class="form-control form-control-sm" placeholder="Search user, action, module, or reference..." oninput="filterLogs()"></div>
    <div class="col-md-3">
      <select id="actionFilter" class="form-select form-select-sm" onchange="filterLogs()">
        <option value="">All Actions</option>
        <option value="VIEW">VIEW</option>
        <option value="CREATE">CREATE</option>
        <option value="EDIT">EDIT</option>
        <option value="UPDATE">UPDATE</option>
        <option value="DELETE">DELETE</option>
        <option value="APPROVE">APPROVE</option>
        <option value="REJECT">REJECT</option>
        <option value="PRINT">PRINT</option>
        <option value="EXPORT">EXPORT</option>
        <option value="IMPORT">IMPORT</option>
        <option value="UNAUTHORIZED_ATTEMPT">UNAUTHORIZED ATTEMPT</option>
        <option value="LOGIN">LOGIN</option>
        <option value="LOGOUT">LOGOUT</option>
      </select>
    </div>
    <div class="col-md-3 text-end d-flex align-items-center justify-content-end text-muted small">
      <span id="logCountBadge">Showing 0 events</span>
    </div>
  </div>
  <div class="table-responsive responsive-table">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Date &amp; Time</th>
          <th>User</th>
          <th>Module</th>
          <th>Action</th>
          <th>Details / Record</th>
          <th>IP Address</th>
        </tr>
      </thead>
      <tbody id="auditTableBody">
        <tr><td colspan="6" class="text-center text-muted py-4">Loading audit logs...</td></tr>
      </tbody>
    </table>
  </div>
</div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a></div></div>
<div class="toast position-fixed bottom-0 end-0 m-3" id="toast"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let allLogs = [];

function loadAuditLogs(){
  fetch('/api/audit-logs')
    .then(r => {
      if(!r.ok) throw new Error('Status ' + r.status);
      return r.json();
    })
    .then(data => {
      if(data && data.logs){
        allLogs = data.logs;
        filterLogs();
      }
    })
    .catch(() => {
      // Fallback to local storage
      try {
        const local = JSON.parse(localStorage.getItem('mis_audit_v2') || '[]');
        allLogs = local.map(l => ({
          created_at: l.time,
          username: l.user,
          module: l.module,
          action: l.action,
          reference: l.reference,
          ip_address: '127.0.0.1'
        }));
        filterLogs();
      } catch(e) {
        document.getElementById('auditTableBody').innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No audit logs found.</td></tr>';
      }
    });
}

function getBadge(action){
  const act = String(action).toUpperCase();
  if(act === 'CREATE') return '<span class="badge bg-success-subtle text-success border border-success-subtle">CREATE</span>';
  if(act === 'UPDATE' || act === 'EDIT') return '<span class="badge bg-info-subtle text-info border border-info-subtle">UPDATE</span>';
  if(act === 'DELETE') return '<span class="badge bg-danger text-white">DELETE</span>';
  if(act === 'APPROVE') return '<span class="badge bg-primary-subtle text-primary border border-primary-subtle">APPROVE</span>';
  if(act === 'REJECT') return '<span class="badge bg-warning-subtle text-warning border border-warning-subtle">REJECT</span>';
  if(act === 'PRINT') return '<span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">PRINT</span>';
  if(act === 'EXPORT') return '<span class="badge bg-success text-white">EXPORT</span>';
  if(act === 'IMPORT') return '<span class="badge bg-dark text-white">IMPORT</span>';
  if(act.includes('UNAUTHORIZED') || act.includes('FORBIDDEN')) return '<span class="badge bg-danger text-white">UNAUTHORIZED ATTEMPT</span>';
  if(act === 'LOGIN') return '<span class="badge bg-light text-dark border">LOGIN</span>';
  if(act === 'LOGOUT') return '<span class="badge bg-light text-secondary border">LOGOUT</span>';
  return `<span class="badge bg-light text-dark border">${act}</span>`;
}

function filterLogs(){
  const search = (document.getElementById('auditSearch').value || '').toLowerCase();
  const act = document.getElementById('actionFilter').value;

  const filtered = allLogs.filter(l => {
    if(act && String(l.action).toUpperCase() !== act) return false;
    if(search){
      const text = `${l.created_at} ${l.username} ${l.module} ${l.action} ${l.reference} ${l.ip_address}`.toLowerCase();
      if(!text.includes(search)) return false;
    }
    return true;
  });

  document.getElementById('logCountBadge').textContent = `Showing ${filtered.length} of ${allLogs.length} events`;

  if(filtered.length === 0){
    document.getElementById('auditTableBody').innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No matching audit events found.</td></tr>';
    return;
  }

  document.getElementById('auditTableBody').innerHTML = filtered.map(l => `
    <tr>
      <td class="text-nowrap small text-muted">${l.created_at || 'Just now'}</td>
      <td><strong>${esc(l.username || 'System')}</strong></td>
      <td><span class="badge text-bg-light border">${esc(l.module)}</span></td>
      <td>${getBadge(l.action)}</td>
      <td class="small">${esc(l.reference || '—')}</td>
      <td class="text-nowrap small font-monospace text-muted">${esc(l.ip_address || '127.0.0.1')}</td>
    </tr>
  `).join('');

  if(window.lucide) lucide.createIcons();
}

function esc(s){
  return String(s ?? '').replace(/[&<>'"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[m]));
}

document.addEventListener('DOMContentLoaded', () => {
  loadAuditLogs();
});
</script>
</body></html>
