<!doctype html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Target & Activity | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link rel="stylesheet" href="{{ asset('assets/css/app.css') }}"><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="target-activity">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
  <div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div>
  <div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
 <div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Target & Activity</h1></div></div>
 <div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="mb-4"><h2 class="page-title h3">Target & Activity</h2><p class="muted">Set MIS targets and record monthly/periodic activities.</p></div>
<div class="cardx p-3">
  <form id="targetForm" onsubmit="event.preventDefault(); saveTargetActivity();">
    <div class="row g-3">
      <div class="col-md-3"><label class="form-label fw-semibold">Period</label><select class="form-select" id="targetPeriod"><option>September 2026</option><option>October 2026</option><option>November 2026</option><option>December 2026</option></select></div>
      <div class="col-md-3"><label class="form-label fw-semibold">Area</label><select class="form-select" id="targetArea"><option value="All Areas">All Areas</option></select></div>
      <div class="col-md-3"><label class="form-label fw-semibold">Indicator</label><input class="form-control" id="targetIndicator" placeholder="OP / KPI" required></div>
      <div class="col-md-3"><label class="form-label fw-semibold">Target</label><input class="form-control" id="targetValue" type="number" placeholder="Target Value" required></div>
    </div>
    <hr>
    <label class="form-label fw-semibold">Activity Description</label>
    <textarea class="form-control mb-3" id="targetActivityDesc" rows="4" placeholder="Describe monthly or periodic activity milestones..."></textarea>
    <button class="btn btn-primary" type="submit"><i data-lucide="save" class="me-1"></i>Save Activity</button>
  </form>
</div>

<div class="cardx p-3 mt-4">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <h5 class="fw-bold mb-0">Recorded Targets &amp; Activities</h5>
    <input type="text" class="form-control form-control-sm" style="max-width: 240px;" id="searchTargets" placeholder="Search targets..." oninput="renderTargets()">
  </div>
  <div class="table-responsive responsive-table">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Period</th>
          <th>Area</th>
          <th>Indicator</th>
          <th>Target</th>
          <th>Activity Description</th>
          <th>Recorded At</th>
          <th class="action-cell actions-head text-end">Action</th>
        </tr>
      </thead>
      <tbody id="targetsTableBody">
      </tbody>
    </table>
  </div>
</div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a></div></div>
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const TARGETS_KEY = 'mis_target_activities_v1';
const defaultTargets = [
  { id: 'TGT-1', period: 'September 2026', area: 'Dhaka Division', indicator: 'Loan Disbursement Rate', target: 95, desc: 'Target 95% recovery and timely branch disbursement verification.', at: '2026-09-01 10:00:00' },
  { id: 'TGT-2', period: 'September 2026', area: 'Rajshahi Division', indicator: 'Monthly MIS Data Entry Compliance', target: 100, desc: 'All field branch offices to finalize report entries before cutoff date.', at: '2026-09-05 11:30:00' }
];

function getTargets() {
  try {
    const raw = localStorage.getItem(TARGETS_KEY);
    return raw ? JSON.parse(raw) : defaultTargets;
  } catch (e) {
    return defaultTargets;
  }
}

function saveTargets(list) {
  localStorage.setItem(TARGETS_KEY, JSON.stringify(list));
}

function populateAreas() {
  const sel = document.getElementById('targetArea');
  if (!sel) return;
  const branches = typeof MIS_getBranches === 'function' ? MIS_getBranches() : [];
  const zones = typeof MIS_getZones === 'function' ? MIS_getZones() : [];
  let opts = '<option value="All Areas">All Areas</option>';
  zones.forEach(z => {
    opts += `<option value="${z.name || z.zone}">${z.name || z.zone} (Zone)</option>`;
  });
  branches.slice(0, 15).forEach(b => {
    opts += `<option value="${b.name || b.branchName}">${b.name || b.branchName} (${b.district || 'Branch'})</option>`;
  });
  sel.innerHTML = opts;
}

function renderTargets() {
  const tbody = document.getElementById('targetsTableBody');
  if (!tbody) return;
  const q = (document.getElementById('searchTargets')?.value || '').toLowerCase();
  const list = getTargets().filter(item => {
    if (!q) return true;
    return (item.period + ' ' + item.area + ' ' + item.indicator + ' ' + item.desc).toLowerCase().includes(q);
  });

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No targets or activities found.</td></tr>';
    return;
  }

  tbody.innerHTML = list.map(item => `
    <tr>
      <td><strong>${item.period}</strong></td>
      <td>${item.area}</td>
      <td>${item.indicator}</td>
      <td><span class="badge bg-primary">${item.target}</span></td>
      <td>${item.desc || '-'}</td>
      <td class="small text-muted">${item.at || '-'}</td>
      <td class="action-cell actions-head text-end">
        <button class="btn btn-sm btn-outline-danger" onclick="deleteTarget('${item.id}')" title="Delete">
          <i data-lucide="trash-2" style="width:14px;height:14px"></i>
        </button>
      </td>
    </tr>
  `).join('');

  if (window.lucide) lucide.createIcons();
}

function saveTargetActivity() {
  const period = document.getElementById('targetPeriod').value;
  const area = document.getElementById('targetArea').value;
  const indicator = document.getElementById('targetIndicator').value.trim();
  const target = document.getElementById('targetValue').value;
  const desc = document.getElementById('targetActivityDesc').value.trim();

  const newEntry = {
    id: 'TGT-' + Date.now(),
    period,
    area,
    indicator,
    target: Number(target),
    desc,
    at: new Date().toISOString().replace('T', ' ').substring(0, 19)
  };

  const list = getTargets();
  list.unshift(newEntry);
  saveTargets(list);

  if (typeof MIS_addAudit === 'function') {
    MIS_addAudit('Target & Activity', 'CREATE', `${indicator} (${period} - ${area})`);
  }

  toast('Target & Activity saved successfully');
  document.getElementById('targetForm').reset();
  renderTargets();
}

function deleteTarget(id) {
  if (!confirm('Are you sure you want to delete this target?')) return;
  const list = getTargets().filter(x => x.id !== id);
  saveTargets(list);
  if (typeof MIS_addAudit === 'function') {
    MIS_addAudit('Target & Activity', 'DELETE', id);
  }
  toast('Target deleted');
  renderTargets();
}

document.addEventListener('DOMContentLoaded', () => {
  populateAreas();
  renderTargets();
});
</script>
</body></html>