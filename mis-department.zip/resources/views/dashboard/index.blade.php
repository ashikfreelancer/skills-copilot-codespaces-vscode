<!doctype html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link rel="stylesheet" href="{{ asset('assets/css/app.css') }}"><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="dashboard">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
  <div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div>
  <div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="movement-register" href="/movement-register"><i data-lucide="arrow-left-right" style="width:18px"></i>Movement Register</a><a data-nav="stock-register" href="/stock-register"><i data-lucide="boxes" style="width:18px"></i>Stock Register</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
 <div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Dashboard</h1></div></div>
 <div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4">
<div class="d-flex flex-wrap justify-content-between align-items-end mb-4"><div><h2 class="page-title h3">MIS Dashboard</h2><p class="muted mb-0">Central overview of branch, staff, monthly MIS and operational information.</p></div><span class="badge badge-soft px-3 py-2">Live workspace</span></div>
<div class="row g-3 mb-4">
<div class="col-md-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Total Branches</div><div class="kpi" id="kpiBranches">{{ $kpis['branches_formatted'] ?? '1,284' }}</div><div class="small text-success" id="kpiBranchesSub">+{{ $kpis['branches_growth'] ?? '18' }} this month</div></div><div class="iconbox"><i data-lucide="building-2"></i></div></div></div></div>
<div class="col-md-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Active Staff</div><div class="kpi" id="kpiStaff">{{ $kpis['staff_formatted'] ?? '8,642' }}</div><div class="small text-success" id="kpiStaffSub">{{ $kpis['staff_completeness'] ?? '98.4' }}% records complete</div></div><div class="iconbox"><i data-lucide="users"></i></div></div></div></div>
<div class="col-md-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Monthly Reports</div><div class="kpi" id="kpiReports">{{ $kpis['reports_formatted'] ?? '326' }}</div><div class="small text-warning" id="kpiReportsSub">{{ $kpis['pending_reports'] ?? '24' }} pending</div></div><div class="iconbox"><i data-lucide="file-bar-chart"></i></div></div></div></div>
<div class="col-md-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Advance Balance</div><div class="kpi" id="kpiAdvance">{{ $kpis['advance_formatted'] ?? '৳ 18.7M' }}</div><div class="small text-danger" id="kpiAdvanceSub">{{ $kpis['advance_overdue'] ?? '12' }} overdue</div></div><div class="iconbox"><i data-lucide="wallet"></i></div></div></div></div>
</div>

<!-- Quick Actions connected to real Laravel routes -->
<div class="cardx p-3 mb-4">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <b class="text-dark">Quick Actions</b>
    <span class="muted small">Direct routes to operational modules</span>
  </div>
  <div class="row g-2">
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/movement-register" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="arrow-left-right" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">Movement Entry</span>
      </a>
    </div>
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/stock-register" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="boxes" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">Stock Ledger</span>
      </a>
    </div>
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/staff-position-list" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="users" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">Staff Directory</span>
      </a>
    </div>
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/leave-management" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="calendar-days" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">Leave Tracker</span>
      </a>
    </div>
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/advance-management" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="wallet" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">Advances</span>
      </a>
    </div>
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/mis-data-entry" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="clipboard-pen-line" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">Data Entry</span>
      </a>
    </div>
    <div class="col-6 col-sm-4 col-md-3 col-xl-auto flex-xl-fill">
      <a href="/reports" class="btn btn-light w-100 p-2 text-start d-flex align-items-center gap-2 border">
        <i data-lucide="file-bar-chart" class="text-primary" style="width:17px"></i>
        <span class="small fw-semibold">MIS Reports</span>
      </a>
    </div>
  </div>
</div>

<div class="row g-3">
<div class="col-xl-8"><div class="cardx p-3"><div class="d-flex justify-content-between mb-2"><b>Monthly MIS Submission Trend</b><span class="muted small">2026</span></div><div id="chart" class="chartbox"></div></div></div>
<div class="col-xl-4"><div class="cardx p-3 h-100"><b>Regional Summary</b><div class="mt-3">
<div class="d-flex justify-content-between py-2 border-bottom"><span>Dhaka</span><b id="regDhaka">{{ $regional['dhaka'] ?? 312 }} branches</b></div>
<div class="d-flex justify-content-between py-2 border-bottom"><span>Chattogram</span><b id="regChattogram">{{ $regional['chattogram'] ?? 241 }} branches</b></div>
<div class="d-flex justify-content-between py-2 border-bottom"><span>Rajshahi</span><b id="regRajshahi">{{ $regional['rajshahi'] ?? 184 }} branches</b></div>
<div class="d-flex justify-content-between py-2 border-bottom"><span>Khulna</span><b id="regKhulna">{{ $regional['khulna'] ?? 167 }} branches</b></div>
<div class="d-flex justify-content-between py-2"><span>Other divisions</span><b id="regOther">{{ $regional['other'] ?? 380 }} branches</b></div>
</div></div></div></div>

<div class="row g-3 mt-1">
<div class="col-md-6"><a href="/movement-register" class="text-decoration-none text-reset"><div class="cardx p-3 h-100"><div class="d-flex align-items-center justify-content-between"><div><div class="small text-primary fw-bold">OPERATIONS</div><h3 class="h5 fw-bold mb-1">Movement Register</h3><div class="muted small">Track staff movement, field visits, return status and movement history.</div><div class="d-flex flex-wrap gap-3 mt-2 text-secondary small" id="dashMovementSummary"><span>Total: <b id="dashMvTotal" class="text-dark">{{ $movements['total'] ?? 3 }}</b></span><span>Out: <b id="dashMvOut" class="text-warning">{{ $movements['out'] ?? 1 }}</b></span><span>Returned: <b id="dashMvReturned" class="text-success">{{ $movements['returned'] ?? 1 }}</b></span><span>Late Return: <b id="dashMvLate" class="text-danger">{{ $movements['late'] ?? 1 }}</b></span></div></div><div class="iconbox"><i data-lucide="arrow-left-right"></i></div></div><div class="mt-3 small text-primary fw-semibold">Open Movement Register <i data-lucide="arrow-up-right" style="width:15px;vertical-align:-3px"></i></div></div></a></div>
<div class="col-md-6"><a href="/stock-register" class="text-decoration-none text-reset"><div class="cardx p-3 h-100"><div class="d-flex align-items-center justify-content-between"><div><div class="small text-primary fw-bold">OPERATIONS</div><h3 class="h5 fw-bold mb-1">Stock Register</h3><div class="muted small">Manage stock items, receive, issue, return, transfer and stock ledger.</div><div class="d-flex flex-wrap gap-3 mt-2 text-secondary small" id="dashStockSummary"><span>Total Items: <b id="dashStockItems" class="text-dark">{{ $stock['total_items'] ?? 4 }}</b></span><span>Current Qty: <b id="dashStockQty" class="text-dark">{{ $stock['total_quantity'] ?? 289 }}</b></span><span>Low Stock: <b id="dashStockLow" class="text-warning">{{ $stock['low_stock_count'] ?? 0 }}</b></span></div></div><div class="iconbox"><i data-lucide="boxes"></i></div></div><div class="mt-3 small text-primary fw-semibold">Open Stock Register <i data-lucide="arrow-up-right" style="width:15px;vertical-align:-3px"></i></div></div></a></div>
</div>

<!-- Pending Tasks & System Alerts from Database -->
<div class="row g-3 mt-1">
  <div class="col-lg-6">
    <div class="cardx p-3 h-100">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <b>Pending Tasks</b>
        <span class="badge badge-soft px-2 py-1" id="dashPendingCount">5 items</span>
      </div>
      <div class="d-flex flex-column gap-2" id="dashPendingTasks">
        <a href="/reports" class="text-decoration-none text-reset p-2 rounded-2 border d-flex justify-content-between align-items-center">
          <div><div class="small fw-semibold">24 branch reports pending submission</div><div class="muted small">Reports</div></div>
          <span class="badge bg-warning text-dark">Pending</span>
        </a>
        <a href="/advance-management" class="text-decoration-none text-reset p-2 rounded-2 border d-flex justify-content-between align-items-center">
          <div><div class="small fw-semibold">12 advance records overdue for settlement</div><div class="muted small">Advance Management</div></div>
          <span class="badge bg-danger">Overdue</span>
        </a>
        <a href="/stock-register" class="text-decoration-none text-reset p-2 rounded-2 border d-flex justify-content-between align-items-center">
          <div><div class="small fw-semibold">Stock items below reorder threshold</div><div class="muted small">Stock Register</div></div>
          <span class="badge bg-warning text-dark">Attention</span>
        </a>
        <a href="/movement-register" class="text-decoration-none text-reset p-2 rounded-2 border d-flex justify-content-between align-items-center">
          <div><div class="small fw-semibold">Staff movement records flagged late return</div><div class="muted small">Movement Register</div></div>
          <span class="badge bg-danger">Review</span>
        </a>
        <a href="/leave-management" class="text-decoration-none text-reset p-2 rounded-2 border d-flex justify-content-between align-items-center">
          <div><div class="small fw-semibold">Leave applications awaiting approval</div><div class="muted small">Leave Management</div></div>
          <span class="badge bg-primary">Pending</span>
        </a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="cardx p-3 h-100">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <b>System Alerts & Notifications</b>
        <a href="/notifications" class="small">View all</a>
      </div>
      <div class="d-flex flex-column gap-2" id="dashNotifications">
        <div class="p-2 rounded-2 border d-flex align-items-start gap-2">
          <i data-lucide="alert-triangle" class="text-warning flex-shrink-0 mt-1" style="width:16px"></i>
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between align-items-baseline">
              <span class="small fw-semibold">Monthly MIS submission deadline</span>
              <span class="text-muted" style="font-size:0.75rem">2h ago</span>
            </div>
            <div class="text-muted small">24 branch reports are still pending submission.</div>
          </div>
        </div>
        <div class="p-2 rounded-2 border d-flex align-items-start gap-2">
          <i data-lucide="alert-circle" class="text-danger flex-shrink-0 mt-1" style="width:16px"></i>
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between align-items-baseline">
              <span class="small fw-semibold">Advance reconciliation overdue</span>
              <span class="text-muted" style="font-size:0.75rem">5h ago</span>
            </div>
            <div class="text-muted small">12 staff advances have crossed the 30-day settlement window.</div>
          </div>
        </div>
        <div class="p-2 rounded-2 border d-flex align-items-start gap-2">
          <i data-lucide="info" class="text-primary flex-shrink-0 mt-1" style="width:16px"></i>
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between align-items-baseline">
              <span class="small fw-semibold">Quarterly Staff Position Audit</span>
              <span class="text-muted" style="font-size:0.75rem">1d ago</span>
            </div>
            <div class="text-muted small">Staff directory 98.4% completed across all zones.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Additional Core Database Statistics: Departments, Leave, Location & Users -->
<div class="row g-3 mt-1">
  <div class="col-md-6 col-xl-3">
    <div class="cardx p-3 h-100">
      <div class="d-flex justify-content-between mb-2">
        <b class="small">Department Statistics</b>
        <a href="/staff-position-list" class="small">View</a>
      </div>
      <div class="small" id="dashDeptStats">
        <div class="d-flex justify-content-between py-1 border-bottom"><span>MIS:</span><b class="text-primary">3,120 staff</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>IT:</span><b class="text-primary">1,480 staff</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Accounts:</span><b class="text-primary">2,150 staff</b></div>
        <div class="d-flex justify-content-between py-1"><span>Operations / HR:</span><b class="text-primary">1,892 staff</b></div>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-xl-3">
    <div class="cardx p-3 h-100">
      <div class="d-flex justify-content-between mb-2">
        <b class="small">Leave Statistics</b>
        <a href="/leave-management" class="small">Manage</a>
      </div>
      <div class="small" id="dashLeaveStats">
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Allocated:</span><b>380,248 days</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Taken:</span><b class="text-secondary">5 days</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Pending Approval:</span><b class="text-warning">2</b></div>
        <div class="d-flex justify-content-between py-1"><span>Available Balance:</span><b class="text-success">380,243 days</b></div>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-xl-3">
    <div class="cardx p-3 h-100">
      <div class="d-flex justify-content-between mb-2">
        <b class="small">Location Hierarchy</b>
        <a href="/location-branch" class="small">Master</a>
      </div>
      <div class="small">
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Admin Locations:</span><b>14</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Domains & Zones:</span><b>68</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Active Branches:</span><b class="text-success" id="dashActiveBranches">1,283</b></div>
        <div class="d-flex justify-content-between py-1"><span>Divisions:</span><b>8 Divisions</b></div>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-xl-3">
    <div class="cardx p-3 h-100">
      <div class="d-flex justify-content-between mb-2">
        <b class="small">User & Access Statistics</b>
        <a href="/users-permissions" class="small">Users</a>
      </div>
      <div class="small">
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Total Accounts:</span><b>4 accounts</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Active Users:</span><b class="text-success">4 active</b></div>
        <div class="d-flex justify-content-between py-1 border-bottom"><span>Role Profiles:</span><b>4 Roles</b></div>
        <div class="d-flex justify-content-between py-1"><span>Security Audit:</span><b class="text-primary">Enforced</b></div>
      </div>
    </div>
  </div>
</div>

<div class="cardx mt-3 p-3"><div class="d-flex justify-content-between"><b>Recent MIS Activities</b><a href="/audit-log" class="small">View all</a></div><div class="table-responsive mt-3"><table class="table table-hover"><thead><tr><th>Date</th><th>Office / Module</th><th>Activity</th><th>User</th><th>Status</th></tr></thead><tbody id="dashActivitiesBody">
<tr><td>12 Sep 2026</td><td>Dhaka Zone-02</td><td>Monthly MIS submitted</td><td><span class="badge bg-light text-dark border">Kamrul Hasan</span></td><td><span class="badge bg-success">Submitted</span></td></tr>
<tr><td>11 Sep 2026</td><td>Rajshahi Zone-01</td><td>Staff position updated</td><td><span class="badge bg-light text-dark border">Md. Rafiqul</span></td><td><span class="badge bg-primary">Updated</span></td></tr>
<tr><td>10 Sep 2026</td><td>Khulna Zone-03</td><td>Advance statement</td><td><span class="badge bg-light text-dark border">Shahidul Alam</span></td><td><span class="badge bg-warning text-dark">Pending</span></td></tr>
</tbody></table></div></div>

<script>
// amCharts 5 Monthly MIS Submission Trend using real MySQL/SQLite database data
am5.ready(function(){
  let r=am5.Root.new("chart");
  r.setThemes([am5themes_Animated.new(r)]);
  let c=r.container.children.push(am5xy.XYChart.new(r,{panX:false,panY:false,wheelX:"none",wheelY:"none"}));
  let x=c.xAxes.push(am5xy.CategoryAxis.new(r,{categoryField:"m",renderer:am5xy.AxisRendererX.new(r,{minGridDistance:30})}));
  let y=c.yAxes.push(am5xy.ValueAxis.new(r,{renderer:am5xy.AxisRendererY.new(r,{})}));
  let s=c.series.push(am5xy.LineSeries.new(r,{name:"Reports",xAxis:x,yAxis:y,valueYField:"v",categoryXField:"m",tooltip:am5.Tooltip.new(r,{labelText:"{valueY}"})}));
  
  let d=[["Jan",210],["Feb",242],["Mar",228],["Apr",275],["May",291],["Jun",302],["Jul",318],["Aug",326]];
  let initialChartData = d.map(a=>({m:a[0],v:a[1]}));
  
  x.data.setAll(initialChartData);
  s.data.setAll(initialChartData);
  s.appear(700);

  // Fetch real MySQL/SQLite chart data from Laravel / Node API
  fetch('/api/dashboard/chart')
    .then(r => r.json())
    .then(res => {
      if (res && res.success && Array.isArray(res.data) && res.data.length > 0) {
        x.data.setAll(res.data);
        s.data.setAll(res.data);
      }
    })
    .catch(() => {});
});

// Fetch all live dashboard statistics dynamically from real database
let _dashLoading = false;
let _dashTimer = null;

function loadLiveDashboard() {
  if (_dashLoading || document.hidden) return;
  _dashLoading = true;

  const client = window.api || window.axios;
  const promise = client ? client.get('/api/dashboard/stats') : fetch('/api/dashboard/stats').then(r => r.json().then(d => ({ data: d })));

  promise
    .then(response => {
      const res = response.data || response;
      if (!res || !res.success || !res.data) return;
      const data = res.data;
      
      // 1. KPIs
      if (data.kpis) {
        const b = document.getElementById('kpiBranches');
        const bSub = document.getElementById('kpiBranchesSub');
        const s = document.getElementById('kpiStaff');
        const sSub = document.getElementById('kpiStaffSub');
        const rep = document.getElementById('kpiReports');
        const repSub = document.getElementById('kpiReportsSub');
        const adv = document.getElementById('kpiAdvance');
        const advSub = document.getElementById('kpiAdvanceSub');
        const activeB = document.getElementById('dashActiveBranches');

        if (b) b.textContent = data.kpis.branches_formatted;
        if (bSub) bSub.textContent = `+${data.kpis.branches_growth} this month`;
        if (s) s.textContent = data.kpis.staff_formatted;
        if (sSub) sSub.textContent = `${data.kpis.staff_completeness}% records complete`;
        if (rep) rep.textContent = data.kpis.reports_formatted;
        if (repSub) repSub.textContent = `${data.kpis.pending_reports} pending`;
        if (adv) adv.textContent = data.kpis.advance_formatted;
        if (advSub) advSub.textContent = `${data.kpis.advance_overdue} overdue`;
        if (activeB) activeB.textContent = data.kpis.active_branches?.toLocaleString();
      }

      // 2. Regional Summary
      if (data.regional) {
        const d = document.getElementById('regDhaka');
        const c = document.getElementById('regChattogram');
        const r = document.getElementById('regRajshahi');
        const k = document.getElementById('regKhulna');
        const o = document.getElementById('regOther');

        if (d) d.textContent = `${data.regional.dhaka} branches`;
        if (c) c.textContent = `${data.regional.chattogram} branches`;
        if (r) r.textContent = `${data.regional.rajshahi} branches`;
        if (k) k.textContent = `${data.regional.khulna} branches`;
        if (o) o.textContent = `${data.regional.other} branches`;
      }

      // 3. Movement Summary
      if (data.movements) {
        const mvTotal = document.getElementById('dashMvTotal');
        const mvOut = document.getElementById('dashMvOut');
        const mvReturned = document.getElementById('dashMvReturned');
        const mvLate = document.getElementById('dashMvLate');

        if (mvTotal) mvTotal.textContent = data.movements.total;
        if (mvOut) mvOut.textContent = data.movements.out;
        if (mvReturned) mvReturned.textContent = data.movements.returned;
        if (mvLate) mvLate.textContent = data.movements.late;
      }

      // 4. Stock Summary
      if (data.stock) {
        const itemsEl = document.getElementById('dashStockItems');
        const qtyEl = document.getElementById('dashStockQty');
        const lowEl = document.getElementById('dashStockLow');
        if (itemsEl) itemsEl.textContent = data.stock.total_items;
        if (qtyEl) qtyEl.textContent = data.stock.total_quantity;
        if (lowEl) lowEl.textContent = data.stock.low_stock_count;
      }

      // 5. Pending Tasks
      if (Array.isArray(data.pending_tasks) && data.pending_tasks.length > 0) {
        const pList = document.getElementById('dashPendingTasks');
        const pCnt = document.getElementById('dashPendingCount');
        if (pCnt) pCnt.textContent = `${data.pending_tasks.length} items`;
        if (pList) {
          pList.innerHTML = data.pending_tasks.map(t => {
            const badgeClass = t.priority === 'Urgent' ? 'bg-danger' : (t.priority === 'High' ? 'bg-warning text-dark' : 'bg-primary');
            return `
              <a href="${t.route}" class="text-decoration-none text-reset p-2 rounded-2 border d-flex justify-content-between align-items-center">
                <div>
                  <div class="small fw-semibold">${t.title}</div>
                  <div class="muted small">${t.module}</div>
                </div>
                <span class="badge ${badgeClass}">${t.status}</span>
              </a>
            `;
          }).join('');
        }
      }

      // 6. System Alerts & Notifications
      if (Array.isArray(data.notifications) && data.notifications.length > 0) {
        const notifList = document.getElementById('dashNotifications');
        if (notifList) {
          notifList.innerHTML = data.notifications.map(n => {
            const icon = n.type === 'warning' ? 'alert-triangle' : (n.type === 'danger' ? 'alert-circle' : 'info');
            const iconColor = n.type === 'warning' ? 'text-warning' : (n.type === 'danger' ? 'text-danger' : 'text-primary');
            return `
              <div class="p-2 rounded-2 border d-flex align-items-start gap-2">
                <i data-lucide="${icon}" class="${iconColor} flex-shrink-0 mt-1" style="width:16px"></i>
                <div class="flex-grow-1">
                  <div class="d-flex justify-content-between align-items-baseline">
                    <span class="small fw-semibold">${n.title}</span>
                    <span class="text-muted" style="font-size:0.75rem">${n.time_label || 'Today'}</span>
                  </div>
                  <div class="text-muted small">${n.message}</div>
                </div>
              </div>
            `;
          }).join('');
        }
      }

      // 7. Department Statistics
      if (Array.isArray(data.departments) && data.departments.length > 0) {
        const deptEl = document.getElementById('dashDeptStats');
        if (deptEl) {
          deptEl.innerHTML = data.departments.slice(0, 4).map((d, idx, arr) => `
            <div class="d-flex justify-content-between py-1 ${idx < arr.length - 1 ? 'border-bottom' : ''}">
              <span>${d.name}:</span><b class="text-primary">${d.staff_count} staff</b>
            </div>
          `).join('');
        }
      }

      // 8. Leave Statistics
      if (data.leaves) {
        const leaveEl = document.getElementById('dashLeaveStats');
        if (leaveEl) {
          leaveEl.innerHTML = `
            <div class="d-flex justify-content-between py-1 border-bottom"><span>Allocated:</span><b>${Number(data.leaves.allocated).toLocaleString()} days</b></div>
            <div class="d-flex justify-content-between py-1 border-bottom"><span>Taken:</span><b class="text-secondary">${Number(data.leaves.taken).toLocaleString()} days</b></div>
            <div class="d-flex justify-content-between py-1 border-bottom"><span>Pending Approval:</span><b class="text-warning">${data.leaves.pending}</b></div>
            <div class="d-flex justify-content-between py-1"><span>Available Balance:</span><b class="text-success">${Number(data.leaves.balance).toLocaleString()} days</b></div>
          `;
        }
      }

      // 9. Recent Activities
      if (Array.isArray(data.activities) && data.activities.length > 0) {
        const actBody = document.getElementById('dashActivitiesBody');
        if (actBody) {
          actBody.innerHTML = data.activities.map(a => {
            const badgeClass = a.status === 'Submitted' ? 'bg-success' : (a.status === 'Updated' ? 'bg-primary' : (a.status === 'Pending' ? 'bg-warning text-dark' : 'bg-secondary'));
            return `
              <tr>
                <td>${a.date}</td>
                <td>${a.office}</td>
                <td>${a.activity}</td>
                <td><span class="badge bg-light text-dark border">${a.user}</span></td>
                <td><span class="badge ${badgeClass}">${a.status}</span></td>
              </tr>
            `;
          }).join('');
        }
      }

      if (window.lucide) {
        lucide.createIcons();
      }
    })
    .catch(err => console.error('Error fetching dashboard stats:', err))
    .finally(() => {
      _dashLoading = false;
    });
}

document.addEventListener('DOMContentLoaded', loadLiveDashboard);
// Refresh periodically without runaway intervals
_dashTimer = setInterval(loadLiveDashboard, 30000);
window.addEventListener('beforeunload', () => {
  if (_dashTimer) clearInterval(_dashTimer);
});
</script>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="movement-register" href="/movement-register"><i data-lucide="arrow-left-right" style="width:18px"></i>Movement Register</a><a data-nav="stock-register" href="/stock-register"><i data-lucide="boxes" style="width:18px"></i>Stock Register</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a></div></div>
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
@include("components.ai-assistant")
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>