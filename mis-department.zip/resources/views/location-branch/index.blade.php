<!doctype html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8">
  <meta name=\"csrf-token\" content=\"{{ csrf_token() }}\"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Location & Branch | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jspdf-autotable@3.8.4/dist/jspdf.plugin.autotable.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link rel="stylesheet" href="{{ asset('assets/css/app.css') }}"><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="location-branch">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
  <div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div>
  <div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
 <div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Location & Branch</h1></div></div>
 <div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>

<div class="p-3 p-lg-4 page-wrap">
<div class="d-flex justify-content-between align-items-center mb-3 gap-3 flex-wrap">
<div><h2 class="page-title h3 mb-1">Location & Branch Directory</h2><p class="muted mb-0">Division → District → Thana → Upazila → Union / Municipality / City Corporation → Ward → Branch.</p></div>
<div class="d-flex gap-2 flex-wrap"><button class="btn btn-outline-secondary" onclick="locExport()"><i data-lucide="download"></i> Export</button><button class="btn btn-primary" data-permission="location-branch:create" data-bs-toggle="modal" data-bs-target="#locationModal" onclick="locOpen()"><i data-lucide="plus"></i> Add Location</button></div>
</div>
<div class="row g-3 mb-3">
<div class="col-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Divisions</div><div id="kDiv" class="kpi">0</div></div><div class="iconbox"><i data-lucide="map"></i></div></div></div></div>
<div class="col-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Districts</div><div id="kDist" class="kpi">0</div></div><div class="iconbox"><i data-lucide="map-pinned"></i></div></div></div></div>
<div class="col-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Thana / Upazila</div><div id="kUpa" class="kpi">0</div></div><div class="iconbox"><i data-lucide="landmark"></i></div></div></div></div>
<div class="col-6 col-xl-3"><div class="cardx stat"><div class="d-flex justify-content-between"><div><div class="muted small">Branches</div><div id="kBranch" class="kpi">0</div></div><div class="iconbox"><i data-lucide="building-2"></i></div></div></div></div>
</div>
<div class="cardx p-3 mb-3"><div class="row g-2">
<div class="col-12 col-md-3"><label class="form-label">Division</label><select id="fDiv" class="form-select"><option value="">All Divisions</option></select></div>
<div class="col-12 col-md-3"><label class="form-label">District</label><select id="fDist" class="form-select"><option value="">All Districts</option></select></div>
<div class="col-12 col-md-3"><label class="form-label">Thana</label><select id="fThana" class="form-select"><option value="">All Thana</option></select></div><div class="col-12 col-md-3"><label class="form-label">Upazila</label><select id="fUpa" class="form-select"><option value="">All Upazila</option></select></div>
<div class="col-12 col-md-3"><label class="form-label">Search</label><input id="fSearch" class="form-control" placeholder="Name, code, branch, address..."></div>
</div></div>
<div class="cardx p-3 mb-3">
  <div class="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
    <div><b>Administrative Location Management</b><div class="muted small">Super Admin can separately Add • View • Edit • Delete • Update Division, District, Thana and Upazila.</div></div>
    <button class="btn btn-primary" data-permission="location-branch:create" onclick="masterOpen()"><i data-lucide="plus"></i> Add Administrative Location</button>
  </div>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0"><thead><tr><th>SL</th><th>Type</th><th>Name</th><th>Parent Location</th><th>Status</th><th class="no-print">Actions</th></tr></thead><tbody id="masterLocationRows"></tbody></table>
  </div>
</div>
<div class="row g-3">
<div class="col-xl-4"><div class="cardx p-3 h-100"><div class="d-flex justify-content-between align-items-center"><b>Administrative Location Tree</b><button class="btn btn-sm btn-light" onclick="locRenderTree()" title="Refresh"><i data-lucide="refresh-cw"></i></button></div><div id="locTree" class="tree mt-3"></div></div></div>
<div class="col-xl-8"><div class="cardx p-3"><div class="d-flex justify-content-between align-items-center mb-2 gap-2 flex-wrap"><div><b>Location & Branch Records</b><div class="muted small">Complete report of Division → District → Thana → Upazila → Union / Municipality / City Corporation → Ward → Branch.</div></div><div class="d-flex gap-2 flex-wrap no-print"><button class="btn btn-outline-secondary btn-sm" onclick="printLocationReport()"><i data-lucide="printer"></i> Print</button><button class="btn btn-outline-secondary btn-sm" onclick="downloadLocationPDF()"><i data-lucide="file-text"></i> Download PDF</button><button class="btn btn-outline-secondary btn-sm" onclick="downloadLocationExcel()"><i data-lucide="file-spreadsheet"></i> Download Excel</button><span id="recordCount" class="badge badge-soft align-self-center">0 records</span></div></div>
<div class="table-responsive"><table id="locationTable" class="table table-hover align-middle"><thead><tr><th>SL</th><th onclick="locSortBy('division')" style="cursor:pointer;user-select:none;" title="Sort by Division">Division <span id="sort_division"></span></th><th onclick="locSortBy('district')" style="cursor:pointer;user-select:none;" title="Sort by District">District <span id="sort_district"></span></th><th onclick="locSortBy('thana')" style="cursor:pointer;user-select:none;" title="Sort by Thana">Thana <span id="sort_thana"></span></th><th onclick="locSortBy('upazila')" style="cursor:pointer;user-select:none;" title="Sort by Upazila">Upazila <span id="sort_upazila"></span></th><th onclick="locSortBy('union_name')" style="cursor:pointer;user-select:none;" title="Sort by Union">Union / Municipality / City Corp. <span id="sort_union_name"></span></th><th onclick="locSortBy('ward')" style="cursor:pointer;user-select:none;" title="Sort by Ward">Ward <span id="sort_ward"></span></th><th onclick="locSortBy('branch')" style="cursor:pointer;user-select:none;" title="Sort by Branch">Branch <span id="sort_branch"></span></th><th onclick="locSortBy('code')" style="cursor:pointer;user-select:none;" title="Sort by Code">Code <span id="sort_code"></span></th><th onclick="locSortBy('manager')" style="cursor:pointer;user-select:none;" title="Sort by Manager">Manager <span id="sort_manager"></span></th><th>Office Mobile</th><th>Personal Mobile</th><th>Office Email</th><th onclick="locSortBy('status')" style="cursor:pointer;user-select:none;" title="Sort by Status">Status <span id="sort_status"></span></th><th>Full Address</th><th class="action-cell no-print">Actions</th></tr></thead><tbody id="locationRows"></tbody></table></div>
<div id="locPagination" class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top flex-wrap gap-2 no-print">
  <div class="small text-muted" id="locPaginationInfo">Showing 0 to 0 of 0 records</div>
  <div class="d-flex align-items-center gap-2">
    <div class="d-flex align-items-center gap-1 small text-muted">
      <span>Per page:</span>
      <select id="locPageSizeSelect" class="form-select form-select-sm" style="width: auto;" onchange="locChangePageSize(this.value)">
        <option value="10">10</option>
        <option value="25" selected>25</option>
        <option value="50">50</option>
        <option value="100">100</option>
        <option value="all">All</option>
      </select>
    </div>
    <ul class="pagination pagination-sm mb-0" id="locPaginationNav"></ul>
  </div>
</div>
</div></div>
</div></div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a></div></div>
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<div class="modal fade" id="locationModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
<div class="modal-header"><b id="locModalTitle">Add Location & Branch</b><button class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><form id="locForm" onsubmit="event.preventDefault();locSave()"><div class="row g-3">
<div class="col-md-6"><label class="form-label">Branch Name *</label><input id="mBranch" class="form-control" placeholder="Enter branch name" required></div><div class="col-md-6"><label class="form-label">Branch Code</label><input id="mCode" class="form-control" placeholder="Enter branch code"></div>
<div class="col-md-4"><label class="form-label">Branch Manager</label><input id="mManager" class="form-control" placeholder="Manager name"></div><div class="col-md-4"><label class="form-label">Office Mobile Number</label><input id="mMobile" class="form-control" placeholder="01XXXXXXXXX"></div><div class="col-md-4"><label class="form-label">Personal Mobile Number</label><input id="mPersonalMobile" class="form-control" placeholder="01XXXXXXXXX"></div>
<div class="col-md-6"><label class="form-label">Office Email</label><input id="mEmail" type="email" class="form-control" placeholder="office@example.com"></div><div class="col-md-6"><label class="form-label">Division *</label><select id="mDiv" class="form-select" required></select></div>
<div class="col-md-4"><label class="form-label">District *</label><select id="mDist" class="form-select" required></select></div><div class="col-md-4"><label class="form-label">Thana *</label><select id="mThana" class="form-select" required></select></div><div class="col-md-4"><label class="form-label">Upazila *</label><select id="mUpa" class="form-select" required></select></div>
<div class="col-md-8"><label class="form-label">Union / Municipality / City Corporation</label><input id="mUnion" class="form-control"></div><div class="col-md-4"><label class="form-label">Ward</label><input id="mWard" class="form-control"></div>
<div class="col-md-4"><label class="form-label">Status</label><select id="mStatus" class="form-select"><option>Active</option><option>Inactive</option><option>Review</option></select></div><div class="col-12"><label class="form-label">Full Address</label><textarea id="mAddress" class="form-control" rows="2"></textarea></div>
</div></form></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="locSave()">Save / Update</button></div></div></div></div>
<div class="modal fade" id="viewLocationModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><b>Location / Branch Details</b><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="viewLocationBody"></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Close</button></div></div></div></div>
<div class="modal fade" id="masterLocationModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><b id="masterModalTitle">Add Administrative Location</b><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><form id="masterLocationForm" onsubmit="event.preventDefault();masterSave()"><input type="hidden" id="masterId"><div class="row g-3"><div class="col-md-4"><label class="form-label">Location Type *</label><select id="masterType" class="form-select" required><option value="Division">Division</option><option value="District">District</option><option value="Thana">Thana</option><option value="Upazila">Upazila</option></select></div><div class="col-md-8"><label class="form-label">Location Name *</label><input id="masterName" class="form-control" required></div><div class="col-md-6"><label class="form-label">Parent Division</label><select id="masterDivision" class="form-select"></select></div><div class="col-md-6"><label class="form-label">Parent District</label><select id="masterDistrict" class="form-select"></select></div><div class="col-md-6"><label class="form-label">Parent Thana</label><select id="masterThana" class="form-select"></select></div><div class="col-md-6"><label class="form-label">Status</label><select id="masterStatus" class="form-select"><option>Active</option><option>Inactive</option></select></div></div></form></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="masterSave()">Save / Update</button></div></div></div></div>
<div class="modal fade" id="masterViewModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><b>Administrative Location Details</b><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="masterViewBody"></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Close</button></div></div></div></div>
<script>
let masterCache = [];
let locCache = [];

async function masterFetch() {
  try {
    const res = await axios.get('/api/location-branch/administrative');
    if (res.data && res.data.success) {
      masterCache = res.data.data;
      masterRender();
      fillFilters();
    }
  } catch (err) {
    console.error('Failed to load administrative locations:', err);
  }
}

async function locFetch() {
  try {
    const res = await axios.get('/api/location-branch/branches?per_page=500');
    if (res.data && res.data.success) {
      locCache = res.data.data;
      locRender();
      if (typeof MIS_write === 'function' && window.MIS_SHARED_KEYS) {
        MIS_write(MIS_SHARED_KEYS.branches, locCache);
      }
      localStorage.setItem('mis_location_branches_v1', JSON.stringify(locCache));
      localStorage.setItem('mis_branches', JSON.stringify(locCache));
      window.dispatchEvent(new CustomEvent('mis:branches:updated', { detail: locCache }));
    }
  } catch (err) {
    console.error('Failed to load branches:', err);
  }
}

function masterData() {
  return masterCache;
}

function masterOpts(id, items, placeholder, selected = '') {
  const e = document.getElementById(id);
  if (!e) return;
  e.innerHTML = '<option value="">' + placeholder + '</option>' + items.map(x => '<option value="' + esc(x) + '">' + esc(x) + '</option>').join('');
  if (selected) e.value = selected;
}

function masterRender() {
  const a = [...masterCache];
  const order = { Division: 1, District: 2, Thana: 3, Upazila: 4 };
  a.sort((x, y) => (order[x.type] - order[y.type]) || x.name.localeCompare(y.name));
  const el = document.getElementById('masterLocationRows');
  if (!el) return;
  el.innerHTML = a.map((x, i) => {
    const parent = [x.division, x.district, x.thana].filter(Boolean).join(' → ');
    return '<tr><td>' + String(i + 1).padStart(2, '0') + '</td><td><span class="badge badge-soft">' + esc(x.type) + '</span></td><td><b>' + esc(x.name) + '</b></td><td>' + esc(parent || '—') + '</td><td><span class="badge ' + (x.status === 'Active' ? 'bg-success' : 'bg-secondary') + '">' + esc(x.status) + '</span></td><td class="no-print"><div class="action-group"><button class="btn btn-light" onclick="masterView(\'' + x.id + '\')"><i data-lucide="eye"></i><span class="action-text">View</span></button><button class="btn btn-light" onclick="masterEdit(\'' + x.id + '\')"><i data-lucide="pencil"></i><span class="action-text">Edit</span></button><button class="btn btn-light text-danger" onclick="masterDelete(\'' + x.id + '\')"><i data-lucide="trash-2"></i><span class="action-text">Delete</span></button></div></td></tr>';
  }).join('');
  if (window.lucide) lucide.createIcons();
}

function masterRefreshParents(type, selected = {}) {
  const a = masterCache;
  masterOpts('masterDivision', a.filter(x => x.type === 'Division' && x.status === 'Active').map(x => x.name), 'Select Division', selected.division || '');
  masterOpts('masterDistrict', a.filter(x => x.type === 'District' && x.status === 'Active' && (!selected.division || x.division === selected.division)).map(x => x.name), 'Select District', selected.district || '');
  masterOpts('masterThana', a.filter(x => x.type === 'Thana' && x.status === 'Active' && (!selected.division || x.division === selected.division) && (!selected.district || x.district === selected.district)).map(x => x.name), 'Select Thana', selected.thana || '');
  document.getElementById('masterDivision').disabled = type === 'Division';
  document.getElementById('masterDistrict').disabled = type === 'Division' || type === 'District';
  document.getElementById('masterThana').disabled = type !== 'Upazila';
}

function masterOpen(id = '') {
  const x = id ? masterCache.find(a => a.id === id) : null;
  masterId.value = id;
  masterType.value = x?.type || 'Division';
  masterName.value = x?.name || '';
  masterStatus.value = x?.status || 'Active';
  masterRefreshParents(masterType.value, x || {});
  masterModalTitle.textContent = id ? 'Edit Administrative Location' : 'Add Administrative Location';
  bootstrap.Modal.getOrCreateInstance(masterLocationModal).show();
}

function masterEdit(id) {
  if (!MIS_hasPermission('location-branch', 'update') && !MIS_hasPermission('location-branch', 'edit')) return toast('Permission denied');
  masterOpen(id);
}

async function masterSave() {
  const id = masterId.value, type = masterType.value, action = id ? 'update' : 'create';
  if (!MIS_hasPermission('location-branch', action)) return toast('Permission denied');
  const name = masterName.value.trim();
  if (!name) return toast('Location name is required');

  const payload = {
    type,
    name,
    division: type === 'Division' ? '' : masterDivision.value,
    district: type === 'Division' || type === 'District' ? '' : masterDistrict.value,
    thana: type === 'Upazila' ? masterThana.value : '',
    status: masterStatus.value
  };

  try {
    if (id) {
      await axios.put('/api/location-branch/administrative/' + id, payload);
      toast('Administrative location updated successfully');
    } else {
      await axios.post('/api/location-branch/administrative', payload);
      toast('Administrative location added successfully');
    }
    bootstrap.Modal.getInstance(masterLocationModal).hide();
    await masterFetch();
    locRender();
  } catch (err) {
    const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to save location';
    toast(msg);
  }
}

function masterView(id) {
  const x = masterCache.find(a => a.id === id);
  if (!x) return;
  masterViewBody.innerHTML = '<div class="row g-3">' + [
    ['Type', x.type],
    ['Name', x.name],
    ['Division', x.division],
    ['District', x.district],
    ['Thana', x.thana],
    ['Status', x.status]
  ].map(v => '<div class="col-md-6"><div class="border rounded-3 p-3 h-100"><div class="muted small">' + esc(v[0]) + '</div><b>' + esc(v[1] || '—') + '</b></div></div>').join('') + '</div>';
  bootstrap.Modal.getOrCreateInstance(masterViewModal).show();
}

async function masterDelete(id) {
  if (!MIS_hasPermission('location-branch', 'delete')) return toast('Permission denied');
  const x = masterCache.find(a => a.id === id);
  if (!x || !confirm('Delete ' + x.type + ' "' + x.name + '"?')) return;

  try {
    await axios.delete('/api/location-branch/administrative/' + id);
    toast('Administrative location deleted successfully');
    await masterFetch();
    locRender();
  } catch (err) {
    const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to delete location';
    toast(msg);
  }
}

function locData() {
  return locCache;
}

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m] || m));
}

function uniq(a) {
  return [...new Set(a.filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

function opts(id, items, placeholder, selected = '') {
  const e = document.getElementById(id);
  if (!e) return;
  e.innerHTML = '<option value="">' + placeholder + '</option>' + items.map(x => '<option value="' + esc(x) + '">' + esc(x) + '</option>').join('');
  if (selected) e.value = selected;
}

function fillFilters() {
  const a = masterCache.filter(x => x.status === 'Active');
  const d = fDiv.value, dt = fDist.value, t = fThana.value, u = fUpa.value;
  opts('fDiv', uniq(a.filter(x => x.type === 'Division').map(x => x.name)), 'All Divisions', d);
  opts('fDist', uniq(a.filter(x => x.type === 'District' && (!d || x.division === d)).map(x => x.name)), 'All Districts', dt);
  opts('fThana', uniq(a.filter(x => x.type === 'Thana' && (!d || x.division === d) && (!dt || x.district === dt)).map(x => x.name)), 'All Thana', t);
  opts('fUpa', uniq(a.filter(x => x.type === 'Upazila' && (!d || x.division === d) && (!dt || x.district === dt) && (!t || x.thana === t)).map(x => x.name)), 'All Upazila', u);
}

let currentSort = { field: '', asc: true };
let locCurrentPage = 1;
let locPageSize = 25;

function locSortBy(field) {
  if (currentSort.field === field) {
    currentSort.asc = !currentSort.asc;
  } else {
    currentSort.field = field;
    currentSort.asc = true;
  }
  locRender();
}

function locChangePageSize(val) {
  locPageSize = val === 'all' ? 'all' : parseInt(val, 10);
  locCurrentPage = 1;
  locRender();
}

function locGoToPage(p) {
  locCurrentPage = p;
  locRender();
}

function renderPagination(total, start, end, totalPages) {
  const infoEl = document.getElementById('locPaginationInfo');
  const navEl = document.getElementById('locPaginationNav');
  if (!infoEl || !navEl) return;

  if (total === 0) {
    infoEl.textContent = 'Showing 0 to 0 of 0 records';
    navEl.innerHTML = '';
    return;
  }

  infoEl.textContent = 'Showing ' + (start + 1) + ' to ' + end + ' of ' + total + ' records';

  let html = '';
  html += '<li class="page-item ' + (locCurrentPage <= 1 ? 'disabled' : '') + '"><a class="page-link" href="javascript:void(0)" onclick="locGoToPage(' + (locCurrentPage - 1) + ')">&laquo;</a></li>';

  const startP = Math.max(1, locCurrentPage - 2);
  const endP = Math.min(totalPages, startP + 4);
  for (let p = startP; p <= endP; p++) {
    html += '<li class="page-item ' + (p === locCurrentPage ? 'active' : '') + '"><a class="page-link" href="javascript:void(0)" onclick="locGoToPage(' + p + ')">' + p + '</a></li>';
  }

  html += '<li class="page-item ' + (locCurrentPage >= totalPages ? 'disabled' : '') + '"><a class="page-link" href="javascript:void(0)" onclick="locGoToPage(' + (locCurrentPage + 1) + ')">&raquo;</a></li>';
  navEl.innerHTML = html;
}

function locRender() {
  fillFilters();
  const all = locCache;
  const d = fDiv.value, dt = fDist.value, t = fThana.value, u = fUpa.value, q = fSearch.value.toLowerCase().trim();
  let rows = all.filter(x => (!d || x.division === d) && (!dt || x.district === dt) && (!t || x.thana === t) && (!u || x.upazila === u) && (!q || Object.values(x).join(' ').toLowerCase().includes(q)));
  
  if (currentSort.field) {
    const f = currentSort.field;
    const mult = currentSort.asc ? 1 : -1;
    rows.sort((a, b) => {
      const va = (a[f] ?? '').toString().toLowerCase();
      const vb = (b[f] ?? '').toString().toLowerCase();
      return va.localeCompare(vb, undefined, { numeric: true }) * mult;
    });
  }

  ['division', 'district', 'thana', 'upazila', 'union_name', 'ward', 'branch', 'code', 'manager', 'status'].forEach(col => {
    const el = document.getElementById('sort_' + col);
    if (el) {
      if (currentSort.field === col) {
        el.textContent = currentSort.asc ? ' ▲' : ' ▼';
        el.className = 'text-primary small';
      } else {
        el.textContent = '';
      }
    }
  });

  const totalFiltered = rows.length;
  recordCount.textContent = totalFiltered + ' records';
  kDiv.textContent = masterCache.filter(x => x.type === 'Division' && x.status === 'Active').length;
  kDist.textContent = masterCache.filter(x => x.type === 'District' && x.status === 'Active').length;
  kUpa.textContent = masterCache.filter(x => x.type === 'Upazila' && x.status === 'Active').length;
  kBranch.textContent = all.length;

  const pageSize = locPageSize === 'all' ? totalFiltered : locPageSize;
  const totalPages = Math.max(1, Math.ceil(totalFiltered / (pageSize || 1)));
  if (locCurrentPage > totalPages) locCurrentPage = totalPages;
  if (locCurrentPage < 1) locCurrentPage = 1;

  const startIdx = locPageSize === 'all' ? 0 : (locCurrentPage - 1) * pageSize;
  const endIdx = locPageSize === 'all' ? totalFiltered : Math.min(startIdx + pageSize, totalFiltered);
  const pagedRows = rows.slice(startIdx, endIdx);

  locationRows.innerHTML = pagedRows.map((x, i) => '<tr><td>' + String(startIdx + i + 1).padStart(2, '0') + '</td><td>' + esc(x.division) + '</td><td>' + esc(x.district) + '</td><td>' + esc(x.thana) + '</td><td>' + esc(x.upazila) + '</td><td>' + esc(x.union_name || x.union || '') + '</td><td>' + esc(x.ward || '') + '</td><td><b>' + esc(x.branch) + '</b></td><td>' + esc(x.code) + '</td><td>' + esc(x.manager || '') + '</td><td>' + esc(x.mobile || '') + '</td><td>' + esc(x.personal_mobile || x.personalMobile || '') + '</td><td>' + esc(x.email || '') + '</td><td><span class="badge ' + (x.status === 'Active' ? 'bg-success' : x.status === 'Review' ? 'bg-warning text-dark' : 'bg-secondary') + '">' + esc(x.status) + '</span></td><td>' + esc(x.address || '') + '</td><td class="action-cell no-print"><div class="action-group"><button class="btn btn-light" onclick="locView(&quot;' + x.id + '&quot;)" title="View"><i data-lucide="eye"></i><span class="action-text">View</span></button><button class="btn btn-light" onclick="locEdit(&quot;' + x.id + '&quot;)" title="Edit"><i data-lucide="pencil"></i><span class="action-text">Edit</span></button><button class="btn btn-light" onclick="locApprove(&quot;' + x.id + '&quot;)" title="Change Status"><i data-lucide="check-circle"></i><span class="action-text">Status</span></button><button class="btn btn-light text-danger" onclick="locDelete(&quot;' + x.id + '&quot;)" title="Delete"><i data-lucide="trash-2"></i><span class="action-text">Delete</span></button></div></td></tr>').join('');

  renderPagination(totalFiltered, startIdx, endIdx, totalPages);
  locRenderTree();
  if (window.lucide) lucide.createIcons();
}

function locRenderTree() {
  const root = {};
  locCache.forEach(x => {
    root[x.division] ??= {};
    root[x.division][x.district] ??= {};
    root[x.division][x.district][x.thana] ??= {};
    root[x.division][x.district][x.thana][x.upazila] ??= [];
    root[x.division][x.district][x.thana][x.upazila].push(x);
  });
  function walk(o, l) {
    return Object.entries(o).map(([n, v]) => l === 3 ? '<li>▾ <b>' + esc(n) + '</b><ul>' + v.map(x => '<li>↳ ' + esc(x.branch) + ' <span class="muted small">(' + esc(x.code) + ')</span></li>').join('') + '</ul></li>' : '<li>▾ <b>' + esc(n) + '</b><ul>' + walk(v, l + 1) + '</ul></li>').join('');
  }
  locTree.innerHTML = Object.keys(root).length ? '<ul>' + walk(root, 0) + '</ul>' : '<div class="empty-note">No location records found.</div>';
}

function locCascade(div, dist, thana, upa) {
  const a = masterCache.filter(x => x.status === 'Active');
  opts('mDist', uniq(a.filter(x => x.type === 'District' && (!div || x.division === div)).map(x => x.name)), 'Select District', dist);
  opts('mThana', uniq(a.filter(x => x.type === 'Thana' && (!div || x.division === div) && (!dist || x.district === dist)).map(x => x.name)), 'Select Thana', thana);
  opts('mUpa', uniq(a.filter(x => x.type === 'Upazila' && (!div || x.division === div) && (!dist || x.district === dist) && (!thana || x.thana === thana)).map(x => x.name)), 'Select Upazila', upa);
}

function locOpen(id = '') {
  const x = id ? locCache.find(a => a.id === id) : null;
  locationModal.dataset.edit = id;
  opts('mDiv', uniq(masterCache.filter(a => a.type === 'Division' && a.status === 'Active').map(a => a.name)), 'Select Division', x?.division || '');
  locCascade(x?.division || '', x?.district || '', x?.thana || '', x?.upazila || '');
  
  [['mUnion', x?.union_name || x?.union || ''], ['mWard', x?.ward || ''], ['mBranch', x?.branch || ''], ['mCode', x?.code || ''], ['mManager', x?.manager || ''], ['mMobile', x?.mobile || ''], ['mPersonalMobile', x?.personal_mobile || x?.personalMobile || ''], ['mEmail', x?.email || ''], ['mStatus', x?.status || 'Active'], ['mAddress', x?.address || '']].forEach(([id, val]) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  });

  locModalTitle.textContent = id ? 'Edit Location & Branch' : 'Add Location & Branch';
  bootstrap.Modal.getOrCreateInstance(locationModal).show();
}

function locEdit(id) {
  if (!MIS_hasPermission('location-branch', 'update') && !MIS_hasPermission('location-branch', 'edit')) return toast('Permission denied');
  locOpen(id);
}

async function locSave() {
  const id = locationModal.dataset.edit, action = id ? 'update' : 'create';
  if (!MIS_hasPermission('location-branch', action)) return toast('Permission denied');

  const payload = {
    division: mDiv.value,
    district: mDist.value,
    thana: mThana.value,
    upazila: mUpa.value,
    union_name: mUnion.value.trim(),
    ward: mWard.value.trim(),
    branch: mBranch.value.trim(),
    code: mCode.value.trim(),
    manager: mManager.value.trim(),
    mobile: mMobile.value.trim(),
    personal_mobile: mPersonalMobile.value.trim(),
    email: mEmail.value.trim(),
    status: mStatus.value,
    address: mAddress.value.trim()
  };

  if (!payload.division || !payload.district || !payload.thana || !payload.upazila || !payload.branch || !payload.code) {
    return toast('Division, District, Thana, Upazila, Branch name, and Branch code are required');
  }

  try {
    if (id) {
      await axios.put('/api/location-branch/branches/' + id, payload);
      toast('Location updated successfully');
    } else {
      await axios.post('/api/location-branch/branches', payload);
      toast('Location added successfully');
    }
    bootstrap.Modal.getInstance(locationModal).hide();
    await locFetch();
  } catch (err) {
    const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to save branch';
    toast(msg);
  }
}

function locView(id) {
  const x = locCache.find(a => a.id === id);
  if (!x) return;
  viewLocationBody.innerHTML = '<div class="row g-3">' + [
    ['Division', x.division],
    ['District', x.district],
    ['Thana', x.thana],
    ['Upazila', x.upazila],
    ['Union / Municipality / City Corporation', x.union_name || x.union || '—'],
    ['Ward', x.ward || '—'],
    ['Branch', x.branch],
    ['Branch Code', x.code],
    ['Branch Manager', x.manager || '—'],
    ['Office Mobile', x.mobile || '—'],
    ['Personal Mobile', x.personal_mobile || x.personalMobile || '—'],
    ['Office Email', x.email || '—'],
    ['Status', x.status],
    ['Full Address', x.address || '—']
  ].map(v => '<div class="col-md-6"><div class="border rounded-3 p-3 h-100"><div class="muted small">' + esc(v[0]) + '</div><b>' + esc(v[1] || '—') + '</b></div></div>').join('') + '</div>';
  bootstrap.Modal.getOrCreateInstance(viewLocationModal).show();
}

async function locApprove(id) {
  if (!MIS_hasPermission('location-branch', 'approve')) return toast('Permission denied: approval rights required');
  const x = locCache.find(a => a.id === id);
  if (!x) return;
  const newStatus = x.status === 'Active' ? 'Inactive' : 'Active';
  if (!confirm('Change status of branch "' + x.branch + '" to ' + newStatus + '?')) return;

  try {
    await axios.post('/api/location-branch/branches/' + id + '/status', { status: newStatus });
    toast('Branch status changed to ' + newStatus);
    await locFetch();
  } catch (err) {
    const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to update status';
    toast(msg);
  }
}

async function locDelete(id) {
  if (!MIS_hasPermission('location-branch', 'delete')) return toast('Permission denied');
  const x = locCache.find(a => a.id === id);
  if (!x || !confirm('Delete ' + x.branch + '? This action cannot be undone.')) return;

  try {
    await axios.delete('/api/location-branch/branches/' + id);
    toast('Location deleted successfully');
    await locFetch();
  } catch (err) {
    const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to delete branch';
    toast(msg);
  }
}

function currentLocationRows() {
  const all = locCache;
  const d = fDiv.value, dt = fDist.value, t = fThana.value, u = fUpa.value, q = fSearch.value.toLowerCase().trim();
  return all.filter(x => (!d || x.division === d) && (!dt || x.district === dt) && (!t || x.thana === t) && (!u || x.upazila === u) && (!q || Object.values(x).join(' ').toLowerCase().includes(q)));
}

function locationReportRows() {
  return currentLocationRows().map((x, i) => [
    i + 1,
    x.division,
    x.district,
    x.thana,
    x.upazila,
    x.union_name || x.union || '',
    x.ward || '',
    x.branch,
    x.code,
    x.manager || '',
    x.mobile || '',
    x.personal_mobile || x.personalMobile || '',
    x.email || '',
    x.status,
    x.address || ''
  ]);
}

function printLocationReport() {
  if (!MIS_hasPermission('location-branch', 'print')) return toast('Permission denied: Print not allowed');
  const rows = locationReportRows(), w = window.open('', '_blank', 'width=1400,height=900');
  if (!w) return toast('Please allow pop-ups to print the report');
  axios.post('/api/location-branch/action', { action: 'print', reference: 'Printed Location & Branch directory report' }).catch(() => {});
  if (typeof MIS_addAudit === 'function') MIS_addAudit('location-branch', 'PRINT', 'Printed Location & Branch directory');
  w.document.write('<!doctype html><html><head><title>Location & Branch Records</title><style>body{font-family:Arial,sans-serif;margin:24px;color:#1f2937}h1{font-size:22px;margin:0 0 6px}p{color:#6b7280;font-size:12px;margin:0 0 16px}.meta{font-size:12px;margin-bottom:12px}table{width:100%;border-collapse:collapse;font-size:9px}th,td{border:1px solid #d1d5db;padding:5px;vertical-align:top}th{background:#eef5ff;text-align:left}tr:nth-child(even){background:#fafafa}@media print{body{margin:10mm}table{font-size:7px}}</style></head><body><h1>Location & Branch Records</h1><p>Complete report: Division → District → Thana → Upazila → Union / Municipality / City Corporation → Ward → Branch</p><div class="meta">Generated: ' + new Date().toLocaleString() + ' | Total Records: ' + rows.length + '</div><table><thead><tr><th>SL</th><th>Division</th><th>District</th><th>Thana</th><th>Upazila</th><th>Union / Municipality / City Corp.</th><th>Ward</th><th>Branch</th><th>Code</th><th>Manager</th><th>Office Mobile</th><th>Personal Mobile</th><th>Email</th><th>Status</th><th>Full Address</th></tr></thead><tbody>' + rows.map(r => '<tr>' + r.map(v => '<td>' + esc(v) + '</td>').join('') + '</tr>').join('') + '</tbody></table></body></html>');
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 250);
}

function downloadLocationPDF() {
  if (!MIS_hasPermission('location-branch', 'export')) return toast('Permission denied: Export not allowed');
  axios.post('/api/location-branch/action', { action: 'export', reference: 'Exported Location & Branch PDF report' }).catch(() => {});
  if (typeof MIS_addAudit === 'function') MIS_addAudit('location-branch', 'EXPORT', 'Exported Location & Branch PDF');
  if (!window.jspdf) return printLocationReport();
  const rows = locationReportRows();
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a3' });
  doc.setFontSize(16);
  doc.text('Location & Branch Records', 36, 32);
  doc.setFontSize(9);
  doc.text('Division → District → Thana → Upazila → Union / Municipality / City Corporation → Ward → Branch', 36, 48);
  doc.text('Generated: ' + new Date().toLocaleString() + ' | Total Records: ' + rows.length, 36, 62);
  doc.autoTable({
    startY: 72,
    head: [['SL', 'Division', 'District', 'Thana', 'Upazila', 'Union / Municipality / City Corp.', 'Ward', 'Branch', 'Code', 'Manager', 'Office Mobile', 'Personal Mobile', 'Email', 'Status', 'Full Address']],
    body: rows.map(r => r.map(v => String(v ?? ''))),
    styles: { fontSize: 7, cellPadding: 3, overflow: 'linebreak' },
    headStyles: { fontSize: 7 },
    margin: { left: 24, right: 24 },
    theme: 'grid'
  });
  doc.save('location-branch-records.pdf');
}

function downloadLocationExcel() {
  if (!MIS_hasPermission('location-branch', 'export')) return toast('Permission denied: Export not allowed');
  axios.post('/api/location-branch/action', { action: 'export', reference: 'Exported Location & Branch Excel file' }).catch(() => {});
  if (typeof MIS_addAudit === 'function') MIS_addAudit('location-branch', 'EXPORT', 'Exported Location & Branch Excel');
  if (typeof XLSX === 'undefined') return locExport();
  const data = locationReportRows().map(r => ({
    'SL': r[0],
    'Division': r[1],
    'District': r[2],
    'Thana': r[3],
    'Upazila': r[4],
    'Union / Municipality / City Corporation': r[5],
    'Ward': r[6],
    'Branch Name': r[7],
    'Branch Code': r[8],
    'Branch Manager': r[9],
    'Office Mobile': r[10],
    'Personal Mobile': r[11],
    'Office Email': r[12],
    'Status': r[13],
    'Full Address': r[14]
  }));
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Location & Branch Records');
  XLSX.writeFile(wb, 'location-branch-records.xlsx');
}

function locExport() {
  if (!MIS_hasPermission('location-branch', 'export')) return toast('Permission denied');
  axios.post('/api/location-branch/action', { action: 'export', reference: 'Exported Location & Branch CSV directory' }).catch(() => {});
  if (typeof MIS_addAudit === 'function') MIS_addAudit('location-branch', 'EXPORT', 'Exported Location & Branch CSV');
  const keys = ['division', 'district', 'thana', 'upazila', 'union_name', 'ward', 'branch', 'code', 'manager', 'mobile', 'personal_mobile', 'email', 'status', 'address'];
  const csv = [keys, ...locCache.map(x => keys.map(k => x[k] || ''))].map(r => r.map(v => '"' + String(v).replaceAll('"', '""') + '"').join(',')).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = 'location-branch-directory.csv';
  a.click();
}

document.addEventListener('DOMContentLoaded', async () => {
  await masterFetch();
  await locFetch();
  ['fDiv', 'fDist', 'fThana', 'fUpa', 'fSearch'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', locRender);
      el.addEventListener('change', locRender);
    }
  });
  mDiv.addEventListener('change', () => locCascade(mDiv.value, '', '', ''));
  mDist.addEventListener('change', () => locCascade(mDiv.value, mDist.value, '', ''));
  mThana.addEventListener('change', () => locCascade(mDiv.value, mDist.value, mThana.value, ''));
  masterType.addEventListener('change', () => masterRefreshParents(masterType.value, { division: masterDivision.value, district: masterDistrict.value, thana: masterThana.value }));
  masterDivision.addEventListener('change', () => masterRefreshParents(masterType.value, { division: masterDivision.value, district: '', thana: '' }));
  masterDistrict.addEventListener('change', () => masterRefreshParents(masterType.value, { division: masterDivision.value, district: masterDistrict.value, thana: '' }));
});
</script>
</body></html>