<!DOCTYPE html>

<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"/>
  <meta name=\"csrf-token\" content=\"{{ csrf_token() }}\"><meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>Report Requests | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link href="{{ asset('assets/css/app.css') }}" rel="stylesheet"/><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="report-requests">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i class="text-primary" data-lucide="database"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Report Requests</h1></div></div>
<div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="mb-4"><h2 class="page-title h3">Report Requests</h2><p class="muted">Receive, assign, track and deliver MIS report requests.</p></div>
<div class="cardx p-3 mb-3 d-flex flex-wrap align-items-center justify-content-between gap-3">
  <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#checkedFormModal"><i data-lucide="plus" class="me-1"></i>New Report Request</button>
  <div class="d-flex align-items-center gap-2">
    <input type="text" class="form-control form-control-sm" id="reportSearch" placeholder="Search requests..." oninput="renderReportRequests()">
    <select class="form-select form-select-sm" id="reportStatusFilter" onchange="renderReportRequests()" style="min-width: 140px;">
      <option value="">All Statuses</option>
      <option value="New">New</option>
      <option value="Assigned">Assigned</option>
      <option value="Processing">Processing</option>
      <option value="Review">Review</option>
      <option value="Completed">Completed</option>
      <option value="Delivered">Delivered</option>
    </select>
  </div>
</div>
<div class="cardx p-3">
  <div class="table-responsive responsive-table">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Request ID</th>
          <th>Requested By</th>
          <th>Report</th>
          <th>Due Date</th>
          <th>Priority</th>
          <th>Status</th>
          <th class="action-cell actions-head text-end">Action</th>
        </tr>
      </thead>
      <tbody id="reportRequestsBody">
      </tbody>
    </table>
  </div>
</div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a></div></div>
<div class="toast position-fixed bottom-0 end-0 m-3" id="toast"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<div aria-hidden="true" class="modal fade" id="checkedFormModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable">
<div class="modal-content border-0 shadow">
<div class="modal-header bg-primary text-white">
<div><h5 class="modal-title">Create / Update Report Requests</h5><small>Receive and track customized management reports</small></div>
<button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button"></button>
</div>
<form id="reportRequestForm" onsubmit="event.preventDefault(); saveReportRequest();">
<div class="modal-body"><div class="row g-3">
<div class="col-md-6"><label class="form-label fw-semibold">Requester Name</label><input class="form-control" id="reqName" placeholder="Requester Name" type="text" required/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Requester Department</label><input class="form-control" id="reqDepartment" placeholder="Department" type="text" required/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Required Report</label><input class="form-control" id="reqReport" placeholder="Report Name" type="text" required/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Request Date</label><input class="form-control" id="reqDate" type="date" required/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Deadline</label><input class="form-control" id="reqDeadline" type="date" required/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Priority</label><select class="form-select" id="reqPriority" required><option value="Normal">Normal</option><option value="High">High</option><option value="Urgent">Urgent</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Assigned To</label><input class="form-control" id="reqAssigned" placeholder="Assigned User" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Status</label><select class="form-select" id="reqStatus"><option value="New">New</option><option value="Assigned">Assigned</option><option value="Processing">Processing</option><option value="Review">Review</option><option value="Completed">Completed</option><option value="Delivered">Delivered</option></select></div>
<div class="col-12"><label class="form-label fw-semibold">Remarks</label><textarea class="form-control" id="reqRemarks" placeholder="Remarks and specific filters or column requirements..." rows="3"></textarea></div></div></div>
<div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal" type="button">Cancel</button><button class="btn btn-primary" type="submit">Save</button></div>
</form>
</div>
</div>
</div>
<script>
const REQ_KEY = 'mis_report_requests_v1';
const defaultRequests = [
  { id: 'REQ-2026-0912', requester: 'Management', department: 'Executive', report: 'District-wise Branch Summary', requestDate: '2026-09-08', deadline: '2026-09-13', priority: 'High', assigned: 'MIS Officer', status: 'Processing', remarks: 'Need updated figures for Bogura and Dhaka.' },
  { id: 'REQ-2026-0911', requester: 'HR Department', department: 'Human Resources', report: 'Staff Position List', requestDate: '2026-09-09', deadline: '2026-09-15', priority: 'Normal', assigned: 'MIS Senior Analyst', status: 'Completed', remarks: 'Include home districts and current posting.' }
];

function getRequests() {
  try {
    const raw = localStorage.getItem(REQ_KEY);
    return raw ? JSON.parse(raw) : defaultRequests;
  } catch (e) {
    return defaultRequests;
  }
}

function saveRequests(list) {
  localStorage.setItem(REQ_KEY, JSON.stringify(list));
}

function badgePriority(p) {
  if (p === 'Urgent') return '<span class="badge bg-danger">Urgent</span>';
  if (p === 'High') return '<span class="badge bg-danger">High</span>';
  return '<span class="badge bg-secondary">Normal</span>';
}

function badgeStatus(s) {
  if (s === 'Completed' || s === 'Delivered') return `<span class="badge bg-success">${s}</span>`;
  if (s === 'Processing' || s === 'Review') return `<span class="badge bg-warning text-dark">${s}</span>`;
  return `<span class="badge bg-info text-dark">${s}</span>`;
}

function renderReportRequests() {
  const tbody = document.getElementById('reportRequestsBody');
  if (!tbody) return;
  const q = (document.getElementById('reportSearch')?.value || '').toLowerCase();
  const sf = document.getElementById('reportStatusFilter')?.value || '';
  
  const list = getRequests().filter(r => {
    if (sf && r.status !== sf) return false;
    if (!q) return true;
    return (r.id + ' ' + r.requester + ' ' + r.report + ' ' + (r.department||'') + ' ' + (r.assigned||'')).toLowerCase().includes(q);
  });

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No report requests match your criteria.</td></tr>';
    return;
  }

  tbody.innerHTML = list.map(r => `
    <tr>
      <td><strong>${r.id}</strong></td>
      <td>${r.requester} <span class="small text-muted d-block">${r.department || ''}</span></td>
      <td>${r.report}</td>
      <td>${r.deadline || '-'}</td>
      <td>${badgePriority(r.priority)}</td>
      <td>${badgeStatus(r.status)}</td>
      <td class="action-cell actions-head text-end">
        <button class="btn btn-sm btn-outline-danger" onclick="deleteRequest('${r.id}')" title="Delete">
          <i data-lucide="trash-2" style="width:14px;height:14px"></i>
        </button>
      </td>
    </tr>
  `).join('');

  if (window.lucide) lucide.createIcons();
}

function saveReportRequest() {
  const newReq = {
    id: 'REQ-2026-' + Math.floor(1000 + Math.random() * 9000),
    requester: document.getElementById('reqName').value.trim(),
    department: document.getElementById('reqDepartment').value.trim(),
    report: document.getElementById('reqReport').value.trim(),
    requestDate: document.getElementById('reqDate').value,
    deadline: document.getElementById('reqDeadline').value,
    priority: document.getElementById('reqPriority').value,
    assigned: document.getElementById('reqAssigned').value.trim(),
    status: document.getElementById('reqStatus').value,
    remarks: document.getElementById('reqRemarks').value.trim()
  };

  const list = getRequests();
  list.unshift(newReq);
  saveRequests(list);

  if (typeof MIS_addAudit === 'function') {
    MIS_addAudit('Report Requests', 'CREATE', `${newReq.id} - ${newReq.report}`);
  }

  toast('Report request saved successfully');
  bootstrap.Modal.getInstance(document.getElementById('checkedFormModal')).hide();
  document.getElementById('reportRequestForm').reset();
  renderReportRequests();
}

function deleteRequest(id) {
  if (!confirm('Are you sure you want to delete report request ' + id + '?')) return;
  const list = getRequests().filter(r => r.id !== id);
  saveRequests(list);
  if (typeof MIS_addAudit === 'function') {
    MIS_addAudit('Report Requests', 'DELETE', id);
  }
  toast('Request deleted');
  renderReportRequests();
}

document.addEventListener('DOMContentLoaded', () => {
  renderReportRequests();
  const d = document.querySelector('#checkedFormModal #reqDate');
  if (d && !d.value) d.value = new Date().toISOString().slice(0, 10);
});
</script></body></html>