<!doctype html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Backup & Settings | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link rel="stylesheet" href="{{ asset('assets/css/app.css') }}"><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="backup-settings">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
  <div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div>
  <div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
 <div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Backup & Settings</h1></div></div>
 <div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="mb-4"><h2 class="page-title h3">Backup & System Settings</h2><p class="muted">System configuration, database backup, and Login Page branding personalization for Super Admin.</p></div>

<!-- Super Admin Branding Customization Section -->
<div class="cardx p-4 mb-4 border-primary shadow-sm" style="border-left: 5px solid #2ecc71;">
  <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <div>
      <h4 class="h5 fw-bold mb-1 text-slate-800 d-flex align-items-center gap-2">
        <i data-lucide="palette" class="text-success"></i> লগইন পেজ ও ব্র্যান্ডিং কাস্টমাইজেশন (Login Page & Branding)
      </h4>
      <p class="small text-muted mb-0">সুপার এডমিন এখান থেকে লগইন পেজের শিরোনাম, সাবটাইটেল, লোগো এবং হিরো ইমেজ পরিবর্তন করতে পারবেন।</p>
    </div>
    <span class="badge bg-emerald-100 text-emerald-800 border border-emerald-300 px-3 py-1.5 rounded-full text-xs font-semibold">
      Super Admin Access Only
    </span>
  </div>

  <div class="row g-4">
    <!-- Left form controls -->
    <div class="col-lg-7">
      <form id="brandingForm" onsubmit="event.preventDefault(); saveBrandingSettings();">
        <div class="mb-3">
          <label class="form-label fw-semibold small text-slate-700">অ্যাপ্লিকেশনের নাম (App Name)</label>
          <input type="text" id="brandAppName" class="form-control" placeholder="Management Information System" required>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold small text-slate-700">লগইন ব্যানারের প্রধান শিরোনাম (Login Hero Title)</label>
          <input type="text" id="brandLoginTitle" class="form-control" placeholder="Welcome to Management Information System" required>
          <div class="form-text small">ছবিটির উপর বড় করে প্রদর্শিত শিরোনাম।</div>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold small text-slate-700">সাবটাইটেল / বিবরণ (Login Subtitle)</label>
          <textarea id="brandLoginSubtitle" class="form-control" rows="2" placeholder="Manage your management information system efficiently and effectively."></textarea>
        </div>

        <div class="row g-3 mb-3">
          <div class="col-md-6">
            <label class="form-label fw-semibold small text-slate-700">ব্র্যান্ডের মূল রঙ (Primary Brand Color)</label>
            <div class="d-flex align-items-center gap-2">
              <input type="color" id="brandColorPicker" class="form-control form-control-color" value="#2ecc71" style="width: 50px; height: 40px; cursor: pointer;">
              <input type="text" id="brandColorHex" class="form-control" value="#2ecc71" style="font-family: monospace;">
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold small text-slate-700">লগইন প্রিভিউ লিংক</label>
            <div class="pt-1">
              <a href="/login" target="_blank" class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-center gap-1.5">
                <i data-lucide="external-link" style="width: 16px;"></i> লগইন পেজ দেখুন (Open)
              </a>
            </div>
          </div>
        </div>

        <!-- Logo Upload & URL -->
        <div class="p-3 mb-3 bg-light rounded-3 border">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <label class="form-label fw-semibold small text-slate-700 mb-0">প্রতিষ্ঠানের লোগো (Brand Logo)</label>
            <button type="button" class="btn btn-link btn-sm p-0 text-decoration-none text-muted" onclick="resetDefaultLogo()">ডিফল্ট TMSS লোগো</button>
          </div>
          <div class="d-flex gap-2 mb-2">
            <input type="text" id="brandLogoUrl" class="form-control form-control-sm" placeholder="/assets/images/tmss-logo.png">
            <label class="btn btn-sm btn-primary mb-0 d-flex align-items-center gap-1 cursor-pointer" style="white-space: nowrap;">
              <i data-lucide="upload" style="width: 14px;"></i> আপলোড
              <input type="file" id="logoFileInput" accept="image/*" class="d-none" onchange="uploadAssetFile('logo')">
            </label>
          </div>
          <div class="small text-muted">সুপারিশ: স্বচ্ছ ব্যাকগ্রাউন্ডের PNG বা SVG (যেমন TMSS গ্রিন লোগো)।</div>
        </div>

        <!-- Hero Illustration Image Upload & URL -->
        <div class="p-3 mb-3 bg-light rounded-3 border">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <label class="form-label fw-semibold small text-slate-700 mb-0">হিরো ব্যানার ভেক্টর ছবি (Hero Illustration Image)</label>
            <button type="button" class="btn btn-link btn-sm p-0 text-decoration-none text-muted" onclick="resetDefaultHero()">ডিফল্ট অ্যানালিটিক্স ছবি</button>
          </div>
          <div class="d-flex gap-2 mb-2">
            <input type="text" id="brandHeroUrl" class="form-control form-control-sm" placeholder="/assets/images/login-hero.jpg">
            <label class="btn btn-sm btn-primary mb-0 d-flex align-items-center gap-1 cursor-pointer" style="white-space: nowrap;">
              <i data-lucide="upload" style="width: 14px;"></i> আপলোড
              <input type="file" id="heroFileInput" accept="image/*" class="d-none" onchange="uploadAssetFile('hero')">
            </label>
          </div>
          <div class="small text-muted">সুপারিশ: হাই রেজুলুশন কর্পোরেট ড্যাশবোর্ড / মিটিং ভেক্টর চিত্র (JPG/PNG)।</div>
        </div>

        <div class="d-flex gap-2 mt-3">
          <button type="submit" id="btnSaveBranding" class="btn btn-success d-flex align-items-center gap-2">
            <i data-lucide="save" style="width: 16px;"></i> পরিবর্তন সেভ করুন (Save Changes)
          </button>
          <button type="button" class="btn btn-outline-secondary" onclick="restoreBrandingDefaults()">
            ডিফল্ট রিস্টোর করুন
          </button>
        </div>
      </form>
    </div>

    <!-- Right Live Preview Miniature -->
    <div class="col-lg-5">
      <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden bg-white">
        <div class="card-header bg-slate-900 text-white py-2 px-3 d-flex justify-content-between align-items-center">
          <span class="small fw-semibold d-flex align-items-center gap-1.5">
            <i data-lucide="eye" style="width: 14px;"></i> লাইভ প্রিভিউ (Live Preview)
          </span>
          <span class="badge bg-slate-700 text-slate-300 text-xs">Login Screen</span>
        </div>
        <div class="card-body p-2 d-flex flex-column" style="min-height: 380px; background: #f8fafc;">
          <!-- Miniature card -->
          <div class="rounded-3 border overflow-hidden shadow-sm d-flex flex-row flex-grow-1" style="min-height: 340px;">
            <!-- Miniature left hero -->
            <div id="prevHeroBox" class="p-3 text-white d-flex flex-column justify-content-center text-center position-relative" style="flex: 1.2; background-size: cover; background-position: center; background-repeat: no-repeat;">
              <div style="position: absolute; inset: 0; background: rgba(15,23,42,0.45);"></div>
              <div class="position-relative" style="z-index: 2;">
                <h6 id="prevTitle" class="fw-bold mb-1 text-white" style="font-size: 0.95rem; text-shadow: 0 1px 4px rgba(0,0,0,0.8);">
                  Welcome to Management Information System
                </h6>
                <p id="prevSubtitle" class="small mb-0 text-white-50" style="font-size: 0.72rem; line-height: 1.3;">
                  Manage your management information system efficiently and effectively.
                </p>
              </div>
            </div>
            <!-- Miniature right form -->
            <div class="p-3 bg-white d-flex flex-column justify-content-center align-items-center" style="flex: 1;">
              <img id="prevLogo" src="/assets/images/tmss-logo.png" alt="Logo" style="height: 52px; width: auto; object-fit: contain;" class="mb-3">
              
              <div class="w-100 mb-2">
                <div class="text-muted" style="font-size: 8px; font-weight: 700;">USERNAME</div>
                <div class="border rounded px-2 py-1 text-muted" style="font-size: 10px; background: #fff;">Enter your username</div>
              </div>
              <div class="w-100 mb-2">
                <div class="text-muted" style="font-size: 8px; font-weight: 700;">PASSWORD</div>
                <div class="border rounded px-2 py-1 text-muted" style="font-size: 10px; background: #fff;">••••••••</div>
              </div>
              <div class="w-100 d-flex justify-content-between mb-3" style="font-size: 8px;">
                <span class="text-muted">☑ Remember Me</span>
                <span class="text-muted">Forgot?</span>
              </div>
              <button id="prevBtn" type="button" class="btn btn-sm text-white w-100 py-1" style="background: #2ecc71; font-size: 11px; font-weight: 600; border-radius: 4px;">
                Sign in
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3"><div class="col-xl-6"><div class="cardx p-4"><h5>Backup</h5><div class="row g-3"><div class="col-6"><label class="form-label">Backup Frequency</label><select class="form-select"><option>Daily</option><option>Weekly</option></select></div><div class="col-6"><label class="form-label">Retention</label><select class="form-select"><option>30 Days</option><option>90 Days</option></select></div></div><button class="btn btn-primary mt-3" onclick="toast('Backup settings saved')">Save Settings</button></div></div><div class="col-xl-6"><div class="cardx p-4"><h5>System Preferences</h5><div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Enable notification alerts</label></div><div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Require approval for submitted reports</label></div><button class="btn btn-outline-primary" onclick="toast('Preferences saved')">Save Preferences</button></div></div></div>
</div>

<script>
// Branding Management Logic
let currentBranding = {
  app_name: 'Management Information System',
  login_title: 'Welcome to Management Information System',
  login_subtitle: 'Manage your management information system efficiently and effectively.',
  login_hero_image: '/assets/images/login-hero.jpg',
  login_logo: '/assets/images/tmss-logo.png',
  brand_color: '#2ecc71'
};

async function loadBrandingSettings() {
  try {
    const res = await axios.get('/api/settings/branding');
    if (res.data && res.data.branding) {
      currentBranding = { ...currentBranding, ...res.data.branding };
    }
  } catch(e) {
    console.warn('Could not load remote branding, using current/defaults');
  }
  syncFormToState();
  updateLivePreview();
}

function syncFormToState() {
  document.getElementById('brandAppName').value = currentBranding.app_name || '';
  document.getElementById('brandLoginTitle').value = currentBranding.login_title || '';
  document.getElementById('brandLoginSubtitle').value = currentBranding.login_subtitle || '';
  document.getElementById('brandLogoUrl').value = currentBranding.login_logo || '';
  document.getElementById('brandHeroUrl').value = currentBranding.login_hero_image || '';
  document.getElementById('brandColorPicker').value = currentBranding.brand_color || '#2ecc71';
  document.getElementById('brandColorHex').value = currentBranding.brand_color || '#2ecc71';
}

function updateLivePreview() {
  const title = document.getElementById('brandLoginTitle').value || currentBranding.login_title;
  const subtitle = document.getElementById('brandLoginSubtitle').value || currentBranding.login_subtitle;
  const logo = document.getElementById('brandLogoUrl').value || currentBranding.login_logo;
  const hero = document.getElementById('brandHeroUrl').value || currentBranding.login_hero_image;
  const color = document.getElementById('brandColorHex').value || currentBranding.brand_color;

  document.getElementById('prevTitle').textContent = title;
  document.getElementById('prevSubtitle').textContent = subtitle;
  document.getElementById('prevLogo').src = logo;
  document.getElementById('prevHeroBox').style.backgroundImage = `url('${hero}')`;
  document.getElementById('prevBtn').style.background = color;
}

// Bind live changes
['brandLoginTitle', 'brandLoginSubtitle', 'brandLogoUrl', 'brandHeroUrl'].forEach(id => {
  document.getElementById(id).addEventListener('input', updateLivePreview);
});

document.getElementById('brandColorPicker').addEventListener('input', (e) => {
  document.getElementById('brandColorHex').value = e.target.value;
  updateLivePreview();
});
document.getElementById('brandColorHex').addEventListener('input', (e) => {
  if(/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) {
    document.getElementById('brandColorPicker').value = e.target.value;
    updateLivePreview();
  }
});

function resetDefaultLogo() {
  document.getElementById('brandLogoUrl').value = '/assets/images/tmss-logo.png';
  updateLivePreview();
}

function resetDefaultHero() {
  document.getElementById('brandHeroUrl').value = '/assets/images/login-hero.jpg';
  updateLivePreview();
}

function restoreBrandingDefaults() {
  currentBranding = {
    app_name: 'Management Information System',
    login_title: 'Welcome to Management Information System',
    login_subtitle: 'Manage your management information system efficiently and effectively.',
    login_hero_image: '/assets/images/login-hero.jpg',
    login_logo: '/assets/images/tmss-logo.png',
    brand_color: '#2ecc71'
  };
  syncFormToState();
  updateLivePreview();
  toast('Defaults restored. Click Save to apply.');
}

async function uploadAssetFile(type) {
  const input = type === 'logo' ? document.getElementById('logoFileInput') : document.getElementById('heroFileInput');
  if (!input.files || !input.files[0]) return;

  const file = input.files[0];
  const formData = new FormData();
  formData.append('asset_file', file);
  formData.append('type', type);

  toast('Uploading image...');
  try {
    const res = await axios.post('/api/settings/upload-branding-asset', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    if (res.data && res.data.url) {
      if (type === 'logo') {
        document.getElementById('brandLogoUrl').value = res.data.url;
      } else {
        document.getElementById('brandHeroUrl').value = res.data.url;
      }
      updateLivePreview();
      toast('Image uploaded successfully!');
    }
  } catch(err) {
    alert(err.response?.data?.error || 'Upload failed. Only PNG, JPG, SVG, WebP supported.');
  }
}

async function saveBrandingSettings() {
  const btn = document.getElementById('btnSaveBranding');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Saving...';

  const payload = {
    app_name: document.getElementById('brandAppName').value.trim(),
    login_title: document.getElementById('brandLoginTitle').value.trim(),
    login_subtitle: document.getElementById('brandLoginSubtitle').value.trim(),
    login_logo: document.getElementById('brandLogoUrl').value.trim(),
    login_hero_image: document.getElementById('brandHeroUrl').value.trim(),
    brand_color: document.getElementById('brandColorHex').value.trim(),
  };

  try {
    const res = await axios.post('/api/settings/branding', payload);
    toast(res.data.message || 'লগইন ব্র্যান্ডিং সেটিংস সফলভাবে সংরক্ষিত হয়েছে!');
  } catch(err) {
    alert(err.response?.data?.message || 'Error saving branding settings.');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i data-lucide="save" style="width: 16px;"></i> পরিবর্তন সেভ করুন (Save Changes)';
    lucide.createIcons();
  }
}

// Initial load
document.addEventListener('DOMContentLoaded', () => {
  loadBrandingSettings();
});
</script>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a></div></div>
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>