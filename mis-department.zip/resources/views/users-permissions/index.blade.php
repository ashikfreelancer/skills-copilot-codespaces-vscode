<!doctype html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Users & Permissions | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><script src="https://cdn.tailwindcss.com"></script><script>tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}</script><script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script><script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script><script src="https://unpkg.com/lucide@latest"></script><link rel="stylesheet" href="{{ asset('assets/css/app.css') }}">
<style>.permission-table th,.permission-table td{vertical-align:middle;white-space:nowrap;font-size:13px;padding:8px 10px}.permission-table input{width:16px;height:16px;cursor:pointer}.role-card{border:1px solid #e5eaf1;border-radius:14px;padding:14px;background:#fff}.scope-box{background:#f8fafc;border:1px solid #e8edf3;border-radius:12px;padding:14px}.sticky-actions{position:sticky;right:0;background:#fff;box-shadow:-5px 0 10px rgba(15,23,42,.05)}@media print{.desktop-sidebar,.topbar,.no-print,.offcanvas,.modal,#toast{display:none!important}.col-lg-10{width:100%!important}}
#userModal .modal-dialog{height:calc(100vh - 1rem);max-height:calc(100vh - 1rem);margin:.5rem auto;}
#userModal .modal-content{height:100%;max-height:100%;display:flex;flex-direction:column;overflow:hidden;}
#userModal #userForm{min-height:0;display:flex;flex:1 1 auto;flex-direction:column;overflow:hidden;}
#userModal #userForm .modal-body{min-height:0;flex:1 1 auto;overflow-y:auto;overflow-x:hidden;}
#userModal .modal-footer{flex:0 0 auto;}
@media(max-width:575.98px){
 #userModal .modal-dialog{height:calc(100vh - .5rem);max-height:calc(100vh - .5rem);margin:.25rem auto;}
 #userModal .modal-footer .btn{flex:1 1 auto;}
}
</style><script src="{{ asset('assets/js/app.js') }}"></script></head><script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script><body data-page="users-permissions"><div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3"><div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div><div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i>MIS Reports</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined"></i>Analytics</a><div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target"></i>Target & Activity</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings"></i>Backup & Settings</a></aside>
<main class="col-lg-10"><header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4"><div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Users & Permissions</h1></div></div><div class="d-flex align-items-center gap-2">
<div class="dropdown no-print">
  <button class="btn btn-sm btn-outline-primary dropdown-toggle d-flex align-items-center gap-1" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    <span class="badge bg-primary" id="activeRoleBadge">Super Admin</span> <span class="d-none d-md-inline small">Role Simulation</span>
  </button>
  <ul class="dropdown-menu dropdown-menu-end shadow border-0 p-2">
    <li><h6 class="dropdown-header text-uppercase small fw-bold">Switch Role Simulation</h6></li>
    <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Super Admin')"><div class="fw-bold">Super Admin</div><div class="text-muted small">Full system access to all modules & actions</div></button></li>
    <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Admin')"><div class="fw-bold">Admin</div><div class="text-muted small">Manage operations, no delete on other admins</div></button></li>
    <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Accountant')"><div class="fw-bold">Accountant</div><div class="text-muted small">Advance, Stock, Reports (Blocked on Users & Settings)</div></button></li>
    <li><button class="dropdown-item rounded-2 py-2" onclick="MIS_switchRole('Computer Operator')"><div class="fw-bold">Computer Operator</div><div class="text-muted small">Data Entry & Registries (No approve/reject/delete)</div></button></li>
  </ul>
</div>
<button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div></header>
<div class="p-3 p-lg-4"><div class="d-flex justify-content-between flex-wrap gap-3 mb-4"><div><h2 class="page-title h3">Users & Permissions</h2><p class="muted mb-0">Role & Permission System backed by Laravel-native Middleware, Gates, Policies, and Security Audit Logging.</p></div><button class="btn btn-primary no-print" onclick="openUserModal()"><i data-lucide="user-plus"></i> Add User</button></div>
<div class="row g-3 mb-3"><div class="col-md-3"><div class="role-card"><div class="muted small">Total Users</div><div id="userCount" class="fs-3 fw-bold">0</div></div></div><div class="col-md-3"><div class="role-card"><div class="muted small">Active Accounts</div><div id="activeCount" class="fs-3 fw-bold">0</div></div></div><div class="col-md-3"><div class="role-card"><div class="muted small">Super Admins</div><div id="adminCount" class="fs-3 fw-bold">0</div></div></div><div class="col-md-3"><div class="role-card"><div class="muted small">Configured Roles</div><div class="fs-3 fw-bold">4</div></div></div></div>
<div class="cardx p-3"><div class="d-flex justify-content-between align-items-center mb-3"><b>User Access Register</b><input id="userSearch" class="form-control form-control-sm no-print" style="max-width:280px" placeholder="Search user, role, scope..." oninput="renderUsers()"></div><div class="table-responsive"><table class="table permission-table mb-0"><thead><tr><th>User</th><th>Role</th><th>Department</th><th>Scope</th><th>Status</th><th class="sticky-actions">Actions</th></tr></thead><tbody id="usersBody"></tbody></table></div></div>
<div class="cardx p-3 mt-3"><div class="d-flex justify-content-between align-items-center mb-3"><b>Permission Matrix (Role: <span id="matrixRoleName" class="text-primary">Super Admin</span>)</b><div class="d-flex gap-2 align-items-center"><span class="small muted">Supported Actions: View, Create, Edit, Update, Delete, Approve, Reject, Print, Export, Import</span><select id="matrixUserSelect" class="form-select form-select-sm" style="width:200px" onchange="renderMatrix()"></select></div></div><div class="table-responsive"><table class="table permission-table"><thead><tr><th>Module</th><th>View</th><th>Create</th><th>Edit</th><th>Update</th><th>Delete</th><th>Approve</th><th>Reject</th><th>Print</th><th>Export</th><th>Import</th></tr></thead><tbody id="matrixBody"></tbody></table></div></div></div></main></div></div>
<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">SYSTEM</div><a href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a><a href="/advance-management"><i data-lucide="wallet"></i>Advance Management</a></div></div><div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
<div class="modal fade" id="userModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content border-0 shadow"><div class="modal-header bg-primary text-white"><div><h5 id="userModalTitle" class="modal-title">Add User</h5><small>Identity, role, scope and granular permissions</small></div><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><form id="userForm"><input type="hidden" id="editUserId"><div class="modal-body"><div class="row g-3"><div class="col-md-6"><label class="form-label">Full Name *</label><input id="uName" class="form-control" required></div><div class="col-md-6"><label class="form-label">User ID / Email *</label><input id="uLogin" class="form-control" required></div><div class="col-md-6"><label class="form-label">Password *</label><div class="input-group"><input id="uPassword" class="form-control" type="password" autocomplete="new-password" minlength="6" placeholder="Enter password"><button type="button" class="btn btn-outline-secondary" id="toggleUserPassword" aria-label="Show password"><i data-lucide="eye"></i></button></div><div class="form-text">Minimum 6 characters.</div></div><div class="col-md-6"><label class="form-label">Confirm Password *</label><div class="input-group"><input id="uPasswordConfirm" class="form-control" type="password" autocomplete="new-password" minlength="6" placeholder="Confirm password"><button type="button" class="btn btn-outline-secondary" id="toggleUserPasswordConfirm" aria-label="Show password"><i data-lucide="eye"></i></button></div></div><div class="col-md-4"><label class="form-label">Role *</label><select id="uRole" class="form-select" onchange="applyRolePreset()"><option value="Super Admin">Super Admin</option><option value="Admin">Admin</option><option value="Accountant">Accountant</option><option value="Computer Operator" selected>Computer Operator</option></select></div><div class="col-md-4"><label class="form-label">Department</label><input id="uDept" class="form-control" value="MIS"></div><div class="col-md-4"><label class="form-label">Status</label><select id="uStatus" class="form-select"><option value="Active">Active</option><option value="Inactive">Inactive</option><option value="Suspended">Suspended</option></select></div><div class="col-12"><div class="scope-box"><div class="fw-bold mb-2">Geographic / Organizational Scope</div><div class="row g-2"><div class="col-md-3"><label class="form-label small">Division</label><select id="scopeDivision" class="form-select"><option>All</option><option>Dhaka</option><option>Chattogram</option><option>Rajshahi</option><option>Khulna</option><option>Barishal</option><option>Sylhet</option><option>Rangpur</option><option>Mymensingh</option></select></div><div class="col-md-3"><label class="form-label small">District</label><input id="scopeDistrict" class="form-control" placeholder="All"></div><div class="col-md-3"><label class="form-label small">Upazila</label><input id="scopeUpazila" class="form-control" placeholder="All"></div><div class="col-md-3"><label class="form-label small">Department</label><input id="scopeDepartment" class="form-control" value="All"></div></div></div></div><div class="col-12"><div class="d-flex justify-content-between align-items-center mb-2"><div class="fw-bold">Module Permissions (10 Actions Supported)</div><div class="d-flex gap-2"><button type="button" class="btn btn-sm btn-outline-primary" onclick="setAllPerms(true)">Allow All</button><button type="button" class="btn btn-sm btn-outline-secondary" onclick="setAllPerms(false)">Clear All</button></div></div><div class="table-responsive"><table class="table permission-table"><thead><tr><th>Module</th><th>View</th><th>Create</th><th>Edit</th><th>Update</th><th>Delete</th><th>Approve</th><th>Reject</th><th>Print</th><th>Export</th><th>Import</th></tr></thead><tbody id="formPermBody"></tbody></table></div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary"><i data-lucide="save"></i> Save User & Permissions</button></div></form></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const UP_KEY='mis_users_v2';
const MODULES=['dashboard','location-branch','domain-zone-management','department-management','staff-position-list','leave-management','movement-register','stock-register','mis-data-entry','advance-management','target-activity','monitoring','reports','report-requests','analytics','notifications','users-permissions','note-document-cabinet','excel-import-export','backup-settings','data-quality','audit-log'];
const ACTIONS=['view','create','edit','update','delete','approve','reject','print','export','import'];

function defaultPerms(role='Computer Operator'){
  const p={};
  MODULES.forEach(m=>{
    p[m]={};
    ACTIONS.forEach(a=>p[m][a]=false);
  });

  const r = (role||'').toLowerCase();
  if(r==='super admin' || r==='mis super admin'){
    MODULES.forEach(m=>{
      ACTIONS.forEach(a=>p[m][a]=true);
    });
  } else if(r==='admin' || r==='mis admin'){
    MODULES.forEach(m=>{
      ['view','create','edit','update','approve','reject','print','export','import'].forEach(a=>p[m][a]=true);
    });
    if(p['users-permissions']) p['users-permissions']['delete']=false;
  } else if(r==='accountant'){
    const acctModules=['dashboard','advance-management','stock-register','reports','report-requests','excel-import-export','analytics','notifications'];
    acctModules.forEach(m=>{
      ['view','create','edit','update','approve','reject','print','export'].forEach(a=>{
        if(p[m]) p[m][a]=true;
      });
    });
    if(p['stock-register']) p['stock-register']['import']=true;
    if(p['advance-management']) p['advance-management']['import']=true;
  } else if(r==='computer operator' || r==='mis data entry'){
    const operModules=['dashboard','mis-data-entry','movement-register','stock-register','staff-position-list','location-branch','reports','notifications'];
    operModules.forEach(m=>{
      ['view','create','edit','update','print','import'].forEach(a=>{
        if(p[m]) p[m][a]=true;
      });
    });
  } else {
    MODULES.forEach(m=>{
      p[m]['view']=true;
    });
  }
  return p;
}

function normalizePermissions(perms, role){
  const base = defaultPerms(role);
  if(!perms) return base;
  if(perms['*']===true){
    MODULES.forEach(m=>ACTIONS.forEach(a=>base[m][a]=true));
    return base;
  }
  MODULES.forEach(m=>{
    ACTIONS.forEach(a=>{
      if(perms[m] && typeof perms[m][a]!=='undefined'){
        base[m][a]=!!perms[m][a];
      }
    });
  });
  return base;
}

let cachedUsers = [];

function loadUsers(callback){
  fetch('/api/users')
    .then(r => {
      if(!r.ok) throw new Error('Status: ' + r.status);
      return r.json();
    })
    .then(data => {
      if(data && data.users){
        cachedUsers = data.users.map(u => {
          u.permissions = normalizePermissions(u.permissions, u.role);
          return u;
        });
        localStorage.setItem(UP_KEY, JSON.stringify(cachedUsers));
        if(callback) callback(cachedUsers);
        else renderUsers();
      }
    })
    .catch(err => {
      console.warn('Falling back to local user store:', err);
      const x = localStorage.getItem(UP_KEY);
      if(x){
        cachedUsers = JSON.parse(x);
      } else {
        cachedUsers = [
          {id:'U-001',name:'MIS Super Admin',login:'superadmin@mis.local',email:'superadmin@mis.local',role:'Super Admin',department:'MIS',scope:'All / All / All / All',status:'Active',password:'admin123',permissions:defaultPerms('Super Admin')},
          {id:'U-002',name:'MIS Operations Admin',login:'admin@mis.local',email:'admin@mis.local',role:'Admin',department:'MIS',scope:'All / All / All / All',status:'Active',password:'admin123',permissions:defaultPerms('Admin')},
          {id:'U-003',name:'Finance Accountant',login:'accountant@mis.local',email:'accountant@mis.local',role:'Accountant',department:'Accounts & Finance',scope:'All / All / All / All',status:'Active',password:'acct123',permissions:defaultPerms('Accountant')},
          {id:'U-004',name:'Field Computer Operator',login:'operator@mis.local',email:'operator@mis.local',role:'Computer Operator',department:'Field MIS',scope:'Dhaka / Dhaka / All / MIS',status:'Active',password:'oper123',permissions:defaultPerms('Computer Operator')}
        ];
        localStorage.setItem(UP_KEY, JSON.stringify(cachedUsers));
      }
      if(callback) callback(cachedUsers);
      else renderUsers();
    });
}

function users(){
  return cachedUsers.length > 0 ? cachedUsers : (JSON.parse(localStorage.getItem(UP_KEY)||'[]'));
}

function renderUsers(){
  const all = users();
  const q = (document.getElementById('userSearch').value||'').toLowerCase();
  const rows = all.filter(u=>Object.values(u).join(' ').toLowerCase().includes(q));
  
  document.getElementById('usersBody').innerHTML = rows.map(u=>`
    <tr>
      <td>
        <b>${esc(u.name)}</b>
        <div class="small muted">${esc(u.email||u.login)}</div>
      </td>
      <td><span class="badge text-bg-light border">${esc(u.role)}</span></td>
      <td>${esc(u.department||'MIS')}</td>
      <td><span class="small">${esc(u.scope||'All')}</span></td>
      <td><span class="badge ${u.status==='Active'?'bg-success':(u.status==='Suspended'?'bg-danger':'bg-secondary')}">${esc(u.status)}</span></td>
      <td class="sticky-actions">
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-primary" title="View Permission Details" onclick="viewUser('${u.id}')"><i data-lucide="eye" style="width:14px"></i></button>
          <button class="btn btn-outline-secondary" title="Edit User & Permissions" onclick="editUser('${u.id}')"><i data-lucide="pencil" style="width:14px"></i></button>
          <button class="btn btn-outline-danger" title="Delete User" onclick="deleteUser('${u.id}')"><i data-lucide="trash-2" style="width:14px"></i></button>
          <button class="btn btn-outline-dark" title="Test As This Role" onclick="MIS_switchRole('${u.role}')"><i data-lucide="shield-check" style="width:14px"></i></button>
        </div>
      </td>
    </tr>
  `).join('');

  document.getElementById('userCount').textContent = all.length;
  document.getElementById('activeCount').textContent = all.filter(x=>x.status==='Active').length;
  document.getElementById('adminCount').textContent = all.filter(x=>x.role==='Super Admin'||x.role==='MIS Super Admin').length;

  // Populate matrix selector
  const sel = document.getElementById('matrixUserSelect');
  const curVal = sel.value;
  sel.innerHTML = all.map(u=>`<option value="${u.id}">${esc(u.name)} (${esc(u.role)})</option>`).join('');
  if(curVal && all.some(u=>u.id===curVal)) sel.value = curVal;

  updateActiveRoleBadge();
  renderMatrix();
  if(window.lucide) lucide.createIcons();
}

function updateActiveRoleBadge(){
  fetch('/api/auth/me').then(r=>r.json()).then(res=>{
    if(res && res.user){
      const el = document.getElementById('activeRoleBadge');
      if(el) el.textContent = res.user.role;
    }
  }).catch(()=>{});
}

function renderMatrix(){
  const all = users();
  const sel = document.getElementById('matrixUserSelect');
  const targetId = sel ? sel.value : null;
  const target = all.find(x=>x.id===targetId) || all.find(x=>x.role==='Super Admin') || all[0];
  
  if(target){
    document.getElementById('matrixRoleName').textContent = target.role + ' - ' + target.name;
    const perms = target.permissions || defaultPerms(target.role);
    document.getElementById('matrixBody').innerHTML = MODULES.map(m=>`
      <tr>
        <td><b>${pretty(m)}</b></td>
        ${ACTIONS.map(a=>{
          const allowed = (target.role==='Super Admin'||target.role==='MIS Super Admin') ? true : !!(perms[m] && perms[m][a]);
          return `<td>${allowed ? '<span class="text-success fw-bold">✓</span>' : '<span class="text-muted opacity-50">—</span>'}</td>`;
        }).join('')}
      </tr>
    `).join('');
  }
}

function renderFormPerms(p){
  document.getElementById('formPermBody').innerHTML = MODULES.map(m=>`
    <tr>
      <td><b>${pretty(m)}</b></td>
      ${ACTIONS.map(a=>`
        <td>
          <input class="perm-check" data-module="${m}" data-action="${a}" type="checkbox" ${p?.[m]?.[a]?'checked':''}>
        </td>
      `).join('')}
    </tr>
  `).join('');
}

function applyRolePreset(){
  const role = document.getElementById('uRole').value;
  renderFormPerms(defaultPerms(role));
}

function setAllPerms(v){
  document.querySelectorAll('#formPermBody .perm-check').forEach(x=>x.checked=v);
}

function openUserModal(id){
  document.getElementById('userForm').reset();
  document.getElementById('editUserId').value = '';
  document.getElementById('userModalTitle').textContent = 'Add User';
  document.getElementById('uRole').value = 'Computer Operator';
  applyRolePreset();
  document.getElementById('uPassword').value = '';
  document.getElementById('uPasswordConfirm').value = '';
  
  if(id){
    const u = users().find(x=>x.id===id);
    if(!u) return;
    document.getElementById('userModalTitle').textContent = 'Edit User & Permissions';
    document.getElementById('editUserId').value = id;
    document.getElementById('uName').value = u.name;
    document.getElementById('uLogin').value = u.email || u.login;
    document.getElementById('uPassword').value = u.password || '';
    document.getElementById('uPasswordConfirm').value = u.password || '';
    document.getElementById('uRole').value = u.role;
    document.getElementById('uDept').value = u.department || 'MIS';
    document.getElementById('uStatus').value = u.status || 'Active';
    const parts = (u.scope || 'All').split(' / ');
    document.getElementById('scopeDivision').value = parts[0] || 'All';
    document.getElementById('scopeDistrict').value = parts[1] || 'All';
    document.getElementById('scopeUpazila').value = parts[2] || 'All';
    document.getElementById('scopeDepartment').value = parts[3] || 'All';
    renderFormPerms(u.permissions);
  }
  bootstrap.Modal.getOrCreateInstance(document.getElementById('userModal')).show();
  if(window.lucide) lucide.createIcons();
}

function editUser(id){
  openUserModal(id);
}

function collectPerms(){
  const p = defaultPerms();
  document.querySelectorAll('#formPermBody .perm-check').forEach(x=>{
    p[x.dataset.module][x.dataset.action] = x.checked;
  });
  return p;
}

document.getElementById('userForm').addEventListener('submit', e=>{
  e.preventDefault();
  const pw = document.getElementById('uPassword').value;
  const cpw = document.getElementById('uPasswordConfirm').value;
  if(!pw || pw.length < 6){
    toast('Password must be at least 6 characters');
    document.getElementById('uPassword').focus();
    return;
  }
  if(pw !== cpw){
    toast('Password and Confirm Password do not match');
    document.getElementById('uPasswordConfirm').focus();
    return;
  }

  const id = document.getElementById('editUserId').value;
  const role = document.getElementById('uRole').value;
  const item = {
    name: document.getElementById('uName').value.trim(),
    login: document.getElementById('uLogin').value.trim(),
    email: document.getElementById('uLogin').value.trim(),
    role: role,
    department: document.getElementById('uDept').value.trim(),
    scope: [
      document.getElementById('scopeDivision').value,
      document.getElementById('scopeDistrict').value.trim() || 'All',
      document.getElementById('scopeUpazila').value.trim() || 'All',
      document.getElementById('scopeDepartment').value.trim() || 'All'
    ].join(' / '),
    status: document.getElementById('uStatus').value,
    password: pw,
    permissions: collectPerms()
  };

  const url = id ? `/api/users/${id}` : '/api/users';
  const method = id ? 'PUT' : 'POST';

  fetch(url, {
    method: method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(item)
  })
  .then(r => r.json())
  .then(res => {
    if(res.error){
      toast('Error: ' + res.error);
      return;
    }
    bootstrap.Modal.getInstance(document.getElementById('userModal')).hide();
    toast(id ? 'User & Permissions updated successfully' : 'User created successfully');
    loadUsers();
  })
  .catch(err => {
    console.error(err);
    // Fallback locally
    let arr = users();
    if(id){
      arr = arr.map(x=>x.id===id ? { ...item, id } : x);
    } else {
      arr.unshift({ ...item, id: 'U-' + Date.now().toString().slice(-4) });
    }
    localStorage.setItem(UP_KEY, JSON.stringify(arr));
    bootstrap.Modal.getInstance(document.getElementById('userModal')).hide();
    toast('Saved locally');
    renderUsers();
  });
});

function deleteUser(id){
  const u = users().find(x=>x.id===id);
  if(!u) return;
  if((u.role==='Super Admin'||u.role==='MIS Super Admin') && users().filter(x=>x.role==='Super Admin'||x.role==='MIS Super Admin').length <= 1){
    toast('At least one Super Admin must remain in the system');
    return;
  }
  if(!confirm(`Are you sure you want to delete user "${u.name}" (${u.role})?`)) return;

  fetch(`/api/users/${id}`, { method: 'DELETE' })
    .then(r => r.json())
    .then(res => {
      if(res.error){
        toast('Error: ' + res.error);
        return;
      }
      toast('User deleted successfully');
      loadUsers();
    })
    .catch(() => {
      const filtered = users().filter(x=>x.id!==id);
      localStorage.setItem(UP_KEY, JSON.stringify(filtered));
      toast('User deleted locally');
      renderUsers();
    });
}

function viewUser(id){
  const u = users().find(x=>x.id===id);
  if(!u) return;
  const allowed = MODULES.filter(m => ACTIONS.some(a => u.role==='Super Admin' || u.permissions?.[m]?.[a])).map(pretty).join(', ');
  if (typeof Swal !== 'undefined' && Swal.fire) {
    Swal.fire({
      title: u.name,
      html: `<div class="text-start">
        <p class="mb-1"><strong>Email/ID:</strong> ${esc(u.email||u.login)}</p>
        <p class="mb-1"><strong>Role:</strong> <span class="badge bg-primary">${esc(u.role)}</span></p>
        <p class="mb-1"><strong>Scope:</strong> ${esc(u.scope || 'All')}</p>
        <p class="mb-1"><strong>Status:</strong> <span class="badge ${u.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${esc(u.status)}</span></p>
        <hr class="my-2">
        <p class="mb-1"><strong>Allowed Modules:</strong></p>
        <div class="small text-muted" style="max-height: 140px; overflow-y: auto;">${esc(allowed || 'None')}</div>
      </div>`,
      confirmButtonText: 'Close'
    });
  } else {
    toast(`User: ${u.name} (${u.role}) - Status: ${u.status}`);
  }
}

function pretty(s){
  return s.split('-').map(x=>x.charAt(0).toUpperCase()+x.slice(1)).join(' ');
}

function esc(s){
  return String(s??'').replace(/[&<>'"]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
}

function toggleFieldPassword(inputId, buttonId){
  const input = document.getElementById(inputId);
  const btn = document.getElementById(buttonId);
  if(!input || !btn) return;
  btn.addEventListener('click', ()=>{
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.innerHTML = show ? '<i data-lucide="eye-off"></i>' : '<i data-lucide="eye"></i>';
    if(window.lucide) lucide.createIcons();
  });
}
toggleFieldPassword('uPassword','toggleUserPassword');
toggleFieldPassword('uPasswordConfirm','toggleUserPasswordConfirm');

document.addEventListener('DOMContentLoaded', ()=>{
  loadUsers();
});
</script></body></html>
