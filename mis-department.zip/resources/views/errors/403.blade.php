@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-sm rounded-4 text-center p-4 p-md-5">
                <div class="mb-3">
                    <span class="badge bg-danger-subtle text-danger fs-6 px-3 py-2 rounded-pill">
                        HTTP 403 &bull; Authorization Required
                    </span>
                </div>
                <div class="display-3 fw-bold text-danger mb-2">403</div>
                <h2 class="h4 fw-bold text-slate-800 mb-3">Access Forbidden</h2>
                <p class="text-muted mb-4">
                    Your current role <strong>({{ $user->role ?? 'User' }})</strong> does not have permission to 
                    <span class="text-dark fw-semibold">{{ $action ?? 'view' }}</span> the 
                    <span class="text-primary fw-semibold">{{ ucwords(str_replace('-', ' ', $module ?? 'requested')) }}</span> module.
                </p>
                <div class="alert alert-light border text-start small mb-4">
                    <div class="d-flex align-items-center gap-2 text-secondary mb-1">
                        <i data-lucide="shield-alert" class="text-warning" style="width: 16px; height: 16px;"></i>
                        <strong>Security Audit Notice</strong>
                    </div>
                    <div>This unauthorized access attempt has been recorded in the system audit log with your account identifier, timestamp, and IP address.</div>
                </div>
                <div class="d-flex justify-content-center gap-2 flex-wrap">
                    <a href="/dashboard" class="btn btn-primary px-4">
                        <i data-lucide="arrow-left" class="me-1" style="width: 16px; height: 16px;"></i>
                        Back to Dashboard
                    </a>
                    <a href="/users-permissions" class="btn btn-outline-secondary px-3">
                        View Role Permissions
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
