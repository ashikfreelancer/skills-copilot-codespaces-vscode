@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-sm rounded-4 text-center p-4 p-md-5">
                <div class="mb-3">
                    <span class="badge bg-warning-subtle text-warning-emphasis fs-6 px-3 py-2 rounded-pill">
                        HTTP 404 &bull; Page Not Found
                    </span>
                </div>
                <div class="display-3 fw-bold text-warning mb-2">404</div>
                <h2 class="h4 fw-bold text-slate-800 mb-3">Resource Not Found</h2>
                <p class="text-muted mb-4">
                    The MIS module, record, or endpoint you are attempting to reach does not exist or has been relocated.
                </p>
                <div class="alert alert-light border text-start small mb-4">
                    <div class="d-flex align-items-center gap-2 text-secondary mb-1">
                        <i data-lucide="info" class="text-primary" style="width: 16px; height: 16px;"></i>
                        <strong>Navigation Guidance</strong>
                    </div>
                    <div>Please verify the URL or return to the main MIS Dashboard to browse authorized system directories and operational registers.</div>
                </div>
                <div class="d-flex justify-content-center gap-2 flex-wrap">
                    <a href="/dashboard" class="btn btn-primary px-4">
                        <i data-lucide="layout-dashboard" class="me-1" style="width: 16px; height: 16px;"></i>
                        Return to Dashboard
                    </a>
                    <a href="/mis-data-entry" class="btn btn-outline-secondary px-3">
                        MIS Data Entry
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
