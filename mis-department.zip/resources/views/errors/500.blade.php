@extends('layouts.app')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-sm rounded-4 text-center p-4 p-md-5">
                <div class="mb-3">
                    <span class="badge bg-danger-subtle text-danger fs-6 px-3 py-2 rounded-pill">
                        HTTP 500 &bull; Internal Server Error
                    </span>
                </div>
                <div class="display-3 fw-bold text-danger mb-2">500</div>
                <h2 class="h4 fw-bold text-slate-800 mb-3">System Processing Error</h2>
                <p class="text-muted mb-4">
                    The server encountered an unexpected situation while processing the request. No data corruption occurred.
                </p>
                <div class="alert alert-light border text-start small mb-4">
                    <div class="d-flex align-items-center gap-2 text-danger mb-1">
                        <i data-lucide="alert-triangle" class="text-danger" style="width: 16px; height: 16px;"></i>
                        <strong>Diagnostic Summary</strong>
                    </div>
                    <div>An error was logged to the MIS monitoring database. If this persists, please contact the System Administrator or check the system logs in Monitoring.</div>
                </div>
                <div class="d-flex justify-content-center gap-2 flex-wrap">
                    <a href="/dashboard" class="btn btn-primary px-4">
                        <i data-lucide="refresh-cw" class="me-1" style="width: 16px; height: 16px;"></i>
                        Return to Safe Dashboard
                    </a>
                    <a href="/monitoring" class="btn btn-outline-secondary px-3">
                        System Health & Logs
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
