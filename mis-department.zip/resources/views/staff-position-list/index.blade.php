<!doctype html>
<html lang="en">
<head>
  <script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Staff Position List | MIS Department</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
  </script>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="{{ asset('assets/css/app.css') }}">
  <style>
    .cardx {
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      background: #ffffff;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }
    .badge-active { background: #dcfce7; color: #166534; font-weight: 600; cursor: pointer; }
    .badge-inactive { background: #fee2e2; color: #991b1b; font-weight: 600; cursor: pointer; }
    .badge-leave { background: #fef9c3; color: #854d0e; font-weight: 600; cursor: pointer; }
    .badge-transferred { background: #e0f2fe; color: #075985; font-weight: 600; cursor: pointer; }
    .sort-header { cursor: pointer; user-select: none; }
    .sort-header:hover { background-color: #f1f5f9; }
    
    /* Dedicated Timeline Visual Hierarchy Styles */
    .timeline-container {
      position: relative;
      padding-left: 28px;
    }
    .timeline-container::before {
      content: '';
      position: absolute;
      left: 17px;
      top: 14px;
      bottom: 24px;
      width: 2px;
      background: linear-gradient(180deg, #3b82f6 0%, #cbd5e1 90%, #f1f5f9 100%);
    }
    .timeline-node {
      position: absolute;
      left: -28px;
      top: 16px;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: #ffffff;
      border: 3px solid #3b82f6;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 4px rgba(0,0,0,0.08);
      z-index: 2;
    }
    .timeline-node.node-close {
      border-color: #f59e0b;
      color: #d97706;
      background: #fffbeb;
    }
    .timeline-node.node-transfer {
      border-color: #2563eb;
      color: #1d4ed8;
      background: #eff6ff;
    }
    .timeline-node.node-join {
      border-color: #10b981;
      color: #059669;
      background: #ecfdf5;
    }
    .timeline-node.node-current {
      border-color: #6366f1;
      color: #4f46e5;
      background: #eef2ff;
    }
    .timeline-card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.03);
      transition: all 0.2s ease-in-out;
    }
    .timeline-card:hover {
      border-color: #cbd5e1;
      box-shadow: 0 8px 16px -4px rgba(0,0,0,0.08);
      transform: translateY(-1px);
    }
    .branch-path-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 6px 12px;
      font-size: 0.875rem;
    }
    .nav-tabs-custom .nav-link {
      color: #64748b;
      font-weight: 500;
      border: none;
      border-bottom: 2px solid transparent;
      padding: 10px 18px;
      transition: all 0.2s;
    }
    .nav-tabs-custom .nav-link:hover {
      color: #1e293b;
      border-color: #cbd5e1;
    }
    .nav-tabs-custom .nav-link.active {
      color: #2563eb;
      font-weight: 600;
      border-color: #2563eb;
      background: transparent;
    }
    @media print {
      .desktop-sidebar, .topbar, .no-print, .btn, .search-filters-row, .pagination-row, .nav-tabs-custom {
        display: none !important;
      }
      main { width: 100% !important; }
      .cardx { box-shadow: none !important; border: none !important; }
    }
  </style>
  <script src="{{ asset('assets/js/app.js') }}"></script>
</head>
<body data-page="staff-position-list">
<div class="container-fluid">
  <div class="row g-0">
    <!-- Sidebar -->
    <aside class="col-lg-2 desktop-sidebar sidebar p-3">
      <div class="d-flex align-items-center gap-2 px-2 py-2 mb-2">
        <div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div>
        <div class="text-white fw-bold">MIS Management</div>
      </div>
      <div class="text-slate-400 px-2 small mb-3">Management Information System</div>
      <div class="group-title">MAIN</div>
      <a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a>
      <a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location & Branch</a>
      <a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain & Zone Head Information</a>
      <a data-nav="department-management" href="/department-management"><i data-lucide="building-2" style="width:18px"></i>Department Management</a>
      <a data-nav="staff-position-list" href="/staff-position-list" class="active"><i data-lucide="users" style="width:18px"></i>Staff Position List</a>
      <a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a>
      <a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a>
      <a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a>
      <a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a>
      <a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a>
      <div class="group-title">DOCUMENTS & FINANCE</div>
      <a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note & Document Cabinet</a>
      <a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a>
      <a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target & Activity</a>
      <div class="group-title">OPERATIONS</div>
      <a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a>
      <a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a>
      <a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a>
      <div class="group-title">SYSTEM</div>
      <a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a>
      <a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users & Permissions</a>
      <a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a>
      <a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup & Settings</a>
    </aside>

    <!-- Main Content -->
    <main class="col-lg-10">
      <header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav">
            <i data-lucide="menu"></i>
          </button>
          <div>
            <div class="small muted">MIS Department</div>
            <h1 class="h5 mb-0 fw-bold">Staff Position List</h1>
          </div>
        </div>
        <div class="d-flex align-items-center gap-2">
          <button class="btn btn-light" onclick="printPage()" title="Print List">
            <i data-lucide="printer"></i>
          </button>
          <button class="btn btn-light" onclick="exportStaffCSV()" title="Export CSV">
            <i data-lucide="download"></i>
          </button>
          <div class="rounded-circle bg-primary text-white d-grid place-items-center fw-bold" style="width:38px;height:38px">SA</div>
        </div>
      </header>

      <div class="p-3 p-lg-4">
        <!-- Module Header & View Tabs Navigation -->
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
          <div>
            <h2 class="page-title h3 mb-1" id="moduleMainTitle">Staff Position List & Postings</h2>
            <p class="muted mb-0" id="moduleMainSubtitle">Maintain staff master positions and track inter-branch transfers and station closures.</p>
          </div>
          <div class="d-flex align-items-center gap-2 mt-2 mt-md-0 no-print">
            <button class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1" onclick="openTransferModal('Transfer')">
              <i data-lucide="arrow-left-right" style="width: 15px; height: 15px;"></i>
              <span>Record Transfer</span>
            </button>
            <button class="btn btn-outline-danger btn-sm d-flex align-items-center gap-1" onclick="openTransferModal('Close')">
              <i data-lucide="log-out" style="width: 15px; height: 15px;"></i>
              <span>Record Staff Close</span>
            </button>
            <button class="btn btn-primary btn-sm d-flex align-items-center gap-1" onclick="openStaffAddModal()">
              <i data-lucide="user-plus" style="width: 15px; height: 15px;"></i>
              <span>Add Staff</span>
            </button>
          </div>
        </div>

        <!-- Top Navigation Tabs (View Switcher) -->
        <div class="mb-3 border-bottom pb-1">
          <ul class="nav nav-tabs nav-tabs-custom border-bottom-0" id="staffModuleTabs">
            <li class="nav-item">
              <button class="nav-link active d-flex align-items-center gap-2" id="tabRosterBtn" onclick="switchStaffView('roster')">
                <i data-lucide="users" style="width: 18px; height: 18px;"></i>
                <span>Staff Directory & Positions</span>
              </button>
            </li>
            <li class="nav-item">
              <button class="nav-link d-flex align-items-center gap-2" id="tabTimelineBtn" onclick="switchStaffView('timeline')">
                <i data-lucide="route" style="width: 18px; height: 18px;"></i>
                <span>Transfer & Branch Close Timeline</span>
                <span class="badge bg-primary rounded-pill px-2 py-0.5" id="timelineCountBadge">0</span>
              </button>
            </li>
          </ul>
        </div>

        <!-- VIEW 1: STAFF ROSTER & DIRECTORY -->
        <div id="rosterView">
          <!-- Filter Card -->
          <div class="cardx p-3 mb-3 search-filters-row">
            <div class="row g-2">
              <div class="col-md-3">
                <select id="filterDepartment" class="form-select" onchange="applyFilters()">
                  <option value="">All Departments</option>
                </select>
              </div>
              <div class="col-md-3">
                <select id="filterPosition" class="form-select" onchange="applyFilters()">
                  <option value="">All Positions</option>
                </select>
              </div>
              <div class="col-md-2">
                <select id="filterDistrict" class="form-select" onchange="applyFilters()">
                  <option value="">All Districts</option>
                </select>
              </div>
              <div class="col-md-2">
                <select id="filterStatus" class="form-select" onchange="applyFilters()">
                  <option value="">All Status</option>
                  <option value="Active">Active</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Transferred">Transferred</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
              <div class="col-md-2">
                <input id="filterSearch" class="form-control" placeholder="Search name / ID..." oninput="debounceStaffLoad()">
              </div>
            </div>
          </div>

          <!-- Table Card -->
          <div class="cardx p-3">
            <div class="table-responsive">
              <table id="staffTable" class="table table-bordered table-hover align-middle mb-0">
                <thead class="table-light">
                  <tr>
                    <th style="width: 50px;" class="sort-header" onclick="changeSort('serial')">ক্রমিক <span id="sort_icon_serial">↕</span></th>
                    <th class="sort-header" onclick="changeSort('name')">কর্মকর্তার নাম <span id="sort_icon_name">↕</span></th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>পিতার নাম</th>
                    <th>মাতার নাম</th>
                    <th class="sort-header" onclick="changeSort('staff_id')">ID নং <span id="sort_icon_staff_id">↕</span></th>
                    <th class="sort-header" onclick="changeSort('designation')">পদবী <span id="sort_icon_designation">↕</span></th>
                    <th class="sort-header" onclick="changeSort('join_date')">TMSS-এ যোগদান <span id="sort_icon_join_date">↕</span></th>
                    <th>বর্তমান কর্মস্থলে যোগদান</th>
                    <th>সর্বশেষ পদোন্নতি</th>
                    <th>শিক্ষাগত যোগ্যতা</th>
                    <th>নিজ জেলা</th>
                    <th>পূর্ববর্তী কর্মস্থল</th>
                    <th>বর্তমান কর্মস্থল</th>
                    <th class="sort-header" onclick="changeSort('department')">Department <span id="sort_icon_department">↕</span></th>
                    <th class="sort-header" onclick="changeSort('status')">Status <span id="sort_icon_status">↕</span></th>
                    <th class="no-print text-center" style="min-width: 170px;">Actions</th>
                  </tr>
                </thead>
                <tbody id="staffTableBody">
                  <tr>
                    <td colspan="18" class="text-center py-4 text-muted">
                      <div class="spinner-border spinner-border-sm me-2"></div> Loading staff position records...
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- Pagination Info -->
            <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top pagination-row">
              <div class="small text-muted" id="paginationInfo">Showing 0 to 0 of 0 records</div>
              <div class="d-flex gap-1" id="paginationControls"></div>
            </div>
          </div>
        </div>

        <!-- VIEW 2: DEDICATED TRANSFER & BRANCH CLOSE TIMELINE -->
        <div id="timelineView" style="display: none;">
          <!-- KPI Summary Ribbon -->
          <div class="row g-3 mb-3">
            <div class="col-sm-6 col-xl-3">
              <div class="cardx p-3 bg-white d-flex align-items-center gap-3">
                <div class="p-3 rounded-3 bg-primary-subtle text-primary">
                  <i data-lucide="route" style="width: 24px; height: 24px;"></i>
                </div>
                <div>
                  <div class="text-muted small fw-medium">Total Timeline Events</div>
                  <div class="h4 mb-0 fw-bold text-dark" id="statTotalMovements">0</div>
                  <div class="text-muted small" style="font-size: 0.75rem;">Transfers & Station Closures</div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-xl-3">
              <div class="cardx p-3 bg-white d-flex align-items-center gap-3">
                <div class="p-3 rounded-3 bg-info-subtle text-info">
                  <i data-lucide="arrow-left-right" style="width: 24px; height: 24px;"></i>
                </div>
                <div>
                  <div class="text-muted small fw-medium">Branch Transfers</div>
                  <div class="h4 mb-0 fw-bold text-dark" id="statTotalTransfers">0</div>
                  <div class="text-muted small" style="font-size: 0.75rem;">Inter-branch Rotations</div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-xl-3">
              <div class="cardx p-3 bg-white d-flex align-items-center gap-3">
                <div class="p-3 rounded-3 bg-warning-subtle text-warning">
                  <i data-lucide="shield-alert" style="width: 24px; height: 24px;"></i>
                </div>
                <div>
                  <div class="text-muted small fw-medium">Station Closures / Releases</div>
                  <div class="h4 mb-0 fw-bold text-dark" id="statTotalClosures">0</div>
                  <div class="text-muted small" style="font-size: 0.75rem;">Branch Close & Clearance</div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-xl-3">
              <div class="cardx p-3 bg-white d-flex align-items-center gap-3">
                <div class="p-3 rounded-3 bg-success-subtle text-success">
                  <i data-lucide="map-pin" style="width: 24px; height: 24px;"></i>
                </div>
                <div>
                  <div class="text-muted small fw-medium">Branches Involved</div>
                  <div class="h4 mb-0 fw-bold text-dark" id="statBranchesInvolved">0</div>
                  <div class="text-muted small" style="font-size: 0.75rem;">Origin & Target Stations</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Timeline Filter Card -->
          <div class="cardx p-3 mb-3 search-filters-row">
            <div class="row g-2 align-items-center">
              <div class="col-md-2">
                <label class="form-label small text-muted mb-1 fw-semibold">Event Type</label>
                <select id="tlFilterType" class="form-select form-select-sm" onchange="applyTimelineFilters()">
                  <option value="All">All Events (Transfers & Closes)</option>
                  <option value="Transfer">Branch Transfers Only</option>
                  <option value="Close">Staff Close / Releases Only</option>
                </select>
              </div>
              <div class="col-md-3">
                <label class="form-label small text-muted mb-1 fw-semibold">Branch (Origin / Destination)</label>
                <select id="tlFilterBranch" class="form-select form-select-sm" onchange="applyTimelineFilters()">
                  <option value="">All Branches</option>
                </select>
              </div>
              <div class="col-md-2">
                <label class="form-label small text-muted mb-1 fw-semibold">Department</label>
                <select id="tlFilterDepartment" class="form-select form-select-sm" onchange="applyTimelineFilters()">
                  <option value="">All Departments</option>
                </select>
              </div>
              <div class="col-md-3">
                <label class="form-label small text-muted mb-1 fw-semibold">Search Staff / Order / Reason</label>
                <input id="tlFilterSearch" class="form-control form-control-sm" placeholder="Search name, ID, order, branch..." oninput="debounceTimelineLoad()">
              </div>
              <div class="col-md-2 d-flex gap-1 align-items-end">
                <div class="btn-group w-100" role="group">
                  <button type="button" class="btn btn-sm btn-outline-secondary active" id="btnModeStream" onclick="switchTimelineMode('stream')" title="Timeline Stream View">
                    <i data-lucide="list-ordered" style="width: 14px; height: 14px;"></i> Stream
                  </button>
                  <button type="button" class="btn btn-sm btn-outline-secondary" id="btnModeJourney" onclick="switchTimelineMode('journey')" title="Staff Career Journey View">
                    <i data-lucide="user-check" style="width: 14px; height: 14px;"></i> Journeys
                  </button>
                  <button type="button" class="btn btn-sm btn-outline-secondary" id="btnModeMatrix" onclick="switchTimelineMode('matrix')" title="Branch In/Out Movement Matrix">
                    <i data-lucide="grid-3x3" style="width: 14px; height: 14px;"></i> Matrix
                  </button>
                </div>
              </div>
            </div>
            <div class="row g-2 mt-1 align-items-center">
              <div class="col-md-3">
                <div class="input-group input-group-sm">
                  <span class="input-group-text bg-light text-muted">From Date</span>
                  <input type="date" id="tlFilterDateFrom" class="form-control" onchange="applyTimelineFilters()">
                </div>
              </div>
              <div class="col-md-3">
                <div class="input-group input-group-sm">
                  <span class="input-group-text bg-light text-muted">To Date</span>
                  <input type="date" id="tlFilterDateTo" class="form-control" onchange="applyTimelineFilters()">
                </div>
              </div>
              <div class="col-md-6 d-flex justify-content-end gap-2">
                <button class="btn btn-sm btn-light border" onclick="resetTimelineFilters()">
                  <i data-lucide="rotate-ccw" style="width: 13px; height: 13px;" class="me-1"></i>Reset Filters
                </button>
                <button class="btn btn-sm btn-light border" onclick="printTimelineReport()">
                  <i data-lucide="printer" style="width: 13px; height: 13px;" class="me-1"></i>Print Timeline
                </button>
                <button class="btn btn-sm btn-light border" onclick="exportTimelineCSV()">
                  <i data-lucide="download" style="width: 13px; height: 13px;" class="me-1"></i>Export History CSV
                </button>
              </div>
            </div>
          </div>

          <!-- SUB-VIEW 1: Visual Timeline Stream -->
          <div id="tlModeStreamContainer">
            <div class="timeline-container ps-4 ps-md-5" id="timelineStreamList">
              <div class="text-center py-5 text-muted">
                <div class="spinner-border spinner-border-sm me-2"></div> Loading transfer and branch close timeline...
              </div>
            </div>
          </div>

          <!-- SUB-VIEW 2: Staff Career Journeys -->
          <div id="tlModeJourneyContainer" style="display: none;">
            <div id="tlJourneysList" class="row g-3">
              <div class="col-12 text-center py-5 text-muted">
                <div class="spinner-border spinner-border-sm me-2"></div> Loading staff posting journeys...
              </div>
            </div>
          </div>

          <!-- SUB-VIEW 3: Branch In/Out Movement Matrix -->
          <div id="tlModeMatrixContainer" style="display: none;">
            <div class="cardx p-3">
              <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle mb-0">
                  <thead class="table-light">
                    <tr>
                      <th>Branch Name</th>
                      <th class="text-center text-primary">Transfers IN (Joined Branch)</th>
                      <th class="text-center text-secondary">Transfers OUT (Left Branch)</th>
                      <th class="text-center text-danger">Station Closures / Releases</th>
                      <th class="text-center">Net Movement</th>
                      <th class="text-center">Active Staff In Station</th>
                      <th class="text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody id="tlMatrixTableBody">
                    <tr>
                      <td colspan="7" class="text-center py-4 text-muted">Calculating branch movement matrix...</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <!-- Timeline Pagination Footer -->
          <div class="cardx p-3 mt-3 d-flex flex-wrap justify-content-between align-items-center pagination-row">
            <div class="small text-muted" id="tlPaginationInfo">Showing 0 to 0 of 0 timeline events</div>
            <div class="d-flex gap-1" id="tlPaginationControls"></div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<!-- Staff Entry / Edit Modal -->
<div class="modal fade" id="staffModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-light">
        <b id="staffModalTitle">Add Staff Position Record</b>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="staffDbId">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label fw-semibold">ক্রমিক নং</label>
            <input id="staffSerial" class="form-control" placeholder="e.g. 01">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">কর্মকর্তার নাম <span class="text-danger">*</span></label>
            <input id="staffName" class="form-control" placeholder="Full name">
            <div class="invalid-feedback" id="staffNameErr"></div>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">Gender</label>
            <select id="staffGender" class="form-select">
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">Date of Birth</label>
            <input type="date" id="staffDob" class="form-control">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">পিতার নাম</label>
            <input id="staffFather" class="form-control" placeholder="Father's name">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">মাতার নাম</label>
            <input id="staffMother" class="form-control" placeholder="Mother's name">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">ID নং <span class="text-danger">*</span></label>
            <input id="staffEmployeeId" class="form-control" placeholder="e.g. TMSS-001">
            <div class="invalid-feedback" id="staffEmployeeIdErr"></div>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">পদবী <span class="text-danger">*</span></label>
            <input id="staffDesignation" class="form-control" placeholder="e.g. Senior Officer">
            <div class="invalid-feedback" id="staffDesignationErr"></div>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">Department <span class="text-danger">*</span></label>
            <select id="staffDepartmentSelect" class="form-select">
              <option value="">Select Department</option>
            </select>
            <div class="invalid-feedback" id="staffDepartmentErr"></div>
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">TMSS-এ যোগদানের তারিখ</label>
            <input type="date" id="staffJoinDate" class="form-control">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">বর্তমান কর্মস্থলে যোগদানের তারিখ</label>
            <input type="date" id="staffPostingDate" class="form-control">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">সর্বশেষ পদোন্নতির তারিখ</label>
            <input type="date" id="staffPromotionDate" class="form-control">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">শিক্ষাগত যোগ্যতা</label>
            <input id="staffEducation" class="form-control" placeholder="e.g. MBA / BSc in CSE">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">নিজ জেলা</label>
            <input id="staffHomeDistrict" class="form-control" placeholder="e.g. Bogura">
          </div>
          <div class="col-md-4">
            <label class="form-label fw-semibold">পূর্ববর্তী কর্মস্থল</label>
            <input id="staffPreviousPosting" class="form-control" placeholder="e.g. Head Office">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">বর্তমান কর্মস্থল</label>
            <input id="staffCurrentPosting" class="form-control" placeholder="e.g. Dhaka Branch">
          </div>
          <div class="col-md-6">
            <label class="form-label fw-semibold">Status</label>
            <select id="staffStatus" class="form-select">
              <option value="Active">Active</option>
              <option value="On Leave">On Leave</option>
              <option value="Transferred">Transferred</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="saveStaffBtn" onclick="saveStaffRecord()">
          <i data-lucide="check" class="me-1"></i>Save Record
        </button>
      </div>
    </div>
  </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="staffViewModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-light">
        <b class="modal-title">Staff Details</b>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-3" id="staffViewBody"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Record Staff Transfer & Close Modal -->
<div class="modal fade" id="staffTransferModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-light">
        <div class="d-flex align-items-center gap-2">
          <div class="p-2 rounded-2 bg-primary-subtle text-primary">
            <i data-lucide="arrow-left-right" style="width: 18px; height: 18px;"></i>
          </div>
          <div>
            <b class="modal-title h6 mb-0" id="transferModalTitle">Record Staff Transfer / Station Close</b>
            <div class="small text-muted">Update branch assignments, handover accountability, and career movements</div>
          </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-3 p-md-4">
        <form id="staffTransferForm" onsubmit="event.preventDefault(); submitTransferForm();">
          <input type="hidden" id="trSelectedStaffId" value="">

          <!-- Movement Action Type -->
          <div class="mb-3">
            <label class="form-label fw-bold text-dark small text-uppercase">Action Type <span class="text-danger">*</span></label>
            <div class="d-flex gap-3 p-2 border rounded-3 bg-light">
              <div class="form-check">
                <input class="form-check-input" type="radio" name="trType" id="trTypeTransfer" value="Transfer" checked onchange="handleTransferTypeChange()">
                <label class="form-check-label fw-semibold text-primary" for="trTypeTransfer">
                  <i data-lucide="arrow-right" style="width: 14px; height: 14px;" class="me-1"></i> Inter-Branch Transfer
                </label>
                <div class="small text-muted">Transfer officer from one operational branch to another target branch.</div>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="trType" id="trTypeClose" value="Close" onchange="handleTransferTypeChange()">
                <label class="form-check-label fw-semibold text-warning-emphasis" for="trTypeClose">
                  <i data-lucide="log-out" style="width: 14px; height: 14px;" class="me-1"></i> Staff Station Close / Release
                </label>
                <div class="small text-muted">Release officer from current branch upon station closure, consolidation, or recall.</div>
              </div>
            </div>
          </div>

          <!-- Staff Officer Selection -->
          <div class="row g-3 mb-3">
            <div class="col-12">
              <label class="form-label fw-semibold">Select Staff Officer <span class="text-danger">*</span></label>
              <select id="trStaffSelect" class="form-select" onchange="onTransferStaffSelected()" required>
                <option value="">-- Choose Staff Officer --</option>
              </select>
              <div class="invalid-feedback" id="trStaffErr">Please select a staff member.</div>
            </div>
          </div>

          <!-- Auto-filled officer info card -->
          <div id="trStaffInfoBanner" class="p-2 mb-3 bg-light border rounded-2 d-none">
            <div class="row g-2 small">
              <div class="col-md-3"><b>Staff ID:</b> <span id="trStaffIdBadge" class="font-monospace text-primary">-</span></div>
              <div class="col-md-4"><b>Designation:</b> <span id="trStaffDesignation">-</span></div>
              <div class="col-md-5"><b>Department:</b> <span id="trStaffDepartment">-</span></div>
            </div>
          </div>

          <!-- Origin & Destination Branches -->
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Origin Branch (Current Posting) <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text bg-light"><i data-lucide="building" style="width: 16px; height: 16px;"></i></span>
                <input type="text" id="trFromBranch" class="form-control" placeholder="Origin branch" required>
              </div>
              <div class="form-text">Pre-filled from officer's current posting.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold" id="trToBranchLabel">Destination Branch <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text bg-light"><i data-lucide="map-pin" style="width: 16px; height: 16px;"></i></span>
                <select id="trToBranchSelect" class="form-select" required>
                  <option value="">-- Select Destination Branch --</option>
                </select>
                <input type="text" id="trToBranchCustom" class="form-control d-none" placeholder="Target station or 'Closed / Released'">
              </div>
              <div class="invalid-feedback" id="trToBranchErr">Please specify the destination branch.</div>
            </div>
          </div>

          <!-- Date & Official Memo Ref -->
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Effective Transfer / Release Date <span class="text-danger">*</span></label>
              <input type="date" id="trDate" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Transfer Order / Memo Number <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="text" id="trOrderNumber" class="form-control font-monospace" placeholder="e.g. TMSS/TR/2026/0491" required>
                <button type="button" class="btn btn-outline-secondary" onclick="generateRandomOrderNo()" title="Generate Official Reference">
                  <i data-lucide="sparkles" style="width: 14px; height: 14px;"></i> Auto
                </button>
              </div>
            </div>
          </div>

          <!-- Handover & Approvals Section -->
          <div class="p-3 border rounded-3 bg-light mb-3">
            <div class="fw-bold text-dark small text-uppercase mb-2">Clearance & Handover Accountability</div>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label small fw-semibold">Handover Status</label>
                <select id="trHandoverStatus" class="form-select form-select-sm">
                  <option value="Completed">Completed (Cleared)</option>
                  <option value="Pending Clearance">Pending Clearance</option>
                  <option value="In Progress">In Progress</option>
                </select>
              </div>
              <div class="col-md-4">
                <label class="form-label small fw-semibold">Charge Handed Over To</label>
                <input type="text" id="trHandoverTo" class="form-control form-control-sm" placeholder="Colleague name / ID">
              </div>
              <div class="col-md-4">
                <label class="form-label small fw-semibold">Approved By (Authority)</label>
                <input type="text" id="trApprovedBy" class="form-control form-control-sm" value="Zonal Manager" placeholder="e.g. Zonal Manager / Director">
              </div>
            </div>
          </div>

          <!-- Reason & Remarks -->
          <div class="row g-3 mb-2">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Transfer / Release Reason</label>
              <select id="trReasonSelect" class="form-select" onchange="checkCustomReason(this)">
                <option value="Routine 2-Year Branch Rotation">Routine 2-Year Branch Rotation</option>
                <option value="Promotion & Higher Responsibility Posting">Promotion & Higher Responsibility Posting</option>
                <option value="Branch Restructuring & Consolidation">Branch Restructuring & Consolidation</option>
                <option value="Station Close & Resource Migration">Station Close & Resource Migration</option>
                <option value="Emergency Operational Need">Emergency Operational Need</option>
                <option value="Officer Personal Hardship Request">Officer Personal Hardship Request</option>
                <option value="Administrative Reassignment">Administrative Reassignment</option>
                <option value="OTHER">Other / Custom Reason...</option>
              </select>
              <input type="text" id="trCustomReason" class="form-control mt-2 d-none" placeholder="Enter custom movement reason...">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Administrative Remarks / Notes</label>
              <textarea id="trRemarks" class="form-control" rows="2" placeholder="e.g. All branch records and digital assets formally transferred."></textarea>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer bg-light">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="saveTransferBtn" onclick="submitTransferForm()">
          <i data-lucide="check" class="me-1"></i> Confirm & Record Movement
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Staff Career Posting Journey Modal -->
<div class="modal fade" id="staffJourneyModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-light">
        <div class="d-flex align-items-center gap-2">
          <div class="p-2 rounded-2 bg-primary-subtle text-primary">
            <i data-lucide="git-merge" style="width: 18px; height: 18px;"></i>
          </div>
          <div>
            <b class="modal-title h6 mb-0" id="journeyModalStaffName">Staff Career & Posting Journey</b>
            <div class="small text-muted" id="journeyModalStaffSub">Chronological station history and transfer audit trail</div>
          </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-3 p-md-4">
        <!-- Staff Summary Header Card -->
        <div class="cardx p-3 mb-4 bg-light border">
          <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div class="d-flex align-items-center gap-3">
              <div class="rounded-circle bg-primary text-white d-grid place-items-center fw-bold fs-5" style="width:50px;height:50px" id="journeyAvatar">
                ST
              </div>
              <div>
                <h5 class="mb-0 fw-bold text-dark" id="journeyCardName">-</h5>
                <div class="text-muted small">
                  <span id="journeyCardDesignation">-</span> &bull; 
                  <span id="journeyCardDept">-</span>
                </div>
              </div>
            </div>
            <div class="d-flex flex-column align-items-end">
              <span class="badge bg-light text-dark border font-monospace fs-6 px-2 py-1 mb-1" id="journeyCardStaffId">-</span>
              <span id="journeyCardStatusBadge"></span>
            </div>
          </div>
        </div>

        <!-- Milestones Timeline Container -->
        <h6 class="fw-bold text-dark mb-3 d-flex align-items-center gap-2">
          <i data-lucide="milestone" style="width: 16px; height: 16px;" class="text-primary"></i>
          Posting Milestones & Movements
        </h6>
        <div class="timeline-container ps-4" id="journeyTimelineItems">
          <div class="text-center py-4 text-muted">
            <div class="spinner-border spinner-border-sm me-2"></div> Loading posting journey...
          </div>
        </div>
      </div>
      <div class="modal-footer bg-light">
        <button type="button" class="btn btn-outline-primary btn-sm" onclick="printCurrentJourney()">
          <i data-lucide="printer" style="width: 14px; height: 14px;" class="me-1"></i> Print Journey
        </button>
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Printable Transfer Advice Slip Modal -->
<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1100;">
  <div id="toast" class="toast align-items-center text-bg-primary border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">Notification message</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>

<div class="modal fade" id="transferAdviceModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-light no-print">
        <b class="modal-title">Official Transfer / Release Advice Slip</b>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4" id="transferAdviceSlipContent">
        <!-- Printable Advice Content Injected dynamically -->
      </div>
      <div class="modal-footer bg-light no-print">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="printAdviceSlip()">
          <i data-lucide="printer" class="me-1"></i> Print Official Order
        </button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
let currentStaffList = [];
let currentSort = { column: 'serial', order: 'asc' };
let currentPage = 1;
let debounceTimer = null;
let cachedDepartments = [];

function esc(x) {
  return String(x ?? '').replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  }[m]));
}

function formatDate(x) {
  if (!x) return '-';
  const d = new Date(x.includes('T') ? x : x + 'T00:00:00');
  return isNaN(d) ? x : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function showToast(msg, isError = false) {
  Swal.fire({
    toast: true,
    position: 'bottom-end',
    icon: isError ? 'error' : 'success',
    title: msg,
    showConfirmButton: false,
    timer: 2500
  });
}

function debounceStaffLoad() {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    currentPage = 1;
    loadStaffPositions();
  }, 300);
}

function applyFilters() {
  currentPage = 1;
  loadStaffPositions();
}

function changeSort(col) {
  if (currentSort.column === col) {
    currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
  } else {
    currentSort.column = col;
    currentSort.order = 'asc';
  }
  updateSortIcons();
  loadStaffPositions();
}

function updateSortIcons() {
  ['serial', 'name', 'staff_id', 'designation', 'join_date', 'department', 'status'].forEach(c => {
    const el = document.getElementById(`sort_icon_${c}`);
    if (el) {
      if (currentSort.column === c) {
        el.textContent = currentSort.order === 'asc' ? '↑' : '↓';
        el.className = 'text-primary fw-bold';
      } else {
        el.textContent = '↕';
        el.className = 'text-muted';
      }
    }
  });
}

async function loadStaffPositions() {
  const department = document.getElementById('filterDepartment')?.value || '';
  const position = document.getElementById('filterPosition')?.value || '';
  const district = document.getElementById('filterDistrict')?.value || '';
  const status = document.getElementById('filterStatus')?.value || '';
  const search = document.getElementById('filterSearch')?.value?.trim() || '';

  const tbody = document.getElementById('staffTableBody');
  if (tbody) {
    tbody.innerHTML = `<tr><td colspan="18" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading staff position records...</td></tr>`;
  }

  try {
    const params = new URLSearchParams({
      department,
      position,
      district,
      status,
      search,
      sort_by: currentSort.column,
      sort_order: currentSort.order,
      page: currentPage,
      per_page: 50
    });

    const res = await axios.get(`/api/staff-position-list?${params.toString()}`);
    if (res.data.success) {
      currentStaffList = res.data.data || [];
      const meta = res.data.meta || {};
      const pagination = res.data.pagination || {};

      populateDropdownOptions(meta);
      renderStaffTable(currentStaffList, pagination);
    }
  } catch (err) {
    console.error('Error loading staff list:', err);
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="18" class="text-center py-4 text-danger">Failed to load staff records. ${err.response?.data?.message || err.message}</td></tr>`;
    }
  }
}

function populateDropdownOptions(meta) {
  // Update positions dropdown if empty
  const posSelect = document.getElementById('filterPosition');
  if (posSelect && posSelect.options.length <= 1 && meta.positions) {
    meta.positions.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p;
      posSelect.appendChild(opt);
    });
  }

  // Update districts dropdown if empty
  const distSelect = document.getElementById('filterDistrict');
  if (distSelect && distSelect.options.length <= 1 && meta.districts) {
    meta.districts.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d;
      opt.textContent = d;
      distSelect.appendChild(opt);
    });
  }
}

async function loadDepartmentsDropdown() {
  try {
    const res = await axios.get('/api/department-management?per_page=200');
    if (res.data.success) {
      cachedDepartments = res.data.data || [];
      const filterSelect = document.getElementById('filterDepartment');
      const formSelect = document.getElementById('staffDepartmentSelect');

      if (filterSelect) {
        const curVal = filterSelect.value;
        filterSelect.innerHTML = '<option value="">All Departments</option>';
        cachedDepartments.forEach(d => {
          const opt = document.createElement('option');
          opt.value = d.name;
          opt.textContent = d.name;
          filterSelect.appendChild(opt);
        });
        filterSelect.value = curVal;
      }

      if (formSelect) {
        formSelect.innerHTML = '<option value="">Select Department</option>';
        cachedDepartments.forEach(d => {
          const opt = document.createElement('option');
          opt.value = d.name;
          opt.textContent = d.name;
          formSelect.appendChild(opt);
        });
      }
    }
  } catch (e) {
    console.error('Failed to load departments dropdown:', e);
  }
}

function getStatusBadge(status) {
  switch (status) {
    case 'Active': return '<span class="badge badge-active">Active</span>';
    case 'On Leave': return '<span class="badge badge-leave">On Leave</span>';
    case 'Transferred': return '<span class="badge badge-transferred">Transferred</span>';
    default: return '<span class="badge badge-inactive">Inactive</span>';
  }
}

function renderStaffTable(staff, pagination) {
  const tbody = document.getElementById('staffTableBody');
  if (!tbody) return;

  if (!staff.length) {
    tbody.innerHTML = `<tr><td colspan="18" class="text-center py-4 text-muted">No staff records found matching criteria.</td></tr>`;
    renderPagination(pagination);
    return;
  }

  tbody.innerHTML = staff.map((s, idx) => `
    <tr>
      <td>${esc(s.serial || String(idx + 1).padStart(2, '0'))}</td>
      <td class="fw-semibold text-primary">${esc(s.name)}</td>
      <td>${esc(s.gender || 'Male')}</td>
      <td>${formatDate(s.dob)}</td>
      <td>${esc(s.father || '-')}</td>
      <td>${esc(s.mother || '-')}</td>
      <td><span class="badge bg-light text-dark border font-monospace">${esc(s.staff_id)}</span></td>
      <td>${esc(s.designation)}</td>
      <td>${formatDate(s.join_date)}</td>
      <td>${formatDate(s.posting_date)}</td>
      <td>${formatDate(s.promotion_date)}</td>
      <td>${esc(s.education || '-')}</td>
      <td>${esc(s.home_district || '-')}</td>
      <td>${esc(s.previous_posting || '-')}</td>
      <td>${esc(s.current_posting || '-')}</td>
      <td><span class="badge bg-secondary-subtle text-dark border">${esc(s.department)}</span></td>
      <td>
        <span onclick="cycleStaffStatus('${s.id}', '${s.status}')" title="Click to change status" style="cursor: pointer;">
          ${getStatusBadge(s.status)}
        </span>
      </td>
      <td class="no-print text-center">
        <div class="action-group d-flex gap-1 justify-content-center">
          <button type="button" class="btn btn-sm btn-outline-primary" onclick="staffViewId('${s.id}')" title="View Details">
            <i data-lucide="eye"></i>
          </button>
          <button type="button" class="btn btn-sm btn-outline-info" onclick="viewStaffTransferTimeline('${esc(s.staff_id)}', '${esc(s.name)}')" title="View Transfer & Close Timeline">
            <i data-lucide="route"></i>
          </button>
          <button type="button" class="btn btn-sm btn-outline-success" onclick="openTransferModalForStaff('${esc(s.staff_id)}')" title="Transfer / Close Station">
            <i data-lucide="arrow-left-right"></i>
          </button>
          <button type="button" class="btn btn-sm btn-outline-secondary" onclick="staffEditId('${s.id}')" title="Edit Record">
            <i data-lucide="pencil"></i>
          </button>
          <button type="button" class="btn btn-sm btn-outline-danger" onclick="staffDeleteId('${s.id}', '${esc(s.name)}')" title="Delete Record">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

  if (window.lucide) lucide.createIcons();
  renderPagination(pagination);
}

function renderPagination(pagination) {
  const infoEl = document.getElementById('paginationInfo');
  const controlsEl = document.getElementById('paginationControls');
  if (!infoEl || !controlsEl) return;

  const total = pagination.total || 0;
  const page = pagination.page || 1;
  const perPage = pagination.per_page || 50;
  const lastPage = pagination.last_page || 1;

  const start = total === 0 ? 0 : (page - 1) * perPage + 1;
  const end = Math.min(page * perPage, total);
  infoEl.textContent = `Showing ${start} to ${end} of ${total} records`;

  if (lastPage <= 1) {
    controlsEl.innerHTML = '';
    return;
  }

  let html = `<button class="btn btn-sm btn-outline-secondary ${page <= 1 ? 'disabled' : ''}" onclick="goToStaffPage(${page - 1})">Prev</button>`;
  for (let p = 1; p <= lastPage; p++) {
    html += `<button class="btn btn-sm ${p === page ? 'btn-primary' : 'btn-outline-secondary'}" onclick="goToStaffPage(${p})">${p}</button>`;
  }
  html += `<button class="btn btn-sm btn-outline-secondary ${page >= lastPage ? 'disabled' : ''}" onclick="goToStaffPage(${page + 1})">Next</button>`;
  controlsEl.innerHTML = html;
}

function goToStaffPage(p) {
  currentPage = p;
  loadStaffPositions();
}

function openStaffAddModal() {
  document.getElementById('staffDbId').value = '';
  document.getElementById('staffSerial').value = '';
  document.getElementById('staffName').value = '';
  document.getElementById('staffGender').value = 'Male';
  document.getElementById('staffDob').value = '';
  document.getElementById('staffFather').value = '';
  document.getElementById('staffMother').value = '';
  document.getElementById('staffEmployeeId').value = '';
  document.getElementById('staffDesignation').value = '';
  document.getElementById('staffDepartmentSelect').value = '';
  document.getElementById('staffJoinDate').value = '';
  document.getElementById('staffPostingDate').value = '';
  document.getElementById('staffPromotionDate').value = '';
  document.getElementById('staffEducation').value = '';
  document.getElementById('staffHomeDistrict').value = '';
  document.getElementById('staffPreviousPosting').value = '';
  document.getElementById('staffCurrentPosting').value = '';
  document.getElementById('staffStatus').value = 'Active';

  document.getElementById('staffModalTitle').textContent = 'Add Staff Position Record';
  clearValidationErrors();
  bootstrap.Modal.getOrCreateInstance(document.getElementById('staffModal')).show();
}

async function staffEditId(id) {
  clearValidationErrors();
  try {
    const res = await axios.get(`/api/staff-position-list/${id}`);
    if (res.data.success) {
      const s = res.data.data;
      document.getElementById('staffDbId').value = s.id;
      document.getElementById('staffSerial').value = s.serial || '';
      document.getElementById('staffName').value = s.name || '';
      document.getElementById('staffGender').value = s.gender || 'Male';
      document.getElementById('staffDob').value = s.dob || '';
      document.getElementById('staffFather').value = s.father || '';
      document.getElementById('staffMother').value = s.mother || '';
      document.getElementById('staffEmployeeId').value = s.staff_id || '';
      document.getElementById('staffDesignation').value = s.designation || '';
      document.getElementById('staffDepartmentSelect').value = s.department || '';
      document.getElementById('staffJoinDate').value = s.join_date || '';
      document.getElementById('staffPostingDate').value = s.posting_date || '';
      document.getElementById('staffPromotionDate').value = s.promotion_date || '';
      document.getElementById('staffEducation').value = s.education || '';
      document.getElementById('staffHomeDistrict').value = s.home_district || '';
      document.getElementById('staffPreviousPosting').value = s.previous_posting || '';
      document.getElementById('staffCurrentPosting').value = s.current_posting || '';
      document.getElementById('staffStatus').value = s.status || 'Active';

      document.getElementById('staffModalTitle').textContent = 'Edit Staff Position Record';
      bootstrap.Modal.getOrCreateInstance(document.getElementById('staffModal')).show();
    }
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to load staff record.', true);
  }
}

async function saveStaffRecord() {
  clearValidationErrors();
  const id = document.getElementById('staffDbId').value.trim();
  const payload = {
    serial: document.getElementById('staffSerial').value.trim(),
    name: document.getElementById('staffName').value.trim(),
    gender: document.getElementById('staffGender').value,
    dob: document.getElementById('staffDob').value,
    father: document.getElementById('staffFather').value.trim(),
    mother: document.getElementById('staffMother').value.trim(),
    staff_id: document.getElementById('staffEmployeeId').value.trim(),
    designation: document.getElementById('staffDesignation').value.trim(),
    department: document.getElementById('staffDepartmentSelect').value,
    join_date: document.getElementById('staffJoinDate').value,
    posting_date: document.getElementById('staffPostingDate').value,
    promotion_date: document.getElementById('staffPromotionDate').value,
    education: document.getElementById('staffEducation').value.trim(),
    home_district: document.getElementById('staffHomeDistrict').value.trim(),
    previous_posting: document.getElementById('staffPreviousPosting').value.trim(),
    current_posting: document.getElementById('staffCurrentPosting').value.trim(),
    status: document.getElementById('staffStatus').value
  };

  let hasError = false;
  if (!payload.name) {
    setFieldError('staffName', 'Staff Name is required.');
    hasError = true;
  }
  if (!payload.staff_id) {
    setFieldError('staffEmployeeId', 'Staff ID is required.');
    hasError = true;
  }
  if (!payload.designation) {
    setFieldError('staffDesignation', 'Designation is required.');
    hasError = true;
  }
  if (!payload.department) {
    setFieldError('staffDepartmentSelect', 'Department selection is required.');
    hasError = true;
  }
  if (hasError) return;

  const btn = document.getElementById('saveStaffBtn');
  if (btn) btn.disabled = true;

  try {
    let res;
    if (id) {
      res = await axios.put(`/api/staff-position-list/${id}`, payload);
    } else {
      res = await axios.post('/api/staff-position-list', payload);
    }

    if (res.data.success) {
      bootstrap.Modal.getInstance(document.getElementById('staffModal')).hide();
      showToast(id ? 'Staff record updated successfully.' : 'Staff record created successfully.');
      loadStaffPositions();
    }
  } catch (err) {
    const resp = err.response?.data;
    if (resp?.errors) {
      if (resp.errors.name) setFieldError('staffName', resp.errors.name);
      if (resp.errors.staff_id) setFieldError('staffEmployeeId', resp.errors.staff_id);
      if (resp.errors.designation) setFieldError('staffDesignation', resp.errors.designation);
      if (resp.errors.department) setFieldError('staffDepartmentSelect', resp.errors.department);
    } else {
      showToast(resp?.message || resp?.error || 'Failed to save staff record.', true);
    }
  } finally {
    if (btn) btn.disabled = false;
  }
}

function setFieldError(fieldId, msg) {
  const input = document.getElementById(fieldId);
  const err = document.getElementById(fieldId.replace('Select', '') + 'Err');
  if (input) input.classList.add('is-invalid');
  if (err) {
    err.textContent = msg;
    err.style.display = 'block';
  }
}

function clearValidationErrors() {
  ['staffName', 'staffEmployeeId', 'staffDesignation', 'staffDepartmentSelect'].forEach(id => {
    const input = document.getElementById(id);
    const err = document.getElementById(id.replace('Select', '') + 'Err');
    if (input) input.classList.remove('is-invalid');
    if (err) {
      err.textContent = '';
      err.style.display = 'none';
    }
  });
}

async function staffViewId(id) {
  const modalBody = document.getElementById('staffViewBody');
  modalBody.innerHTML = `<div class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading details...</div>`;
  bootstrap.Modal.getOrCreateInstance(document.getElementById('staffViewModal')).show();

  try {
    const res = await axios.get(`/api/staff-position-list/${id}`);
    if (res.data.success) {
      const s = res.data.data;
      modalBody.innerHTML = `
        <div class="row g-3">
          <div class="col-md-6">
            <div class="border rounded p-3 bg-light">
              <div class="small text-muted">কর্মকর্তার নাম</div>
              <div class="h5 fw-bold text-primary mb-2">${esc(s.name)}</div>
              <div class="small text-muted">ID নং</div>
              <div class="fw-bold font-monospace mb-2">${esc(s.staff_id)}</div>
              <div class="small text-muted">পদবী</div>
              <div class="fw-semibold mb-2">${esc(s.designation)}</div>
              <div class="small text-muted">Department</div>
              <div class="fw-semibold mb-2">${esc(s.department)}</div>
              <div class="small text-muted">Status</div>
              <div class="mb-0">${getStatusBadge(s.status)}</div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="border rounded p-3">
              <div class="d-flex justify-content-between border-bottom py-1"><b>Gender:</b> <span>${esc(s.gender)}</span></div>
              <div class="d-flex justify-content-between border-bottom py-1"><b>Date of Birth:</b> <span>${formatDate(s.dob)}</span></div>
              <div class="d-flex justify-content-between border-bottom py-1"><b>পিতার নাম:</b> <span>${esc(s.father || '-')}</span></div>
              <div class="d-flex justify-content-between border-bottom py-1"><b>মাতার নাম:</b> <span>${esc(s.mother || '-')}</span></div>
              <div class="d-flex justify-content-between border-bottom py-1"><b>শিক্ষাগত যোগ্যতা:</b> <span>${esc(s.education || '-')}</span></div>
              <div class="d-flex justify-content-between py-1"><b>নিজ জেলা:</b> <span>${esc(s.home_district || '-')}</span></div>
            </div>
          </div>
          <div class="col-12">
            <div class="border rounded p-3">
              <div class="row g-2">
                <div class="col-md-4">
                  <div class="small text-muted">TMSS-এ যোগদান</div>
                  <div class="fw-semibold">${formatDate(s.join_date)}</div>
                </div>
                <div class="col-md-4">
                  <div class="small text-muted">বর্তমান কর্মস্থলে যোগদান</div>
                  <div class="fw-semibold">${formatDate(s.posting_date)}</div>
                </div>
                <div class="col-md-4">
                  <div class="small text-muted">সর্বশেষ পদোন্নতি</div>
                  <div class="fw-semibold">${formatDate(s.promotion_date)}</div>
                </div>
                <div class="col-md-6 mt-3">
                  <div class="small text-muted">পূর্ববর্তী কর্মস্থল</div>
                  <div>${esc(s.previous_posting || '-')}</div>
                </div>
                <div class="col-md-6 mt-3">
                  <div class="small text-muted">বর্তমান কর্মস্থল</div>
                  <div class="fw-semibold text-dark">${esc(s.current_posting || '-')}</div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 mt-3 pt-2 border-top d-flex flex-wrap justify-content-end gap-2">
            <button type="button" class="btn btn-outline-info btn-sm d-flex align-items-center gap-1" onclick="bootstrap.Modal.getInstance(document.getElementById('staffViewModal')).hide(); viewStaffTransferTimeline('${esc(s.staff_id)}', '${esc(s.name)}')">
              <i data-lucide="route" style="width: 15px; height: 15px;"></i>
              <span>View Transfer & Close Timeline</span>
            </button>
            <button type="button" class="btn btn-outline-success btn-sm d-flex align-items-center gap-1" onclick="bootstrap.Modal.getInstance(document.getElementById('staffViewModal')).hide(); openTransferModalForStaff('${esc(s.staff_id)}')">
              <i data-lucide="arrow-left-right" style="width: 15px; height: 15px;"></i>
              <span>Transfer / Close Station</span>
            </button>
          </div>
        </div>
      `;
      if (window.lucide) lucide.createIcons();
    }
  } catch (err) {
    modalBody.innerHTML = `<div class="alert alert-danger mb-0">${err.response?.data?.message || 'Failed to load details.'}</div>`;
  }
}

async function cycleStaffStatus(id, currentStatus) {
  const statuses = ['Active', 'On Leave', 'Transferred', 'Inactive'];
  const nextIdx = (statuses.indexOf(currentStatus) + 1) % statuses.length;
  const newStatus = statuses[nextIdx];

  try {
    const res = await axios.post(`/api/staff-position-list/${id}/status`, { status: newStatus });
    if (res.data.success) {
      showToast(`Status updated to ${newStatus}.`);
      loadStaffPositions();
    }
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to update status.', true);
  }
}

async function staffDeleteId(id, name) {
  const result = await Swal.fire({
    title: 'Delete Staff Record?',
    html: `Are you sure you want to permanently delete record for <b>${name || id}</b>?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#64748b',
    confirmButtonText: 'Yes, Delete'
  });

  if (!result.isConfirmed) return;

  try {
    const res = await axios.delete(`/api/staff-position-list/${id}`);
    if (res.data.success) {
      showToast('Staff record deleted successfully.');
      loadStaffPositions();
    }
  } catch (err) {
    Swal.fire({
      title: 'Delete Failed',
      text: err.response?.data?.message || 'Failed to delete record.',
      icon: 'error'
    });
  }
}

async function printPage() {
  try {
    await axios.post('/api/staff-position-list/action', {
      action: 'print',
      reference: 'Staff Position List Print Report'
    });
  } catch (e) {}
  window.print();
}

async function exportStaffCSV() {
  try {
    const res = await axios.get('/api/staff-position-list?per_page=1000');
    const rows = res.data.data || [];

    await axios.post('/api/staff-position-list/action', {
      action: 'export',
      reference: `Staff Position CSV Export (${rows.length} records)`
    });

    const headers = [
      'SL', 'Name', 'Gender', 'DOB', 'Father', 'Mother', 'Staff ID',
      'Designation', 'TMSS Join Date', 'Current Posting Date', 'Promotion Date',
      'Education', 'Home District', 'Previous Posting', 'Current Posting',
      'Department', 'Status'
    ];

    const csvRows = [headers];
    rows.forEach((r, idx) => {
      csvRows.push([
        r.serial || idx + 1,
        r.name || '',
        r.gender || '',
        r.dob || '',
        r.father || '',
        r.mother || '',
        r.staff_id || '',
        r.designation || '',
        r.join_date || '',
        r.posting_date || '',
        r.promotion_date || '',
        r.education || '',
        r.home_district || '',
        r.previous_posting || '',
        r.current_posting || '',
        r.department || '',
        r.status || ''
      ]);
    });

    const csvContent = csvRows.map(row =>
      row.map(val => `"${String(val).replaceAll('"', '""')}"`).join(',')
    ).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `staff_positions_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);

    showToast('CSV export downloaded successfully.');
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to export CSV.', true);
  }
}

/* =========================================================================
   DEDICATED STAFF TRANSFER & BRANCH CLOSE TIMELINE ENGINE
   ========================================================================= */

let activeStaffView = 'roster';
let activeTimelineMode = 'stream';
let timelinePage = 1;
let timelinePerPage = 20;
let timelineDebounceTimer = null;
let cachedBranches = [];
let cachedStaffMembers = [];
let currentTimelineList = [];
let currentTimelineStats = {};
let currentTimelinePagination = {};
let currentSelectedStaffJourney = null;

function switchStaffView(viewName) {
  activeStaffView = viewName;
  const rosterBtn = document.getElementById('tabRosterBtn');
  const timelineBtn = document.getElementById('tabTimelineBtn');
  const rosterView = document.getElementById('rosterView');
  const timelineView = document.getElementById('timelineView');
  const mainTitle = document.getElementById('moduleMainTitle');
  const mainSubtitle = document.getElementById('moduleMainSubtitle');

  if (viewName === 'timeline') {
    if (rosterBtn) rosterBtn.classList.remove('active');
    if (timelineBtn) timelineBtn.classList.add('active');
    if (rosterView) rosterView.style.display = 'none';
    if (timelineView) timelineView.style.display = 'block';

    if (mainTitle) mainTitle.textContent = 'Staff Transfer & Branch Close Timeline';
    if (mainSubtitle) mainSubtitle.textContent = 'Visual chronological tracking of staff transfers, branch assignments, and station release histories.';

    window.location.hash = '#timeline';
    loadTimelineBranches();
    loadStaffMembersForTransfer();
    loadTimelineDepartments();
    loadTransferTimeline();
  } else {
    if (timelineBtn) timelineBtn.classList.remove('active');
    if (rosterBtn) rosterBtn.classList.add('active');
    if (timelineView) timelineView.style.display = 'none';
    if (rosterView) rosterView.style.display = 'block';

    if (mainTitle) mainTitle.textContent = 'Staff Position List & Postings';
    if (mainSubtitle) mainSubtitle.textContent = 'Maintain staff master positions and track inter-branch transfers and station closures.';

    window.location.hash = '#roster';
  }

  if (window.lucide) lucide.createIcons();
}

function switchTimelineMode(mode) {
  activeTimelineMode = mode;
  ['stream', 'journey', 'matrix'].forEach(m => {
    const btn = document.getElementById(`btnMode${m.charAt(0).toUpperCase() + m.slice(1)}`);
    const container = document.getElementById(`tlMode${m.charAt(0).toUpperCase() + m.slice(1)}Container`);
    if (btn) btn.classList.toggle('active', m === mode);
    if (container) container.style.display = m === mode ? 'block' : 'none';
  });

  if (mode === 'stream') {
    renderTimelineStream(currentTimelineList, currentTimelinePagination);
  } else if (mode === 'journey') {
    renderStaffJourneys(currentTimelineList);
  } else if (mode === 'matrix') {
    renderBranchMatrix(currentTimelineList);
  }

  if (window.lucide) lucide.createIcons();
}

async function loadTimelineBranches() {
  if (cachedBranches.length > 0) return;
  try {
    const res = await axios.get('/api/staff-transfers/branches');
    if (res.data.success) {
      cachedBranches = res.data.data || [];
      const filterSelect = document.getElementById('tlFilterBranch');
      const targetSelect = document.getElementById('trToBranchSelect');

      if (filterSelect) {
        filterSelect.innerHTML = '<option value="">All Branches</option>';
        cachedBranches.forEach(b => {
          const opt = document.createElement('option');
          opt.value = b.branch_name;
          opt.textContent = `${b.branch_name} (${b.district || 'Branch'})`;
          filterSelect.appendChild(opt);
        });
      }

      if (targetSelect) {
        targetSelect.innerHTML = '<option value="">-- Select Destination Branch --</option>';
        cachedBranches.forEach(b => {
          const opt = document.createElement('option');
          opt.value = b.branch_name;
          opt.textContent = `${b.branch_name} (${b.district || 'Branch'})`;
          targetSelect.appendChild(opt);
        });
      }
    }
  } catch (e) {
    console.error('Failed to load branches for timeline:', e);
  }
}

async function loadStaffMembersForTransfer() {
  if (cachedStaffMembers.length > 0) return;
  try {
    const res = await axios.get('/api/staff-transfers/staff');
    if (res.data.success) {
      cachedStaffMembers = res.data.data || [];
      const select = document.getElementById('trStaffSelect');
      if (select) {
        select.innerHTML = '<option value="">-- Choose Staff Officer --</option>';
        cachedStaffMembers.forEach(s => {
          const opt = document.createElement('option');
          opt.value = s.staff_id;
          opt.textContent = `[${s.staff_id}] ${s.name} - ${s.designation} (${s.current_posting || 'Unassigned'})`;
          opt.dataset.name = s.name;
          opt.dataset.designation = s.designation;
          opt.dataset.department = s.department;
          opt.dataset.branch = s.current_posting || '';
          select.appendChild(opt);
        });
      }
    }
  } catch (e) {
    console.error('Failed to load staff list for transfers:', e);
  }
}

function loadTimelineDepartments() {
  const deptSelect = document.getElementById('tlFilterDepartment');
  if (deptSelect && deptSelect.options.length <= 1 && cachedDepartments.length > 0) {
    deptSelect.innerHTML = '<option value="">All Departments</option>';
    cachedDepartments.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.name;
      opt.textContent = d.name;
      deptSelect.appendChild(opt);
    });
  }
}

function debounceTimelineLoad() {
  clearTimeout(timelineDebounceTimer);
  timelineDebounceTimer = setTimeout(() => {
    timelinePage = 1;
    loadTransferTimeline();
  }, 300);
}

function applyTimelineFilters() {
  timelinePage = 1;
  loadTransferTimeline();
}

function resetTimelineFilters() {
  const tType = document.getElementById('tlFilterType');
  const tBranch = document.getElementById('tlFilterBranch');
  const tDept = document.getElementById('tlFilterDepartment');
  const tSearch = document.getElementById('tlFilterSearch');
  const tFrom = document.getElementById('tlFilterDateFrom');
  const tTo = document.getElementById('tlFilterDateTo');

  if (tType) tType.value = 'All';
  if (tBranch) tBranch.value = '';
  if (tDept) tDept.value = '';
  if (tSearch) tSearch.value = '';
  if (tFrom) tFrom.value = '';
  if (tTo) tTo.value = '';

  timelinePage = 1;
  loadTransferTimeline();
}

async function loadTransferTimeline() {
  const type = document.getElementById('tlFilterType')?.value || 'All';
  const branch = document.getElementById('tlFilterBranch')?.value || '';
  const department = document.getElementById('tlFilterDepartment')?.value || '';
  const search = document.getElementById('tlFilterSearch')?.value?.trim() || '';
  const date_from = document.getElementById('tlFilterDateFrom')?.value || '';
  const date_to = document.getElementById('tlFilterDateTo')?.value || '';

  const streamContainer = document.getElementById('timelineStreamList');
  if (streamContainer && activeTimelineMode === 'stream') {
    streamContainer.innerHTML = `<div class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading transfer and branch close timeline...</div>`;
  }

  try {
    const params = new URLSearchParams({
      type,
      branch,
      department,
      search,
      date_from,
      date_to,
      page: timelinePage,
      per_page: timelinePerPage
    });

    const res = await axios.get(`/api/staff-transfers?${params.toString()}`);
    if (res.data.success) {
      currentTimelineList = res.data.data || [];
      currentTimelineStats = res.data.stats || {};
      currentTimelinePagination = res.data.pagination || {};

      // Update KPI Statistics Ribbon
      document.getElementById('statTotalMovements').textContent = (currentTimelineStats.total || 0).toLocaleString();
      document.getElementById('statTotalTransfers').textContent = (currentTimelineStats.transfers || 0).toLocaleString();
      document.getElementById('statTotalClosures').textContent = (currentTimelineStats.closures || 0).toLocaleString();
      document.getElementById('statBranchesInvolved').textContent = (currentTimelineStats.branches_involved || 0).toLocaleString();

      const badge = document.getElementById('timelineCountBadge');
      if (badge) badge.textContent = (currentTimelineStats.total || currentTimelineList.length).toString();

      // Render Active View Mode
      if (activeTimelineMode === 'stream') {
        renderTimelineStream(currentTimelineList, currentTimelinePagination);
      } else if (activeTimelineMode === 'journey') {
        renderStaffJourneys(currentTimelineList);
      } else if (activeTimelineMode === 'matrix') {
        renderBranchMatrix(currentTimelineList);
      }

      renderTimelinePagination(currentTimelinePagination);
    }
  } catch (err) {
    console.error('Error loading timeline records:', err);
    if (streamContainer) {
      streamContainer.innerHTML = `<div class="text-center py-4 text-danger">Failed to load transfer records. ${err.response?.data?.message || err.message}</div>`;
    }
  }
}

function renderTimelineStream(items, pagination) {
  const container = document.getElementById('timelineStreamList');
  if (!container) return;

  if (!items.length) {
    container.innerHTML = `
      <div class="cardx p-4 text-center text-muted">
        <i data-lucide="route" class="mx-auto mb-2 text-slate-400" style="width: 36px; height: 36px;"></i>
        <div class="h6 fw-semibold text-dark">No Transfer or Branch Close Records Found</div>
        <p class="small text-muted mb-3">There are no movements matching your current filters and search query.</p>
        <button class="btn btn-outline-primary btn-sm" onclick="resetTimelineFilters()">
          <i data-lucide="rotate-ccw" class="me-1"></i> Reset Filters
        </button>
      </div>
    `;
    if (window.lucide) lucide.createIcons();
    return;
  }

  container.innerHTML = items.map((t, idx) => {
    const isClose = (t.transfer_type || '').toLowerCase() === 'close';
    const nodeClass = isClose ? 'node-close' : 'node-transfer';
    const nodeIcon = isClose ? 'log-out' : 'arrow-right-left';
    const typeLabel = isClose ? 'Staff Close / Station Release' : 'Inter-Branch Transfer';
    const typeBadgeClass = isClose ? 'bg-warning-subtle text-warning-emphasis border-warning' : 'bg-primary-subtle text-primary border-primary-subtle';

    const handoverBadge = t.handover_status === 'Completed' 
      ? '<span class="badge bg-success-subtle text-success border border-success-subtle"><i data-lucide="check-circle" style="width:12px;height:12px;" class="me-1"></i>Handover Completed</span>'
      : (t.handover_status === 'Pending Clearance' 
        ? '<span class="badge bg-danger-subtle text-danger border border-danger-subtle"><i data-lucide="clock" style="width:12px;height:12px;" class="me-1"></i>Pending Clearance</span>'
        : '<span class="badge bg-warning-subtle text-warning-emphasis border"><i data-lucide="refresh-cw" style="width:12px;height:12px;" class="me-1"></i>In Progress</span>');

    const staffInitial = (t.staff_name || 'ST').substring(0, 2).toUpperCase();

    return `
      <div class="position-relative mb-4">
        <!-- Node on Vertical Line -->
        <div class="timeline-node ${nodeClass}" title="${esc(typeLabel)}">
          <i data-lucide="${nodeIcon}" style="width: 16px; height: 16px;"></i>
        </div>

        <!-- Event Card -->
        <div class="timeline-card p-3 p-md-4 ms-3">
          <!-- Card Header & Metadata -->
          <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 border-bottom pb-3 mb-3">
            <div class="d-flex align-items-center gap-3">
              <div class="rounded-circle bg-light border text-primary fw-bold d-grid place-items-center" style="width: 44px; height: 44px;">
                ${staffInitial}
              </div>
              <div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                  <span class="h6 mb-0 fw-bold text-dark">${esc(t.staff_name || 'Staff Member')}</span>
                  <span class="badge bg-light text-dark border font-monospace small">${esc(t.staff_id)}</span>
                  <span class="badge ${typeBadgeClass} border px-2 py-0.5">${esc(typeLabel)}</span>
                </div>
                <div class="text-muted small mt-0.5">
                  <span class="fw-semibold text-slate-700">${esc(t.designation || 'Staff')}</span>
                  ${t.department ? ` &bull; <span class="text-muted">${esc(t.department)}</span>` : ''}
                </div>
              </div>
            </div>

            <!-- Date & Official Memo Ref -->
            <div class="text-end">
              <div class="fw-bold text-dark d-flex align-items-center justify-content-end gap-1">
                <i data-lucide="calendar" style="width: 14px; height: 14px;" class="text-primary"></i>
                ${formatDate(t.transfer_date)}
              </div>
              <div class="text-muted small font-monospace">
                Ref: <span class="text-dark fw-medium">${esc(t.order_number || 'N/A')}</span>
              </div>
            </div>
          </div>

          <!-- Movement Branch Flow Path -->
          <div class="p-3 rounded-3 bg-light border mb-3">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
              <!-- Origin Station -->
              <div class="flex-grow-1" style="min-width: 200px;">
                <div class="small text-muted text-uppercase fw-bold" style="font-size: 0.72rem;">
                  ${isClose ? 'Station Released From' : 'Origin Branch (Previous Posting)'}
                </div>
                <div class="d-flex align-items-center gap-2 mt-1">
                  <div class="p-1.5 rounded-2 bg-white border text-secondary">
                    <i data-lucide="building-2" style="width: 18px; height: 18px;"></i>
                  </div>
                  <div>
                    <span class="fw-bold text-dark">${esc(t.from_branch || 'Head Office')}</span>
                    <button class="btn btn-link p-0 text-decoration-none ms-1 text-muted" onclick="filterTimelineByBranch('${esc(t.from_branch)}')" title="Filter by this branch">
                      <i data-lucide="filter" style="width: 12px; height: 12px;"></i>
                    </button>
                  </div>
                </div>
              </div>

              <!-- Arrow / Close Indicator -->
              <div class="d-flex flex-column align-items-center px-2">
                <div class="p-2 rounded-circle ${isClose ? 'bg-warning-subtle text-warning' : 'bg-primary-subtle text-primary'}">
                  <i data-lucide="${isClose ? 'lock' : 'arrow-right'}" style="width: 18px; height: 18px;"></i>
                </div>
                <span class="small fw-semibold text-muted mt-1" style="font-size: 0.75rem;">
                  ${isClose ? 'Station Closed' : 'Transferred To'}
                </span>
              </div>

              <!-- Destination Station -->
              <div class="flex-grow-1" style="min-width: 200px;">
                <div class="small text-muted text-uppercase fw-bold" style="font-size: 0.72rem;">
                  ${isClose ? 'Clearance / Assignment' : 'Destination Branch (New Posting)'}
                </div>
                <div class="d-flex align-items-center gap-2 mt-1">
                  <div class="p-1.5 rounded-2 bg-white border ${isClose ? 'text-warning' : 'text-primary'}">
                    <i data-lucide="${isClose ? 'shield-check' : 'map-pin'}" style="width: 18px; height: 18px;"></i>
                  </div>
                  <div>
                    <span class="fw-bold ${isClose ? 'text-warning-emphasis' : 'text-primary'}">${esc(t.to_branch || 'Closed')}</span>
                    ${!isClose && t.to_branch ? `
                      <button class="btn btn-link p-0 text-decoration-none ms-1 text-muted" onclick="filterTimelineByBranch('${esc(t.to_branch)}')" title="Filter by this branch">
                        <i data-lucide="filter" style="width: 12px; height: 12px;"></i>
                      </button>
                    ` : ''}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Accountability, Reason & Remarks -->
          <div class="row g-2 small mb-3">
            <div class="col-md-4">
              <div class="text-muted fw-semibold">Reason for Movement:</div>
              <div class="text-dark">${esc(t.reason || 'Routine Administrative Transfer')}</div>
            </div>
            <div class="col-md-4">
              <div class="text-muted fw-semibold">Handover & Clearance:</div>
              <div class="d-flex align-items-center gap-2 mt-0.5">
                ${handoverBadge}
                ${t.handover_to ? `<span class="text-muted">to <b>${esc(t.handover_to)}</b></span>` : ''}
              </div>
            </div>
            <div class="col-md-4">
              <div class="text-muted fw-semibold">Authorized Authority:</div>
              <div class="text-dark fw-medium">${esc(t.approved_by || 'Zonal Authority')}</div>
            </div>
            ${t.remarks ? `
              <div class="col-12 mt-2">
                <div class="p-2 rounded bg-slate-50 border small text-muted">
                  <b>Remarks:</b> ${esc(t.remarks)}
                </div>
              </div>
            ` : ''}
          </div>

          <!-- Quick Action Buttons -->
          <div class="d-flex flex-wrap justify-content-end gap-2 border-top pt-2">
            <button type="button" class="btn btn-sm btn-outline-primary d-flex align-items-center gap-1" onclick="viewStaffTransferTimeline('${esc(t.staff_id)}', '${esc(t.staff_name)}')">
              <i data-lucide="git-merge" style="width: 14px; height: 14px;"></i>
              <span>View Career Posting Journey</span>
            </button>
            <button type="button" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1" onclick="openTransferAdviceSlip('${esc(t.id)}')">
              <i data-lucide="file-text" style="width: 14px; height: 14px;"></i>
              <span>Official Advice Order</span>
            </button>
            <button type="button" class="btn btn-sm btn-outline-success d-flex align-items-center gap-1" onclick="openTransferModalForStaff('${esc(t.staff_id)}')">
              <i data-lucide="arrow-left-right" style="width: 14px; height: 14px;"></i>
              <span>Transfer Again</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
}

function filterTimelineByBranch(branchName) {
  if (!branchName) return;
  const select = document.getElementById('tlFilterBranch');
  if (select) {
    select.value = branchName;
    applyTimelineFilters();
  }
}

function renderStaffJourneys(items) {
  const container = document.getElementById('tlJourneysList');
  if (!container) return;

  if (!items.length) {
    container.innerHTML = `<div class="col-12 text-center py-4 text-muted">No staff transfer histories found.</div>`;
    return;
  }

  // Group transfers by staff_id
  const staffMap = {};
  items.forEach(t => {
    if (!staffMap[t.staff_id]) {
      staffMap[t.staff_id] = {
        staff_id: t.staff_id,
        name: t.staff_name || 'Staff Member',
        designation: t.designation || 'Staff',
        department: t.department || 'General',
        current_posting: t.current_posting || t.to_branch || 'Current Station',
        transfers: []
      };
    }
    staffMap[t.staff_id].transfers.push(t);
  });

  const staffArray = Object.values(staffMap);

  container.innerHTML = staffArray.map(s => `
    <div class="col-md-6 col-xl-4">
      <div class="cardx p-3 h-100 d-flex flex-column justify-content-between">
        <div>
          <div class="d-flex align-items-center justify-content-between mb-2">
            <span class="badge bg-light text-dark border font-monospace">${esc(s.staff_id)}</span>
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle">
              ${s.transfers.length} Movement${s.transfers.length > 1 ? 's' : ''}
            </span>
          </div>
          <h6 class="fw-bold text-dark mb-1">${esc(s.name)}</h6>
          <div class="small text-muted mb-2">${esc(s.designation)} &bull; ${esc(s.department)}</div>
          <div class="p-2 rounded bg-light border small mb-3">
            <div class="text-muted" style="font-size: 0.72rem;">CURRENT ASSIGNMENT</div>
            <div class="fw-bold text-primary">${esc(s.current_posting)}</div>
          </div>
          <div class="small text-muted mb-1 fw-semibold">Recent Movements:</div>
          <div class="list-group list-group-flush border rounded-2 mb-3">
            ${s.transfers.slice(0, 3).map(m => `
              <div class="list-group-item px-2 py-1.5 small d-flex justify-content-between align-items-center">
                <span class="text-truncate" style="max-width: 170px;" title="${esc(m.from_branch)} ➔ ${esc(m.to_branch)}">
                  ${esc(m.from_branch)} ➔ ${esc(m.to_branch)}
                </span>
                <span class="badge bg-light text-muted border font-monospace">${formatDate(m.transfer_date)}</span>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="pt-2 border-top d-flex gap-2">
          <button class="btn btn-sm btn-outline-primary w-100 d-flex align-items-center justify-content-center gap-1" onclick="viewStaffTransferTimeline('${esc(s.staff_id)}', '${esc(s.name)}')">
            <i data-lucide="git-merge" style="width: 14px; height: 14px;"></i> View Full Journey
          </button>
          <button class="btn btn-sm btn-outline-success" onclick="openTransferModalForStaff('${esc(s.staff_id)}')" title="Transfer / Close">
            <i data-lucide="arrow-left-right" style="width: 14px; height: 14px;"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');

  if (window.lucide) lucide.createIcons();
}

function renderBranchMatrix(items) {
  const tbody = document.getElementById('tlMatrixTableBody');
  if (!tbody) return;

  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-muted">No movement records available to compute matrix.</td></tr>`;
    return;
  }

  const matrix = {};
  items.forEach(t => {
    const isClose = (t.transfer_type || '').toLowerCase() === 'close';
    const from = t.from_branch;
    const to = t.to_branch;

    if (from) {
      if (!matrix[from]) matrix[from] = { name: from, in: 0, out: 0, close: 0 };
      if (isClose) {
        matrix[from].close += 1;
      } else {
        matrix[from].out += 1;
      }
    }

    if (to && !isClose && to !== 'Closed' && to !== 'Closed / Released') {
      if (!matrix[to]) matrix[to] = { name: to, in: 0, out: 0, close: 0 };
      matrix[to].in += 1;
    }
  });

  const branchRows = Object.values(matrix).sort((a, b) => (b.in + b.out + b.close) - (a.in + a.out + a.close));

  tbody.innerHTML = branchRows.map(b => {
    const net = b.in - b.out - b.close;
    const netBadge = net > 0 
      ? `<span class="badge bg-success-subtle text-success">+${net}</span>`
      : (net < 0 ? `<span class="badge bg-danger-subtle text-danger">${net}</span>` : `<span class="badge bg-light text-dark">0</span>`);

    return `
      <tr>
        <td class="fw-bold text-dark">${esc(b.name)}</td>
        <td class="text-center"><span class="badge bg-primary-subtle text-primary fs-6">${b.in}</span></td>
        <td class="text-center"><span class="badge bg-secondary-subtle text-dark fs-6">${b.out}</span></td>
        <td class="text-center"><span class="badge bg-warning-subtle text-warning-emphasis fs-6">${b.close}</span></td>
        <td class="text-center">${netBadge}</td>
        <td class="text-center"><span class="badge bg-light border text-muted">Operational</span></td>
        <td class="text-center">
          <button class="btn btn-sm btn-outline-primary" onclick="filterTimelineByBranch('${esc(b.name)}')" title="View Timeline for this Branch">
            <i data-lucide="route" style="width: 14px; height: 14px;" class="me-1"></i> Filter Timeline
          </button>
        </td>
      </tr>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
}

function renderTimelinePagination(pagination) {
  const info = document.getElementById('tlPaginationInfo');
  const controls = document.getElementById('tlPaginationControls');
  if (!info || !controls) return;

  const total = pagination.total || 0;
  const page = pagination.page || 1;
  const perPage = pagination.per_page || 20;
  const lastPage = pagination.last_page || 1;

  const start = total === 0 ? 0 : (page - 1) * perPage + 1;
  const end = Math.min(page * perPage, total);
  info.textContent = `Showing ${start} to ${end} of ${total} timeline events`;

  if (lastPage <= 1) {
    controls.innerHTML = '';
    return;
  }

  let html = `
    <button class="btn btn-sm btn-light border" ${page === 1 ? 'disabled' : ''} onclick="goToTimelinePage(${page - 1})">
      &laquo; Prev
    </button>
  `;

  for (let p = Math.max(1, page - 2); p <= Math.min(lastPage, page + 2); p++) {
    html += `
      <button class="btn btn-sm ${p === page ? 'btn-primary' : 'btn-light border'}" onclick="goToTimelinePage(${p})">
        ${p}
      </button>
    `;
  }

  html += `
    <button class="btn btn-sm btn-light border" ${page === lastPage ? 'disabled' : ''} onclick="goToTimelinePage(${page + 1})">
      Next &raquo;
    </button>
  `;

  controls.innerHTML = html;
}

function goToTimelinePage(p) {
  timelinePage = p;
  loadTransferTimeline();
}

/* =========================================================================
   STAFF TRANSFER & CLOSE MODAL ACTIONS
   ========================================================================= */

function openTransferModal(type = 'Transfer', preSelectedStaffId = null) {
  const form = document.getElementById('staffTransferForm');
  if (form) form.reset();

  const isClose = type === 'Close';
  const rTransfer = document.getElementById('trTypeTransfer');
  const rClose = document.getElementById('trTypeClose');

  if (isClose) {
    if (rClose) rClose.checked = true;
  } else {
    if (rTransfer) rTransfer.checked = true;
  }

  handleTransferTypeChange();

  // Set default transfer date to today
  const dateInput = document.getElementById('trDate');
  if (dateInput) dateInput.value = new Date().toISOString().substring(0, 10);

  // Generate official order reference
  generateRandomOrderNo();

  // Pre-select staff if specified
  loadStaffMembersForTransfer().then(() => {
    if (preSelectedStaffId) {
      const select = document.getElementById('trStaffSelect');
      if (select) {
        select.value = preSelectedStaffId;
        onTransferStaffSelected();
      }
    }
  });

  loadTimelineBranches();

  bootstrap.Modal.getOrCreateInstance(document.getElementById('staffTransferModal')).show();
  if (window.lucide) lucide.createIcons();
}

function openTransferModalForStaff(staffId) {
  openTransferModal('Transfer', staffId);
}

function handleTransferTypeChange() {
  const isClose = document.getElementById('trTypeClose')?.checked;
  const modalTitle = document.getElementById('transferModalTitle');
  const toBranchLabel = document.getElementById('trToBranchLabel');
  const toBranchSelect = document.getElementById('trToBranchSelect');
  const toBranchCustom = document.getElementById('trToBranchCustom');
  const reasonSelect = document.getElementById('trReasonSelect');

  if (isClose) {
    if (modalTitle) modalTitle.textContent = 'Record Staff Station Close / Release';
    if (toBranchLabel) toBranchLabel.textContent = 'Station Clearance / Relocation Status *';
    if (toBranchSelect) toBranchSelect.classList.add('d-none');
    if (toBranchCustom) {
      toBranchCustom.classList.remove('d-none');
      toBranchCustom.value = 'Station Closed / Released';
    }
    if (reasonSelect) reasonSelect.value = 'Station Close & Resource Migration';
  } else {
    if (modalTitle) modalTitle.textContent = 'Record Inter-Branch Staff Transfer';
    if (toBranchLabel) toBranchLabel.textContent = 'Destination Branch *';
    if (toBranchSelect) {
      toBranchSelect.classList.remove('d-none');
      toBranchSelect.value = '';
    }
    if (toBranchCustom) toBranchCustom.classList.add('d-none');
    if (reasonSelect) reasonSelect.value = 'Routine 2-Year Branch Rotation';
  }
}

function onTransferStaffSelected() {
  const select = document.getElementById('trStaffSelect');
  if (!select) return;

  const opt = select.options[select.selectedIndex];
  const infoBanner = document.getElementById('trStaffInfoBanner');
  const fromBranchInput = document.getElementById('trFromBranch');

  if (!opt || !opt.value) {
    if (infoBanner) infoBanner.classList.add('d-none');
    return;
  }

  document.getElementById('trStaffIdBadge').textContent = opt.value;
  document.getElementById('trStaffDesignation').textContent = opt.dataset.designation || '-';
  document.getElementById('trStaffDepartment').textContent = opt.dataset.department || '-';
  if (fromBranchInput) fromBranchInput.value = opt.dataset.branch || 'Head Office';

  if (infoBanner) infoBanner.classList.remove('d-none');
}

function generateRandomOrderNo() {
  const year = new Date().getFullYear();
  const num = Math.floor(1000 + Math.random() * 9000);
  const input = document.getElementById('trOrderNumber');
  if (input) input.value = `TMSS/TR/${year}/${num}`;
}

function checkCustomReason(selectEl) {
  const customInput = document.getElementById('trCustomReason');
  if (customInput) {
    customInput.classList.toggle('d-none', selectEl.value !== 'OTHER');
    if (selectEl.value === 'OTHER') customInput.focus();
  }
}

async function submitTransferForm() {
  const isClose = document.getElementById('trTypeClose')?.checked;
  const staffSelect = document.getElementById('trStaffSelect');
  const staff_id = staffSelect?.value;
  const from_branch = document.getElementById('trFromBranch')?.value?.trim();
  
  let to_branch = '';
  if (isClose) {
    to_branch = document.getElementById('trToBranchCustom')?.value?.trim() || 'Station Closed / Released';
  } else {
    to_branch = document.getElementById('trToBranchSelect')?.value;
  }

  const transfer_date = document.getElementById('trDate')?.value;
  const order_number = document.getElementById('trOrderNumber')?.value?.trim();
  const handover_status = document.getElementById('trHandoverStatus')?.value || 'Completed';
  const handover_to = document.getElementById('trHandoverTo')?.value?.trim();
  const approved_by = document.getElementById('trApprovedBy')?.value?.trim() || 'Zonal Authority';
  
  let reason = document.getElementById('trReasonSelect')?.value;
  if (reason === 'OTHER') {
    reason = document.getElementById('trCustomReason')?.value?.trim() || 'Administrative Reassignment';
  }
  const remarks = document.getElementById('trRemarks')?.value?.trim() || '';

  // Validation
  let hasError = false;
  if (!staff_id) {
    document.getElementById('trStaffSelect')?.classList.add('is-invalid');
    hasError = true;
  } else {
    document.getElementById('trStaffSelect')?.classList.remove('is-invalid');
  }

  if (!from_branch) {
    document.getElementById('trFromBranch')?.classList.add('is-invalid');
    hasError = true;
  } else {
    document.getElementById('trFromBranch')?.classList.remove('is-invalid');
  }

  if (!to_branch) {
    if (!isClose) document.getElementById('trToBranchSelect')?.classList.add('is-invalid');
    hasError = true;
  } else {
    if (!isClose) document.getElementById('trToBranchSelect')?.classList.remove('is-invalid');
  }

  if (!transfer_date) {
    document.getElementById('trDate')?.classList.add('is-invalid');
    hasError = true;
  } else {
    document.getElementById('trDate')?.classList.remove('is-invalid');
  }

  if (!order_number) {
    document.getElementById('trOrderNumber')?.classList.add('is-invalid');
    hasError = true;
  } else {
    document.getElementById('trOrderNumber')?.classList.remove('is-invalid');
  }

  if (hasError) return;

  const btn = document.getElementById('saveTransferBtn');
  if (btn) btn.disabled = true;

  try {
    const payload = {
      staff_id,
      from_branch,
      to_branch,
      transfer_date,
      transfer_type: isClose ? 'Close' : 'Transfer',
      order_number,
      approved_by,
      reason,
      handover_status,
      handover_to,
      remarks
    };

    const res = await axios.post('/api/staff-transfers', payload);
    if (res.data.success) {
      bootstrap.Modal.getInstance(document.getElementById('staffTransferModal')).hide();
      showToast(isClose ? 'Staff station release recorded successfully.' : 'Staff transfer recorded successfully.');

      // Refresh both views
      loadTransferTimeline();
      loadStaffPositions();
    }
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to record transfer.', true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* =========================================================================
   INDIVIDUAL STAFF CAREER JOURNEY TIMELINE MODAL
   ========================================================================= */

async function viewStaffTransferTimeline(staffId, staffName) {
  const container = document.getElementById('journeyTimelineItems');
  const modalName = document.getElementById('journeyModalStaffName');
  const cardName = document.getElementById('journeyCardName');
  const cardId = document.getElementById('journeyCardStaffId');
  const cardDesignation = document.getElementById('journeyCardDesignation');
  const cardDept = document.getElementById('journeyCardDept');
  const avatar = document.getElementById('journeyAvatar');
  const statusBadge = document.getElementById('journeyCardStatusBadge');

  if (modalName) modalName.textContent = `Career & Transfer Journey: ${staffName || staffId}`;
  if (cardName) cardName.textContent = staffName || staffId;
  if (cardId) cardId.textContent = staffId;
  if (avatar) avatar.textContent = (staffName || 'ST').substring(0, 2).toUpperCase();

  if (container) {
    container.innerHTML = `<div class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm me-2"></div>Loading journey milestones...</div>`;
  }

  bootstrap.Modal.getOrCreateInstance(document.getElementById('staffJourneyModal')).show();

  try {
    const res = await axios.get(`/api/staff-transfers/timeline/${encodeURIComponent(staffId)}`);
    if (res.data.success) {
      const staff = res.data.staff || {};
      const timeline = res.data.timeline || [];
      currentSelectedStaffJourney = { staff, timeline };

      if (cardDesignation) cardDesignation.textContent = staff.designation || 'Officer';
      if (cardDept) cardDept.textContent = staff.department || 'Department';
      if (statusBadge) statusBadge.innerHTML = getStatusBadge(staff.status);

      if (!timeline.length) {
        container.innerHTML = `<div class="text-center py-4 text-muted">No timeline milestones found for this staff member.</div>`;
        return;
      }

      container.innerHTML = timeline.map((m, idx) => {
        let nodeClass = 'node-transfer';
        let nodeIcon = 'arrow-right-left';
        let badgeColor = 'bg-primary-subtle text-primary border-primary-subtle';

        if (m.type === 'join') {
          nodeClass = 'node-join';
          nodeIcon = 'user-check';
          badgeColor = 'bg-success-subtle text-success border-success-subtle';
        } else if (m.type === 'close') {
          nodeClass = 'node-close';
          nodeIcon = 'log-out';
          badgeColor = 'bg-warning-subtle text-warning-emphasis border-warning';
        } else if (m.type === 'promotion') {
          nodeClass = 'node-current';
          nodeIcon = 'award';
          badgeColor = 'bg-purple-subtle text-purple border';
        } else if (m.type === 'current') {
          nodeClass = 'node-current';
          nodeIcon = 'map-pin';
          badgeColor = 'bg-info-subtle text-info border';
        }

        return `
          <div class="position-relative mb-3 pb-1">
            <div class="timeline-node ${nodeClass}" style="width:32px;height:32px;left:-26px;">
              <i data-lucide="${nodeIcon}" style="width: 14px; height: 14px;"></i>
            </div>
            <div class="timeline-card p-3 ms-2">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                  <span class="badge ${badgeColor} border px-2 py-0.5 me-2">${esc(m.title)}</span>
                  <span class="fw-bold text-dark">${esc(m.details || m.branch)}</span>
                </div>
                <div class="text-end font-monospace small text-muted">
                  ${formatDate(m.date)}
                </div>
              </div>

              ${m.from_branch && m.to_branch ? `
                <div class="p-2 rounded bg-light border small my-2 d-flex align-items-center gap-2">
                  <span class="fw-semibold text-secondary">${esc(m.from_branch)}</span>
                  <i data-lucide="arrow-right" style="width: 14px; height: 14px;" class="text-muted"></i>
                  <span class="fw-bold text-primary">${esc(m.to_branch)}</span>
                </div>
              ` : ''}

              <div class="row g-1 small text-muted mt-1">
                ${m.order_number ? `<div class="col-md-6"><b>Memo Ref:</b> <span class="font-monospace text-dark">${esc(m.order_number)}</span></div>` : ''}
                ${m.approved_by ? `<div class="col-md-6"><b>Authority:</b> <span class="text-dark">${esc(m.approved_by)}</span></div>` : ''}
                ${m.handover_to ? `<div class="col-md-6"><b>Handover:</b> <span class="text-dark">${esc(m.handover_to)}</span> (${esc(m.handover_status)})</div>` : ''}
                ${m.reason ? `<div class="col-md-6"><b>Reason:</b> <span class="text-dark">${esc(m.reason)}</span></div>` : ''}
              </div>

              ${m.remarks ? `<div class="mt-2 p-1.5 rounded bg-slate-50 border small text-muted"><b>Remarks:</b> ${esc(m.remarks)}</div>` : ''}
            </div>
          </div>
        `;
      }).join('');

      if (window.lucide) lucide.createIcons();
    }
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger mb-0">${e.response?.data?.message || 'Failed to load career journey.'}</div>`;
  }
}

function printCurrentJourney() {
  if (!currentSelectedStaffJourney) return;
  window.print();
}

function openTransferAdviceSlip(transferId) {
  const item = currentTimelineList.find(x => String(x.id) === String(transferId));
  if (!item) return;

  const content = document.getElementById('transferAdviceSlipContent');
  if (!content) return;

  const isClose = (item.transfer_type || '').toLowerCase() === 'close';

  content.innerHTML = `
    <div class="p-4 border rounded-3 bg-white">
      <div class="text-center border-bottom pb-3 mb-4">
        <div class="h4 fw-bold text-primary mb-1">TMSS ICT & MIS MANAGEMENT SYSTEM</div>
        <div class="text-muted small">Central Human Resource & Posting Transfer Division</div>
        <div class="badge bg-light text-dark border font-monospace mt-2 px-3 py-1 fs-6">
          OFFICIAL OFFICE ORDER / RELEASE ADVICE NOTE
        </div>
      </div>

      <div class="d-flex justify-content-between mb-4">
        <div><b>Memo / Order No:</b> <span class="font-monospace text-primary fw-bold">${esc(item.order_number)}</span></div>
        <div><b>Effective Date:</b> <span class="fw-bold">${formatDate(item.transfer_date)}</span></div>
      </div>

      <p class="mb-3">
        In accordance with the operational directive of the Management Information System, the following official movement has been sanctioned:
      </p>

      <table class="table table-bordered mb-4">
        <tbody>
          <tr>
            <th class="bg-light" style="width: 30%;">Officer Name</th>
            <td class="fw-bold text-dark">${esc(item.staff_name)}</td>
          </tr>
          <tr>
            <th class="bg-light">Staff ID Number</th>
            <td class="font-monospace fw-bold text-primary">${esc(item.staff_id)}</td>
          </tr>
          <tr>
            <th class="bg-light">Designation & Dept</th>
            <td>${esc(item.designation)} &bull; ${esc(item.department)}</td>
          </tr>
          <tr>
            <th class="bg-light">${isClose ? 'Station Released From' : 'Origin Station (Released)'}</th>
            <td class="fw-semibold text-secondary">${esc(item.from_branch)}</td>
          </tr>
          <tr>
            <th class="bg-light">${isClose ? 'Final Status' : 'Destination Station (Posted)'}</th>
            <td class="fw-bold ${isClose ? 'text-warning-emphasis' : 'text-primary'}">${esc(item.to_branch)}</td>
          </tr>
          <tr>
            <th class="bg-light">Official Purpose / Reason</th>
            <td>${esc(item.reason || 'Administrative Operational Routine')}</td>
          </tr>
          <tr>
            <th class="bg-light">Charge Handover Accountability</th>
            <td><b>Status:</b> ${esc(item.handover_status)} ${item.handover_to ? ` | <b>Handed To:</b> ${esc(item.handover_to)}` : ''}</td>
          </tr>
          <tr>
            <th class="bg-light">Approving Authority</th>
            <td class="fw-medium">${esc(item.approved_by || 'Zonal Authority')}</td>
          </tr>
        </tbody>
      </table>

      ${item.remarks ? `<div class="p-2 border rounded bg-light small mb-4"><b>Administrative Instructions:</b> ${esc(item.remarks)}</div>` : ''}

      <div class="row pt-5 mt-5 text-center">
        <div class="col-4">
          <div class="border-top pt-2 small fw-semibold">Signature of Officer</div>
        </div>
        <div class="col-4">
          <div class="border-top pt-2 small fw-semibold">Handover Authorized By</div>
        </div>
        <div class="col-4">
          <div class="border-top pt-2 small fw-semibold">Zonal / MIS Director</div>
        </div>
      </div>
    </div>
  `;

  bootstrap.Modal.getOrCreateInstance(document.getElementById('transferAdviceModal')).show();
}

function printAdviceSlip() {
  window.print();
}

function printTimelineReport() {
  switchTimelineMode('stream');
  setTimeout(() => {
    window.print();
  }, 200);
}

async function exportTimelineCSV() {
  try {
    const res = await axios.get('/api/staff-transfers?per_page=1000');
    const rows = res.data.data || [];

    const headers = [
      'ID', 'Staff ID', 'Officer Name', 'Designation', 'Department',
      'Event Type', 'From Branch', 'To Branch', 'Transfer Date',
      'Order Ref No', 'Approved By', 'Handover Status', 'Handover To', 'Reason', 'Remarks'
    ];

    const csvRows = [headers];
    rows.forEach(r => {
      csvRows.push([
        r.id || '',
        r.staff_id || '',
        r.staff_name || '',
        r.designation || '',
        r.department || '',
        r.transfer_type || '',
        r.from_branch || '',
        r.to_branch || '',
        r.transfer_date || '',
        r.order_number || '',
        r.approved_by || '',
        r.handover_status || '',
        r.handover_to || '',
        r.reason || '',
        r.remarks || ''
      ]);
    });

    const csvContent = csvRows.map(row =>
      row.map(val => `"${String(val).replaceAll('"', '""')}"`).join(',')
    ).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `staff_transfers_timeline_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);

    showToast('Timeline history CSV exported successfully.');
  } catch (err) {
    showToast(err.response?.data?.message || 'Failed to export timeline CSV.', true);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadDepartmentsDropdown();
  loadStaffPositions();
  updateSortIcons();

  // Check URL hash for timeline navigation
  if (window.location.hash === '#timeline') {
    switchStaffView('timeline');
  } else {
    // Preload stats for timeline badge in background
    axios.get('/api/staff-transfers?per_page=1').then(res => {
      if (res.data.success && res.data.stats) {
        const badge = document.getElementById('timelineCountBadge');
        if (badge) badge.textContent = (res.data.stats.total || 0).toString();
      }
    }).catch(() => {});
  }

  if (window.lucide) lucide.createIcons();
});
</script>
</body>
</html>
