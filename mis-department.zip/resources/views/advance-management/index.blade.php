<!doctype html>
<html lang="en">
<head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8">
  <meta name="csrf-token" content="{{ csrf_token() }}"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Advance Management | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script><script>tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script><script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script><script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script><script src="https://code.jquery.com/jquery-3.7.1.min.js"></script><script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script><script src="https://cdn.amcharts.com/lib/5/index.js"></script><script src="https://cdn.amcharts.com/lib/5/xy.js"></script><script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script><link rel="stylesheet" href="{{ asset('assets/css/app.css') }}">
<style>
.advance-toolbar{display:flex;gap:10px;flex-wrap:wrap}.advance-table th{white-space:nowrap}.advance-table td{vertical-align:middle}.action-cell{white-space:nowrap}.summary-card{border:1px solid #e5eaf1;border-radius:14px;background:#fff;padding:16px}.summary-card .value{font-size:24px;font-weight:800}.form-section{background:#f8fafc;border:1px solid #e8edf3;border-radius:12px;padding:14px}.required:after{content:' *';color:#dc3545}.permission-denied{background:#fff7ed;border:1px solid #fed7aa;border-radius:12px;padding:12px;color:#9a3412}
/* Robust modal scrolling for long Add/Edit Advance forms */
#advanceModal .modal-dialog{height:calc(100vh - 1rem);max-height:calc(100vh - 1rem);margin:.5rem auto}
#advanceModal .modal-content{height:100%;max-height:100%;display:flex;flex-direction:column;overflow:hidden}
#advanceModal #advanceForm{display:flex;flex-direction:column;flex:1 1 auto;min-height:0;height:100%}
#advanceModal .modal-header,#advanceModal .modal-footer{flex:0 0 auto}
#advanceModal .modal-body{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch}
#advanceModal .modal-body .form-section{margin-bottom:0}
@media(max-width:575.98px){#advanceModal .modal-dialog{height:100vh;max-height:100vh;margin:0}#advanceModal .modal-content{border-radius:0!important}}

@media print{.desktop-sidebar,.topbar,.no-print,.offcanvas,#toast,.modal{display:none!important}.col-lg-10{width:100%!important}.cardx{box-shadow:none!important;border:1px solid #ddd!important}.action-cell,.actions-head{display:none!important}body{background:#fff}.page-title{margin-top:0}}
</style><script src="{{ asset('assets/js/app.js') }}"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="advance-management">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3"> 
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div><div class="text-slate-400 px-2 small mb-3">Management Information System</div>
<div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog"></i>Domain & Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined"></i>Analytics</a>
<div class="group-title">DOCUMENTS & FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open"></i>Note & Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target"></i>Target & Activity</a>
<div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet"></i>Excel Import / Export</a>
<div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings"></i>Backup & Settings</a>
</aside>
<main class="col-lg-10"><header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4"><div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Advance Management</h1></div></div><div class="d-flex align-items-center gap-2"><span id="roleBadge" class="badge text-bg-primary">Super Admin</span><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div></header>
<div class="p-3 p-lg-4"><div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4"><div><h2 class="page-title h3">Advance Management</h2><p class="muted mb-0">Add, view, edit, delete and monitor employee advances, settlement and outstanding balances.</p></div><div class="advance-toolbar no-print"><button class="btn btn-primary" id="addAdvanceBtn" onclick="openAdvanceModal()"><i data-lucide="plus-circle"></i> Add Advance</button><button class="btn btn-outline-secondary" onclick="exportAdvanceCSV()"><i data-lucide="download"></i> Export CSV</button></div></div>
<div class="row g-3 mb-3"><div class="col-md-3"><div class="summary-card"><div class="muted small">Total Advance</div><div id="sumAdvance" class="value">৳ 0</div></div></div><div class="col-md-3"><div class="summary-card"><div class="muted small">Adjusted</div><div id="sumAdjusted" class="value">৳ 0</div></div></div><div class="col-md-3"><div class="summary-card"><div class="muted small">Outstanding</div><div id="sumOutstanding" class="value">৳ 0</div></div></div><div class="col-md-3"><div class="summary-card"><div class="muted small">Overdue</div><div id="sumOverdue" class="value">0</div></div></div></div>
<div id="deniedBox" class="permission-denied d-none mb-3">You do not have permission to view Advance Management.</div>
<div class="cardx p-3" id="advanceCard"><div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><b>Advance Register</b><div class="d-flex gap-2 no-print"><input id="advanceSearch" class="form-control form-control-sm" style="min-width:240px" placeholder="Search reference, employee, purpose..." oninput="debouncedRenderAdvances()"><select id="statusFilter" class="form-select form-select-sm" style="width:150px" onchange="renderAdvances()"><option value="">All Status</option><option>Open</option><option>Adjusted</option><option>Overdue</option></select></div></div><div class="table-responsive"><table class="table advance-table mb-0"><thead><tr><th>Ref</th><th>Employee</th><th>Department</th><th>Purpose</th><th>Amount</th><th>Adjusted</th><th>Balance</th><th>Status</th><th class="actions-head">Actions</th></tr></thead><tbody id="advanceBody"></tbody></table></div></div></div></main></div></div>
<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">SYSTEM</div><a href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a><a href="/advance-management"><i data-lucide="wallet"></i>Advance Management</a></div></div>
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
<div class="modal fade" id="advanceModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content border-0 shadow"><div class="modal-header bg-primary text-white"><div><h5 id="advanceModalTitle" class="modal-title">Add Advance</h5><small>Advance request and settlement record</small></div><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><form id="advanceForm"><input type="hidden" id="advanceId"><div class="modal-body"><div class="form-section mb-3"><div class="fw-bold mb-3">Employee & Request</div><div class="row g-3"><div class="col-md-4"><label class="form-label required">Reference</label><input id="ref" class="form-control" required placeholder="ADV-1003"></div><div class="col-md-4"><label class="form-label required">Employee</label><input id="employee" class="form-control" required placeholder="Employee name"></div><div class="col-md-4"><label class="form-label">Employee ID</label><input id="employeeId" class="form-control" placeholder="1001"></div><div class="col-md-4"><label class="form-label">Department</label><input id="department" class="form-control" value="MIS"></div><div class="col-md-4"><label class="form-label">Designation</label><input id="designation" class="form-control" placeholder="Officer"></div><div class="col-md-4"><label class="form-label required">Purpose</label><input id="purpose" class="form-control" required placeholder="Official travel"></div><div class="col-md-4"><label class="form-label required">Request Date</label><input id="requestDate" type="date" class="form-control" required></div><div class="col-md-4"><label class="form-label">Due Date</label><input id="dueDate" type="date" class="form-control"></div><div class="col-md-4"><label class="form-label required">Amount (৳)</label><input id="amount" type="number" min="0" step="0.01" class="form-control" required></div><div class="col-md-4"><label class="form-label">Adjusted / Settled (৳)</label><input id="adjusted" type="number" min="0" step="0.01" value="0" class="form-control"></div><div class="col-md-4"><label class="form-label">Status</label><select id="status" class="form-select"><option>Open</option><option>Adjusted</option><option>Overdue</option></select></div><div class="col-md-4"><label class="form-label">Approval Status</label><select id="approval" class="form-select"><option>Pending</option><option>Approved</option><option>Rejected</option></select></div><div class="col-12"><label class="form-label">Advance Voucher / Supporting Document</label><input id="voucherFile" type="file" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx"><div class="form-text">ভাউচার/সমর্থক ডকুমেন্ট আপলোড করুন। সর্বোচ্চ 10 MB প্রতি ফাইল।</div><div id="voucherList" class="mt-2"></div></div><div class="col-12"><label class="form-label">Notes</label><textarea id="notes" class="form-control" rows="3" placeholder="Additional notes..."></textarea></div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" type="submit"><i data-lucide="save"></i> Save Advance</button></div></form></div></div></div>
<div class="modal fade" id="viewAdvanceModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Advance Details</h5><button class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="viewAdvanceBody"></div><div class="modal-footer border-top d-block"><div class="d-flex justify-content-between align-items-center mb-2"><b>Voucher & Document History</b><button class="btn btn-sm btn-outline-secondary" onclick="showVoucherHistory(currentAdvanceViewId)"><i data-lucide="history"></i> History</button></div><div id="advanceVoucherHistory"></div></div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Close</button></div></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const ADV_KEY='mis_advances_v2';
const seedAdvances=[{id:'ADV-1001',employee:'Example Officer',employeeId:'1001',department:'MIS',designation:'Officer',purpose:'Official travel',requestDate:'2026-01-10',dueDate:'2026-02-10',amount:50000,adjusted:35000,status:'Open',approval:'Approved',notes:'',vouchers:[],voucherHistory:[]},{id:'ADV-1002',employee:'Example Staff',employeeId:'1002',department:'MIS',designation:'Officer',purpose:'Field activity',requestDate:'2026-01-14',dueDate:'2026-02-14',amount:80000,adjusted:80000,status:'Adjusted',approval:'Approved',notes:'',vouchers:[],voucherHistory:[]}];
let currentAdvanceViewId='';
function money(n){return '৳ '+Number(n||0).toLocaleString('en-BD',{maximumFractionDigits:2});}
function getAdvances(){const x=localStorage.getItem(ADV_KEY);if(x){const a=JSON.parse(x);a.forEach(v=>{v.vouchers=v.vouchers||[];v.voucherHistory=v.voucherHistory||[]});return a;}localStorage.setItem(ADV_KEY,JSON.stringify(seedAdvances));return seedAdvances;}
function saveAdvances(a){localStorage.setItem(ADV_KEY,JSON.stringify(a));}
function esc(s){return String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));}
function badge(s){const c=s==='Adjusted'?'success':s==='Overdue'?'danger':'warning';return `<span class="badge bg-${c}${c==='warning'?' text-dark':''}">${esc(s)}</span>`;}
const debouncedRenderAdvances = (typeof MIS_debounce === 'function') ? MIS_debounce(renderAdvances, 250) : renderAdvances;
window.debouncedRenderAdvances = debouncedRenderAdvances;
function renderAdvances(){if(!MIS_hasPermission('advance-management','view')){document.getElementById('deniedBox').classList.remove('d-none');document.getElementById('advanceCard').classList.add('d-none');return;}document.getElementById('deniedBox').classList.add('d-none');document.getElementById('advanceCard').classList.remove('d-none');const q=(document.getElementById('advanceSearch').value||'').toLowerCase(),sf=document.getElementById('statusFilter').value;const rows=getAdvances().filter(a=>(!q||Object.values({...a,vouchers:undefined,voucherHistory:undefined}).join(' ').toLowerCase().includes(q))&&(!sf||a.status===sf));document.getElementById('advanceBody').innerHTML=rows.map(a=>{const bal=Math.max(0,Number(a.amount)-Number(a.adjusted));const overdue=a.dueDate&&new Date(a.dueDate)<new Date()&&bal>0;if(overdue&&a.status!=='Overdue')a.status='Overdue';return `<tr><td><b>${esc(a.id)}</b></td><td>${esc(a.employee)}<div class="small muted">${esc(a.employeeId||'')}</div></td><td>${esc(a.department||'')}</td><td>${esc(a.purpose)}</td><td>${money(a.amount)}</td><td>${money(a.adjusted)}</td><td><b>${money(bal)}</b></td><td>${badge(a.status)}</td><td class="action-cell actions-head"><div class="btn-group btn-group-sm">${MIS_hasPermission('advance-management','view')?`<button class="btn btn-outline-primary" title="View" onclick="viewAdvance('${esc(a.id)}')"><i data-lucide="eye"></i></button>`:''}${MIS_hasPermission('advance-management','edit')?`<button class="btn btn-outline-secondary" title="Edit" onclick="editAdvance('${esc(a.id)}')"><i data-lucide="pencil"></i></button>`:''}${MIS_hasPermission('advance-management','delete')?`<button class="btn btn-outline-danger" title="Delete" onclick="deleteAdvance('${esc(a.id)}')"><i data-lucide="trash-2"></i></button>`:''}</div></td></tr>`}).join('')||'<tr><td colspan="9" class="text-center muted py-4">No advance records found.</td></tr>';updateSummary();lucide.createIcons();}
function updateSummary(){const a=getAdvances();let total=0,adj=0,out=0,over=0;a.forEach(x=>{const b=Math.max(0,Number(x.amount)-Number(x.adjusted));total+=Number(x.amount)||0;adj+=Number(x.adjusted)||0;out+=b;if(x.status==='Overdue')over++;});document.getElementById('sumAdvance').textContent=money(total);document.getElementById('sumAdjusted').textContent=money(adj);document.getElementById('sumOutstanding').textContent=money(out);document.getElementById('sumOverdue').textContent=over;}
function readFile(file){return new Promise((resolve,reject)=>{if(!file)return resolve(null);if(file.size>10*1024*1024)return reject(new Error('File size must be 10 MB or less.'));const allowed=['application/pdf','image/jpeg','image/png','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];if(file.type&&!allowed.includes(file.type))return reject(new Error('Unsupported voucher file type.'));const r=new FileReader();r.onload=()=>resolve({id:'VCH-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),name:file.name,type:file.type,size:file.size,dataUrl:r.result,uploadedAt:new Date().toISOString()});r.onerror=()=>reject(new Error('Could not read file.'));r.readAsDataURL(file);});}
function fileIcon(type){return type&&type.startsWith('image/')?'image':'file-text';}
function voucherRows(a,editable=true){const vs=a?.vouchers||[];if(!vs.length)return '<div class="small muted">No voucher uploaded.</div>';return vs.map(v=>`<div class="d-flex align-items-center justify-content-between gap-2 border rounded p-2 mb-2"><div class="d-flex align-items-center gap-2 text-truncate"><i data-lucide="${fileIcon(v.type)}"></i><div class="text-truncate"><b>${esc(v.name)}</b><div class="small muted">${(v.size/1024/1024).toFixed(2)} MB · ${new Date(v.uploadedAt).toLocaleString()}</div></div></div><div class="btn-group btn-group-sm flex-shrink-0"><button class="btn btn-outline-primary" onclick="previewVoucher('${esc(a.id)}','${esc(v.id)}')"><i data-lucide="eye"></i></button><button class="btn btn-outline-secondary" onclick="downloadVoucher('${esc(a.id)}','${esc(v.id)}')"><i data-lucide="download"></i></button>${editable?`<button class="btn btn-outline-danger" onclick="deleteVoucher('${esc(a.id)}','${esc(v.id)}')"><i data-lucide="trash-2"></i></button>`:''}</div></div>`).join('');}
function renderVoucherList(id){const a=getAdvances().find(x=>x.id===id);document.getElementById('voucherList').innerHTML=voucherRows(a,true);lucide.createIcons();}
function openAdvanceModal(id){if(!MIS_hasPermission('advance-management',id?'edit':'create')){toast('Permission denied');return;}document.getElementById('advanceForm').reset();document.getElementById('advanceId').value='';document.getElementById('requestDate').value=new Date().toISOString().slice(0,10);document.getElementById('advanceModalTitle').textContent='Add Advance';document.getElementById('voucherList').innerHTML='<div class="small muted">No voucher uploaded.</div>';if(id){const a=getAdvances().find(x=>x.id===id);if(!a)return;document.getElementById('advanceModalTitle').textContent='Edit Advance';['id','employee','employeeId','department','designation','purpose','requestDate','dueDate','amount','adjusted','status','approval','notes'].forEach(k=>{const el=document.getElementById(k);if(el)el.value=k==='id'?a.id:(a[k]??'');});document.getElementById('advanceId').value=id;renderVoucherList(id);}bootstrap.Modal.getOrCreateInstance(document.getElementById('advanceModal')).show();}
function editAdvance(id){openAdvanceModal(id)}
function viewAdvance(id){if(!MIS_hasPermission('advance-management','view'))return;const a=getAdvances().find(x=>x.id===id);if(!a)return;currentAdvanceViewId=id;const bal=Math.max(0,Number(a.amount)-Number(a.adjusted));document.getElementById('viewAdvanceBody').innerHTML=`<div class="row g-3"><div class="col-md-4"><b>Reference</b><div>${esc(a.id)}</div></div><div class="col-md-4"><b>Employee</b><div>${esc(a.employee)}</div></div><div class="col-md-4"><b>Employee ID</b><div>${esc(a.employeeId||'-')}</div></div><div class="col-md-4"><b>Department</b><div>${esc(a.department||'-')}</div></div><div class="col-md-4"><b>Designation</b><div>${esc(a.designation||'-')}</div></div><div class="col-md-4"><b>Purpose</b><div>${esc(a.purpose)}</div></div><div class="col-md-4"><b>Amount</b><div>${money(a.amount)}</div></div><div class="col-md-4"><b>Adjusted</b><div>${money(a.adjusted)}</div></div><div class="col-md-4"><b>Balance</b><div><strong>${money(bal)}</strong></div></div><div class="col-md-4"><b>Request Date</b><div>${esc(a.requestDate||'-')}</div></div><div class="col-md-4"><b>Due Date</b><div>${esc(a.dueDate||'-')}</div></div><div class="col-md-4"><b>Status</b><div>${badge(a.status)}</div></div><div class="col-md-4"><b>Approval</b><div>${esc(a.approval||'-')}</div></div><div class="col-12"><b>Notes</b><div class="p-3 bg-light rounded mt-1">${esc(a.notes||'No notes')}</div></div><div class="col-12"><b>Advance Voucher</b><div class="mt-2">${voucherRows(a,false)}</div></div></div>`;document.getElementById('advanceVoucherHistory').innerHTML='';bootstrap.Modal.getOrCreateInstance(document.getElementById('viewAdvanceModal')).show();lucide.createIcons();}
function showVoucherHistory(id){const a=getAdvances().find(x=>x.id===id);const h=a?.voucherHistory||[];document.getElementById('advanceVoucherHistory').innerHTML=h.length?h.slice().reverse().map(x=>`<div class="border rounded p-2 mb-2"><div><b>${esc(x.action)}</b> — ${esc(x.name)}</div><div class="small muted">${new Date(x.at).toLocaleString()} · ${esc(x.by||'Super Admin')}</div></div>`).join(''):'<div class="small muted">No voucher history.</div>';}
function downloadVoucher(aid,vid){const a=getAdvances().find(x=>x.id===aid),v=a?.vouchers?.find(x=>x.id===vid);if(!v)return;const link=document.createElement('a');link.href=v.dataUrl;link.download=v.name;link.click();}
function previewVoucher(aid,vid){const a=getAdvances().find(x=>x.id===aid),v=a?.vouchers?.find(x=>x.id===vid);if(!v)return;const w=window.open('','_blank');if(!w){toast('Please allow pop-ups to preview the document');return;}if(v.type&&v.type.startsWith('image/'))w.document.write(`<title>${esc(v.name)}</title><img src="${v.dataUrl}" style="max-width:100%;height:auto">`);else if(v.type==='application/pdf')w.document.write(`<title>${esc(v.name)}</title><iframe src="${v.dataUrl}" style="width:100%;height:100vh;border:0"></iframe>`);else {w.close();downloadVoucher(aid,vid);toast('Preview is not available for this file type; downloaded instead.');}}
function deleteVoucher(aid,vid){if(!MIS_hasPermission('advance-management','edit')&&!MIS_hasPermission('advance-management','delete')){toast('Permission denied');return;}const arr=getAdvances();const a=arr.find(x=>x.id===aid);if(!a)return;const v=(a.vouchers||[]).find(x=>x.id===vid);if(!v)return;if(!confirm('Delete voucher '+v.name+'?'))return;a.vouchers=a.vouchers.filter(x=>x.id!==vid);a.voucherHistory=a.voucherHistory||[];a.voucherHistory.push({action:'Deleted',name:v.name,at:new Date().toISOString(),by:'Super Admin'});saveAdvances(arr);MIS_addAudit('Advance Voucher','Deleted',aid+' / '+v.name);renderVoucherList(aid);toast('Voucher deleted');}
async function syncAdvancesFromApi() {
  try {
    const res = await fetch('/api/advance-management');
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      const localStore = JSON.parse(localStorage.getItem(ADV_KEY) || '[]');
      const localMap = new Map(localStore.map(x => [x.id, x]));
      
      const merged = json.data.map(apiItem => {
        const local = localMap.get(apiItem.id) || {};
        return {
          id: apiItem.id,
          employee: apiItem.employee || local.employee || '',
          employeeId: apiItem.employee_id || apiItem.employeeId || local.employeeId || '',
          department: apiItem.department || local.department || '',
          designation: apiItem.designation || local.designation || '',
          purpose: apiItem.purpose || local.purpose || '',
          requestDate: apiItem.request_date || apiItem.requestDate || local.requestDate || '',
          dueDate: apiItem.due_date || apiItem.dueDate || local.dueDate || '',
          amount: Number(apiItem.amount ?? local.amount ?? 0),
          adjusted: Number(apiItem.adjusted ?? local.adjusted ?? 0),
          status: apiItem.status || local.status || 'Open',
          approval: apiItem.approval || local.approval || 'Approved',
          notes: apiItem.notes || local.notes || '',
          vouchers: local.vouchers || [],
          voucherHistory: local.voucherHistory || []
        };
      });
      saveAdvances(merged);
    }
  } catch (err) {
    console.debug('API sync note:', err);
  }
  renderAdvances();
}

let _advSubmitting = false;
document.getElementById('advanceForm').addEventListener('submit',async e=>{
  e.preventDefault();
  if(_advSubmitting) return;
  _advSubmitting = true;
  try {
    const editId=document.getElementById('advanceId').value;
  const arr=getAdvances();
  let existing=editId?arr.find(x=>x.id===editId):null;
  let vouchers=existing?.vouchers||[];
  let history=existing?.voucherHistory||[];
  const file=document.getElementById('voucherFile').files[0];
  if(file){
    try{
      const v=await readFile(file);
      vouchers=[...vouchers,v];
      history=[...history,{action:'Uploaded',name:v.name,at:v.uploadedAt,by:'Super Admin'}];
    }catch(err){
      toast(err.message);
      return;
    }
  }
  const item={
    id:document.getElementById('ref').value.trim(),
    employee:document.getElementById('employee').value.trim(),
    employeeId:document.getElementById('employeeId').value.trim(),
    department:document.getElementById('department').value.trim(),
    designation:document.getElementById('designation').value.trim(),
    purpose:document.getElementById('purpose').value.trim(),
    requestDate:document.getElementById('requestDate').value,
    dueDate:document.getElementById('dueDate').value,
    amount:Number(document.getElementById('amount').value||0),
    adjusted:Number(document.getElementById('adjusted').value||0),
    status:document.getElementById('status').value,
    approval:document.getElementById('approval').value,
    notes:document.getElementById('notes').value.trim(),
    vouchers,
    voucherHistory:history
  };
  if(item.adjusted>item.amount){
    toast('Adjusted amount cannot exceed advance amount');
    return;
  }

  const apiPayload = {
    id: item.id,
    employee: item.employee,
    employee_id: item.employeeId,
    department: item.department,
    designation: item.designation,
    purpose: item.purpose,
    request_date: item.requestDate,
    due_date: item.dueDate,
    amount: item.amount,
    adjusted: item.adjusted,
    status: item.status,
    approval: item.approval,
    notes: item.notes
  };

  if(editId){
    if(!MIS_hasPermission('advance-management','edit')) return;
    try {
      await fetch(`/api/advance-management/${encodeURIComponent(editId)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(apiPayload)
      });
    } catch (e) {}
    const originalId=editId;
    arr.splice(arr.findIndex(x=>x.id===editId),1,item);
    MIS_addAudit('Advance','Updated',item.id);
    toast('Advance updated');
  }else{
    if(arr.some(x=>x.id===item.id)){
      toast('Reference already exists');
      return;
    }
    try {
      await fetch('/api/advance-management', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(apiPayload)
      });
    } catch (e) {}
    arr.unshift(item);
    MIS_addAudit('Advance','Created',item.id);
    toast('Advance added');
  }
  try{
    saveAdvances(arr);
  }catch(err){
    toast('Storage limit reached. Please use smaller files or a server storage.');
    return;
  }
    bootstrap.Modal.getInstance(document.getElementById('advanceModal'))?.hide();
    renderAdvances();
  } finally {
    _advSubmitting = false;
    MIS_unlockForm(document.getElementById('advanceForm'));
  }
});

async function deleteAdvance(id){
  if(!MIS_hasPermission('advance-management','delete')){
    toast('Permission denied');
    return;
  }
  const a=getAdvances().find(x=>x.id===id);
  if(!a)return;
  if(!confirm('Delete advance '+id+'?'))return;
  try {
    await fetch(`/api/advance-management/${encodeURIComponent(id)}`, { method: 'DELETE' });
  } catch (e) {}
  saveAdvances(getAdvances().filter(x=>x.id!==id));
  MIS_addAudit('Advance','Deleted',id);
  toast('Advance deleted');
  renderAdvances();
}
function exportAdvanceCSV(){if(!MIS_hasPermission('advance-management','export')){toast('Export permission denied');return;}const rows=getAdvances(),head=['Ref','Employee','Employee ID','Department','Designation','Purpose','Request Date','Due Date','Amount','Adjusted','Balance','Status','Approval','Voucher Count'];const csv=[head,...rows.map(a=>[a.id,a.employee,a.employeeId,a.department,a.designation,a.purpose,a.requestDate,a.dueDate,a.amount,a.adjusted,Math.max(0,a.amount-a.adjusted),a.status,a.approval,(a.vouchers||[]).length])].map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='advance-register.csv';a.click();URL.revokeObjectURL(url);}
document.addEventListener('DOMContentLoaded',()=>{if(window.MIS_applyRoleUI)MIS_applyRoleUI();syncAdvancesFromApi();});
</script></body></html>