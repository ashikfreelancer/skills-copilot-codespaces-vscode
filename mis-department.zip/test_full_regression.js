import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';
const AUTH_COOKIE = 'auth_role=Super Admin; auth_user=admin';
const HEADERS = {
  'Content-Type': 'application/json',
  'Cookie': AUTH_COOKIE
};

async function testAll() {
  console.log('=== STARTING 22-MODULE FULL REGRESSION AUDIT ===');
  let passed = 0;
  let failed = 0;

  function assert(cond, name) {
    if (cond) {
      console.log(`[PASS] ${name}`);
      passed++;
    } else {
      console.error(`[FAIL] ${name}`);
      failed++;
    }
  }

  const pages = [
    { url: '/dashboard', title: 'Dashboard' },
    { url: '/location-branch', title: 'Location & Branch' },
    { url: '/domain-zone-management', title: 'Domain & Zone' },
    { url: '/department-management', title: 'Department' },
    { url: '/staff-position-list', title: 'Staff Position' },
    { url: '/leave-management', title: 'Leave' },
    { url: '/movement-register', title: 'Movement' },
    { url: '/stock-register', title: 'Stock' },
    { url: '/mis-data-entry', title: 'MIS Data Entry' },
    { url: '/advance-management', title: 'Advance' },
    { url: '/target-activity', title: 'Target & Activity' },
    { url: '/monitoring', title: 'Monitoring' },
    { url: '/reports', title: 'Reports' },
    { url: '/report-requests', title: 'Report Requests' },
    { url: '/analytics', title: 'Analytics' },
    { url: '/notifications', title: 'Notifications' },
    { url: '/users-permissions', title: 'Users & Permissions' },
    { url: '/note-document-cabinet', title: 'Note & Document Cabinet' },
    { url: '/excel-import-export', title: 'Excel Import / Export' },
    { url: '/backup-settings', title: 'Backup Settings' },
    { url: '/data-quality', title: 'Data Quality' },
    { url: '/audit-log', title: 'Audit Log' },
    { url: '/login', title: 'Login' }
  ];

  console.log('\n--- 1. Testing All 22 Blade Page Renders (HTTP 200) ---');
  for (const p of pages) {
    try {
      const res = await fetch(`${BASE_URL}${p.url}`, { headers: HEADERS });
      const html = await res.text();
      assert(res.status === 200 && html.length > 500, `Page ${p.url} renders with HTTP 200 (${html.length} bytes)`);
    } catch (err) {
      assert(false, `Page ${p.url} error: ${err.message}`);
    }
  }

  console.log('\n--- 2. Testing All 22 Data Endpoints (JSON + Pagination / Empty Search) ---');
  const apiEndpoints = [
    { url: '/api/dashboard', key: 'stats' },
    { url: '/api/location-branch', key: 'data' },
    { url: '/api/domain-zone-management', key: 'data' },
    { url: '/api/department-management', key: 'data' },
    { url: '/api/staff-position-list', key: 'data' },
    { url: '/api/leave-management', key: 'data' },
    { url: '/api/movement-register', key: 'data' },
    { url: '/api/stock-register/items', key: 'data' },
    { url: '/api/mis-data-entry/forms', key: 'data' },
    { url: '/api/advance-management', key: 'data' },
    { url: '/api/target-activity', key: 'data' },
    { url: '/api/monitoring', key: 'data' },
    { url: '/api/reports', key: 'data' },
    { url: '/api/report-requests', key: 'data' },
    { url: '/api/analytics', key: 'data' },
    { url: '/api/notifications', key: 'data' },
    { url: '/api/users-permissions', key: 'data' },
    { url: '/api/note-document-cabinet', key: 'data' },
    { url: '/api/excel-import-export', key: 'data' },
    { url: '/api/backup-settings', key: 'data' },
    { url: '/api/data-quality', key: 'data' },
    { url: '/api/audit-log', key: 'data' }
  ];

  for (const ep of apiEndpoints) {
    try {
      const res = await fetch(`${BASE_URL}${ep.url}`, { headers: HEADERS });
      const json = await res.json();
      assert(res.status === 200 && (json.success === true || json[ep.key] !== undefined), `GET ${ep.url} returns valid data`);
    } catch (err) {
      assert(false, `GET ${ep.url} error: ${err.message}`);
    }
  }

  console.log('\n--- 3. Testing Zero-Record / Empty Result Handling ---');
  // Check empty search query returns { success: true, data: [] }
  try {
    const emptyRes = await fetch(`${BASE_URL}/api/department-management?search=__ZERO_RESULTS_TEST__`, { headers: HEADERS });
    const emptyJson = await emptyRes.json();
    assert(emptyJson.success === true && Array.isArray(emptyJson.data) && emptyJson.data.length === 0, 'Empty search returns empty array, not error');
  } catch (err) {
    assert(false, `Empty search error: ${err.message}`);
  }

  console.log('\n--- 4. Testing End-to-End Leave Workflow ---');
  try {
    // Create leave
    const newLeave = await fetch(`${BASE_URL}/api/leave-management`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({
        employee_id: 'EMP-AUDIT-01',
        employee_name: 'Audit User',
        leave_type: 'Casual',
        start_date: '2026-10-01',
        end_date: '2026-10-03',
        days: 3,
        reason: 'Automated Audit Verification'
      })
    });
    const leaveData = await newLeave.json();
    assert(leaveData.success === true && leaveData.data.id, 'Created new leave application');

    // Approve leave
    const approveRes = await fetch(`${BASE_URL}/api/leave-management/${leaveData.data.id}/status`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({ status: 'Approved', remarks: 'Passed audit' })
    });
    const approveJson = await approveRes.json();
    assert(approveJson.success === true, 'Approved leave application');

    // Delete test leave
    const delRes = await fetch(`${BASE_URL}/api/leave-management/${leaveData.data.id}`, {
      method: 'DELETE',
      headers: HEADERS
    });
    const delJson = await delRes.json();
    assert(delJson.success === true, 'Deleted test leave application');
  } catch (err) {
    assert(false, `Leave workflow error: ${err.message}`);
  }

  console.log('\n--- 5. Testing Advance Management Calculations ---');
  try {
    const advList = await (await fetch(`${BASE_URL}/api/advance-management`, { headers: HEADERS })).json();
    assert(advList.success && Array.isArray(advList.data) && advList.data.length > 0, `Advance list loaded (${advList.data.length} records)`);
    assert(advList.stats && advList.stats.total_disbursed >= 0, `Disbursed calculation verified: ${advList.stats?.total_disbursed}`);
  } catch (err) {
    assert(false, `Advance calculation error: ${err.message}`);
  }

  console.log('\n======================================================');
  console.log(`FULL REGRESSION RESULT: ${passed} PASSED, ${failed} FAILED`);
  console.log('======================================================');
  if (failed > 0) process.exit(1);
}

testAll().catch(err => {
  console.error('Test script crashed:', err);
  process.exit(1);
});
