<?php

// -----------------------------------------------------------------------------
// MIS Department Laravel Bootstrap Engine
// -----------------------------------------------------------------------------

// 1. PSR-4 Class Autoloader & Fallback Loader
if (file_exists(dirname(__DIR__) . '/vendor/autoload.php')) {
    require_once dirname(__DIR__) . '/vendor/autoload.php';
}

spl_autoload_register(function ($class) {
    // 1. Standard App\ namespace
    $prefix = 'App\\';
    $baseDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR;
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) === 0) {
        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', DIRECTORY_SEPARATOR, $relativeClass) . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }

    // 2. Fallback for classes called without leading namespace (e.g. BackupSettingsController)
    $candidateDirs = [
        dirname(__DIR__) . '/app/Http/Controllers/',
        dirname(__DIR__) . '/app/Models/',
        dirname(__DIR__) . '/app/Services/',
        dirname(__DIR__) . '/app/Auth/',
    ];
    $cleanName = basename(str_replace('\\', '/', $class));
    foreach ($candidateDirs as $dir) {
        $file = $dir . $cleanName . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// 2. Standard Laravel Global Helper Functions
if (!function_exists('env')) {
    function env(string $key, $default = null)
    {
        $value = getenv($key);
        if ($value === false) {
            $value = $_ENV[$key] ?? $_SERVER[$key] ?? null;
        }
        if ($value === null) {
            return $default;
        }
        switch (strtolower($value)) {
            case 'true':
            case '(true)':
                return true;
            case 'false':
            case '(false)':
                return false;
            case 'empty':
            case '(empty)':
                return '';
            case 'null':
            case '(null)':
                return null;
        }
        return $value;
    }
}

if (!function_exists('base_path')) {
    function base_path(string $path = ''): string
    {
        return dirname(__DIR__) . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

if (!function_exists('app_path')) {
    function app_path(string $path = ''): string
    {
        return base_path('app') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

if (!function_exists('storage_path')) {
    function storage_path(string $path = ''): string
    {
        return base_path('storage') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

if (!function_exists('public_path')) {
    function public_path(string $path = ''): string
    {
        return base_path('public') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

if (!function_exists('config_path')) {
    function config_path(string $path = ''): string
    {
        return base_path('config') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

if (!function_exists('database_path')) {
    function database_path(string $path = ''): string
    {
        return base_path('database') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

if (!function_exists('config')) {
    function config(?string $key = null, $default = null)
    {
        static $configs = [];
        if ($key === null) {
            return $configs;
        }
        $parts = explode('.', $key);
        $file = $parts[0];
        if (!isset($configs[$file])) {
            $filePath = config_path($file . '.php');
            if (file_exists($filePath)) {
                $configs[$file] = require $filePath;
            } else {
                $configs[$file] = [];
            }
        }
        $current = $configs[$file];
        for ($i = 1; $i < count($parts); $i++) {
            if (!is_array($current) || !isset($current[$parts[$i]])) {
                return $default;
            }
            $current = $current[$parts[$i]];
        }
        return $current;
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        return \App\Auth\AuthManager::csrfToken();
    }
}

if (!function_exists('auth')) {
    function auth()
    {
        $user = \App\Auth\AuthManager::user();
        if ($user) {
            return $user;
        }

        // Return a proxy object where ->user() also safely resolves
        return new class {
            public function user() {
                return \App\Auth\AuthManager::user();
            }
            public function check() {
                return \App\Auth\AuthManager::check();
            }
            public function id() {
                return \App\Auth\AuthManager::id();
            }
            public function __get($prop) {
                $u = \App\Auth\AuthManager::user();
                return $u ? $u->{$prop} : null;
            }
        };
    }
}

if (!function_exists('session')) {
    function session(?string $key = null, $default = null)
    {
        \App\Auth\AuthManager::startSession();
        if ($key === null) {
            return $_SESSION;
        }
        return $_SESSION[$key] ?? \App\Auth\AuthManager::getFlash($key, $default);
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        $clean = ltrim($path, '/');
        return '/' . $clean;
    }
}

if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        $base = config('app.url', 'http://localhost:3000');
        return rtrim($base, '/') . '/' . ltrim($path, '/');
    }
}

if (!function_exists('route')) {
    function route(string $name, array $parameters = []): string
    {
        $routes = [
            'login' => '/login',
            'logout' => '/logout',
            'dashboard' => '/dashboard',
            'location-branch' => '/location-branch',
            'domain-zone-management' => '/domain-zone-management',
            'department-management' => '/department-management',
            'staff-position-list' => '/staff-position-list',
            'leave-management' => '/leave-management',
            'movement-register' => '/movement-register',
            'stock-register' => '/stock-register',
            'mis-data-entry' => '/mis-data-entry',
            'advance-management' => '/advance-management',
            'target-activity' => '/target-activity',
            'monitoring' => '/monitoring',
            'reports' => '/reports',
            'report-requests' => '/report-requests',
            'analytics' => '/analytics',
            'notifications' => '/notifications',
            'users-permissions' => '/users-permissions',
            'note-document-cabinet' => '/note-document-cabinet',
            'excel-import-export' => '/excel-import-export',
            'backup-settings' => '/backup-settings',
            'data-quality' => '/data-quality',
            'audit-log' => '/audit-log',
        ];
        return $routes[$name] ?? ('/' . $name);
    }
}

if (!function_exists('redirect')) {
    function redirect(string $to = '/')
    {
        header('Location: ' . $to);
        exit;
    }
}

if (!function_exists('response')) {
    function response($content = '', int $status = 200, array $headers = [])
    {
        http_response_code($status);
        foreach ($headers as $k => $v) {
            header("{$k}: {$v}");
        }
        return new class($content) {
            private $content;
            public function __construct($c) { $this->content = $c; }
            public function json(array $data, int $status = 200) {
                http_response_code($status);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode($data, JSON_UNESCAPED_UNICODE);
                exit;
            }
            public function __toString() {
                return (string) $this->content;
            }
        };
    }
}

if (!function_exists('abort')) {
    function abort(int $code = 404, string $message = '')
    {
        http_response_code($code);
        $viewPath = resource_path("views/errors/{$code}.blade.php");
        if (file_exists($viewPath)) {
            echo view("errors.{$code}", ['message' => $message]);
        } else {
            echo "{$code} " . ($message ?: 'Error');
        }
        exit;
    }
}

if (!function_exists('resource_path')) {
    function resource_path(string $path = ''): string
    {
        return base_path('resources') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
    }
}

// 3. Database Initialization
\App\Database::init();

// 4. Standalone Laravel Blade Engine
class SimpleBladeEngine
{
    private string $viewsDir;
    private string $cacheDir;
    private array $sections = [];
    private ?string $currentSection = null;
    private array $stacks = [];

    public function __construct(string $viewsDir, string $cacheDir)
    {
        $this->viewsDir = rtrim($viewsDir, '/');
        $this->cacheDir = rtrim($cacheDir, '/');
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0777, true);
        }
    }

    public function render(string $view, array $data = []): string
    {
        $viewPath = $this->resolvePath($view);
        if (!$viewPath || !file_exists($viewPath)) {
            throw new Exception("Blade view [{$view}] not found.");
        }

        $template = file_get_contents($viewPath);
        return $this->compileAndEvaluate($template, $data, $view);
    }

    private function resolvePath(string $view): ?string
    {
        $rel = str_replace('.', '/', $view);
        $candidates = [
            "{$this->viewsDir}/{$rel}.blade.php",
            "{$this->viewsDir}/{$rel}/index.blade.php",
            "{$this->viewsDir}/{$rel}.php",
        ];
        foreach ($candidates as $cand) {
            if (file_exists($cand)) return $cand;
        }
        return null;
    }

    private function compileAndEvaluate(string $template, array $data, string $viewName): string
    {
        // Check for @extends
        $extends = null;
        if (preg_match('/@extends\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)/', $template, $m)) {
            $extends = $m[1];
            $template = str_replace($m[0], '', $template);
        }

        // Capture @section('name') ... @endsection / @show
        preg_match_all('/@section\s*\(\s*[\'"]([^\'"]+)[\'"](?:\s*,\s*([^\)]+))?\s*\)(.*?)@(?:endsection|stop|show)/s', $template, $secMatches, PREG_SET_ORDER);
        foreach ($secMatches as $sm) {
            $sName = $sm[1];
            $sContent = isset($sm[3]) && $sm[3] !== '' ? $sm[3] : trim($sm[2] ?? '', '\'"');
            $this->sections[$sName] = $sContent;
            $template = str_replace($sm[0], '', $template);
        }

        // Compile includes
        $template = preg_replace_callback('/@include\s*\(\s*[\'"]([^\'"]+)[\'"](?:\s*,\s*(\[[^\]]*\]|\{[^\}]*\}))?\s*\)/', function ($im) use ($data) {
            $incView = $im[1];
            $incPath = $this->resolvePath($incView);
            if ($incPath && file_exists($incPath)) {
                return file_get_contents($incPath);
            }
            return "<!-- Include {$incView} not found -->";
        }, $template);

        // If parent layout extends, embed sections into layout
        if ($extends) {
            $parentPath = $this->resolvePath($extends);
            if ($parentPath && file_exists($parentPath)) {
                $parentContent = file_get_contents($parentPath);

                // Parent includes
                $parentContent = preg_replace_callback('/@include\s*\(\s*[\'"]([^\'"]+)[\'"](?:\s*,\s*(\[[^\]]*\]|\{[^\}]*\}))?\s*\)/', function ($im) use ($data) {
                    $incView = $im[1];
                    $incPath = $this->resolvePath($incView);
                    if ($incPath && file_exists($incPath)) {
                        return file_get_contents($incPath);
                    }
                    return "<!-- Include {$incView} not found -->";
                }, $parentContent);

                // Replace @yield('section', 'default')
                $parentContent = preg_replace_callback('/@yield\s*\(\s*[\'"]([^\'"]+)[\'"](?:\s*,\s*[\'"]([^\'"]*)[\'"])?\s*\)/', function ($ym) {
                    $yName = $ym[1];
                    $def = $ym[2] ?? '';
                    return $this->sections[$yName] ?? $def;
                }, $parentContent);

                $template = $parentContent;
            }
        }

        // Replace common Blade directives
        $template = str_replace('@csrf', '<input type="hidden" name="_token" value="' . csrf_token() . '">', $template);
        $template = preg_replace('/@stack\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)/', '', $template);
        $template = preg_replace('/@push\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)(.*?)@endpush/s', '', $template);

        // Handle {{ csrf_token() }}
        $template = preg_replace('/\{\{\s*csrf_token\(\)\s*\}\}/', csrf_token(), $template);

        // Handle {{ asset(...) }}
        $template = preg_replace_callback('/\{\{\s*asset\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)\s*\}\}/', function ($m) {
            return asset($m[1]);
        }, $template);

        // Handle {{ route(...) }}
        $template = preg_replace_callback('/\{\{\s*route\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)\s*\}\}/', function ($m) {
            return route($m[1]);
        }, $template);

        // Replace flat data variables
        foreach ($data as $k => $v) {
            if (is_scalar($v)) {
                $template = str_replace('{{ $' . $k . ' }}', htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'), $template);
                $template = str_replace('{!! $' . $k . ' !!}', (string) $v, $template);
                $template = str_replace('{{ $' . $k . " ?? '' }}", htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'), $template);
                $template = str_replace('{{ $' . $k . ' ?? "" }}', htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'), $template);
            }
        }

        // Replace branding array values dynamically if present
        if (!empty($data['branding']) && is_array($data['branding'])) {
            foreach ($data['branding'] as $bk => $bv) {
                if (is_scalar($bv)) {
                    $template = preg_replace('/\{\{\s*\$branding\[\'' . preg_quote($bk, '/') . '\'\](?:\s*\?\?\s*[^\}]+)?\s*\}\}/', htmlspecialchars((string)$bv, ENT_QUOTES, 'UTF-8'), $template);
                    $template = preg_replace('/\{\{\s*\$branding\["' . preg_quote($bk, '/') . '"\](?:\s*\?\?\s*[^\}]+)?\s*\}\}/', htmlspecialchars((string)$bv, ENT_QUOTES, 'UTF-8'), $template);
                }
            }
        }

        // Clean any remaining unparsed Blade expressions with default fallbacks
        $template = preg_replace_callback('/\{\{\s*([^}]+?)\s*\?\?\s*([\'"])(.*?)\2\s*\}\}/', function ($m) {
            return htmlspecialchars($m[3], ENT_QUOTES, 'UTF-8');
        }, $template);
        $template = preg_replace('/\{\{\s*[^}]*?\s*\}\}/', '', $template);
        $template = preg_replace('/\{!!\s*[^}]*?\s*!!\}/', '', $template);

        return $template;
    }
}

// 5. Initialize Blade Instance
$viewsDir = resource_path('views');
$cacheDir = storage_path('framework/views');

$bladeInstance = null;
if (class_exists('Jenssegers\Blade\Blade')) {
    try {
        $container = new \Illuminate\Container\Container();
        \Illuminate\Container\Container::setInstance($container);
        
        $bladeInstance = new \Jenssegers\Blade\Blade($viewsDir, $cacheDir, $container);
        
        if (!$container->bound('blade.compiler')) {
            $container->singleton('blade.compiler', function () use ($bladeInstance) {
                return $bladeInstance->compiler();
            });
        }
        
        $compiler = $bladeInstance->compiler();
        $compiler->directive('csrf', function () {
            return '<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">';
        });
        $compiler->directive('auth', function () {
            return '<?php if (auth()): ?>';
        });
        $compiler->directive('endauth', function () {
            return '<?php endif; ?>';
        });
        $compiler->directive('guest', function () {
            return '<?php if (!auth()): ?>';
        });
        $compiler->directive('endguest', function () {
            return '<?php endif; ?>';
        });
    } catch (\Throwable $e) {
        $bladeInstance = new SimpleBladeEngine($viewsDir, $cacheDir);
    }
}

if (!$bladeInstance) {
    $bladeInstance = new SimpleBladeEngine($viewsDir, $cacheDir);
}

if (!function_exists('view')) {
    function view(string $view, array $data = []): string
    {
        global $bladeInstance, $viewsDir, $cacheDir;
        $data['csrf_token'] = csrf_token();
        $data['authUser'] = auth();
        
        try {
            return $bladeInstance->render($view, $data);
        } catch (\Throwable $e) {
            // Dynamic fallback to standalone SimpleBladeEngine if reflection/container fails
            $fallbackEngine = new SimpleBladeEngine($viewsDir, $cacheDir);
            return $fallbackEngine->render($view, $data);
        }
    }
}
