<?php

define('LARAVEL_START', microtime(true));

require_once dirname(__DIR__) . '/bootstrap/app.php';

use App\Http\Controllers\AuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\CabinetDocumentController;
use App\Http\Controllers\BackupSettingsController;
use App\Http\Controllers\UserPermissionController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\LocationBranchController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\StockRegisterController;
use App\Http\Controllers\AdvanceController;
use App\Http\Controllers\AnalyticsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DataQualityController;
use App\Http\Controllers\DomainZoneController;
use App\Http\Controllers\MISDataEntryController;
use App\Http\Controllers\MonitoringController;
use App\Http\Controllers\MovementRegisterController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ReportRequestController;
use App\Http\Controllers\StaffPositionController;
use App\Http\Controllers\TargetActivityController;
use App\Http\Controllers\StaffTransferController;
use App\Http\Middleware\VerifyCsrfToken;
use App\Auth\AuthManager;

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

// Clean trailing slashes
if ($uri !== '/' && str_ends_with($uri, '/')) {
    $uri = rtrim($uri, '/');
}

// -----------------------------------------------------------------------------
// 1. Static Asset Server (For PHP built-in server: php -S localhost:8000 -t public)
// -----------------------------------------------------------------------------
if (str_starts_with($uri, '/assets/')) {
    $file = dirname(__DIR__) . '/public' . $uri;
    if (!file_exists($file)) {
        $file = dirname(__DIR__) . '/MIS_Department_HTML_Frontend' . $uri;
    }
    if (file_exists($file) && !is_dir($file)) {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $mimes = [
            'css' => 'text/css',
            'js' => 'application/javascript',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'svg' => 'image/svg+xml',
            'gif' => 'image/gif',
            'woff' => 'font/woff',
            'woff2' => 'font/woff2',
            'ttf' => 'font/ttf',
            'json' => 'application/json',
        ];
        if (isset($mimes[$ext])) {
            header('Content-Type: ' . $mimes[$ext]);
        }
        readfile($file);
        exit;
    }
}

// -----------------------------------------------------------------------------
// 2. Authentication & Session Endpoints
// -----------------------------------------------------------------------------
$authController = new AuthController();
$pageController = new PageController();

if ($uri === '/' || $uri === '/login' || $uri === '/index.html') {
    if ($method === 'GET') {
        echo $authController->showLogin();
        exit;
    } elseif ($method === 'POST') {
        VerifyCsrfToken::handle();
        $authController->login();
        exit;
    }
}

if ($uri === '/logout') {
    if ($method === 'POST') {
        VerifyCsrfToken::handle();
    }
    $authController->logout();
    exit;
}

if ($uri === '/api/auth/me' || $uri === '/api/me') {
    $authController->me();
    exit;
}

if ($uri === '/api/auth/csrf' || $uri === '/csrf-token') {
    header('Content-Type: application/json');
    echo json_encode(['csrf_token' => csrf_token()]);
    exit;
}

if ($uri === '/password/email' || $uri === '/api/auth/forgot-password') {
    if ($method === 'POST') {
        VerifyCsrfToken::handle();
        $authController->forgotPassword();
        exit;
    }
}

if ($uri === '/password/reset' || $uri === '/api/auth/reset-password') {
    if ($method === 'POST') {
        VerifyCsrfToken::handle();
        $authController->resetPassword();
        exit;
    }
}

// -----------------------------------------------------------------------------
// 2.5 API Dynamic Route Dispatcher
// -----------------------------------------------------------------------------
if (str_starts_with($uri, '/api/')) {
    $apiPath = substr($uri, 5); // remove '/api/'
    $user = AuthManager::user();
    $request = new \Illuminate\Http\Request($_GET, $_POST, [], $_COOKIE, $_FILES, $_SERVER);

    // CSRF & Me
    if ($apiPath === 'auth/csrf') {
        header('Content-Type: application/json');
        echo json_encode(['csrf_token' => csrf_token()]);
        exit;
    }
    if ($apiPath === 'auth/me' || $apiPath === 'me') {
        $authController->me();
        exit;
    }

    // Require authentication for all module endpoints
    if (!$user) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Unauthenticated', 'message' => 'Please sign in to proceed.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 1. Department Management
    if ($apiPath === 'department-management' || str_starts_with($apiPath, 'department-management/')) {
        $ctrl = new DepartmentController();
        $sub = substr($apiPath, strlen('department-management'));
        $sub = trim($sub, '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub === 'action' && $method === 'POST') {
            $ctrl->logAction($request);
            exit;
        }
        if (str_ends_with($sub, '/status') && $method === 'POST') {
            $id = substr($sub, 0, -7);
            $ctrl->updateStatus($request, $id);
            exit;
        }
        if ($sub !== '' && $method === 'GET') {
            $ctrl->show($sub);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 2. Location & Branch
    if ($apiPath === 'location-branch' || str_starts_with($apiPath, 'location-branch/')) {
        $ctrl = new LocationBranchController();
        $sub = trim(substr($apiPath, strlen('location-branch')), '/');

        if ($sub === 'action' && $method === 'POST') {
            $ctrl->logAction($request);
            exit;
        }

        // Administrative locations
        if ($sub === 'administrative') {
            if ($method === 'GET') { $ctrl->locations(); exit; }
            if ($method === 'POST') { $ctrl->storeLocation($request); exit; }
        }
        if (str_starts_with($sub, 'administrative/')) {
            $locId = substr($sub, strlen('administrative/'));
            if ($method === 'PUT' || $method === 'POST') { $ctrl->updateLocation($request, $locId); exit; }
            if ($method === 'DELETE') { $ctrl->destroyLocation($locId); exit; }
        }

        // Branches sub-path
        if ($sub === 'branches') {
            if ($method === 'GET') { $ctrl->index($request); exit; }
            if ($method === 'POST') { $ctrl->store($request); exit; }
        }
        if (str_starts_with($sub, 'branches/')) {
            $branchSub = substr($sub, strlen('branches/'));
            if (str_ends_with($branchSub, '/status') && $method === 'POST') {
                $bId = substr($branchSub, 0, -7);
                $ctrl->updateStatus($request, $bId);
                exit;
            }
            if ($method === 'GET') { $ctrl->show($branchSub); exit; }
            if ($method === 'PUT' || $method === 'POST') { $ctrl->update($request, $branchSub); exit; }
            if ($method === 'DELETE') { $ctrl->destroy($branchSub); exit; }
        }

        // Direct path
        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub !== '' && $method === 'GET') {
            $ctrl->show($sub);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 3. Domain & Zone Head Information
    if ($apiPath === 'domain-zone-management' || str_starts_with($apiPath, 'domain-zone-management/')) {
        $ctrl = new DomainZoneController();
        $sub = trim(substr($apiPath, strlen('domain-zone-management')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub !== '' && $method === 'GET') {
            $ctrl->show($sub);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 4. Staff Position List
    if ($apiPath === 'staff-position-list' || str_starts_with($apiPath, 'staff-position-list/')) {
        $ctrl = new StaffPositionController();
        $sub = trim(substr($apiPath, strlen('staff-position-list')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub === 'action' && $method === 'POST') {
            $ctrl->logAction($request);
            exit;
        }
        if (str_ends_with($sub, '/status') && $method === 'POST') {
            $id = substr($sub, 0, -7);
            $ctrl->updateStatus($request, $id);
            exit;
        }
        if ($sub !== '' && $method === 'GET') {
            $ctrl->show($sub);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 4.5 Staff Transfers & Branch Closures
    if ($apiPath === 'staff-transfers' || str_starts_with($apiPath, 'staff-transfers/')) {
        $ctrl = new StaffTransferController();
        $sub = trim(substr($apiPath, strlen('staff-transfers')), '/');

        if ($sub === 'branches' && $method === 'GET') {
            $ctrl->branches($request);
            exit;
        }
        if ($sub === 'staff' && $method === 'GET') {
            $ctrl->staff($request);
            exit;
        }
        if (str_starts_with($sub, 'timeline/') && $method === 'GET') {
            $staffId = substr($sub, 9);
            $ctrl->timeline($request, $staffId);
            exit;
        }
        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 5. Leave Management
    if ($apiPath === 'leave-management' || str_starts_with($apiPath, 'leave-management/')) {
        $ctrl = new LeaveController();
        $sub = trim(substr($apiPath, strlen('leave-management')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === 'staff-summary' && $method === 'GET') {
            $ctrl->staffSummary($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 6. Advance Management
    if ($apiPath === 'advance-management' || str_starts_with($apiPath, 'advance-management/')) {
        $ctrl = new AdvanceController();
        $sub = trim(substr($apiPath, strlen('advance-management')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 7. MIS Data Entry
    if ($apiPath === 'mis-data-entry' || str_starts_with($apiPath, 'mis-data-entry/')) {
        $ctrl = new MISDataEntryController();
        $sub = trim(substr($apiPath, strlen('mis-data-entry')), '/');

        if ($sub === 'forms' && $method === 'GET') {
            $ctrl->forms($request);
            exit;
        }
        if ($sub === 'forms' && $method === 'POST') {
            $ctrl->storeForm($request);
            exit;
        }
        if (str_starts_with($sub, 'forms/') && $method === 'DELETE') {
            $id = substr($sub, 6);
            $ctrl->destroyForm($id);
            exit;
        }
        if ($sub === 'submissions' && $method === 'GET') {
            $ctrl->submissions($request);
            exit;
        }
    }

    // 8. Movement Register
    if ($apiPath === 'movement-register' || str_starts_with($apiPath, 'movement-register/')) {
        $ctrl = new MovementRegisterController();
        $sub = trim(substr($apiPath, strlen('movement-register')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub === 'action' && $method === 'POST') {
            $ctrl->logAction($request);
            exit;
        }
        if (str_ends_with($sub, '/return') && $method === 'POST') {
            $id = substr($sub, 0, -7);
            $ctrl->markReturn($request, $id);
            exit;
        }
        if (str_ends_with($sub, '/approve') && $method === 'POST') {
            $id = substr($sub, 0, -8);
            $ctrl->approve($request, $id);
            exit;
        }
        if ($sub !== '' && $method === 'GET') {
            $ctrl->show($sub);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 9. Stock Register
    if ($apiPath === 'stock-register' || str_starts_with($apiPath, 'stock-register/')) {
        $ctrl = new StockRegisterController();
        $sub = trim(substr($apiPath, strlen('stock-register')), '/');

        if ($sub === 'items' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === 'items' && $method === 'POST') {
            $ctrl->storeItem($request);
            exit;
        }
        if (str_starts_with($sub, 'items/') && $method === 'GET') {
            $id = substr($sub, 6);
            $ctrl->showItem($id);
            exit;
        }
        if (str_starts_with($sub, 'items/') && ($method === 'PUT' || $method === 'POST')) {
            $id = substr($sub, 6);
            $ctrl->updateItem($request, $id);
            exit;
        }
        if (str_starts_with($sub, 'items/') && $method === 'DELETE') {
            $id = substr($sub, 6);
            $ctrl->destroyItem($id);
            exit;
        }
        if ($sub === 'transactions' && $method === 'GET') {
            $ctrl->transactions($request);
            exit;
        }
        if ($sub === 'transactions' && $method === 'POST') {
            $ctrl->storeTransaction($request);
            exit;
        }
        if (str_starts_with($sub, 'transactions/') && $method === 'DELETE') {
            $id = substr($sub, 13);
            $ctrl->destroyTransaction($id);
            exit;
        }
        if ($sub === 'action' && $method === 'POST') {
            $ctrl->logAction($request);
            exit;
        }
    }

    // 10. Reports
    if ($apiPath === 'reports' || str_starts_with($apiPath, 'reports/')) {
        $ctrl = new ReportController();
        $sub = trim(substr($apiPath, strlen('reports')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === 'filter-options' && $method === 'GET') {
            $ctrl->filterOptions();
            exit;
        }
        if ($sub === 'action' && $method === 'POST') {
            $ctrl->logAction($request);
            exit;
        }
    }

    // 11. Dashboard Live Analytics
    if (str_starts_with($apiPath, 'dashboard/')) {
        $ctrl = new DashboardController();
        $sub = substr($apiPath, 10);
        if ($sub === 'stats') { $ctrl->apiStats(); exit; }
        if ($sub === 'chart') { $ctrl->apiChart(); exit; }
        if ($sub === 'activities') { $ctrl->apiActivities(); exit; }
        if ($sub === 'alerts') { $ctrl->apiAlerts(); exit; }
        if ($sub === 'pending-tasks') { $ctrl->apiPendingTasks(); exit; }
        if ($sub === 'stock-summary') { $ctrl->apiStockSummary(); exit; }
        if ($sub === 'movement-summary') { $ctrl->apiMovementSummary(); exit; }
    }

    // 12. Notifications
    if ($apiPath === 'notifications' || str_starts_with($apiPath, 'notifications/')) {
        $ctrl = new NotificationController();
        $sub = trim(substr($apiPath, strlen('notifications')), '/');

        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if (str_ends_with($sub, '/read') && $method === 'POST') {
            $id = substr($sub, 0, -5);
            $ctrl->markRead($id);
            exit;
        }
        if ($sub === 'mark-all-read' && $method === 'POST') {
            $ctrl->markAllRead();
            exit;
        }
    }

    // 13. Target & Activity
    if ($apiPath === 'target-activity' || str_starts_with($apiPath, 'target-activity/')) {
        $ctrl = new TargetActivityController();
        if ($method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($method === 'POST') {
            $ctrl->store($request);
            exit;
        }
    }

    // 14. Report Requests
    if ($apiPath === 'report-requests' || str_starts_with($apiPath, 'report-requests/')) {
        $ctrl = new ReportRequestController();
        if ($method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($method === 'POST') {
            $ctrl->store($request);
            exit;
        }
    }

    // 15. Note & Document Cabinet
    if ($apiPath === 'note-document-cabinet' || str_starts_with($apiPath, 'note-document-cabinet/')) {
        $ctrl = new CabinetDocumentController();
        if ($method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($method === 'POST') {
            $ctrl->store($request);
            exit;
        }
    }

    // 16. Data Quality
    if ($apiPath === 'data-quality' || str_starts_with($apiPath, 'data-quality/')) {
        $ctrl = new DataQualityController();
        $sub = trim(substr($apiPath, strlen('data-quality')), '/');
        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === 'verify' && $method === 'POST') {
            $ctrl->verify($request);
            exit;
        }
    }

    // 17. Monitoring
    if ($apiPath === 'monitoring' || str_starts_with($apiPath, 'monitoring/')) {
        $ctrl = new MonitoringController();
        if ($method === 'GET') {
            $ctrl->index($request);
            exit;
        }
    }

    // 18. Analytics
    if ($apiPath === 'analytics' || str_starts_with($apiPath, 'analytics/')) {
        $ctrl = new AnalyticsController();
        if ($method === 'GET') {
            $ctrl->index($request);
            exit;
        }
    }

    // 19. Backup & Settings
    if ($apiPath === 'backup-settings' || str_starts_with($apiPath, 'backup-settings/')) {
        $ctrl = new BackupSettingsController();
        $sub = trim(substr($apiPath, strlen('backup-settings')), '/');
        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === 'trigger' && $method === 'POST') {
            $ctrl->triggerBackup($request);
            exit;
        }
    }

    // 20. Users & Permissions
    if ($apiPath === 'users' || str_starts_with($apiPath, 'users/')) {
        $ctrl = new UserPermissionController();
        $sub = trim(substr($apiPath, strlen('users')), '/');
        if ($sub === '' && $method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($sub === '' && $method === 'POST') {
            $ctrl->store($request);
            exit;
        }
        if ($sub !== '' && ($method === 'PUT' || $method === 'POST')) {
            $ctrl->update($request, $sub);
            exit;
        }
        if ($sub !== '' && $method === 'DELETE') {
            $ctrl->destroy($sub);
            exit;
        }
    }

    // 21. Audit Logs
    if ($apiPath === 'audit-logs' || str_starts_with($apiPath, 'audit-logs/')) {
        $ctrl = new AuditLogController();
        if ($method === 'GET') {
            $ctrl->index($request);
            exit;
        }
        if ($method === 'POST') {
            $ctrl->store($request);
            exit;
        }
    }

    // 22. Generic Actions Performer
    if ($apiPath === 'actions/perform' && $method === 'POST') {
        $module = $request->input('module');
        $action = $request->input('action', 'view');
        $reference = $request->input('reference', '');

        if (!$user->isSuperAdmin() && !$user->hasPermission($module, $action)) {
            \App\Models\AuditLog::record($module, 'UNAUTHORIZED_ATTEMPT', "Denied action: {$action}", $user);
            return response()->json([
                'authorized' => false,
                'error' => 'Forbidden',
                'message' => "You do not have permission to {$action} in {$module}."
            ], 403);
        }

        \App\Models\AuditLog::record($module, strtoupper($action), $reference, $user);
        return response()->json([
            'authorized' => true,
            'success' => true,
            'message' => "Action '{$action}' performed and recorded in audit log."
        ]);
    }
}

// -----------------------------------------------------------------------------
// 3. File Upload & Download Endpoints & Branding Settings
// -----------------------------------------------------------------------------
$cabinetController = new CabinetDocumentController();
$backupSettingsController = new BackupSettingsController();

if ($uri === '/api/settings/branding') {
    if ($method === 'GET') {
        $backupSettingsController->getBranding();
        exit;
    }
    if ($method === 'POST') {
        $backupSettingsController->updateBranding(new \App\Http\Request());
        exit;
    }
}

if ($uri === '/api/settings/upload-branding-asset' && $method === 'POST') {
    $backupSettingsController->uploadBrandingAsset();
    exit;
}

if ($uri === '/api/documents/upload' && $method === 'POST') {
    $cabinetController->upload();
    exit;
}

if (str_starts_with($uri, '/api/documents/download/')) {
    $filename = substr($uri, strlen('/api/documents/download/'));
    $cabinetController->download($filename);
    exit;
}

if ($uri === '/api/excel/import' && $method === 'POST') {
    $user = AuthManager::user();
    $file = $_FILES['excel_file'] ?? null;
    if (!$file || empty($file['tmp_name'])) {
        http_response_code(422);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'No excel/csv file uploaded']);
        exit;
    }

    $origName = basename($file['name']);
    $uploadsDir = dirname(__DIR__) . '/storage/app/uploads';
    if (!is_dir($uploadsDir)) mkdir($uploadsDir, 0777, true);
    $safeName = 'import-' . time() . '-' . preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $origName);
    move_uploaded_file($file['tmp_name'], $uploadsDir . '/' . $safeName);

    \App\Models\AuditLog::record('excel-import-export', 'IMPORT', "Imported file {$origName}", $user);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'message' => "File {$origName} validated and imported successfully.",
        'filename' => $safeName,
        'size' => $file['size']
    ]);
    exit;
}

// -----------------------------------------------------------------------------
// 4. AI Assistant Endpoints (Pure PHP implementation)
// -----------------------------------------------------------------------------
if ($uri === '/api/ai/quick-search' && $method === 'GET') {
    header('Content-Type: application/json');
    $q = strtolower(trim($_GET['q'] ?? ''));
    $results = [];

    $catalog = [
        ['name' => 'LeaveCalculationService.php', 'path' => 'app/Services/LeaveCalculationService.php', 'category' => 'Service', 'description' => 'ছুটি অনুমোদন, বার্ষিক কোটা ও ওভারল্যাপ হিসাব'],
        ['name' => 'StockValuationService.php', 'path' => 'app/Services/StockValuationService.php', 'category' => 'Service', 'description' => 'ইনভেন্টরি ব্যালেন্স ও ভ্যালুয়েশন ক্যালকুলেশন'],
        ['name' => 'AdvanceAmortizationService.php', 'path' => 'app/Services/AdvanceAmortizationService.php', 'category' => 'Service', 'description' => 'ঋণ অ্যামরটাইজেশন ও কিস্তি পুনরুদ্ধার হিসাব'],
        ['name' => 'DataQualityAuditService.php', 'path' => 'app/Services/DataQualityAuditService.php', 'category' => 'Service', 'description' => '১০০ ভিত্তিক ডাটা হেলথ স্কোর নিরীক্ষা'],
        ['name' => 'CabinetDocumentController.php', 'path' => 'app/Http/Controllers/CabinetDocumentController.php', 'category' => 'HTTP Controller', 'description' => 'নথি আপলোড, ডাউনলোড ও কেবিনেট হিস্ট্রি'],
        ['name' => 'stock-register/index.blade.php', 'path' => 'resources/views/stock-register/index.blade.php', 'category' => 'Blade View', 'description' => 'স্টক রেজিস্টার ও ইনভেন্টরি খতিয়ান'],
        ['name' => 'leave-management/index.blade.php', 'path' => 'resources/views/leave-management/index.blade.php', 'category' => 'Blade View', 'description' => 'ছুটি ব্যবস্থাপনা ও কোটা ব্যালেন্স ইন্টারফেস'],
        ['name' => 'advance-management/index.blade.php', 'path' => 'resources/views/advance-management/index.blade.php', 'category' => 'Blade View', 'description' => 'অগ্রিম ঋণ বিতরণ ও কিস্তি শিডিউল ইন্টারফেস'],
        ['name' => 'department-management/index.blade.php', 'path' => 'resources/views/department-management/index.blade.php', 'category' => 'Blade View', 'description' => 'ডিপার্টমেন্ট কোড, হেডকাউন্ট ও বাজেট'],
        ['name' => 'location-branch/index.blade.php', 'path' => 'resources/views/location-branch/index.blade.php', 'category' => 'Blade View', 'description' => 'ব্রাঞ্চ কোড ও জোন অ্যাসাইনমেন্ট'],
    ];

    foreach ($catalog as $item) {
        if (!$q || str_contains(strtolower($item['name']), $q) || str_contains(strtolower($item['description']), $q) || str_contains(strtolower($item['path']), $q)) {
            $results[] = $item;
        }
    }
    echo json_encode(['results' => $results], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($uri === '/api/ai/assistant' && $method === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $msg = trim($input['message'] ?? '');

    $reply = "আমি আপনার অনুরোধটি পর্যালোচনা করেছি। প্রজেক্টের সংশ্লিষ্ট ফাইলসমূহ:\n\n" .
        "• **ছুটি/Leave:** `resources/views/leave-management/index.blade.php` ও `app/Services/LeaveCalculationService.php`\n" .
        "• **স্টক/Stock:** `resources/views/stock-register/index.blade.php` ও `app/Services/StockValuationService.php`\n" .
        "• **অগ্রিম ঋণ/Advance:** `resources/views/advance-management/index.blade.php` ও `app/Services/AdvanceAmortizationService.php`\n\n" .
        "প্রয়োজন অনুযায়ী যেকোনো ফাইলে ক্লিক করে আপনি সরাসরি ফিচারটি ব্রাউজারে ব্যবহার করতে পারেন।";

    echo json_encode([
        'reply' => $reply,
        'matchedFiles' => [
            ['name' => 'LeaveCalculationService.php', 'path' => 'app/Services/LeaveCalculationService.php', 'category' => 'Service', 'description' => 'ছুটি অনুমোদন ও ব্যালেন্স হিসাব'],
            ['name' => 'StockValuationService.php', 'path' => 'app/Services/StockValuationService.php', 'category' => 'Service', 'description' => 'ইনভেন্টরি ভ্যালুয়েশন সার্ভিস']
        ],
        'provider' => 'pure-laravel-ai-indexer'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// -----------------------------------------------------------------------------
// 5. System Health Check
// -----------------------------------------------------------------------------
if ($uri === '/health') {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ok',
        'authEngine' => 'Laravel PHP 8.2+',
        'database' => 'SQLite Connected',
        'userCount' => \App\Models\User::count(),
        'authenticated' => AuthManager::check(),
    ]);
    exit;
}

// -----------------------------------------------------------------------------
// 6. Application Module Views (Protected by Laravel Role & Permission Middleware)
// -----------------------------------------------------------------------------
$module = $uri;
if (str_starts_with($module, '/pages/')) {
    $module = substr($module, 7);
}
if (str_ends_with($module, '/index.html')) {
    $module = substr($module, 0, -11);
}
$module = trim($module, '/');

$knownModules = [
    'dashboard',
    'location-branch',
    'domain-zone-management',
    'domain-zone',
    'department-management',
    'department',
    'staff-position-list',
    'staff',
    'leave-management',
    'leave',
    'mis-data-entry',
    'mis-entry',
    'reports',
    'data-quality',
    'analytics',
    'note-document-cabinet',
    'documents',
    'advance-management',
    'advances',
    'target-activity',
    'targets',
    'monitoring',
    'report-requests',
    'excel-import-export',
    'excel',
    'movement-register',
    'movement',
    'stock-register',
    'stock',
    'notifications',
    'users-permissions',
    'users',
    'audit-log',
    'audit',
    'backup-settings',
    'settings',
];

if (in_array($module, $knownModules)) {
    echo $pageController->show($module);
    exit;
}

// Fallback 404
abort(404, 'Page not found');
