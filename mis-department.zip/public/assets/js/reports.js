/**
 * MIS Department - Reports Module Frontend Logic
 * Live SQLite / MySQL integration with Search, Filter, Date Range, Department, Location, Branch,
 * Domain, Zone, Employee, Status, Module-specific filters, Pagination, Summary, Totals, Print, Export & Audit.
 */

let REPORT_CATALOG = [];
let ACTIVE_REPORT = null;
let CURRENT_PAGE = 1;
let PER_PAGE = 25;
let FILTER_OPTIONS = null;

function repEsc(str) {
  return String(str ?? '').replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[m]));
}

function showRepToast(msg, isError = false) {
  const toastEl = document.getElementById('toast');
  if (toastEl) {
    const body = toastEl.querySelector('.toast-body') || toastEl;
    body.textContent = msg;
    toastEl.className = `toast position-fixed bottom-0 end-0 m-3 show text-white ${isError ? 'bg-danger' : 'bg-success'}`;
    setTimeout(() => {
      toastEl.classList.remove('show');
    }, 3500);
  } else {
    console.log(msg);
  }
}

// 1. Initialize Dropdowns and Options
async function initReportsModule() {
  try {
    const res = await fetch('/api/reports/filter-options');
    const json = await res.json();
    if (json.success) {
      FILTER_OPTIONS = json;
      populateFilterDropdowns(json);
    }
  } catch (err) {
    console.warn('Could not load filter options:', err);
  }

  await loadReportsCatalog();

  // If a category was pre-selected or requested, bind events
  bindFilterEvents();
}

function populateFilterDropdowns(opts) {
  // Division
  const divSelect = document.getElementById('filterDivision');
  if (divSelect) {
    divSelect.innerHTML = '<option value="">All Divisions</option>' +
      (opts.divisions || []).map(d => `<option value="${repEsc(d)}">${repEsc(d)}</option>`).join('');
  }

  // Department
  const deptSelect = document.getElementById('filterDepartment');
  if (deptSelect) {
    deptSelect.innerHTML = '<option value="">All Departments</option>' +
      (opts.departments || []).map(d => `<option value="${repEsc(d)}">${repEsc(d)}</option>`).join('');
  }

  // District
  const distSelect = document.getElementById('filterDistrict');
  if (distSelect) {
    distSelect.innerHTML = '<option value="">All Districts</option>' +
      (opts.districts || []).map(d => `<option value="${repEsc(d)}">${repEsc(d)}</option>`).join('');
  }

  // Branch
  const brSelect = document.getElementById('filterBranch');
  if (brSelect) {
    brSelect.innerHTML = '<option value="">All Branches</option>' +
      (opts.branches || []).map(b => `<option value="${repEsc(b.code)}">${repEsc(b.name)} (${repEsc(b.code)})</option>`).join('');
  }

  // Domain
  const domSelect = document.getElementById('filterDomain');
  if (domSelect) {
    domSelect.innerHTML = '<option value="">All Domains</option>' +
      (opts.domains || []).map(d => `<option value="${repEsc(d)}">${repEsc(d)}</option>`).join('');
  }

  // Zone
  const zoneSelect = document.getElementById('filterZone');
  if (zoneSelect) {
    zoneSelect.innerHTML = '<option value="">All Zones</option>' +
      (opts.zones || []).map(z => `<option value="${repEsc(z)}">${repEsc(z)}</option>`).join('');
  }

  // Also populate Modal Template and Branch selects
  const modalTemplate = document.getElementById('modalTemplate');
  if (modalTemplate) {
    modalTemplate.innerHTML = '<option value="">Select Template</option>' +
      '<option value="monthly-mis">Monthly MIS Summary</option>' +
      '<option value="staff-position">Staff Position Report</option>' +
      '<option value="branch-summary">Branch Summary Report</option>' +
      '<option value="domain-zone">Domain & Zone Head Information</option>' +
      '<option value="movement-register">Movement Register Report</option>' +
      '<option value="stock-register">Stock Inventory Report</option>' +
      '<option value="department">Department Management Report</option>' +
      '<option value="audit-log">System Audit & Activity Report</option>';
  }

  const modalBranch = document.getElementById('modalBranchOffice');
  if (modalBranch) {
    modalBranch.innerHTML = '<option value="All Branches">All Branches</option>' +
      (opts.branches || []).map(b => `<option value="${repEsc(b.name)}">${repEsc(b.name)}</option>`).join('');
  }

  updateModuleSpecificFilter();
}

function updateModuleSpecificFilter() {
  const catSelect = document.getElementById('reportCategory');
  const modSelect = document.getElementById('filterModuleSpecific');
  const modContainer = document.getElementById('filterModuleSpecificContainer');
  const modLabel = document.getElementById('filterModuleSpecificLabel');

  if (!catSelect || !modSelect) return;
  const val = (catSelect.value || '').toLowerCase();

  if (val.includes('stock')) {
    if (modContainer) modContainer.style.display = 'block';
    if (modLabel) modLabel.textContent = 'Stock Category';
    modSelect.innerHTML = '<option value="">All Categories</option>' +
      (FILTER_OPTIONS?.stock_categories || []).map(c => `<option value="${repEsc(c)}">${repEsc(c)}</option>`).join('');
  } else if (val.includes('movement')) {
    if (modContainer) modContainer.style.display = 'block';
    if (modLabel) modLabel.textContent = 'Movement Type';
    modSelect.innerHTML = '<option value="">All Types</option>' +
      (FILTER_OPTIONS?.movement_types || ['Official', 'Field Visit', 'Personal']).map(t => `<option value="${repEsc(t)}">${repEsc(t)}</option>`).join('');
  } else if (val.includes('zone') || val.includes('domain')) {
    if (modContainer) modContainer.style.display = 'block';
    if (modLabel) modLabel.textContent = 'Head Type';
    modSelect.innerHTML = '<option value="">All Head Types</option>' +
      (FILTER_OPTIONS?.domain_head_types || ['Domain Head', 'Zone Head']).map(t => `<option value="${repEsc(t)}">${repEsc(t)}</option>`).join('');
  } else if (val.includes('staff')) {
    if (modContainer) modContainer.style.display = 'block';
    if (modLabel) modLabel.textContent = 'Gender';
    modSelect.innerHTML = '<option value="">All Genders</option><option value="Male">Male</option><option value="Female">Female</option>';
  } else {
    if (modContainer) modContainer.style.display = 'none';
    modSelect.innerHTML = '<option value="">All</option>';
  }
}

function bindFilterEvents() {
  const catSelect = document.getElementById('reportCategory');
  if (catSelect) {
    catSelect.addEventListener('change', () => {
      updateModuleSpecificFilter();
    });
  }

  const searchInput = document.getElementById('reportSearch');
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        triggerGenerate();
      }
    });
  }
}

// 2. Load Reports Catalog (Table: Report | Period | Scope | Status | Action)
async function loadReportsCatalog() {
  const tbody = document.getElementById('reportsCatalogBody');
  if (!tbody) return;

  try {
    const res = await fetch('/api/reports');
    const json = await res.json();
    if (!json.success) {
      console.error('Failed to load reports catalog:', json.error);
      return;
    }

    REPORT_CATALOG = json.data || [];
    renderReportsCatalog(REPORT_CATALOG);
  } catch (err) {
    console.error('Error loading reports:', err);
    tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger py-3">Failed to load reports from server.</td></tr>`;
  }
}

function renderReportsCatalog(reports) {
  const tbody = document.getElementById('reportsCatalogBody');
  if (!tbody) return;

  if (reports.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-4">No reports configured.</td></tr>`;
    return;
  }

  tbody.innerHTML = reports.map(r => {
    const catCode = r.category || 'monthly-mis';
    return `
      <tr>
        <td>
          <div class="fw-bold text-dark">${repEsc(r.title)}</div>
          <div class="small text-muted">${repEsc(r.template || r.category)} &bull; ${r.total_records !== undefined ? `<span class="badge bg-light text-dark border">${r.total_records} records</span>` : ''}</div>
        </td>
        <td>
          <span class="text-secondary fw-semibold">${repEsc(r.period || 'Sep 2026')}</span>
        </td>
        <td>
          <span>${repEsc(r.scope || 'All Branches')}</span>
        </td>
        <td>
          <span class="badge ${r.status === 'Ready' ? 'bg-success' : 'bg-secondary'}">${repEsc(r.status || 'Ready')}</span>
        </td>
        <td>
          <div class="btn-group btn-group-sm">
            <button class="btn btn-outline-primary" onclick="viewReport('${repEsc(catCode)}', '${repEsc(r.title)}')" title="View Report">
              <i data-lucide="eye" style="width:14px;height:14px;" class="me-1 inline"></i>View
            </button>
            <button class="btn btn-outline-secondary" onclick="printReportDirect('${repEsc(catCode)}')" title="Print Report">
              <i data-lucide="printer" style="width:14px;height:14px;" class="me-1 inline"></i>Print
            </button>
            <button class="btn btn-outline-success" onclick="exportReportDirect('${repEsc(catCode)}')" title="Export CSV">
              <i data-lucide="download" style="width:14px;height:14px;" class="me-1 inline"></i>Export
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  if (window.lucide) {
    lucide.createIcons();
  }
}

// 3. Build Active Filter Query Object
function getActiveFilterParams() {
  const category = document.getElementById('reportCategory')?.value || '';
  const division = document.getElementById('filterDivision')?.value || '';
  const dateFrom = document.getElementById('filterDateFrom')?.value || '';
  const dateTo = document.getElementById('filterDateTo')?.value || '';

  const search = document.getElementById('reportSearch')?.value || '';
  const department = document.getElementById('filterDepartment')?.value || '';
  const district = document.getElementById('filterDistrict')?.value || '';
  const branch = document.getElementById('filterBranch')?.value || '';
  const domain = document.getElementById('filterDomain')?.value || '';
  const zone = document.getElementById('filterZone')?.value || '';
  const employee = document.getElementById('filterEmployee')?.value || '';
  const status = document.getElementById('filterStatus')?.value || '';
  const moduleFilter = document.getElementById('filterModuleSpecific')?.value || '';

  return {
    category: category && category !== 'Report Category' ? category : 'monthly-mis',
    division: division && division !== 'Division' ? division : '',
    date_from: dateFrom,
    date_to: dateTo,
    search: search.trim(),
    department: department && department !== 'All Departments' ? department : '',
    district: district && district !== 'All Districts' ? district : '',
    branch: branch && branch !== 'All Branches' ? branch : '',
    domain: domain && domain !== 'All Domains' ? domain : '',
    zone: zone && zone !== 'All Zones' ? zone : '',
    employee: employee.trim(),
    status: status && status !== 'All' ? status : '',
    module_filter: moduleFilter && moduleFilter !== 'All' ? moduleFilter : '',
    page: CURRENT_PAGE,
    limit: PER_PAGE
  };
}

// 4. Generate / View Report
async function triggerGenerate(targetCategory = null) {
  if (targetCategory) {
    const catSelect = document.getElementById('reportCategory');
    if (catSelect) {
      catSelect.value = targetCategory;
      updateModuleSpecificFilter();
    }
  }

  CURRENT_PAGE = 1;
  await fetchAndDisplayReport();
}

async function viewReport(category, title = '') {
  const catSelect = document.getElementById('reportCategory');
  if (catSelect) {
    // Select option by value or text
    let found = false;
    for (let opt of catSelect.options) {
      if (opt.value.toLowerCase() === category.toLowerCase() || opt.text.toLowerCase().includes(category.toLowerCase())) {
        catSelect.value = opt.value;
        found = true;
        break;
      }
    }
    if (!found) {
      catSelect.value = category;
    }
    updateModuleSpecificFilter();
  }

  CURRENT_PAGE = 1;
  await fetchAndDisplayReport();
}

async function fetchAndDisplayReport() {
  const filters = getActiveFilterParams();
  const query = new URLSearchParams();

  Object.entries(filters).forEach(([k, v]) => {
    if (v !== '' && v !== null && v !== undefined) {
      query.append(k, v);
    }
  });

  const viewer = document.getElementById('reportViewerContainer');
  if (viewer) {
    viewer.style.display = 'block';
    viewer.scrollIntoView({ behavior: 'smooth' });
  }

  const tableBody = document.getElementById('activeReportTableBody');
  if (tableBody) {
    tableBody.innerHTML = `<tr><td colspan="12" class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm text-primary me-2"></div>Generating real database report...</td></tr>`;
  }

  try {
    const res = await fetch(`/api/reports/data?${query.toString()}`);
    const json = await res.json();

    if (!json.success) {
      showRepToast(json.error || 'Failed to generate report', true);
      if (tableBody) {
        tableBody.innerHTML = `<tr><td colspan="12" class="text-center py-4 text-danger">${repEsc(json.error || 'Failed to generate report')}</td></tr>`;
      }
      return;
    }

    ACTIVE_REPORT = json;
    renderActiveReportView(json);
  } catch (err) {
    console.error('Report fetch error:', err);
    showRepToast('Error connecting to reports server.', true);
  }
}

// 5. Render Generated Report View (Header, Summary Cards, Table, Totals, Pagination)
function renderActiveReportView(report) {
  // Title & Metadata
  const titleEl = document.getElementById('activeReportTitle');
  if (titleEl) titleEl.textContent = report.title || 'MIS Report';

  const periodEl = document.getElementById('activeReportPeriod');
  if (periodEl) periodEl.textContent = report.period || 'Current';

  const scopeEl = document.getElementById('activeReportScope');
  if (scopeEl) scopeEl.textContent = report.scope || 'All';

  const genAtEl = document.getElementById('activeReportGeneratedAt');
  if (genAtEl) genAtEl.textContent = new Date().toLocaleString();

  const countBadge = document.getElementById('activeReportCountBadge');
  if (countBadge) countBadge.textContent = `${report.pagination?.total || 0} Records`;

  // Render Summary Cards
  renderReportSummaryCards(report.summary || {});

  // Render Columns
  const thead = document.getElementById('activeReportTableHead');
  if (thead) {
    let headHtml = '<tr><th style="width: 50px;">#</th>';
    report.columns.forEach(col => {
      const alignClass = col.align === 'right' ? 'text-end' : '';
      headHtml += `<th class="${alignClass}">${repEsc(col.label)}</th>`;
    });
    headHtml += '</tr>';
    thead.innerHTML = headHtml;
  }

  // Render Rows
  const tbody = document.getElementById('activeReportTableBody');
  if (tbody) {
    const rows = report.data || [];
    if (rows.length === 0) {
      tbody.innerHTML = `<tr><td colspan="${(report.columns?.length || 5) + 1}" class="text-center py-5 text-muted">No records found matching the applied filters.</td></tr>`;
    } else {
      const offset = (report.pagination?.page - 1) * report.pagination?.limit;
      tbody.innerHTML = rows.map((row, idx) => {
        let rowHtml = `<tr><td class="text-muted small">${offset + idx + 1}</td>`;
        report.columns.forEach(col => {
          const val = row[col.key];
          const alignClass = col.align === 'right' ? 'text-end' : '';

          // Format special cell types (badges for status)
          let formattedVal = repEsc(val !== undefined && val !== null ? val : '-');
          if (col.key === 'status' || col.key === 'warning') {
            const strVal = String(val || '');
            let badgeClass = 'bg-secondary';
            if (['Active', 'Ready', 'Available', 'Returned', 'Normal'].includes(strVal)) badgeClass = 'bg-success';
            else if (['Out', 'Low Stock', 'Review', 'Pending', 'Active Monitoring'].includes(strVal)) badgeClass = 'bg-warning text-dark';
            else if (['Inactive', 'Late Return', 'Out of Stock'].includes(strVal)) badgeClass = 'bg-danger';
            formattedVal = `<span class="badge ${badgeClass}">${formattedVal}</span>`;
          }

          rowHtml += `<td class="${alignClass}">${formattedVal}</td>`;
        });
        rowHtml += '</tr>';
        return rowHtml;
      }).join('');
    }
  }

  // Render Totals Row in tfoot
  const tfoot = document.getElementById('activeReportTableFoot');
  if (tfoot) {
    if (report.totals && Object.keys(report.totals).length > 0) {
      let footHtml = '<tr class="table-light fw-bold"><td>TOTAL</td>';
      report.columns.forEach(col => {
        const alignClass = col.align === 'right' ? 'text-end' : '';
        if (report.totals[col.key] !== undefined) {
          footHtml += `<td class="${alignClass} text-primary fw-bold">${repEsc(report.totals[col.key])}</td>`;
        } else {
          footHtml += '<td></td>';
        }
      });
      footHtml += '</tr>';
      tfoot.innerHTML = footHtml;
      tfoot.style.display = '';
    } else {
      tfoot.innerHTML = '';
      tfoot.style.display = 'none';
    }
  }

  // Render Pagination
  renderReportPagination(report.pagination);

  if (window.lucide) {
    lucide.createIcons();
  }
}

// 6. Render Summary Metrics KPI Cards
function renderReportSummaryCards(summary) {
  const container = document.getElementById('reportSummaryCardsRow');
  if (!container) return;

  const entries = Object.entries(summary);
  if (entries.length === 0) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = entries.map(([key, val]) => {
    const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    let icon = 'activity';
    let colorClass = 'text-primary';

    if (key.includes('active') || key.includes('available')) {
      icon = 'check-circle';
      colorClass = 'text-success';
    } else if (key.includes('total') || key.includes('stock')) {
      icon = 'layers';
      colorClass = 'text-primary';
    } else if (key.includes('out') || key.includes('low') || key.includes('review')) {
      icon = 'alert-triangle';
      colorClass = 'text-warning';
    } else if (key.includes('inactive') || key.includes('late')) {
      icon = 'x-circle';
      colorClass = 'text-danger';
    }

    return `
      <div class="col-6 col-md-3 col-xl-2">
        <div class="cardx p-3 text-center border-0 shadow-sm">
          <div class="small text-muted mb-1 text-truncate">${repEsc(label)}</div>
          <div class="h4 mb-0 fw-bold ${colorClass}">${repEsc(val)}</div>
        </div>
      </div>
    `;
  }).join('');
}

// 7. Render Pagination Controls
function renderReportPagination(pag) {
  const infoEl = document.getElementById('reportPaginationInfo');
  const navEl = document.getElementById('reportPaginationNav');
  if (!pag) return;

  if (infoEl) {
    if (pag.total === 0) {
      infoEl.textContent = 'Showing 0 of 0 entries';
    } else {
      infoEl.textContent = `Showing ${pag.from} to ${pag.to} of ${pag.total} entries`;
    }
  }

  if (!navEl) return;

  if (pag.total_pages <= 1) {
    navEl.innerHTML = '';
    return;
  }

  let html = '<ul class="pagination pagination-sm mb-0">';

  // Previous
  html += `
    <li class="page-item ${pag.page <= 1 ? 'disabled' : ''}">
      <button class="page-link" onclick="goToReportPage(${pag.page - 1})" aria-label="Previous">&laquo;</button>
    </li>
  `;

  // Page Numbers
  const totalP = pag.total_pages;
  let startP = Math.max(1, pag.page - 2);
  let endP = Math.min(totalP, pag.page + 2);

  if (startP > 1) {
    html += `<li class="page-item"><button class="page-link" onclick="goToReportPage(1)">1</button></li>`;
    if (startP > 2) html += `<li class="page-item disabled"><span class="page-link">&hellip;</span></li>`;
  }

  for (let i = startP; i <= endP; i++) {
    html += `
      <li class="page-item ${i === pag.page ? 'active' : ''}">
        <button class="page-link" onclick="goToReportPage(${i})">${i}</button>
      </li>
    `;
  }

  if (endP < totalP) {
    if (endP < totalP - 1) html += `<li class="page-item disabled"><span class="page-link">&hellip;</span></li>`;
    html += `<li class="page-item"><button class="page-link" onclick="goToReportPage(${totalP})">${totalP}</button></li>`;
  }

  // Next
  html += `
    <li class="page-item ${pag.page >= totalP ? 'disabled' : ''}">
      <button class="page-link" onclick="goToReportPage(${pag.page + 1})" aria-label="Next">&raquo;</button>
    </li>
  `;

  html += '</ul>';
  navEl.innerHTML = html;
}

function goToReportPage(page) {
  if (page < 1) return;
  CURRENT_PAGE = page;
  fetchAndDisplayReport();
}

function changeReportPageSize(newSize) {
  PER_PAGE = newSize === 'all' ? 'all' : parseInt(newSize, 10);
  CURRENT_PAGE = 1;
  fetchAndDisplayReport();
}

function resetReportFilters() {
  document.getElementById('reportSearch').value = '';
  document.getElementById('reportCategory').value = 'monthly-mis';
  document.getElementById('filterDivision').value = '';
  document.getElementById('filterDateFrom').value = '';
  document.getElementById('filterDateTo').value = '';

  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };

  setVal('filterDepartment', '');
  setVal('filterDistrict', '');
  setVal('filterBranch', '');
  setVal('filterDomain', '');
  setVal('filterZone', '');
  setVal('filterEmployee', '');
  setVal('filterStatus', '');
  setVal('filterModuleSpecific', '');

  updateModuleSpecificFilter();
  CURRENT_PAGE = 1;
  triggerGenerate();
}

// 8. Print Report Functionality
async function printCurrentReport() {
  if (!ACTIVE_REPORT) {
    showRepToast('Please generate a report before printing.', true);
    return;
  }

  // Log audit action
  try {
    await fetch('/api/reports/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'print',
        reference: `Printed ${ACTIVE_REPORT.title} (${ACTIVE_REPORT.pagination?.total || 0} records)`
      })
    });
  } catch (e) {
    console.warn('Could not record print audit:', e);
  }

  window.print();
}

async function printReportDirect(category) {
  await viewReport(category);
  setTimeout(() => {
    printCurrentReport();
  }, 400);
}

// 9. Export Report Functionality (CSV with UTF-8 BOM)
async function exportCurrentReport() {
  const filters = getActiveFilterParams();
  filters.limit = 'all';

  const query = new URLSearchParams();
  Object.entries(filters).forEach(([k, v]) => {
    if (v !== '' && v !== null && v !== undefined) {
      query.append(k, v);
    }
  });

  // Log action
  try {
    await fetch('/api/reports/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'export',
        reference: `Exported ${ACTIVE_REPORT?.title || filters.category}`
      })
    });
  } catch (e) {
    console.warn('Could not record export audit:', e);
  }

  // Trigger download
  window.location.href = `/api/reports/export?${query.toString()}`;
  showRepToast('Preparing CSV report download...');
}

function exportReportDirect(category) {
  const query = new URLSearchParams({ category, limit: 'all' });
  window.location.href = `/api/reports/export?${query.toString()}`;
  showRepToast('Preparing CSV report download...');
}

// 10. Handle Modal Form Submission (checkedFormModal)
async function saveReportDefinition(e) {
  e.preventDefault();
  const title = document.getElementById('modalReportTitle')?.value?.trim();
  const period = document.getElementById('modalReportingPeriod')?.value;
  const template = document.getElementById('modalTemplate')?.value;
  const branchOffice = document.getElementById('modalBranchOffice')?.value;
  const reportType = document.getElementById('modalReportType')?.value;
  const submissionStatus = document.getElementById('modalSubmissionStatus')?.value;
  const remarks = document.getElementById('modalRemarks')?.value?.trim();

  if (!title) {
    showRepToast('Report Title is required.', true);
    return;
  }

  try {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        period,
        template,
        branch_office: branchOffice,
        report_type: reportType,
        submission_status: submissionStatus,
        remarks
      })
    });

    const json = await res.json();
    if (!json.success) {
      showRepToast(json.error || 'Failed to save report.', true);
      return;
    }

    showRepToast('Report definition created successfully!');
    const modalEl = document.getElementById('checkedFormModal');
    if (modalEl && window.bootstrap) {
      const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
      modal.hide();
    }

    // Reset form
    document.getElementById('modalReportForm')?.reset();

    // Reload catalog
    await loadReportsCatalog();
  } catch (err) {
    console.error('Save report error:', err);
    showRepToast('Error saving report definition.', true);
  }
}

// 11. Hook window events on load
document.addEventListener('DOMContentLoaded', () => {
  initReportsModule();
});
