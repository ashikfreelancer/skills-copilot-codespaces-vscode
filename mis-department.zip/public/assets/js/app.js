// Safety guard against libraries attempting to write to getter-only window.fetch
try {
  if (typeof window !== 'undefined' && window.fetch) {
    let _fetch = window.fetch;
    const desc = Object.getOwnPropertyDescriptor(window, 'fetch') || (typeof Window !== 'undefined' && Object.getOwnPropertyDescriptor(Window.prototype, 'fetch'));
    if (!desc || desc.set === undefined) {
      try {
        Object.defineProperty(window, 'fetch', {
          get() { return _fetch; },
          set(v) { _fetch = v; },
          configurable: true,
          enumerable: true
        });
      } catch (e) {}
    }
  }
} catch (e) {}

function MIS_requireAuth(){
  try {
    if(sessionStorage.getItem('mis_logged_out')==='1'){
      window.location.replace('/login');
      return;
    }
  } catch(e) {}
}
function MIS_logout(){
  try {
    sessionStorage.setItem('mis_logged_out','1');
    sessionStorage.removeItem('mis_authenticated');
    sessionStorage.removeItem('mis_user');
    window.location.href = '/logout';
  } catch(e) {
    window.location.href = '/logout';
  }
}
if (typeof window.MIS_ACTIONS === 'undefined') {
  window.MIS_ACTIONS = ['view','create','edit','update','delete','approve','reject','print','export','import'];
}
var MIS_ACTIONS = window.MIS_ACTIONS;

if (typeof window.MIS_ROLES === 'undefined') {
  window.MIS_ROLES = ['Super Admin', 'Admin', 'Accountant', 'Computer Operator'];
}
var MIS_ROLES = window.MIS_ROLES;

if (typeof window.MIS_MODULES === 'undefined') {
  window.MIS_MODULES = ['dashboard','location-branch','domain-zone-management','department-management','staff-position-list','leave-management','movement-register','stock-register','mis-data-entry','advance-management','target-activity','monitoring','reports','report-requests','analytics','notifications','users-permissions','note-document-cabinet','excel-import-export','backup-settings','data-quality','audit-log'];
}
var MIS_MODULES = window.MIS_MODULES;
function MIS_getUsers(){try{return JSON.parse(localStorage.getItem('mis_users_v2')||'[]')}catch(e){return[]}}
function MIS_currentUser(){
  try {
    const active = localStorage.getItem('mis_active_user');
    if (active) {
      const parsed = JSON.parse(active);
      if (parsed && (parsed.role || parsed.name)) return parsed;
    }
  } catch(e){}
  const login=sessionStorage.getItem('mis_user');
  const all=MIS_getUsers();
  const u=all.find(x=>x.login===login||x.email===login) || all.find(x=>(x.role==='Super Admin'||x.role==='MIS Super Admin')) || null;
  return u || { id: 'U-001', name: 'MIS Super Admin', email: 'superadmin@mis.local', role: 'Super Admin', permissions: { '*': true } };
}
function MIS_hasPermission(module,action){
  const u=MIS_currentUser();
  if(!u) return true;
  const r=(u.role||'').toLowerCase();
  if(r==='super admin'||r==='mis super admin') return true;
  if(u.permissions && u.permissions['*']) return true;
  return !!(u.permissions && u.permissions[module] && u.permissions[module][action]);
}
function MIS_addAudit(module,action,ref){
  try{
    const key='mis_audit_v2';
    const rows=JSON.parse(localStorage.getItem(key)||'[]');
    const u=MIS_currentUser();
    const entry={
      time:new Date().toISOString().replace('T',' ').substring(0,19),
      user:u?`${u.name} (${u.role})`:(sessionStorage.getItem('mis_user')||'Unknown'),
      module,
      action:String(action).toUpperCase(),
      reference:ref||''
    };
    rows.unshift(entry);
    localStorage.setItem(key,JSON.stringify(rows.slice(0,500)));
    // Server-side audit logging
    if(typeof fetch==='function'){
      fetch('/api/audit-logs',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({module,action:String(action).toUpperCase(),reference:ref||''})
      }).catch(()=>{});
    }
  }catch(e){}
}
function MIS_switchRole(role){
  fetch('/api/auth/switch-user',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({role})
  }).then(r=>r.json()).then(res=>{
    if(res.success && res.user){
      sessionStorage.setItem('mis_user',res.user.login||res.user.email);
      sessionStorage.setItem('mis_role',res.user.role);
      toast('Switched active role to '+res.user.role);
      setTimeout(()=>window.location.reload(),400);
    }
  }).catch(e=>{
    console.error('Role switch error:', e);
  });
}
function MIS_applyRoleUI(){document.querySelectorAll('[data-permission]').forEach(el=>{const [m,a]=el.dataset.permission.split(':');if(!MIS_hasPermission(m,a))el.classList.add('d-none');});}
function MIS_ensureOperationsModules(){
  const links=[
    {module:'movement-register',label:'Movement Register',icon:'arrow-left-right'},
    {module:'stock-register',label:'Stock Register',icon:'boxes'}
  ];
  document.querySelectorAll('.sidebar').forEach(sidebar=>{
    const opsTitle=[...sidebar.querySelectorAll('.group-title')].find(el=>el.textContent.trim().toUpperCase()==='OPERATIONS');
    if(!opsTitle) return;
    links.forEach(item=>{
      if(sidebar.querySelector('[data-nav="'+item.module+'"]')) return;
      const a=document.createElement('a');
      a.dataset.nav=item.module;
      a.href='/'+item.module;
      a.innerHTML='<i data-lucide="'+item.icon+'" style="width:18px"></i>'+item.label;
      opsTitle.insertAdjacentElement('afterend',a);
    });
  });
}

function MIS_ensureDepartmentNav(){
  document.querySelectorAll('.sidebar').forEach(sidebar=>{
    if(sidebar.querySelector('[data-nav="department-management"]')) return;
    const loc=sidebar.querySelector('[data-nav="location-branch"]');
    if(!loc) return;
    const a=document.createElement('a'); a.dataset.nav='department-management'; a.href='/department-management';
    a.innerHTML='<i data-lucide="building-2" style="width:18px"></i>Department Management';
    loc.insertAdjacentElement('afterend',a);
  });
}

// --------------------------------------------------------------------------
// Centralized Debounce Utility
// --------------------------------------------------------------------------
function MIS_debounce(fn, delay = 300) {
  let timer = null;
  return function(...args) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      fn.apply(this, args);
      timer = null;
    }, delay);
  };
}
window.MIS_debounce = MIS_debounce;

// --------------------------------------------------------------------------
// Double-Click / Double-Submit Concurrency Guard
// --------------------------------------------------------------------------
var _activeLocks = window._activeLocks = window._activeLocks || new Set();
async function MIS_withLock(key, asyncFn) {
  if (_activeLocks.has(key)) return;
  _activeLocks.add(key);
  try {
    return await asyncFn();
  } finally {
    _activeLocks.delete(key);
  }
}
window.MIS_withLock = MIS_withLock;

// Form Submission Double-Click Guard
document.addEventListener('submit', function(e) {
  const form = e.target;
  if (!form || form.tagName !== 'FORM') return;
  if (form.dataset.misSubmitting === 'true') {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }
  form.dataset.misSubmitting = 'true';
  const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
  if (submitBtn && !submitBtn.disabled) {
    submitBtn.dataset.originalHtml = submitBtn.innerHTML;
    submitBtn.dataset.wasDisabled = 'true';
    submitBtn.disabled = true;
  }
  setTimeout(() => {
    delete form.dataset.misSubmitting;
    if (submitBtn && submitBtn.dataset.wasDisabled === 'true') {
      submitBtn.disabled = false;
      delete submitBtn.dataset.wasDisabled;
    }
  }, 4000);
}, true);

window.MIS_unlockForm = function(form) {
  if (!form) return;
  delete form.dataset.misSubmitting;
  const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
  if (submitBtn && submitBtn.dataset.wasDisabled === 'true') {
    submitBtn.disabled = false;
    delete submitBtn.dataset.wasDisabled;
    if (submitBtn.dataset.originalHtml) {
      submitBtn.innerHTML = submitBtn.dataset.originalHtml;
    }
  }
};

// --------------------------------------------------------------------------
// Modal Freeze & Backdrop Cleanup Guard
// --------------------------------------------------------------------------
document.addEventListener('hidden.bs.modal', function(e) {
  setTimeout(() => {
    if (!document.querySelector('.modal.show')) {
      document.querySelectorAll('.modal-backdrop').forEach(b => b.remove());
      document.body.classList.remove('modal-open');
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
    }
  }, 120);

  // Clean up any CKEditor instances attached inside the closed modal if needed
  const modalEl = e.target;
  if (modalEl && typeof window.MIS_ckeditor_instances !== 'undefined') {
    modalEl.querySelectorAll('textarea.editor, textarea[data-editor="classic"]').forEach(ta => {
      if (window.MIS_ckeditor_instances.has(ta)) {
        try {
          const ed = window.MIS_ckeditor_instances.get(ta);
          ta.value = ed.getData();
        } catch(err) {}
      }
    });
  }
});

// --------------------------------------------------------------------------
// amCharts 5 Root Safe Management (Prevents "Root already exists" & Memory Leaks)
// --------------------------------------------------------------------------
function MIS_patchAm5() {
  if (typeof am5 !== 'undefined' && am5.Root && !am5.Root._patchedByMIS) {
    const originalNew = am5.Root.new;
    am5.Root.new = function(id, opts) {
      try {
        if (typeof id === 'string') {
          const el = document.getElementById(id);
          if (el && am5.registry && Array.isArray(am5.registry.rootElements)) {
            for (let i = am5.registry.rootElements.length - 1; i >= 0; i--) {
              const existingRoot = am5.registry.rootElements[i];
              if (existingRoot && (existingRoot.dom === el || existingRoot.dom?.id === id)) {
                try { existingRoot.dispose(); } catch(e){}
              }
            }
          }
        }
      } catch (e) {
        console.debug('am5 root cleanup note:', e);
      }
      return originalNew.call(am5.Root, id, opts);
    };
    am5.Root._patchedByMIS = true;
  }
}
if (typeof am5 !== 'undefined') {
  MIS_patchAm5();
} else {
  window.addEventListener('DOMContentLoaded', MIS_patchAm5);
}

// --------------------------------------------------------------------------
// Central Axios Client with Request Cancellation & Error Interception
// --------------------------------------------------------------------------
var _inFlightControllers = window._inFlightControllers = window._inFlightControllers || new Map();

function MIS_getCsrfToken() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (meta && meta.content) return meta.content;
  const tokenInput = document.querySelector('input[name="_token"]');
  if (tokenInput && tokenInput.value) return tokenInput.value;
  const match = document.cookie.match(new RegExp('(^|;\\s*)XSRF-TOKEN=([^;]*)'));
  return match ? decodeURIComponent(match[2]) : '';
}

function MIS_initApi() {
  if (typeof axios !== 'undefined') {
    const csrf = MIS_getCsrfToken();

    // 1. Configure global axios defaults for all direct axios.* calls
    axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    axios.defaults.headers.common['Accept'] = 'application/json';
    if (csrf) {
      axios.defaults.headers.common['X-CSRF-TOKEN'] = csrf;
    }
    axios.defaults.withCredentials = true;
    axios.defaults.timeout = 30000;

    // Attach request interceptor on global axios to keep CSRF token fresh
    if (!axios._misIntercepted) {
      axios.interceptors.request.use(config => {
        const token = MIS_getCsrfToken();
        if (token) {
          config.headers['X-CSRF-TOKEN'] = token;
        }
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        return config;
      }, error => Promise.reject(error));

      axios.interceptors.response.use(
        response => response,
        error => {
          if (axios.isCancel(error) || error.name === 'CanceledError') {
            return Promise.reject(error);
          }
          const status = error.response?.status;
          const msg = error.response?.data?.message || error.response?.data?.error || error.message;

          if (status === 401) {
            console.warn('[MIS Auth] Session expired or unauthenticated.');
          } else if (status === 403) {
            if (typeof toast === 'function') toast('Action forbidden: ' + (msg || 'Permission denied'), true);
          } else if (status === 419) {
            if (typeof toast === 'function') toast('Page session expired. Please refresh the page.', true);
          }
          return Promise.reject(error);
        }
      );
      axios._misIntercepted = true;
    }

    const defaultHeaders = {
      'X-Requested-With': 'XMLHttpRequest',
      'Accept': 'application/json'
    };
    if (csrf) defaultHeaders['X-CSRF-TOKEN'] = csrf;

    const apiInstance = axios.create({
      headers: defaultHeaders,
      timeout: 30000,
      withCredentials: true
    });

    apiInstance.interceptors.request.use(config => {
      const token = MIS_getCsrfToken();
      if (token) {
        config.headers['X-CSRF-TOKEN'] = token;
      }
      return config;
    }, error => Promise.reject(error));

    // Response interceptor: graceful handling of common HTTP status codes
    apiInstance.interceptors.response.use(
      response => response,
      error => {
        if (axios.isCancel(error) || error.name === 'CanceledError') {
          return Promise.reject(error);
        }
        const status = error.response?.status;
        const msg = error.response?.data?.message || error.response?.data?.error || error.message;

        if (status === 401) {
          console.warn('[MIS Auth] Session expired or unauthenticated.');
        } else if (status === 403) {
          if (typeof toast === 'function') toast('Action forbidden: ' + (msg || 'Permission denied'), true);
        } else if (status === 419) {
          if (typeof toast === 'function') toast('Page session expired. Please refresh the page.', true);
        } else if (status === 422) {
          const errors = error.response?.data?.errors;
          const firstErr = errors ? Object.values(errors)[0]?.[0] : msg;
          if (typeof toast === 'function') toast(firstErr || 'Validation failed. Please review the inputs.', true);
        } else if (status >= 500) {
          if (typeof toast === 'function') toast('Server error: ' + (msg || 'Please try again later.'), true);
        } else if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
          if (typeof toast === 'function') toast('Request timed out. Please check your connection.', true);
        }
        return Promise.reject(error);
      }
    );

    // Cancelable request helper
    apiInstance.cancelable = function(key, requestFn) {
      if (_inFlightControllers.has(key)) {
        try {
          _inFlightControllers.get(key).abort();
        } catch(e) {}
      }
      const controller = new AbortController();
      _inFlightControllers.set(key, controller);
      return requestFn(controller.signal).finally(() => {
        if (_inFlightControllers.get(key) === controller) {
          _inFlightControllers.delete(key);
        }
      });
    };

    window.api = apiInstance;
    window.MIS_api = apiInstance;
  }
}
MIS_initApi();
window.addEventListener('DOMContentLoaded', MIS_initApi);

document.addEventListener('DOMContentLoaded',()=>{
  MIS_ensureOperationsModules();
  MIS_ensureDepartmentNav();
  MIS_initResponsiveNav();
  MIS_initTouchGestures();
  MIS_initCKEditors();
  MIS_initLightbox();
  MIS_patchAm5();
  if(window.lucide)lucide.createIcons();
  const page=document.body.dataset.page;
  document.querySelectorAll('[data-nav]').forEach(a=>{if(a.dataset.nav===page)a.classList.add('active');});
  document.querySelectorAll('[data-date]').forEach(el=>{if(!el.value)el.value=new Date().toISOString().slice(0,10)});
  document.querySelectorAll('[data-submit]').forEach(btn=>{btn.addEventListener('click',()=>{const box=document.querySelector(btn.dataset.submit);if(box){box.classList.remove('d-none');setTimeout(()=>box.classList.add('d-none'),2500)}})});
  
  // Debounced input filtering for tables
  document.querySelectorAll('[data-filter]').forEach(input=>{
    input.addEventListener('input', MIS_debounce(()=>{
      const q=input.value.toLowerCase(),table=document.querySelector(input.dataset.filter);
      if(!table)return;
      table.querySelectorAll('tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none');
    }, 250));
  });

  MIS_applyRoleUI();
});
function toast(msg, isError = false) {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.className = 'toast position-fixed bottom-0 end-0 m-3 text-white border-0';
    el.style.zIndex = '9999';
    el.innerHTML = '<div class="d-flex"><div class="toast-body">Saved</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>';
    document.body.appendChild(el);
  }
  const body = el.querySelector('.toast-body') || el;
  body.textContent = msg;
  el.className = `toast position-fixed bottom-0 end-0 m-3 text-white border-0 ${isError ? 'bg-danger' : 'bg-success'}`;
  el.style.zIndex = '9999';
  if (window.bootstrap && bootstrap.Toast) {
    bootstrap.Toast.getOrCreateInstance(el).show();
  } else {
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 3000);
  }
}
window.toast = toast;
window.showToast = toast;

// SweetAlert2 safe fallback if not loaded on the active page
if (typeof window.Swal === 'undefined') {
  window.Swal = {
    fire: function(opts, text, icon) {
      let title = opts;
      let msg = text || '';
      let isError = icon === 'error';
      if (typeof opts === 'object' && opts !== null) {
        title = opts.title || '';
        msg = opts.text || opts.html || '';
        isError = opts.icon === 'error';
      }
      toast((title ? title + ': ' : '') + msg, isError);
      return Promise.resolve({ isConfirmed: true, value: true });
    },
    showLoading: function() {},
    close: function() {}
  };
}

// CKEditor 5 Lifecycle Management & Registry
window.MIS_ckeditor_instances = window.MIS_ckeditor_instances || new Map();

function MIS_initCKEditors() {
  if (typeof ClassicEditor !== 'undefined') {
    document.querySelectorAll('textarea.editor, textarea[data-editor="classic"]').forEach(el => {
      if (window.MIS_ckeditor_instances.has(el)) return;
      if (!el.dataset.ckeditorInit) {
        el.dataset.ckeditorInit = 'true';
        ClassicEditor.create(el).then(editor => {
          window.MIS_ckeditor_instances.set(el, editor);
        }).catch(err => {
          console.debug('CKEditor init note:', err);
          delete el.dataset.ckeditorInit;
        });
      }
    });
  }
}

function MIS_destroyCKEditors() {
  if (window.MIS_ckeditor_instances) {
    window.MIS_ckeditor_instances.forEach((editor, el) => {
      try {
        editor.destroy();
      } catch(e) {}
      if (el) delete el.dataset.ckeditorInit;
    });
    window.MIS_ckeditor_instances.clear();
  }
}

window.MIS_initCKEditors = MIS_initCKEditors;
window.MIS_destroyCKEditors = MIS_destroyCKEditors;

// Lightbox2 Safe Initialization Guard (Single Instance)
function MIS_initLightbox() {
  if (window._lightboxInitialized) return;
  if (typeof jQuery !== 'undefined' && typeof lightbox !== 'undefined') {
    try {
      lightbox.option({
        'resizeDuration': 200,
        'wrapAround': true,
        'albumLabel': "Image %1 of %2"
      });
      window._lightboxInitialized = true;
    } catch (e) {}
  }
}
window.MIS_initLightbox = MIS_initLightbox;

// Axios safe fallback if not loaded on the active page
if (typeof window.axios === 'undefined') {
  window.axios = {
    get: async function(url, config) {
      const res = await fetch(url, { method: 'GET', headers: config?.headers });
      const data = await res.json();
      return { data, status: res.status, ok: res.ok };
    },
    post: async function(url, data, config) {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(config?.headers || {}) },
        body: JSON.stringify(data)
      });
      const resData = await res.json();
      return { data: resData, status: res.status, ok: res.ok };
    },
    put: async function(url, data, config) {
      const res = await fetch(url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...(config?.headers || {}) },
        body: JSON.stringify(data)
      });
      const resData = await res.json();
      return { data: resData, status: res.status, ok: res.ok };
    },
    delete: async function(url, config) {
      const res = await fetch(url, { method: 'DELETE', headers: config?.headers });
      const resData = await res.json();
      return { data: resData, status: res.status, ok: res.ok };
    }
  };
}

function MIS_initTouchGestures() {
  if (typeof Hammer !== 'undefined') {
    const mainEl = document.querySelector('main') || document.body;
    const mobileNav = document.getElementById('mobileNav');
    if (mainEl && mobileNav && window.bootstrap && bootstrap.Offcanvas) {
      try {
        const mc = new Hammer(mainEl);
        mc.on('swiperight', (e) => {
          if (e.center.x < 80 || e.deltaX > 80) {
            bootstrap.Offcanvas.getOrCreateInstance(mobileNav).show();
          }
        });
        const mcNav = new Hammer(mobileNav);
        mcNav.on('swipeleft', () => {
          bootstrap.Offcanvas.getOrCreateInstance(mobileNav).hide();
        });
      } catch (e) {
        console.debug('Hammer init:', e);
      }
    }
  }
}


document.addEventListener('shown.bs.modal', () => {
  if (window.lucide) lucide.createIcons();
});
document.addEventListener('shown.bs.tab', () => {
  if (window.lucide) lucide.createIcons();
});

function printPage(){window.print();}


function MIS_initResponsiveNav(){
  if(!document.body || !document.querySelector('main')) return;
  const sidebar=document.querySelector('aside.sidebar');
  const topbar=document.querySelector('header.topbar');
  if(!sidebar||!topbar||document.getElementById('mobileNav')) return;
  const off=document.createElement('div'); off.className='offcanvas offcanvas-start'; off.id='mobileNav'; off.tabIndex=-1; off.setAttribute('aria-labelledby','mobileNavLabel');
  const head=document.createElement('div'); head.className='offcanvas-header';
  head.innerHTML='<h5 class="offcanvas-title" id="mobileNavLabel">MIS Management</h5><button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>';
  const body=document.createElement('div'); body.className='offcanvas-body';
  const clone=sidebar.cloneNode(true); clone.classList.remove('d-none','d-lg-block','position-fixed','top-0','bottom-0','start-0'); clone.style.cssText='';
  body.appendChild(clone); off.appendChild(head); off.appendChild(body); document.body.appendChild(off);
  const first=topbar.querySelector(':scope > div');
  if(first && !first.querySelector('[data-bs-target="#mobileNav"]')){
    const btn=document.createElement('button'); btn.type='button'; btn.className='btn btn-light d-lg-none'; btn.setAttribute('data-bs-toggle','offcanvas'); btn.setAttribute('data-bs-target','#mobileNav'); btn.setAttribute('aria-controls','mobileNav'); btn.setAttribute('aria-label','Open navigation'); btn.innerHTML='<i data-lucide="menu"></i>';
    first.classList.add('d-flex','align-items-center','gap-3'); first.insertBefore(btn,first.firstChild);
  }
  if(window.lucide) lucide.createIcons();
}


/* === Cross-module shared data layer: Location/Branch + Staff + Department + Domain/Zone === */
if (typeof window.MIS_SHARED_KEYS === 'undefined') {
  window.MIS_SHARED_KEYS = {
    branches: 'mis_location_branches_v1',
    staff: 'mis_staff_position_v1',
    departments: 'mis_departments_v1',
    domains: 'mis_domains_v1',
    zones: 'mis_zones_v1',
    locations: 'mis_locations_v1',
    master: 'mis_master_data_v1'
  };
}
var MIS_SHARED_KEYS = window.MIS_SHARED_KEYS;
function MIS_read(key,fallback=[]){try{const v=JSON.parse(localStorage.getItem(key)||'null');return (v !== null)?v:fallback}catch(e){return fallback}}
function MIS_write(key,v){localStorage.setItem(key,JSON.stringify(v));try{window.dispatchEvent(new StorageEvent('storage',{key,newValue:JSON.stringify(v)}));}catch(e){}}
function MIS_getBranches(){return MIS_read(MIS_SHARED_KEYS.branches,[])}
function MIS_getStaff(){return MIS_read(MIS_SHARED_KEYS.staff,[])}
function MIS_getDepartments(){return MIS_read(MIS_SHARED_KEYS.departments,[])}
function MIS_getZones(){return MIS_read(MIS_SHARED_KEYS.zones,[])}
function MIS_getDomains(){return MIS_read(MIS_SHARED_KEYS.domains,[])}

function MIS_populateBranchSelects(branches) {
  if (!Array.isArray(branches) || branches.length === 0) return;
  const branchNames = [...new Set(branches.map(b => b.branch || b.name).filter(Boolean))].sort((a, b) => a.localeCompare(b));

  const candidateSelects = [
    document.getElementById('misFormBranch'),
    ...document.querySelectorAll('select[name="branch"]'),
    ...document.querySelectorAll('select[data-source="branches"]')
  ].filter(Boolean);

  document.querySelectorAll('select').forEach(sel => {
    if (candidateSelects.includes(sel)) return;
    if (sel.id && sel.id.startsWith('m') && document.getElementById('locationModal')) return; // skip internal modal selects
    if (sel.id && sel.id.startsWith('f') && document.getElementById('locationTable')) return; // skip filter selects
    const label = sel.closest('.col-md-6, .col-md-4, .col-md-3, .col-12, div')?.querySelector('label');
    const labelText = (label?.textContent || '').toLowerCase();
    const hasBranchOption = Array.from(sel.options).some(o => (o.text || '').toLowerCase().includes('branch'));
    if (labelText.includes('branch') || hasBranchOption) {
      candidateSelects.push(sel);
    }
  });

  candidateSelects.forEach(sel => {
    const curVal = sel.value;
    const firstOpt = sel.options[0];
    const defaultText = firstOpt ? firstOpt.text : 'Select Branch';
    const defaultValue = firstOpt ? firstOpt.value : '';

    const existingOptions = Array.from(sel.options).map(o => o.value);
    const missing = branchNames.some(name => !existingOptions.includes(name));
    if (missing || existingOptions.length <= 2) {
      sel.innerHTML = `<option value="${defaultValue}">${defaultText}</option>` +
        branchNames.map(name => `<option value="${name}">${name}</option>`).join('');
      if (curVal && branchNames.includes(curVal)) {
        sel.value = curVal;
      }
    }
  });
}

async function MIS_syncBranches() {
  try {
    let branches = [];
    if (typeof axios !== 'undefined') {
      const res = await axios.get('/api/location-branch/branches?per_page=500');
      branches = res.data && res.data.data ? res.data.data : [];
    } else if (typeof fetch === 'function') {
      const res = await fetch('/api/location-branch/branches?per_page=500');
      const json = await res.json();
      branches = json.data || [];
    }
    if (Array.isArray(branches) && branches.length > 0) {
      MIS_write(MIS_SHARED_KEYS.branches, branches);
      localStorage.setItem('mis_branches', JSON.stringify(branches));
      MIS_populateBranchSelects(branches);
    } else {
      MIS_populateBranchSelects(MIS_getBranches());
    }
  } catch (e) {
    MIS_populateBranchSelects(MIS_getBranches());
  }
}

function MIS_populateDepartmentSelects(departments) {
  if (!Array.isArray(departments) || departments.length === 0) return;
  const deptNames = [...new Set(departments.filter(d => !d.status || d.status === 'Active').map(d => d.name).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  if (deptNames.length === 0) return;

  const candidateSelects = [
    document.getElementById('posDept'),
    document.getElementById('userDept'),
    document.getElementById('staffDepartment'),
    document.getElementById('filterDepartment'),
    document.getElementById('fDept'),
    ...document.querySelectorAll('select[name="department"]'),
    ...document.querySelectorAll('select[name="dept"]'),
    ...document.querySelectorAll('select[data-source="departments"]')
  ].filter(Boolean);

  document.querySelectorAll('select').forEach(sel => {
    if (candidateSelects.includes(sel)) return;
    if (sel.id === 'depStat' || sel.id === 'depStatus') return; // skip internal department page status selects
    const label = sel.closest('.col-md-6, .col-md-4, .col-md-3, .col-12, div')?.querySelector('label');
    const labelText = (label?.textContent || '').toLowerCase();
    const hasDeptOption = Array.from(sel.options).some(o => (o.text || '').toLowerCase().includes('department') || (o.text || '').includes('বিভাগ'));
    if (labelText.includes('department') || labelText.includes('দপ্তর') || hasDeptOption) {
      candidateSelects.push(sel);
    }
  });

  candidateSelects.forEach(sel => {
    const curVal = sel.value;
    const firstOpt = sel.options[0];
    const defaultText = firstOpt ? firstOpt.text : 'Select Department';
    const defaultValue = firstOpt ? firstOpt.value : '';

    const existingOptions = Array.from(sel.options).map(o => o.value);
    const missing = deptNames.some(name => !existingOptions.includes(name));
    if (missing || existingOptions.length <= 2) {
      sel.innerHTML = `<option value="${defaultValue}">${defaultText}</option>` +
        deptNames.map(name => `<option value="${name}">${name}</option>`).join('');
      if (curVal && deptNames.includes(curVal)) {
        sel.value = curVal;
      }
    }
  });
}

async function MIS_syncDepartments() {
  try {
    let depts = [];
    if (typeof axios !== 'undefined') {
      const res = await axios.get('/api/department-management?per_page=500');
      depts = res.data && res.data.data ? res.data.data : [];
    } else if (typeof fetch === 'function') {
      const res = await fetch('/api/department-management?per_page=500');
      const json = await res.json();
      depts = json.data || [];
    }
    if (Array.isArray(depts) && depts.length > 0) {
      MIS_write(MIS_SHARED_KEYS.departments, depts);
      localStorage.setItem('mis_departments', JSON.stringify(depts));
      MIS_populateDepartmentSelects(depts);
    } else {
      MIS_populateDepartmentSelects(MIS_getDepartments());
    }
  } catch (e) {
    MIS_populateDepartmentSelects(MIS_getDepartments());
  }
}

function MIS_populateStaffSelects(staffList) {
  if (!Array.isArray(staffList) || staffList.length === 0) return;
  const candidateSelects = [
    document.getElementById('movementStaff'),
    document.getElementById('staffSelect'),
    document.getElementById('empSelect'),
    document.getElementById('txStaff'),
    document.getElementById('leaveStaff'),
    document.getElementById('advanceStaff'),
    ...document.querySelectorAll('select[name="staff_id"]'),
    ...document.querySelectorAll('select[name="employee_id"]'),
    ...document.querySelectorAll('select[data-source="staff"]')
  ].filter(Boolean);

  candidateSelects.forEach(sel => {
    const curVal = sel.value;
    const firstOpt = sel.options[0];
    const defaultText = firstOpt ? firstOpt.text : 'Select Staff Member';
    const defaultValue = firstOpt ? firstOpt.value : '';

    sel.innerHTML = `<option value="${defaultValue}">${defaultText}</option>` +
      staffList.map(s => `<option value="${s.staff_id || s.id}" data-name="${s.name}" data-dept="${s.department || ''}" data-desig="${s.designation || ''}">${s.name} (${s.staff_id || s.id}) - ${s.designation || 'Staff'}</option>`).join('');

    if (curVal) {
      sel.value = curVal;
    }
  });

  // Also populate staffDataList datalist if present
  let dl = document.getElementById('staffDataList');
  if (!dl) {
    dl = document.createElement('datalist');
    dl.id = 'staffDataList';
    document.body.appendChild(dl);
  }
  dl.innerHTML = staffList.map(s => `<option value="${s.staff_id}">${s.name} (${s.designation || ''} - ${s.department || ''})</option>`).join('');
}

function MIS_populateDomainZoneSelects(zones, domains) {
  if (Array.isArray(zones) && zones.length > 0) {
    const zoneSelects = [
      document.getElementById('fZone'),
      document.getElementById('filterZone'),
      document.getElementById('movementZone'),
      ...document.querySelectorAll('select[name="zone"]'),
      ...document.querySelectorAll('select[data-source="zones"]')
    ].filter(Boolean);

    const zoneNames = [...new Set(zones.map(z => typeof z === 'string' ? z : z.zone).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    zoneSelects.forEach(sel => {
      const curVal = sel.value;
      const firstOpt = sel.options[0];
      const defaultText = firstOpt ? firstOpt.text : 'Select Zone';
      const defaultValue = firstOpt ? firstOpt.value : '';
      sel.innerHTML = `<option value="${defaultValue}">${defaultText}</option>` +
        zoneNames.map(z => `<option value="${z}">${z}</option>`).join('');
      if (curVal && zoneNames.includes(curVal)) sel.value = curVal;
    });
  }

  if (Array.isArray(domains) && domains.length > 0) {
    const domainSelects = [
      document.getElementById('fDomain'),
      document.getElementById('filterDomain'),
      document.getElementById('movementDomain'),
      ...document.querySelectorAll('select[name="domain"]'),
      ...document.querySelectorAll('select[data-source="domains"]')
    ].filter(Boolean);

    const domainNames = [...new Set(domains.filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    domainSelects.forEach(sel => {
      const curVal = sel.value;
      const firstOpt = sel.options[0];
      const defaultText = firstOpt ? firstOpt.text : 'Select Domain';
      const defaultValue = firstOpt ? firstOpt.value : '';
      sel.innerHTML = `<option value="${defaultValue}">${defaultText}</option>` +
        domainNames.map(d => `<option value="${d}">${d}</option>`).join('');
      if (curVal && domainNames.includes(curVal)) sel.value = curVal;
    });
  }
}

async function MIS_syncMasterData() {
  try {
    let resData = null;
    if (typeof axios !== 'undefined') {
      const res = await axios.get('/api/master-data');
      resData = res.data?.data;
    } else if (typeof fetch === 'function') {
      const res = await fetch('/api/master-data');
      const json = await res.json();
      resData = json.data;
    }

    if (resData) {
      if (resData.branches) {
        MIS_write(MIS_SHARED_KEYS.branches, resData.branches);
        MIS_populateBranchSelects(resData.branches);
      }
      if (resData.departments) {
        MIS_write(MIS_SHARED_KEYS.departments, resData.departments);
        MIS_populateDepartmentSelects(resData.departments);
      }
      if (resData.staff) {
        MIS_write(MIS_SHARED_KEYS.staff, resData.staff);
        MIS_populateStaffSelects(resData.staff);
      }
      if (resData.zones || resData.domain_zones) {
        const z = resData.zones || resData.domain_zones;
        MIS_write(MIS_SHARED_KEYS.zones, z);
        MIS_populateDomainZoneSelects(z, resData.domains);
      }
      localStorage.setItem(MIS_SHARED_KEYS.master, JSON.stringify(resData));
      window.dispatchEvent(new CustomEvent('mis:master-data:updated', { detail: resData }));
    }
  } catch (e) {
    console.warn('Master data sync fallback to cache:', e);
    MIS_populateBranchSelects(MIS_getBranches());
    MIS_populateDepartmentSelects(MIS_getDepartments());
    MIS_populateStaffSelects(MIS_getStaff());
    MIS_populateDomainZoneSelects(MIS_getZones(), MIS_getDomains());
  }
}

window.addEventListener('mis:branches:updated', (e) => {
  if (e.detail && Array.isArray(e.detail)) {
    MIS_populateBranchSelects(e.detail);
  } else {
    MIS_syncMasterData();
  }
});
window.addEventListener('storage', (e) => {
  if (e.key === MIS_SHARED_KEYS.branches) {
    MIS_populateBranchSelects(MIS_getBranches());
  }
  if (e.key === MIS_SHARED_KEYS.departments) {
    MIS_populateDepartmentSelects(MIS_getDepartments());
  }
  if (e.key === MIS_SHARED_KEYS.staff) {
    MIS_populateStaffSelects(MIS_getStaff());
  }
});

window.addEventListener('mis:departments:updated', (e) => {
  if (e.detail && Array.isArray(e.detail)) {
    MIS_populateDepartmentSelects(e.detail);
  } else {
    MIS_syncMasterData();
  }
});

document.addEventListener('DOMContentLoaded', () => {
  MIS_syncBranches();
  MIS_syncDepartments();
  MIS_syncMasterData();
  MIS_initAiAssistant();
});

// ==========================================
// MIS SMART AI ASSISTANT & FILE FINDER
// ==========================================
var _aiChatHistory = window._aiChatHistory = window._aiChatHistory || [];
var _aiIsThinking = window._aiIsThinking = window._aiIsThinking || false;
var _aiSearchTimeout = window._aiSearchTimeout = window._aiSearchTimeout || null;

function MIS_initAiAssistant() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  // Don't show floating assistant on login page
  if (window.location.pathname === '/login' || window.location.pathname === '/') {
    const isLogin = document.getElementById('loginForm') || document.querySelector('form[action*="login"]');
    if (isLogin) return;
  }

  if (document.getElementById('misAiAssistantWidget')) {
    if (typeof lucide !== 'undefined') lucide.createIcons();
    return;
  }

  const widget = document.createElement('div');
  widget.id = 'misAiAssistantWidget';
  widget.className = 'no-print';
  widget.innerHTML = `
    <!-- Floating Launcher Button -->
    <button id="misAiToggleBtn" 
            type="button"
            class="btn position-fixed shadow-lg d-flex align-items-center gap-2 px-3 py-2 rounded-pill text-white"
            style="bottom: 24px; right: 24px; z-index: 1080; background: linear-gradient(135deg, #1e40af 0%, #4338ca 50%, #6d28d9 100%); border: 1px solid rgba(255,255,255,0.25);"
            title="MIS AI Assistant (Ctrl+K)"
            onclick="toggleMisAiDrawer()">
      <span class="position-relative d-inline-flex">
        <i data-lucide="sparkles" style="width: 20px; height: 20px;"></i>
        <span class="position-absolute top-0 start-100 translate-middle p-1 bg-emerald-400 border border-white rounded-circle"></span>
      </span>
      <span class="fw-semibold d-none d-sm-inline" style="font-size: 13.5px; letter-spacing: 0.2px;">AI Assistant</span>
      <span class="badge bg-white/20 text-white rounded-pill px-1.5 py-0.5 ms-1 small" style="font-size: 11px;">Ctrl+K</span>
    </button>

    <!-- AI Assistant Panel / Drawer -->
    <div id="misAiDrawer" 
         class="position-fixed shadow-2xl bg-white d-none flex-column border"
         style="bottom: 0; right: 0; width: 440px; max-width: 100vw; height: 600px; max-height: 92vh; z-index: 1090; border-top-left-radius: 16px; overflow: hidden; transition: all 0.2s ease;">
      
      <!-- Drawer Header -->
      <div class="px-3 py-2.5 text-white d-flex align-items-center justify-content-between"
           style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);">
        <div class="d-flex align-items-center gap-2">
          <div class="p-1.5 rounded-lg bg-indigo-500/30 border border-indigo-400/40 text-indigo-300">
            <i data-lucide="bot" style="width: 20px; height: 20px;"></i>
          </div>
          <div>
            <div class="fw-bold d-flex align-items-center gap-2" style="font-size: 14.5px;">
              <span>MIS AI Assistant</span>
              <span class="badge bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 rounded-pill" style="font-size: 10px;">
                ● Online
              </span>
            </div>
            <div class="text-slate-400" style="font-size: 11px;">Gemini 3.8 Flash &bull; ১৬৩+ ফাইল ইনডেক্সড</div>
          </div>
        </div>
        <div class="d-flex align-items-center gap-1">
          <button type="button" class="btn btn-sm btn-link text-slate-400 hover:text-white p-1" onclick="clearAiChat()" title="Reset Conversation">
            <i data-lucide="rotate-ccw" style="width: 16px; height: 16px;"></i>
          </button>
          <button type="button" class="btn btn-sm btn-link text-slate-400 hover:text-white p-1" onclick="toggleMisAiDrawer()" title="Close">
            <i data-lucide="x" style="width: 20px; height: 20px;"></i>
          </button>
        </div>
      </div>

      <!-- Navigation Tabs: Chat vs Quick Finder -->
      <div class="d-flex border-bottom bg-slate-50 px-2 pt-1" style="font-size: 13px;">
        <button id="aiTabChat" class="btn btn-sm py-1.5 px-3 border-bottom border-primary border-2 text-primary fw-semibold rounded-0" onclick="switchAiTab('chat')">
          <i data-lucide="message-square" style="width: 14px; height: 14px;" class="me-1 d-inline"></i> স্মার্ট চ্যাট
        </button>
        <button id="aiTabSearch" class="btn btn-sm py-1.5 px-3 text-secondary rounded-0" onclick="switchAiTab('search')">
          <i data-lucide="search" style="width: 14px; height: 14px;" class="me-1 d-inline"></i> কুইক ফাইল ফাইন্ডার
        </button>
      </div>

      <!-- TAB 1: Chat View -->
      <div id="aiChatSection" class="flex-grow-1 d-flex flex-column" style="min-height: 0;">
        <div id="aiChatMessages" class="flex-grow-1 p-3 overflow-y-auto" style="background: #f8fafc; font-size: 13.5px; line-height: 1.55;">
          <div class="d-flex gap-2 mb-3">
            <div class="flex-shrink-0">
              <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
                <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
              </div>
            </div>
            <div class="flex-grow-1">
              <div class="bg-white border rounded-3 p-3 shadow-xs text-slate-800">
                <div class="fw-semibold text-indigo-700 mb-1">স্বাগতম! আমি আপনার MIS স্মার্ট এআই সহকারী।</div>
                <p class="mb-2 text-slate-600">
                  এই প্রজেক্টের যেকোনো ফাইল (ব্লেড ভিউ, কন্ট্রোলার, সার্ভিস, ক্যালকুলেশন বা মাইগ্রেশন) কোথায় আছে এবং কীভাবে কাজ করে জানতে আমাকে যেকোনো প্রশ্ন করতে পারেন।
                </p>
                <div class="text-muted small mb-2 fw-semibold">কুইক প্রম্পট সাজেশন:</div>
                <div class="d-flex flex-wrap gap-1.5">
                  <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('ছুটি এবং লিভ ব্যালেন্স হিসাবের ফাইলগুলো কোথায়?')">
                    🌴 ছুটি ও লিভ হিসাব
                  </button>
                  <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('স্টক রেজিস্টার ও ইনভেন্টরি ভ্যালুয়েশনের ফাইল কোনটি?')">
                    📦 স্টক ও ভ্যালুয়েশন
                  </button>
                  <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('অগ্রিম লোন ও কিস্তির ফাইল কোথায় আছে?')">
                    💰 অগ্রিম লোন ও কিস্তি
                  </button>
                  <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('ডিপার্টমেন্ট ও ব্রাঞ্চের ব্লেড ভিউ ফাইলগুলো দেখাও')">
                    🏢 ডিপার্টমেন্ট ও ব্রাঞ্চ
                  </button>
                  <button type="button" class="btn btn-light btn-sm border text-start px-2 py-1" style="font-size: 11.5px;" onclick="quickAiPrompt('ইউজার পারমিশন এবং সিকিউরিটি মিডলওয়্যার ফাইল কোনটি?')">
                    🛡️ পারমিশন ও রোল
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Chat Input Form -->
        <div class="p-2 border-top bg-white">
          <form id="aiChatForm" onsubmit="handleAiChatSubmit(event)" class="d-flex gap-2 align-items-center">
            <input type="text" 
                   id="aiChatInput" 
                   class="form-control form-control-sm rounded-pill px-3 py-2" 
                   placeholder="ফাইল বা ফিচারের নাম লিখুন... (যেমন: leave service)" 
                   autocomplete="off"
                   required />
            <button type="submit" 
                    id="aiChatSubmitBtn"
                    class="btn btn-primary btn-sm rounded-circle d-flex align-items-center justify-content-center p-2" 
                    style="width: 36px; height: 36px; flex-shrink: 0;"
                    title="Send">
              <i data-lucide="send" style="width: 16px; height: 16px;"></i>
            </button>
          </form>
        </div>
      </div>

      <!-- TAB 2: Instant File Search View -->
      <div id="aiSearchSection" class="flex-grow-1 d-none flex-column" style="min-height: 0;">
        <div class="p-2 border-bottom bg-white">
          <div class="input-group input-group-sm">
            <span class="input-group-text bg-light border-end-0"><i data-lucide="search" style="width: 14px; height: 14px;"></i></span>
            <input type="text" 
                   id="aiQuickSearchInput" 
                   class="form-control border-start-0" 
                   placeholder="সার্চ করুন (blade, controller, service, migration)..." 
                   oninput="handleQuickFileSearch(this.value)" />
          </div>
        </div>
        <div id="aiSearchResults" class="flex-grow-1 p-2 overflow-y-auto" style="font-size: 12.5px;">
          <div class="text-center text-muted p-4">
            <i data-lucide="folder-search" style="width: 36px; height: 36px;" class="mx-auto mb-2 text-slate-300"></i>
            <div>যেকোনো ফাইলের নাম বা কিওয়ার্ড টাইপ করুন</div>
          </div>
        </div>
      </div>

    </div>
  `;

  document.body.appendChild(widget);
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function toggleMisAiDrawer() {
  const drawer = document.getElementById('misAiDrawer');
  if (!drawer) return;
  const isHidden = drawer.classList.contains('d-none');
  if (isHidden) {
    drawer.classList.remove('d-none');
    drawer.classList.add('d-flex');
    if (typeof lucide !== 'undefined') lucide.createIcons();
    setTimeout(() => {
      const activeInput = document.getElementById('aiChatSection').classList.contains('d-none')
        ? document.getElementById('aiQuickSearchInput')
        : document.getElementById('aiChatInput');
      activeInput?.focus();
    }, 100);
  } else {
    drawer.classList.add('d-none');
    drawer.classList.remove('d-flex');
  }
}

// Global hotkey: Ctrl+K or Cmd+K
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    toggleMisAiDrawer();
  }
});

function switchAiTab(tab) {
  const chatSec = document.getElementById('aiChatSection');
  const searchSec = document.getElementById('aiSearchSection');
  const chatTab = document.getElementById('aiTabChat');
  const searchTab = document.getElementById('aiTabSearch');

  if (tab === 'chat') {
    chatSec.classList.remove('d-none');
    chatSec.classList.add('d-flex');
    searchSec.classList.add('d-none');
    searchSec.classList.remove('d-flex');

    chatTab.classList.add('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    chatTab.classList.remove('text-secondary');
    searchTab.classList.remove('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    searchTab.classList.add('text-secondary');
    document.getElementById('aiChatInput')?.focus();
  } else {
    chatSec.classList.add('d-none');
    chatSec.classList.remove('d-flex');
    searchSec.classList.remove('d-none');
    searchSec.classList.add('d-flex');

    searchTab.classList.add('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    searchTab.classList.remove('text-secondary');
    chatTab.classList.remove('text-primary', 'border-bottom', 'border-primary', 'border-2', 'fw-semibold');
    chatTab.classList.add('text-secondary');

    const sInp = document.getElementById('aiQuickSearchInput');
    sInp?.focus();
    if (sInp && !sInp.value) {
      handleQuickFileSearch('');
    }
  }
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function quickAiPrompt(text) {
  const inp = document.getElementById('aiChatInput');
  if (inp) {
    inp.value = text;
    document.getElementById('aiChatForm')?.dispatchEvent(new Event('submit', { cancelable: true }));
  }
}

function clearAiChat() {
  _aiChatHistory = [];
  const container = document.getElementById('aiChatMessages');
  if (container) {
    container.innerHTML = `
      <div class="d-flex gap-2 mb-3">
        <div class="flex-shrink-0">
          <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
            <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
          </div>
        </div>
        <div class="flex-grow-1">
          <div class="bg-white border rounded-3 p-3 shadow-xs text-slate-800">
            <div class="fw-semibold text-indigo-700 mb-1">চ্যাট হিস্ট্রি রিসেট করা হয়েছে।</div>
            <p class="mb-0 text-slate-600">আপনি কোন ফাইল বা ফিচার খুঁজতে চান বলুন!</p>
          </div>
        </div>
      </div>
    `;
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }
}

async function handleAiChatSubmit(e) {
  e.preventDefault();
  if (_aiIsThinking) return;

  const inp = document.getElementById('aiChatInput');
  const msg = inp.value.trim();
  if (!msg) return;

  inp.value = '';
  appendUserMessage(msg);

  _aiIsThinking = true;
  const thinkId = appendThinkingIndicator();

  try {
    const res = await fetch('/api/ai/assistant', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, history: _aiChatHistory })
    });
    const data = await res.json();
    removeThinkingIndicator(thinkId);

    const reply = data.reply || 'কোনো উত্তর পাওয়া যায়নি।';
    _aiChatHistory.push({ role: 'user', content: msg });
    _aiChatHistory.push({ role: 'model', content: reply });

    appendAssistantMessage(reply, data.matchedFiles || []);
  } catch (err) {
    removeThinkingIndicator(thinkId);
    appendAssistantMessage('দুঃখিত, এআই সহকারীর সাথে সংযোগে সমস্যা হয়েছে: ' + err.message, []);
  } finally {
    _aiIsThinking = false;
  }
}

function appendUserMessage(text) {
  const container = document.getElementById('aiChatMessages');
  if (!container) return;
  const wrap = document.createElement('div');
  wrap.className = 'd-flex justify-content-end mb-3';
  wrap.innerHTML = `
    <div class="bg-indigo-600 text-white rounded-3 px-3 py-2 shadow-xs" style="max-width: 85%; font-size: 13.5px;">
      ${escapeAiHtml(text)}
    </div>
  `;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
}

function appendThinkingIndicator() {
  const container = document.getElementById('aiChatMessages');
  const id = 'aiThink_' + Date.now();
  const wrap = document.createElement('div');
  wrap.id = id;
  wrap.className = 'd-flex gap-2 mb-3';
  wrap.innerHTML = `
    <div class="flex-shrink-0">
      <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
        <i data-lucide="sparkles" style="width: 16px; height: 16px;"></i>
      </div>
    </div>
    <div class="flex-grow-1">
      <div class="bg-white border rounded-3 px-3 py-2.5 shadow-xs text-slate-500 d-inline-flex align-items-center gap-2">
        <span class="spinner-border spinner-border-sm text-indigo-600" role="status"></span>
        <span style="font-size: 12.5px;">ফাইল ও কোডবেজ অনুসন্ধান করা হচ্ছে...</span>
      </div>
    </div>
  `;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  if (typeof lucide !== 'undefined') lucide.createIcons();
  return id;
}

function removeThinkingIndicator(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

function appendAssistantMessage(markdownText, matchedFiles) {
  const container = document.getElementById('aiChatMessages');
  if (!container) return;
  const wrap = document.createElement('div');
  wrap.className = 'd-flex gap-2 mb-3';

  let formatted = formatAiMarkdown(markdownText);
  let filesHtml = '';
  if (matchedFiles && matchedFiles.length > 0) {
    filesHtml += `<div class="mt-2.5 pt-2 border-top">
      <div class="fw-semibold text-slate-700 small mb-1.5"><i data-lucide="files" style="width:13px; height:13px;" class="d-inline me-1 text-primary"></i>সংশ্লিষ্ট ফাইলসমূহ (${matchedFiles.length}টি):</div>
      <div class="d-flex flex-column gap-1.5">`;

    matchedFiles.slice(0, 5).forEach(f => {
      const isRoute = f.path.startsWith('resources/views/') && f.name === 'index.blade.php';
      const routeName = isRoute ? '/' + f.path.split('/')[2] : null;

      filesHtml += `
        <div class="p-2 rounded bg-slate-50 border d-flex align-items-center justify-content-between gap-2" style="font-size: 11.5px;">
          <div class="overflow-hidden">
            <div class="fw-semibold text-slate-800 text-truncate" title="${f.path}">
              <i data-lucide="file-code" style="width:12px;height:12px;" class="d-inline text-indigo-600 me-1"></i>${f.path}
            </div>
            <div class="text-muted text-truncate" style="font-size: 10.5px;">${f.description}</div>
          </div>
          <div class="d-flex align-items-center gap-1 flex-shrink-0">
            <button type="button" class="btn btn-xs btn-outline-secondary py-0.5 px-1.5" onclick="copyFilePath('${f.path}')" title="Copy file path">
              <i data-lucide="copy" style="width:11px;height:11px;"></i>
            </button>
            ${routeName ? `<a href="${routeName}" class="btn btn-xs btn-primary py-0.5 px-1.5 text-white text-decoration-none" title="Open Page">ওপেন</a>` : ''}
          </div>
        </div>
      `;
    });
    filesHtml += `</div></div>`;
  }

  wrap.innerHTML = `
    <div class="flex-shrink-0">
      <div class="w-8 h-8 rounded-circle bg-indigo-600 text-white d-flex align-items-center justify-content-center shadow-xs">
        <i data-lucide="bot" style="width: 16px; height: 16px;"></i>
      </div>
    </div>
    <div class="flex-grow-1" style="max-width: 88%;">
      <div class="bg-white border rounded-3 p-3 shadow-xs text-slate-800">
        ${formatted}
        ${filesHtml}
      </div>
    </div>
  `;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  if (typeof lucide !== 'undefined') lucide.createIcons();
}

function formatAiMarkdown(txt) {
  if (!txt) return '';
  let h = escapeAiHtml(txt);
  h = h.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/`([^`]+)`/g, '<code class="bg-slate-100 text-indigo-700 px-1 py-0.5 rounded" style="font-size:12px;">$1</code>');
  h = h.replace(/^\s*•\s+(.+)$/gm, '<li class="ms-3">$1</li>');
  h = h.replace(/^\s*\*\s+(.+)$/gm, '<li class="ms-3">$1</li>');
  h = h.replace(/\n\n/g, '<p class="mb-2"></p>').replace(/\n/g, '<br>');
  return h;
}

function escapeAiHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function copyFilePath(path) {
  navigator.clipboard.writeText(path).then(() => {
    if (typeof Swal !== 'undefined') {
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'success',
        title: 'পাথ কপি হয়েছে: ' + path,
        showConfirmButton: false,
        timer: 2000
      });
    } else {
      alert('Copied: ' + path);
    }
  });
}

function handleQuickFileSearch(val) {
  clearTimeout(_aiSearchTimeout);
  _aiSearchTimeout = setTimeout(async () => {
    const resBox = document.getElementById('aiSearchResults');
    if (!resBox) return;

    resBox.innerHTML = `
      <div class="p-3 text-center text-muted">
        <span class="spinner-border spinner-border-sm me-2"></span>ফাইলের তথ্য লোড হচ্ছে...
      </div>
    `;

    try {
      const res = await fetch('/api/ai/quick-search?q=' + encodeURIComponent(val));
      const data = await res.json();
      const files = data.results || [];

      if (files.length === 0) {
        resBox.innerHTML = `
          <div class="p-4 text-center text-muted">
            <i data-lucide="alert-circle" style="width:28px;height:28px;" class="mx-auto mb-1 text-slate-300"></i>
            <div>"${escapeAiHtml(val)}" দিয়ে কোনো ফাইল পাওয়া যায়নি।</div>
          </div>
        `;
      } else {
        let html = `<div class="text-muted small px-1 mb-2">মোট <strong>${files.length}টি</strong> ম্যাচিং ফাইল পাওয়া গেছে:</div><div class="d-flex flex-column gap-1.5">`;
        files.forEach(f => {
          const isRoute = f.path.startsWith('resources/views/') && f.name === 'index.blade.php';
          const routeName = isRoute ? '/' + f.path.split('/')[2] : null;

          html += `
            <div class="card border p-2 bg-white shadow-xs">
              <div class="d-flex align-items-start justify-content-between gap-2">
                <div>
                  <div class="fw-semibold text-slate-800" style="font-size:12.5px;">
                    <i data-lucide="file" style="width:13px;height:13px;" class="d-inline text-indigo-600 me-1"></i>${escapeAiHtml(f.name)}
                  </div>
                  <div class="text-primary font-monospace mt-0.5" style="font-size:11px;">${escapeAiHtml(f.path)}</div>
                  <div class="text-muted mt-1" style="font-size:11px;">${escapeAiHtml(f.description)}</div>
                </div>
                <div class="d-flex gap-1 flex-shrink-0">
                  <button type="button" class="btn btn-xs btn-outline-secondary py-1 px-1.5" onclick="copyFilePath('${f.path}')" title="Copy Path">
                    <i data-lucide="copy" style="width:12px;height:12px;"></i>
                  </button>
                  ${routeName ? `<a href="${routeName}" class="btn btn-xs btn-primary py-1 px-2 text-white text-decoration-none">ওপেন</a>` : ''}
                </div>
              </div>
            </div>
          `;
        });
        html += `</div>`;
        resBox.innerHTML = html;
      }
      if (typeof lucide !== 'undefined') lucide.createIcons();
    } catch (e) {
      resBox.innerHTML = `<div class="p-3 text-danger text-center">অনুসন্ধানে ব্যর্থ: ${e.message}</div>`;
    }
  }, 220);
}

