let MR_DATA = [];

function mrEsc(s) {
  return String(s ?? '').replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[m]));
}

async function mrRefresh() {
  const q = (document.getElementById('mrSearch')?.value || '').trim();
  const fd = document.getElementById('mrDomain')?.value || '';
  const fz = document.getElementById('mrZone')?.value || '';
  const ft = document.getElementById('mrType')?.value || '';
  const fs = document.getElementById('mrStatus')?.value || '';
  const from = document.getElementById('mrFrom')?.value || '';
  const to = document.getElementById('mrTo')?.value || '';

  const params = new URLSearchParams();
  if (q) params.append('search', q);
  if (fd && fd !== 'সব ডোমেইন') params.append('domain', fd);
  if (fz && fz !== 'সব জোন') params.append('zone', fz);
  if (ft) params.append('type', ft);
  if (fs) params.append('status', fs);
  if (from) params.append('from', from);
  if (to) params.append('to', to);

  try {
    const res = await fetch(`/api/movement-register?${params.toString()}`);
    const json = await res.json();
    if (!json.success && json.error) {
      console.error('Movement load error:', json.error);
      return;
    }

    const rows = json.data || [];
    MR_DATA = rows;

    // Populate Domain and Zone filter dropdowns
    const domains = [...new Set(rows.map(x => x.domain).filter(Boolean))].sort();
    const zones = [...new Set(rows.map(x => x.zone).filter(Boolean))].sort();
    mrFill('mrDomain', 'সব ডোমেইন', domains, fd);
    mrFill('mrZone', 'সব জোন', zones, fz);

    const tbody = document.getElementById('mrBody');
    if (tbody) {
      if (rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" class="text-center py-4 text-muted">No movement records found matching criteria.</td></tr>`;
      } else {
        tbody.innerHTML = rows.map((x, i) => {
          const empName = x.employee_name || x.employeeName || '';
          const empId = x.employee_id || x.employeeId || '';
          const outTime = x.out_time || x.outTime || '';
          const actualReturn = x.actual_return || x.actualReturn || '-';
          const badgeClass = x.status === 'Returned' ? 'text-bg-success' :
                             x.status === 'Out' ? 'text-bg-warning' :
                             x.status === 'Late Return' ? 'text-bg-danger' : 'text-bg-secondary';

          return `<tr>
            <td>${i + 1}</td>
            <td>${mrEsc(x.date)}</td>
            <td><b>${mrEsc(empName)}</b><br><small class="text-muted">${mrEsc(empId)}</small></td>
            <td>${mrEsc(x.designation)}</td>
            <td>${mrEsc(x.domain || '')}<br><small class="text-muted">${mrEsc(x.zone || '')}</small></td>
            <td>${mrEsc(x.type)}</td>
            <td>${mrEsc(outTime)}</td>
            <td>${mrEsc(actualReturn)}</td>
            <td>${mrEsc(x.destination)}</td>
            <td><span class="badge ${badgeClass}">${mrEsc(x.status)}</span></td>
            <td class="no-print action-cell">
              <div class="action-group">
                <button class="btn btn-sm btn-outline-info" onclick="mrView('${x.id}')" title="View"><i data-lucide="eye"></i></button>
                ${['Out', 'Pending', 'Late Return'].includes(x.status) ? `<button class="btn btn-sm btn-outline-success" onclick="mrReturn('${x.id}')" title="Mark Returned"><i data-lucide="check-circle"></i></button>` : ''}
                <button class="btn btn-sm btn-outline-primary" onclick="mrEdit('${x.id}')" title="Edit"><i data-lucide="pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger" onclick="mrDelete('${x.id}')" title="Delete"><i data-lucide="trash-2"></i></button>
              </div>
            </td>
          </tr>`;
        }).join('');
      }
    }

    // Update KPI cards
    const meta = json.meta || {};
    if (document.getElementById('mrTotal')) document.getElementById('mrTotal').textContent = meta.total ?? rows.length;
    if (document.getElementById('mrOut')) document.getElementById('mrOut').textContent = meta.out ?? rows.filter(x => x.status === 'Out').length;
    if (document.getElementById('mrReturned')) document.getElementById('mrReturned').textContent = meta.returned ?? rows.filter(x => x.status === 'Returned').length;
    if (document.getElementById('mrPending')) document.getElementById('mrPending').textContent = meta.pending ?? rows.filter(x => x.status === 'Pending').length;
    if (document.getElementById('mrLate')) document.getElementById('mrLate').textContent = meta.late_return ?? rows.filter(x => x.status === 'Late Return').length;

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Failed to load movement register:', err);
  }
}

function mrFill(id, first, vals, current) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = `<option value="">${first}</option>` + vals.map(v => `<option value="${mrEsc(v)}">${mrEsc(v)}</option>`).join('');
  el.value = vals.includes(current) ? current : '';
}

async function mrView(id) {
  try {
    const res = await fetch(`/api/movement-register/${encodeURIComponent(id)}`);
    const json = await res.json();
    const x = json.data || MR_DATA.find(a => a.id === id);
    if (!x) return;

    const fields = [
      ['ID', x.id],
      ['Date', x.date],
      ['Employee', `${x.employee_name || x.employeeName || ''} (${x.employee_id || x.employeeId || ''})`],
      ['Designation', x.designation],
      ['Department', x.department || '-'],
      ['Domain / Zone', `${x.domain || ''} / ${x.zone || ''}`],
      ['Location', x.location || '-'],
      ['Movement Type', x.type],
      ['Out Time', x.out_time || x.outTime],
      ['Expected Return', x.expected_return || x.expectedReturn || '-'],
      ['Actual Return', x.actual_return || x.actualReturn || '-'],
      ['Status', x.status],
      ['Purpose', x.purpose],
      ['Destination', x.destination],
      ['Contact No', x.contact || '-'],
      ['Vehicle', x.vehicle || '-'],
      ['Accompanied By', x.accompanied_by || x.accompaniedBy || '-'],
      ['Approved By', x.approved_by || x.approvedBy || '-'],
      ['Remarks', x.remarks || '-']
    ];

    Swal.fire({
      title: 'Movement Details',
      html: `<div class="text-start">${fields.map(([k, v]) => `
        <div class="d-flex border-bottom py-2 gap-3">
          <strong style="min-width:140px">${mrEsc(k)}</strong>
          <span>${mrEsc(v)}</span>
        </div>`).join('')}</div>`,
      width: 720,
      confirmButtonText: 'Close'
    });

    fetch('/api/movement-register/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'view', reference: `Viewed ${x.id}` })
    }).catch(() => {});
  } catch (err) {
    Swal.fire('Error', 'Failed to load details: ' + err.message, 'error');
  }
}

function mrOpen() {
  const form = document.getElementById('mrForm');
  if (form) form.reset();
  document.getElementById('mrId').value = '';
  document.getElementById('mr_date').value = new Date().toISOString().slice(0, 10);
  document.getElementById('mr_status').value = 'Out';
  document.getElementById('mrModalTitle').textContent = 'নতুন Movement Entry';
  bootstrap.Modal.getOrCreateInstance(document.getElementById('mrModal')).show();
}

async function mrEdit(id) {
  let x = MR_DATA.find(a => a.id === id);
  if (!x) {
    try {
      const res = await fetch(`/api/movement-register/${encodeURIComponent(id)}`);
      const json = await res.json();
      x = json.data;
    } catch (e) {}
  }
  if (!x) return;

  const mapping = {
    date: x.date,
    employeeId: x.employee_id || x.employeeId || '',
    employeeName: x.employee_name || x.employeeName || '',
    designation: x.designation || '',
    department: x.department || '',
    domain: x.domain || '',
    zone: x.zone || '',
    location: x.location || '',
    type: x.type || 'Official',
    outTime: x.out_time || x.outTime || '',
    expectedReturn: x.expected_return || x.expectedReturn || '',
    actualReturn: x.actual_return || x.actualReturn || '',
    status: x.status || 'Out',
    purpose: x.purpose || '',
    destination: x.destination || '',
    contact: x.contact || '',
    vehicle: x.vehicle || '',
    accompaniedBy: x.accompanied_by || x.accompaniedBy || '',
    approvedBy: x.approved_by || x.approvedBy || '',
    remarks: x.remarks || ''
  };

  Object.entries(mapping).forEach(([k, v]) => {
    const el = document.getElementById('mr_' + k);
    if (el) el.value = v;
  });

  document.getElementById('mrId').value = id;
  document.getElementById('mrModalTitle').textContent = 'Movement Entry Edit';
  bootstrap.Modal.getOrCreateInstance(document.getElementById('mrModal')).show();
}

let _mrSaving = false;
async function mrSave() {
  if (_mrSaving) return;
  const f = document.getElementById('mrForm');
  if (!f.checkValidity()) {
    f.reportValidity();
    return;
  }

  _mrSaving = true;
  const id = document.getElementById('mrId').value;
  const payload = {
    date: document.getElementById('mr_date').value,
    employee_id: document.getElementById('mr_employeeId').value.trim(),
    employee_name: document.getElementById('mr_employeeName').value.trim(),
    designation: document.getElementById('mr_designation').value.trim(),
    department: document.getElementById('mr_department').value.trim(),
    domain: document.getElementById('mr_domain').value.trim(),
    zone: document.getElementById('mr_zone').value.trim(),
    location: document.getElementById('mr_location').value.trim(),
    type: document.getElementById('mr_type').value,
    out_time: document.getElementById('mr_outTime').value,
    expected_return: document.getElementById('mr_expectedReturn').value,
    actual_return: document.getElementById('mr_actualReturn').value,
    status: document.getElementById('mr_status').value,
    purpose: document.getElementById('mr_purpose').value.trim(),
    destination: document.getElementById('mr_destination').value.trim(),
    contact: document.getElementById('mr_contact').value.trim(),
    vehicle: document.getElementById('mr_vehicle').value.trim(),
    accompanied_by: document.getElementById('mr_accompaniedBy').value.trim(),
    approved_by: document.getElementById('mr_approvedBy').value.trim(),
    remarks: document.getElementById('mr_remarks').value.trim()
  };

  try {
    const url = id ? `/api/movement-register/${encodeURIComponent(id)}` : '/api/movement-register';
    const method = id ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const json = await res.json();
    if (!res.ok || json.error) {
      const errMsg = json.message || (json.errors ? Object.values(json.errors).join(' ') : json.error);
      Swal.fire('Validation Error', errMsg, 'error');
      return;
    }

    bootstrap.Modal.getInstance(document.getElementById('mrModal'))?.hide();
    Swal.fire({ icon: 'success', title: id ? 'Updated' : 'Saved', timer: 1200, showConfirmButton: false });
    await mrRefresh();
  } catch (err) {
    Swal.fire('Error', 'Failed to save movement record: ' + err.message, 'error');
  } finally {
    _mrSaving = false;
  }
}

function mrDelete(id) {
  const x = MR_DATA.find(a => a.id === id);
  const name = x ? (x.employee_name || x.employeeName || id) : id;

  Swal.fire({
    icon: 'warning',
    title: 'Delete movement?',
    text: name,
    showCancelButton: true,
    confirmButtonText: 'Delete',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#dc2626'
  }).then(async r => {
    if (r.isConfirmed) {
      try {
        const res = await fetch(`/api/movement-register/${encodeURIComponent(id)}`, { method: 'DELETE' });
        const json = await res.json();
        if (!res.ok || json.error) {
          Swal.fire('Error', json.message || json.error, 'error');
          return;
        }
        Swal.fire({ icon: 'success', title: 'Deleted', timer: 1000, showConfirmButton: false });
        await mrRefresh();
      } catch (err) {
        Swal.fire('Error', err.message, 'error');
      }
    }
  });
}

function mrReturn(id) {
  const x = MR_DATA.find(a => a.id === id);
  const name = x ? (x.employee_name || x.employeeName || id) : id;

  Swal.fire({
    icon: 'question',
    title: 'Mark as Returned?',
    text: name,
    showCancelButton: true,
    confirmButtonText: 'Yes, Returned',
    cancelButtonText: 'Cancel'
  }).then(async r => {
    if (r.isConfirmed) {
      try {
        const nowTime = new Date().toTimeString().slice(0, 5);
        const res = await fetch(`/api/movement-register/${encodeURIComponent(id)}/return`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ actual_return: nowTime })
        });
        const json = await res.json();
        if (!res.ok || json.error) {
          Swal.fire('Error', json.message || json.error, 'error');
          return;
        }
        Swal.fire({ icon: 'success', title: `Returned (${json.status})`, timer: 1200, showConfirmButton: false });
        await mrRefresh();
      } catch (err) {
        Swal.fire('Error', err.message, 'error');
      }
    }
  });
}

async function mrCSV() {
  try {
    const res = await fetch('/api/movement-register');
    const json = await res.json();
    const rows = json.data || MR_DATA;

    const headers = [
      'ID', 'Date', 'Employee ID', 'Employee Name', 'Designation', 'Department',
      'Domain', 'Zone', 'Location', 'Type', 'Out Time', 'Expected Return',
      'Actual Return', 'Purpose', 'Destination', 'Contact', 'Vehicle',
      'Accompanied By', 'Approved By', 'Status', 'Remarks'
    ];

    const lines = [
      headers,
      ...rows.map(x => [
        x.id,
        x.date,
        x.employee_id || x.employeeId || '',
        x.employee_name || x.employeeName || '',
        x.designation || '',
        x.department || '',
        x.domain || '',
        x.zone || '',
        x.location || '',
        x.type || '',
        x.out_time || x.outTime || '',
        x.expected_return || x.expectedReturn || '',
        x.actual_return || x.actualReturn || '',
        x.purpose || '',
        x.destination || '',
        x.contact || '',
        x.vehicle || '',
        x.accompanied_by || x.accompaniedBy || '',
        x.approved_by || x.approvedBy || '',
        x.status || '',
        x.remarks || ''
      ])
    ].map(a => a.map(v => '"' + String(v ?? '').replace(/"/g, '""') + '"').join(',')).join('\n');

    const b = new Blob(['\ufeff' + lines], { type: 'text/csv;charset=utf-8' });
    const u = URL.createObjectURL(b);
    const a = document.createElement('a');
    a.href = u;
    a.download = `movement-register-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(u);

    fetch('/api/movement-register/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'export', reference: 'Exported Movement CSV' })
    }).catch(() => {});
  } catch (err) {
    Swal.fire('Export Error', err.message, 'error');
  }
}

function mrPrint() {
  fetch('/api/movement-register/action', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'print', reference: 'Printed Movement Register' })
  }).catch(() => {});
  window.print();
}

document.addEventListener('DOMContentLoaded', () => {
  if (typeof MIS_requireAuth === 'function') MIS_requireAuth();
  const debouncedRefresh = (typeof MIS_debounce === 'function') ? MIS_debounce(mrRefresh, 280) : mrRefresh;
  ['mrSearch', 'mrDomain', 'mrZone', 'mrType', 'mrStatus', 'mrFrom', 'mrTo'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener(id === 'mrSearch' ? 'input' : 'change', id === 'mrSearch' ? debouncedRefresh : mrRefresh);
    }
  });
  mrRefresh();
});
