let ST_ITEMS_CACHE = [];
let ST_TX_CACHE = [];
let stChartObj = null;

function stEsc(s) {
  return String(s ?? '').replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[m]));
}

async function stRefresh() {
  const q = (document.getElementById('stSearch')?.value || '').trim();
  const cat = document.getElementById('stCategory')?.value || '';
  const loc = document.getElementById('stLocation')?.value || '';
  const status = document.getElementById('stStatus')?.value || '';

  const params = new URLSearchParams();
  if (q) params.append('search', q);
  if (cat && cat !== 'সব ক্যাটাগরি') params.append('category', cat);
  if (loc && loc !== 'সব লোকেশন') params.append('location', loc);
  if (status) params.append('status', status);

  try {
    const res = await fetch(`/api/stock-register/items?${params.toString()}`);
    const json = await res.json();
    if (!json.success && json.error) {
      console.error('Stock items error:', json.error);
      return;
    }

    const rows = json.data || [];
    ST_ITEMS_CACHE = rows;
    const meta = json.meta || {};

    // Populate Category and Location filter options dynamically
    const cats = [...new Set(rows.map(x => x.category).filter(Boolean))].sort();
    const locs = [...new Set(rows.map(x => x.location).filter(Boolean))].sort();
    stFill('stCategory', 'সব ক্যাটাগরি', cats, cat);
    stFill('stLocation', 'সব লোকেশন', locs, loc);

    const tbody = document.getElementById('stBody');
    if (tbody) {
      if (rows.length === 0) {
        tbody.innerHTML = `<tr><td colspan="12" class="text-center py-4 text-muted">No stock items found.</td></tr>`;
      } else {
        tbody.innerHTML = rows.map((x, i) => {
          const badgeClass = x.balance <= 0 ? 'text-bg-danger' :
                             x.balance <= x.min ? 'text-bg-warning' : 'text-bg-success';
          const badgeText = x.balance <= 0 ? 'Out of Stock' :
                            x.balance <= x.min ? 'Low Stock' : 'Available';

          return `<tr>
            <td>${i + 1}</td>
            <td><b>${stEsc(x.code)}</b></td>
            <td>${stEsc(x.name)}</td>
            <td>${stEsc(x.category)}</td>
            <td>${stEsc(x.unit)}</td>
            <td>${x.opening}</td>
            <td>${x.received}</td>
            <td>${x.issued}</td>
            <td><b>${x.balance}</b></td>
            <td>${stEsc(x.location)}</td>
            <td><span class="badge ${badgeClass}">${badgeText}</span></td>
            <td class="no-print action-cell">
              <div class="action-group">
                <button class="btn btn-sm btn-outline-info" onclick="stViewItem('${x.id}')" title="View"><i data-lucide="eye"></i></button>
                <button class="btn btn-sm btn-outline-primary" onclick="stEditItem('${x.id}')" title="Edit"><i data-lucide="pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger" onclick="stDeleteItem('${x.id}')" title="Delete"><i data-lucide="trash-2"></i></button>
              </div>
            </td>
          </tr>`;
        }).join('');
      }
    }

    // Update KPI metrics
    if (document.getElementById('stItemsCount')) document.getElementById('stItemsCount').textContent = meta.total_items ?? rows.length;
    if (document.getElementById('stQty')) document.getElementById('stQty').textContent = meta.total_qty ?? rows.reduce((a, x) => a + Number(x.balance || 0), 0);
    if (document.getElementById('stLow')) document.getElementById('stLow').textContent = meta.low_stock ?? 0;
    if (document.getElementById('stOut')) document.getElementById('stOut').textContent = meta.out_of_stock ?? 0;
    if (document.getElementById('stReceive')) document.getElementById('stReceive').textContent = meta.total_received ?? 0;
    if (document.getElementById('stIssue')) document.getElementById('stIssue').textContent = meta.total_issued ?? 0;

    if (window.lucide) lucide.createIcons();

    await stRenderLedger();
    stChart();
  } catch (err) {
    console.error('Failed to load stock items:', err);
  }
}

function stFill(id, first, vals, current) {
  const e = document.getElementById(id);
  if (!e) return;
  e.innerHTML = `<option value="">${first}</option>` + vals.map(v => `<option value="${stEsc(v)}">${stEsc(v)}</option>`).join('');
  e.value = vals.includes(current) ? current : '';
}

async function stViewItem(id) {
  try {
    const res = await fetch(`/api/stock-register/items/${encodeURIComponent(id)}`);
    const json = await res.json();
    const x = json.data;
    if (!x) return;

    const fields = [
      ['Item Code', x.code],
      ['Item Name', x.name],
      ['Category', x.category],
      ['Unit', x.unit],
      ['Opening Stock', x.opening],
      ['Received', x.received],
      ['Issued', x.issued],
      ['Current Balance', x.balance],
      ['Minimum Level', x.min],
      ['Stock Status', x.warning || (x.balance <= 0 ? 'Out of Stock' : (x.balance <= x.min ? 'Low Stock' : 'Available'))],
      ['Location / Store', x.location],
      ['Supplier', x.supplier || '-'],
      ['Status', x.status || 'Active']
    ];

    Swal.fire({
      title: 'Stock Item Details',
      html: `<div class="text-start">${fields.map(([k, v]) => `
        <div class="d-flex border-bottom py-2 gap-3">
          <strong style="min-width:150px">${stEsc(k)}</strong>
          <span>${stEsc(v)}</span>
        </div>`).join('')}</div>`,
      width: 680,
      confirmButtonText: 'Close'
    });

    fetch('/api/stock-register/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'view', reference: `Viewed ${x.code}` })
    }).catch(() => {});
  } catch (err) {
    Swal.fire('Error', err.message, 'error');
  }
}

function stOpenItem() {
  const form = document.getElementById('stItemForm');
  if (form) form.reset();
  document.getElementById('stItemId').value = '';
  document.getElementById('stItemModalTitle').textContent = 'Add Stock Item';
  bootstrap.Modal.getOrCreateInstance(document.getElementById('stItemModal')).show();
}

async function stEditItem(id) {
  let x = ST_ITEMS_CACHE.find(a => a.id === id);
  if (!x) {
    try {
      const res = await fetch(`/api/stock-register/items/${encodeURIComponent(id)}`);
      const json = await res.json();
      x = json.data;
    } catch (e) {}
  }
  if (!x) return;

  ['code', 'name', 'category', 'unit', 'opening', 'min', 'location', 'supplier', 'status'].forEach(k => {
    const el = document.getElementById('sti_' + k);
    if (el) el.value = x[k] ?? '';
  });

  document.getElementById('stItemId').value = id;
  document.getElementById('stItemModalTitle').textContent = 'Edit Stock Item';
  bootstrap.Modal.getOrCreateInstance(document.getElementById('stItemModal')).show();
}

let _stSavingItem = false;
async function stSaveItem() {
  if (_stSavingItem) return;
  const f = document.getElementById('stItemForm');
  if (!f.checkValidity()) {
    f.reportValidity();
    return;
  }

  _stSavingItem = true;
  const id = document.getElementById('stItemId').value;
  const payload = {
    code: document.getElementById('sti_code').value.trim(),
    name: document.getElementById('sti_name').value.trim(),
    category: document.getElementById('sti_category').value.trim(),
    unit: document.getElementById('sti_unit').value.trim(),
    opening: Number(document.getElementById('sti_opening').value || 0),
    min: Number(document.getElementById('sti_min').value || 0),
    location: document.getElementById('sti_location').value.trim(),
    supplier: document.getElementById('sti_supplier').value.trim(),
    status: document.getElementById('sti_status').value
  };

  try {
    const url = id ? `/api/stock-register/items/${encodeURIComponent(id)}` : '/api/stock-register/items';
    const method = id ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const json = await res.json();
    if (!res.ok || json.error) {
      const errMsg = json.message || (json.errors ? Object.values(json.errors).join(' ') : json.error);
      Swal.fire('Validation Error', errMsg, 'error');
      return;
    }

    bootstrap.Modal.getInstance(document.getElementById('stItemModal'))?.hide();
    Swal.fire({ icon: 'success', title: id ? 'Item Updated' : 'Item Saved', timer: 1200, showConfirmButton: false });
    await stRefresh();
  } catch (err) {
    Swal.fire('Error', err.message, 'error');
  } finally {
    _stSavingItem = false;
  }
}

function stDeleteItem(id) {
  const item = ST_ITEMS_CACHE.find(a => a.id === id);
  const name = item ? `${item.code} (${item.name})` : id;

  Swal.fire({
    icon: 'warning',
    title: 'Delete stock item?',
    text: name,
    showCancelButton: true,
    confirmButtonText: 'Delete',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#dc2626'
  }).then(async r => {
    if (r.isConfirmed) {
      try {
        const res = await fetch(`/api/stock-register/items/${encodeURIComponent(id)}`, { method: 'DELETE' });
        const json = await res.json();
        if (!res.ok || json.error) {
          Swal.fire('Cannot Delete', json.message || json.error, 'error');
          return;
        }
        Swal.fire({ icon: 'success', title: 'Deleted', timer: 1000, showConfirmButton: false });
        await stRefresh();
      } catch (err) {
        Swal.fire('Error', err.message, 'error');
      }
    }
  });
}

function stOpenTx(type) {
  const form = document.getElementById('stTxForm');
  if (form) form.reset();
  document.getElementById('stTxId').value = '';
  document.getElementById('stTxType').value = type;

  const titles = {
    Receive: 'Stock Receive (In)',
    Issue: 'Stock Issue (Out)',
    Return: 'Stock Return',
    'Transfer Out': 'Stock Transfer Out',
    'Transfer In': 'Stock Transfer In',
    Adjustment: 'Stock Adjustment'
  };
  document.getElementById('stTxModalTitle').textContent = titles[type] || `Stock ${type}`;

  const sel = document.getElementById('stx_itemId');
  if (sel) {
    sel.innerHTML = ST_ITEMS_CACHE.map(x => `<option value="${x.id}">${stEsc(x.code)} — ${stEsc(x.name)} (${stEsc(x.unit)})</option>`).join('');
  }

  const staff = document.getElementById('stx_staff');
  if (staff) {
    const staffList = typeof MIS_getStaff === 'function' ? MIS_getStaff() : [];
    staff.innerHTML = '<option value="">Select staff (optional)</option>' +
      staffList.map(x => `<option value="${stEsc(x.staffId || x.id)}">${stEsc(x.name)} — ${stEsc(x.staffId || x.id)}</option>`).join('');

    staff.onchange = () => {
      const selected = staffList.find(a => (a.staffId || a.id) === staff.value);
      if (selected) {
        document.getElementById('stx_party').value = `${selected.name} — ${selected.staffId || selected.id}`;
      }
    };
  }

  document.getElementById('stx_date').value = new Date().toISOString().slice(0, 10);
  bootstrap.Modal.getOrCreateInstance(document.getElementById('stTxModal')).show();
}

let _stSavingTx = false;
async function stSaveTx() {
  if (_stSavingTx) return;
  const f = document.getElementById('stTxForm');
  if (!f.checkValidity()) {
    f.reportValidity();
    return;
  }

  const type = document.getElementById('stTxType').value;
  const itemId = document.getElementById('stx_itemId').value;
  const qty = Number(document.getElementById('stx_qty').value);
  const location = document.getElementById('stx_location').value.trim();

  // Local pre-check (also fully validated & guarded by database transactions on server)
  if (type === 'Issue' || type === 'Transfer Out') {
    const item = ST_ITEMS_CACHE.find(x => x.id === itemId);
    if (item && qty > Number(item.balance || 0)) {
      Swal.fire({
        icon: 'error',
        title: 'Insufficient Stock',
        text: `Available stock for ${item.name} (${item.code}) is ${item.balance}, cannot ${type} ${qty} units.`
      });
      return;
    }
  }

  _stSavingTx = true;
  const staffId = document.getElementById('stx_staff')?.value || '';
  const payload = {
    date: document.getElementById('stx_date').value,
    item_id: itemId,
    type,
    qty,
    unit_price: Number(document.getElementById('stx_unitPrice').value || 0),
    location,
    reference: document.getElementById('stx_reference').value.trim(),
    party: document.getElementById('stx_party').value.trim(),
    staff_id: staffId,
    purpose: document.getElementById('stx_purpose').value.trim(),
    approved_by: document.getElementById('stx_approvedBy').value.trim(),
    remarks: document.getElementById('stx_remarks').value.trim()
  };

  try {
    const res = await fetch('/api/stock-register/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const json = await res.json();
    if (!res.ok || json.error) {
      const errMsg = json.message || json.error;
      Swal.fire('Transaction Failed', errMsg, 'error');
      return;
    }

    bootstrap.Modal.getInstance(document.getElementById('stTxModal'))?.hide();
    Swal.fire({ icon: 'success', title: 'Transaction Processed', timer: 1200, showConfirmButton: false });
    await stRefresh();
  } catch (err) {
    Swal.fire('Error', err.message, 'error');
  } finally {
    _stSavingTx = false;
  }
}

async function stRenderLedger() {
  const q = (document.getElementById('stLedgerSearch')?.value || '').trim();
  const from = document.getElementById('stFrom')?.value || '';
  const to = document.getElementById('stTo')?.value || '';

  const params = new URLSearchParams();
  if (q) params.append('search', q);
  if (from) params.append('from', from);
  if (to) params.append('to', to);

  try {
    const res = await fetch(`/api/stock-register/transactions?${params.toString()}`);
    const json = await res.json();
    const tx = json.data || [];
    ST_TX_CACHE = tx;

    const tbody = document.getElementById('stLedgerBody');
    if (!tbody) return;

    if (tx.length === 0) {
      tbody.innerHTML = `<tr><td colspan="10" class="text-center py-4 text-muted">No stock transactions found.</td></tr>`;
      return;
    }

    tbody.innerHTML = tx.map((x, i) => {
      const badgeClass = x.type === 'Receive' || x.type === 'Transfer In' ? 'text-bg-success' :
                         x.type === 'Issue' || x.type === 'Transfer Out' ? 'text-bg-danger' :
                         x.type === 'Return' ? 'text-bg-primary' : 'text-bg-warning';

      return `<tr>
        <td>${i + 1}</td>
        <td>${x.date}</td>
        <td><b>${stEsc(x.item_code || x.itemId)}</b></td>
        <td>${stEsc(x.item_name || '')}</td>
        <td><span class="badge ${badgeClass}">${stEsc(x.type)}</span></td>
        <td><b>${x.qty}</b></td>
        <td>${x.unit_price || 0}</td>
        <td>${stEsc(x.reference || '-')}</td>
        <td>${stEsc(x.party || '-')}</td>
        <td>${stEsc(x.location)}</td>
        <td class="no-print">
          <button class="btn btn-sm btn-outline-danger" onclick="stDeleteTx('${x.id}')" title="Delete"><i data-lucide="trash-2"></i></button>
        </td>
      </tr>`;
    }).join('');

    if (window.lucide) lucide.createIcons();
  } catch (err) {
    console.error('Failed to load ledger:', err);
  }
}

function stDeleteTx(id) {
  Swal.fire({
    icon: 'warning',
    title: 'Delete transaction?',
    text: `Transaction ID: ${id}`,
    showCancelButton: true,
    confirmButtonText: 'Delete',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#dc2626'
  }).then(async r => {
    if (r.isConfirmed) {
      try {
        const res = await fetch(`/api/stock-register/transactions/${encodeURIComponent(id)}`, { method: 'DELETE' });
        const json = await res.json();
        if (!res.ok || json.error) {
          Swal.fire('Error', json.message || json.error, 'error');
          return;
        }
        Swal.fire({ icon: 'success', title: 'Deleted', timer: 1000, showConfirmButton: false });
        await stRefresh();
      } catch (err) {
        Swal.fire('Error', err.message, 'error');
      }
    }
  });
}

async function stCSV() {
  try {
    const res = await fetch('/api/stock-register/transactions');
    const json = await res.json();
    const tx = json.data || ST_TX_CACHE;

    const headers = [
      'ID', 'Date', 'Item Code', 'Item Name', 'Type', 'Quantity',
      'Unit Price', 'Location', 'Reference', 'Party', 'Purpose',
      'Approved By', 'Remarks'
    ];

    const lines = [
      headers,
      ...tx.map(x => [
        x.id,
        x.date,
        x.item_code || '',
        x.item_name || '',
        x.type,
        x.qty,
        x.unit_price || 0,
        x.location,
        x.reference || '',
        x.party || '',
        x.purpose || '',
        x.approved_by || '',
        x.remarks || ''
      ])
    ].map(a => a.map(v => '"' + String(v ?? '').replace(/"/g, '""') + '"').join(',')).join('\n');

    const b = new Blob(['\ufeff' + lines], { type: 'text/csv;charset=utf-8' });
    const u = URL.createObjectURL(b);
    const a = document.createElement('a');
    a.href = u;
    a.download = `stock-ledger-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(u);

    fetch('/api/stock-register/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'export', reference: 'Exported Stock Ledger CSV' })
    }).catch(() => {});
  } catch (err) {
    Swal.fire('Export Error', err.message, 'error');
  }
}

function stPrint() {
  fetch('/api/stock-register/action', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'print', reference: 'Printed Stock Register' })
  }).catch(() => {});
  window.print();
}

function stChart() {
  const el = document.getElementById('stockChart');
  if (!el || !window.Chart) return;

  const topItems = ST_ITEMS_CACHE.slice(0, 8);
  if (stChartObj) stChartObj.destroy();

  stChartObj = new Chart(el, {
    type: 'bar',
    data: {
      labels: topItems.map(x => x.code),
      datasets: [{
        label: 'Current Stock Balance',
        data: topItems.map(x => x.balance),
        backgroundColor: topItems.map(x => x.balance <= 0 ? '#ef4444' : x.balance <= x.min ? '#f59e0b' : '#3b82f6')
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  if (typeof MIS_requireAuth === 'function') MIS_requireAuth();
  const debouncedRefresh = (typeof MIS_debounce === 'function') ? MIS_debounce(stRefresh, 280) : stRefresh;
  ['stSearch', 'stCategory', 'stLocation', 'stStatus', 'stFrom', 'stTo', 'stLedgerSearch'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener(id.includes('Search') ? 'input' : 'change', id.includes('Search') ? debouncedRefresh : stRefresh);
    }
  });
  stRefresh();
});
