import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const viewsDir = path.join(__dirname, 'resources', 'views');

/**
 * Escape HTML to prevent XSS attacks in Blade expressions {{ $var }}
 */
export function escapeHtml(val) {
  if (val === null || val === undefined) return '';
  if (typeof val !== 'string') val = String(val);
  return val
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Resolve blade view path from dot notation
 * e.g. "dashboard.index" -> "resources/views/dashboard/index.blade.php"
 */
export function resolveViewPath(viewName) {
  const relPath = viewName.replace(/\./g, path.sep);
  const possiblePaths = [
    path.join(viewsDir, `${relPath}.blade.php`),
    path.join(viewsDir, relPath, 'index.blade.php'),
    path.join(viewsDir, `${relPath}.php`),
    path.join(viewsDir, `${relPath}.html`)
  ];

  for (const p of possiblePaths) {
    if (fs.existsSync(p) && fs.statSync(p).isFile()) {
      return p;
    }
  }
  return null;
}

/**
 * Render a Blade template file with variables
 */
export function renderBlade(viewName, data = {}) {
  const filePath = resolveViewPath(viewName);
  if (!filePath) {
    throw new Error(`View [${viewName}] not found in [${viewsDir}]`);
  }

  let content = fs.readFileSync(filePath, 'utf-8');
  return compileBladeString(content, data, path.dirname(filePath));
}

/**
 * Compile Blade string
 */
export function compileBladeString(template, data = {}, currentDir = viewsDir) {
  let content = template;

  // 1. Check for @extends('layouts.app') or @extends("layouts.app")
  const extendsMatch = content.match(/@extends\s*\(\s*['"]([^'"]+)['"]\s*\)/);
  if (extendsMatch) {
    const parentView = extendsMatch[1];
    const parentPath = resolveViewPath(parentView);

    if (parentPath) {
      let parentContent = fs.readFileSync(parentPath, 'utf-8');

      // Extract sections from child
      const sections = {};
      const sectionRegex = /@section\s*\(\s*['"]([^'"]+)['"](?:\s*,\s*['"]([^'"]+)['"]\s*\)|\s*\)([\s\S]*?)@(endsection|stop))/g;
      let sMatch;
      while ((sMatch = sectionRegex.exec(content)) !== null) {
        const name = sMatch[1];
        const val = sMatch[2] !== undefined ? sMatch[2] : (sMatch[3] || '');
        sections[name] = val.trim();
      }

      // Extract stacks from child (@push('scripts') ... @endpush)
      const stacks = {};
      const stackRegex = /@push\s*\(\s*['"]([^'"]+)['"]\s*\)([\s\S]*?)@endpush/g;
      let stMatch;
      while ((stMatch = stackRegex.exec(content)) !== null) {
        const name = stMatch[1];
        const val = stMatch[2] || '';
        stacks[name] = (stacks[name] || '') + '\n' + val;
      }

      // Inject sections into parent yields: @yield('name', 'default')
      parentContent = parentContent.replace(/@yield\s*\(\s*['"]([^'"]+)['"](?:\s*,\s*['"]([^'"]+)['"]\s*)?\)/g, (m, name, def) => {
        if (sections[name] !== undefined) return sections[name];
        if (data[name] !== undefined) return data[name];
        return def || '';
      });

      // Inject stacks: @stack('name')
      parentContent = parentContent.replace(/@stack\s*\(\s*['"]([^'"]+)['"]\s*\)/g, (m, name) => {
        return stacks[name] || '';
      });

      content = parentContent;
    }
  }

  // 2. Handle @include('partials.name', [...])
  content = content.replace(/@include\s*\(\s*['"]([^'"]+)['"](?:\s*,\s*(\[[^\]]*\]|\{[^\}]*\}))?\s*\)/g, (match, incView, rawProps) => {
    try {
      let incProps = { ...data };
      if (rawProps) {
        // Simple key => value extraction
        const kvMatches = rawProps.matchAll(/['"]?([a-zA-Z0-9_]+)['"]?\s*=>\s*([^,\}\]]+)/g);
        for (const kv of kvMatches) {
          const key = kv[1];
          let val = kv[2].trim().replace(/^['"]|['"]$/g, '');
          if (val === '$title' && data.title) val = data.title;
          incProps[key] = val;
        }
      }
      return renderBlade(incView, incProps);
    } catch (e) {
      console.warn(`Blade include warning: ${e.message}`);
      return `<!-- Include failed: ${incView} -->`;
    }
  });

  // 3. Handle Blade component tags: <x-sidebar />, <x-topbar title="..." />
  content = content.replace(/<x-([a-zA-Z0-9_-]+)([^>]*?)\s*(?:\/>|>([\s\S]*?)<\/x-\1>)/g, (match, compName, attrString, slotContent) => {
    const componentView = `components.${compName}`;
    const compPath = resolveViewPath(componentView);
    if (!compPath) return match;

    const compData = { ...data, slot: slotContent || '' };
    if (attrString) {
      const attrMatches = attrString.matchAll(/([a-zA-Z0-9_-]+)=["']([^"']*)["']/g);
      for (const am of attrMatches) {
        compData[am[1]] = am[2];
      }
    }
    try {
      return renderBlade(componentView, compData);
    } catch (e) {
      return `<!-- Component failed: ${compName} -->`;
    }
  });

  // 4. Asset helper: {{ asset('path') }} or {{ asset("path") }}
  content = content.replace(/\{\{\s*asset\s*\(\s*['"]([^'"]+)['"]\s*\)\s*\}\}/g, (m, p) => {
    return '/' + p.replace(/^\//, '');
  });

  // 5. CSRF helpers: @csrf and {{ csrf_token() }}
  const csrfToken = data.csrf_token || 'mis-laravel-session-token-2026';
  content = content.replace(/@csrf/g, `<input type="hidden" name="_token" value="${csrfToken}">`);
  content = content.replace(/\{\{\s*(?:\$csrf_token\s*\?\?\s*)?csrf_token\(\)\s*\}\}/g, csrfToken);

  // 6. Year helper: {{ date('Y') }}
  content = content.replace(/\{\{\s*date\s*\(\s*['"]Y['"]\s*\)\s*\}\}/g, '2026');

  // 7. Route & URL helpers: {{ route('name') }}, {{ url('path') }}
  content = content.replace(/\{\{\s*route\s*\(\s*['"]([^'"]+)['"]\s*\)\s*\}\}/g, (m, r) => {
    return '/' + r.replace(/^\//, '');
  });
  content = content.replace(/\{\{\s*url\s*\(\s*['"]([^'"]+)['"]\s*\)\s*\}\}/g, (m, u) => {
    return '/' + u.replace(/^\//, '');
  });

  // 8. Basic @if / @else / @endif blocks for alerts and status
  content = content.replace(/@if\s*\(\s*!empty\(\$status\)\s*\)([\s\S]*?)@else([\s\S]*?)@endif/g, (m, yes, no) => {
    return data.status ? yes.replace(/\{\{\s*\$status\s*\}\}/g, data.status) : no;
  });
  content = content.replace(/@if\s*\(\s*!empty\(\$error\)\s*\)([\s\S]*?)@else([\s\S]*?)@endif/g, (m, yes, no) => {
    return data.error ? yes.replace(/\{\{\s*\$error\s*\}\}/g, data.error) : no;
  });
  content = content.replace(/@if\s*\(\s*isset\(\$topbarActions\)\s*\)([\s\S]*?)@else([\s\S]*?)@endif/g, (m, yes, no) => {
    return data.topbarActions ? yes.replace(/\{!!\s*\$topbarActions\s*!!\}/g, data.topbarActions) : no;
  });

  // 9. @json($var) helper
  content = content.replace(/@json\s*\(\s*\$([a-zA-Z0-9_]+)(?:\s*\?\?\s*([^)]*))?\s*\)/g, (m, v, def) => {
    const val = data[v] !== undefined ? data[v] : (def ? JSON.parse(def) : null);
    return JSON.stringify(val ?? null);
  });

  // 10. Unescaped variables {!! ... !!}
  content = content.replace(/\{!!\s*json_encode\s*\(\s*\$([a-zA-Z0-9_]+)(?:\s*\?\?\s*([^)]*))?\s*\)\s*!!\}/g, (m, v, def) => {
    const val = data[v] !== undefined ? data[v] : (def ? JSON.parse(def) : null);
    return JSON.stringify(val ?? null);
  });
  content = content.replace(/\{!!\s*\$([a-zA-Z0-9_]+)\s*!!\}/g, (m, v) => {
    return data[v] !== undefined ? data[v] : '';
  });

  // 11. Nested variables: {{ $var['prop'] ?? 'default' }} or {{ $var.prop ?? 'default' }}
  content = content.replace(/\{\{\s*\$([a-zA-Z0-9_]+)(?:\[['"]([a-zA-Z0-9_]+)['"]\]|\.([a-zA-Z0-9_]+))(?:\s*\?\?\s*['"]?([^'"\}]*?)['"]?)?\s*\}\}/g, (m, v, p1, p2, def) => {
    const prop = p1 || p2;
    if (data[v] && data[v][prop] !== undefined) {
      return escapeHtml(data[v][prop]);
    }
    return def !== undefined ? escapeHtml(def) : '';
  });

  // 12. Standard variables: {{ $var ?? 'default' }}
  content = content.replace(/\{\{\s*\$([a-zA-Z0-9_]+)(?:\s*\?\?\s*['"]([^'"]*)['"])?\s*\}\}/g, (m, v, def) => {
    if (v === 'slot') {
      return data[v] !== undefined ? data[v] : (def !== undefined ? def : '');
    }
    if (data[v] !== undefined) return escapeHtml(data[v]);
    return def !== undefined ? escapeHtml(def) : '';
  });

  // 13. Clean up remaining unresolved Blade directives
  content = content.replace(/@stack\s*\(\s*['"][^'"]+['"]\s*\)/g, '');
  content = content.replace(/@yield\s*\(\s*['"][^'"]+['"](?:\s*,\s*['"]([^'"]*)['"])?\s*\)/g, (m, def) => def || '');

  return content;
}
