# Data Migration & Schema Mapping Notes

This document describes the schema architecture and migration strategy from the source SQLite database (`database/database.sqlite`) to the production MySQL database (`mis_department`).

---

## 📊 Source-to-Target Table & Record Mapping

| # | Source SQLite Table | Target MySQL Table | SQLite Count | MySQL Target | Data Status |
|---|---|---|---|---|---|
| 1 | `administrative_locations` | `administrative_locations` | 14 | 14 | Preserved |
| 2 | `advances` | `advances` | 57 | 57 | Preserved |
| 3 | `audit_logs` | `audit_logs` | 555 | 555 | Preserved |
| 4 | `branches` | `branches` | 1,287 | 1,287 | Preserved |
| 5 | `cabinet_documents` | `cabinet_documents` | 1 | 1 | Preserved |
| 6 | `data_quality_verifications` | `data_quality_verifications` | 1 | 1 | Preserved |
| 7 | `departments` | `departments` | 13 | 13 | Preserved |
| 8 | `domain_zones` | `domain_zones` | 68 | 68 | Preserved |
| 9 | `leaves` | `leaves` | 9 | 9 | Preserved |
| 10 | `mis_forms` | `mis_forms` | 1 | 1 | Preserved |
| 11 | `monthly_mis_submissions` | `monthly_mis_submissions` | 12 | 12 | Preserved |
| 12 | `movement_registers` | `movement_registers` | 7 | 7 | Preserved |
| 13 | `notifications` | `notifications` | 42 | 42 | Preserved |
| 14 | `password_resets` | `password_resets` | 0 | 0 | Ready |
| 15 | `report_requests` | `report_requests` | 2 | 2 | Preserved |
| 16 | `reports` | `reports` | 326 | 326 | Preserved |
| 17 | `sessions` | `sessions` | 0 | 0 | Ready |
| 18 | `staff_positions` | `staff_positions` | 8,647 | 8,647 | Preserved |
| 19 | `staff_transfers` | `staff_transfers` | 18 | 18 | Preserved |
| 20 | `stock_items` | `stock_items` | 10 | 10 | Preserved |
| 21 | `stock_transactions` | `stock_transactions` | 13 | 13 | Preserved |
| 22 | `system_settings` | `system_settings` | 12 | 12 | Preserved |
| 23 | `target_activities` | `target_activities` | 2 | 2 | Preserved |
| 24 | `users` | `users` | 6 | 6 | Preserved |
| **Total** | **24 Tables** | **24 Tables** | **11,078 Rows** | **11,078 Rows** | **100% Intact** |

---

## 🛡️ Migration & Integrity Guidelines

1. **Charset & Collation:**
   - Database and tables configured to `utf8mb4` with collation `utf8mb4_unicode_ci` to support Bengali (বাংলা) and English characters seamlessly.
2. **Foreign Key Integrity:**
   - The master script `database/mysql_schema.sql` wraps table definitions with `SET FOREIGN_KEY_CHECKS = 0;` and restores them after index creation to avoid circular dependency errors during batch insertion.
3. **Password Security Migration:**
   - User passwords in the target database are stored in salted PBKDF2 / Bcrypt formats.
4. **Zero Overwrite Safety:**
   - The source SQLite database (`database/database.sqlite`) is kept permanently read-only as a master reference archive and is never deleted during MySQL migration.
