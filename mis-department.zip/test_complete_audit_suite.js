import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:3000';
const HEADERS = {
  'Content-Type': 'application/json',
  'Cookie': 'auth_role=Super Admin; auth_user=admin'
};

async function runTests() {
  console.log('--- STARTING COMPLETE AUDIT TEST SUITE ---');
  let passed = 0;
  let failed = 0;

  function assert(condition, name) {
    if (condition) {
      console.log(`✅ PASS: ${name}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${name}`);
      failed++;
    }
  }

  try {
    // 1. Report Requests
    console.log('\n--- 1. Testing Report Requests API ---');
    const rrGet = await (await fetch(`${BASE_URL}/api/report-requests`, { headers: HEADERS })).json();
    assert(rrGet.success && Array.isArray(rrGet.data) && rrGet.data.length >= 2, 'GET /api/report-requests returns records');

    const testReqId = 'TEST-REQ-' + Date.now();
    const rrCreate = await (await fetch(`${BASE_URL}/api/report-requests`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({
        id: testReqId,
        requester: 'Audit Tester',
        department: 'Operations',
        report: 'Quarterly Audit Report',
        deadline: '2026-10-01',
        priority: 'Urgent',
        status: 'Processing'
      })
    })).json();
    assert(rrCreate.success, 'POST /api/report-requests creates a request');

    const rrPut = await (await fetch(`${BASE_URL}/api/report-requests/${testReqId}`, {
      method: 'PUT',
      headers: HEADERS,
      body: JSON.stringify({ status: 'Completed', remarks: 'Verification passed' })
    })).json();
    assert(rrPut.success, 'PUT /api/report-requests updates status');

    const rrDel = await (await fetch(`${BASE_URL}/api/report-requests/${testReqId}`, {
      method: 'DELETE',
      headers: HEADERS
    })).json();
    assert(rrDel.success, 'DELETE /api/report-requests deletes test request');

    // 2. Target Activities
    console.log('\n--- 2. Testing Target & Activity API ---');
    const tgtGet = await (await fetch(`${BASE_URL}/api/target-activity`, { headers: HEADERS })).json();
    assert(tgtGet.success && Array.isArray(tgtGet.data) && tgtGet.data.length >= 2, 'GET /api/target-activity returns targets');

    const testTgtId = 'TEST-TGT-' + Date.now();
    const tgtCreate = await (await fetch(`${BASE_URL}/api/target-activity`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({
        id: testTgtId,
        period: 'Q4 2026',
        area: 'Sylhet Division',
        indicator: 'Digital Audit Compliance',
        target: 100,
        achieved: 95
      })
    })).json();
    assert(tgtCreate.success, 'POST /api/target-activity creates target');

    const tgtPut = await (await fetch(`${BASE_URL}/api/target-activity/${testTgtId}`, {
      method: 'PUT',
      headers: HEADERS,
      body: JSON.stringify({ achieved: 100 })
    })).json();
    assert(tgtPut.success, 'PUT /api/target-activity updates target');

    const tgtDel = await (await fetch(`${BASE_URL}/api/target-activity/${testTgtId}`, {
      method: 'DELETE',
      headers: HEADERS
    })).json();
    assert(tgtDel.success, 'DELETE /api/target-activity deletes target');

    // 3. Note Document Cabinet
    console.log('\n--- 3. Testing Note & Document Cabinet API ---');
    const cabGet = await (await fetch(`${BASE_URL}/api/note-document-cabinet`, { headers: HEADERS })).json();
    assert(cabGet.success && Array.isArray(cabGet.data), 'GET /api/note-document-cabinet returns documents');

    const testDocId = 'TEST-DOC-' + Date.now();
    const cabCreate = await (await fetch(`${BASE_URL}/api/note-document-cabinet`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({
        id: testDocId,
        title: 'System Audit Manual',
        category: 'Policy',
        docType: 'document',
        date: '2026-09-21',
        department: 'MIS',
        attachments: [{ id: 'A1', name: 'audit_manual.pdf', size: 2048 }]
      })
    })).json();
    assert(cabCreate.success, 'POST /api/note-document-cabinet saves document');

    const cabDel = await (await fetch(`${BASE_URL}/api/note-document-cabinet/${testDocId}`, {
      method: 'DELETE',
      headers: HEADERS
    })).json();
    assert(cabDel.success, 'DELETE /api/note-document-cabinet deletes document');

    // 4. MIS Forms
    console.log('\n--- 4. Testing MIS Data Entry Forms API ---');
    const misGet = await (await fetch(`${BASE_URL}/api/mis-data-entry/forms`, { headers: HEADERS })).json();
    assert(misGet.success && Array.isArray(misGet.data), 'GET /api/mis-data-entry/forms returns forms');

    // 5. Data Quality
    console.log('\n--- 5. Testing Data Quality API ---');
    const dqGet = await (await fetch(`${BASE_URL}/api/data-quality`, { headers: HEADERS })).json();
    assert(dqGet.success && dqGet.total_scanned === 326 && Array.isArray(dqGet.issues), 'GET /api/data-quality returns live integrity scans');

    const dqVerify = await (await fetch(`${BASE_URL}/api/data-quality/verify`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({ record_id: 'DQ-TEST-001', module: 'Branches', remarks: 'Verified by audit' })
    })).json();
    assert(dqVerify.success, 'POST /api/data-quality/verify logs verification');

    // 6. Monitoring
    console.log('\n--- 6. Testing Monitoring API ---');
    const monGet = await (await fetch(`${BASE_URL}/api/monitoring`, { headers: HEADERS })).json();
    assert(monGet.success && Array.isArray(monGet.areas) && monGet.areas.length > 0, 'GET /api/monitoring calculates area compliance dynamically');

    // 7. Analytics
    console.log('\n--- 7. Testing Analytics API ---');
    const anGet = await (await fetch(`${BASE_URL}/api/analytics`, { headers: HEADERS })).json();
    assert(anGet.success && Array.isArray(anGet.trend) && Array.isArray(anGet.top_areas), 'GET /api/analytics returns real DB trends and areas');

    // 8. Backup & Settings
    console.log('\n--- 8. Testing Backup & Settings API ---');
    const bkGet = await (await fetch(`${BASE_URL}/api/backup-settings`, { headers: HEADERS })).json();
    assert(bkGet.success && bkGet.table_counts && bkGet.table_counts.branches > 0, 'GET /api/backup-settings returns database statistics');

    const bkPost = await (await fetch(`${BASE_URL}/api/backup-settings/settings`, {
      method: 'POST',
      headers: HEADERS,
      body: JSON.stringify({ backup_frequency: 'Daily', retention: '90 Days' })
    })).json();
    assert(bkPost.success, 'POST /api/backup-settings/settings updates settings');

    // 9. Excel Export
    console.log('\n--- 9. Testing Excel / CSV Exports ---');
    const expStaff = await (await fetch(`${BASE_URL}/api/excel-import-export/export/staff`, { headers: HEADERS })).text();
    assert(expStaff.includes('Employee ID') && expStaff.includes('Full Name'), 'Export staff positions contains CSV headers');

    const expBranch = await (await fetch(`${BASE_URL}/api/excel-import-export/export/branch`, { headers: HEADERS })).text();
    assert(expBranch.includes('Branch Name') && expBranch.includes('Division'), 'Export branch directory contains CSV headers');

    const expAdv = await (await fetch(`${BASE_URL}/api/excel-import-export/export/advance`, { headers: HEADERS })).text();
    assert(expAdv.includes('Ref ID') && expAdv.includes('Employee Name'), 'Export advance register contains CSV headers');

    console.log(`\n==============================================`);
    console.log(`AUDIT TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
    console.log(`==============================================`);
  } catch (err) {
    console.error('Test execution failed with error:', err);
  }
}

runTests();
