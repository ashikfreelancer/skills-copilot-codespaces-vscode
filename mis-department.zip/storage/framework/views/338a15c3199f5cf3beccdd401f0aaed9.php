<!DOCTYPE html>

<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"/><meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>Report Requests | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet"/><script src="<?php echo e(asset('assets/js/app.js')); ?>"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="report-requests">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i class="text-primary" data-lucide="database"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Report Requests</h1></div></div>
<div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="mb-4"><h2 class="page-title h3">Report Requests</h2><p class="muted">Receive, assign, track and deliver MIS report requests.</p></div>
<div class="cardx p-3 mb-3"><button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#checkedFormModal"><i data-lucide="plus" class="me-1"></i>New Report Request</button></div>
<div class="cardx p-3"><div class="table-responsive responsive-table"><table class="table"><thead><tr><th>Request ID</th><th>Requested By</th><th>Report</th><th>Due Date</th><th>Priority</th><th>Status</th></tr></thead><tbody><tr><td>REQ-2026-0912</td><td>Management</td><td>District-wise Branch Summary</td><td>13 Sep 2026</td><td><span class="badge bg-danger">High</span></td><td><span class="badge bg-warning text-dark">Processing</span></td></tr><tr><td>REQ-2026-0911</td><td>MIS</td><td>Staff Position</td><td>15 Sep 2026</td><td>Normal</td><td><span class="badge bg-success">Completed</span></td></tr></tbody></table></div></div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a></div></div>
<div class="toast position-fixed bottom-0 end-0 m-3" id="toast"><div class="toast-body">Saved</div></div>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<div aria-hidden="true" class="modal fade" id="checkedFormModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable">
<div class="modal-content border-0 shadow">
<div class="modal-header bg-primary text-white">
<div><h5 class="modal-title">Create / Update Report Requests</h5><small>Unique professional form</small></div>
<button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button"></button>
</div>
<form id="reportRequestForm" onsubmit="event.preventDefault(); toast('Report request saved successfully'); bootstrap.Modal.getInstance(document.getElementById('checkedFormModal')).hide(); this.reset();">
<div class="modal-body"><div class="row g-3"><div class="col-md-6"><label class="form-label fw-semibold">Requester Name</label><input class="form-control" placeholder="Requester Name" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Requester Department</label><input class="form-control" placeholder="Department" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Required Report</label><input class="form-control" placeholder="Report Name" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Request Date</label><input class="form-control" placeholder="" type="date"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Deadline</label><input class="form-control" placeholder="" type="date"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Priority</label><select class="form-select"><option value="">Select</option><option>Normal</option><option>High</option><option>Urgent</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Assigned To</label><input class="form-control" placeholder="Assigned User" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Status</label><select class="form-select"><option value="">Select</option><option>New</option><option>Assigned</option><option>Processing</option><option>Review</option><option>Completed</option><option>Delivered</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">Remarks</label><textarea class="form-control" placeholder="Remarks" rows="3"></textarea></div></div></div>
<div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal" type="button">Cancel</button><button class="btn btn-primary" type="submit">Save</button></div>
</form>
</div>
</div>
</div>
<script>document.addEventListener('shown.bs.modal',()=>{if(window.lucide) lucide.createIcons();});</script>
<script>document.addEventListener('DOMContentLoaded',()=>{const d=document.querySelector('#checkedFormModal input[type="date"]');if(d&&!d.value)d.value=new Date().toISOString().slice(0,10);if(window.lucide)lucide.createIcons();});</script></body></html><?php /**PATH /app/applet/resources/views/report-requests/index.blade.php ENDPATH**/ ?>