<!doctype html>
<html lang="en">
<head>
<script>
try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}
</script>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign In | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;background:#f4f7fb;color:#0f172a}
.login-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:28px}
.login-card{width:min(1040px,100%);min-height:620px;background:#fff;border:1px solid #e2e8f0;border-radius:24px;overflow:hidden;box-shadow:0 24px 70px rgba(15,23,42,.12)}
.login-brand{position:relative;background:linear-gradient(145deg,#0b1736 0%,#123b80 58%,#1769c2 100%);color:#fff;padding:54px}
.login-brand:after{content:"";position:absolute;width:320px;height:320px;border:1px solid rgba(255,255,255,.10);border-radius:50%;right:-120px;bottom:-120px;box-shadow:0 0 0 60px rgba(255,255,255,.025),0 0 0 120px rgba(255,255,255,.02)}
.brand-mark{width:66px;height:66px;border-radius:17px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);display:grid;place-items:center}
.brand-kicker{font-size:12px;letter-spacing:.13em;text-transform:uppercase;opacity:.72}
.login-form{padding:54px}
.login-title{font-size:30px;font-weight:800;letter-spacing:-.03em}
.login-subtitle{color:#64748b}
.input-label{font-size:13px;font-weight:700;color:#334155;margin-bottom:7px}
.login-input{height:50px;border-radius:10px;border:1px solid #d8e0ea}
.login-input:focus{border-color:#3b82f6;box-shadow:0 0 0 .2rem rgba(59,130,246,.12)}
.input-group .login-input{border-left:0}
.input-group-text{background:#fff;border-color:#d8e0ea}
.login-button{height:50px;border-radius:10px;font-weight:750}
.security-note{background:#f8fafc;border:1px solid #e7edf5;border-radius:11px;padding:11px 13px;color:#64748b;font-size:12px}
.footer-note{font-size:12px;color:#94a3b8}
@media(max-width:767px){
 .login-page{padding:14px}
 .login-card{min-height:auto;border-radius:18px}
 .login-brand,.login-form{padding:32px 24px}
 .login-title{font-size:26px}
}
</style>
</head>
<body>
<div class="login-page">
  <section class="login-card">
    <div class="row g-0 min-vh-100" style="min-height:620px!important">
      <div class="col-lg-5 login-brand d-flex flex-column justify-content-between">
        <div style="position:relative;z-index:1">
          <div class="brand-mark mb-4"><i data-lucide="database" style="width:31px;height:31px"></i></div>
          <div class="brand-kicker mb-2">MIS Department</div>
          <h1 class="display-6 fw-bold mb-3">Management<br>Information System</h1>
          <p class="mb-0 opacity-75" style="line-height:1.7">
            Centralized management information, reporting, monitoring, branch intelligence and operational data workspace.
          </p>
        </div>
        <div class="small opacity-75" style="position:relative;z-index:1">
          <i data-lucide="shield-check" style="width:16px;vertical-align:-3px"></i>
          Secure access for authorized MIS users
        </div>
      </div>

      <div class="col-lg-7 login-form d-flex flex-column justify-content-center">
        <div style="max-width:500px;width:100%;margin:auto">
          <div class="mb-4">
            <div class="text-primary fw-bold small">WELCOME BACK</div>
            <div class="login-title mt-1">Sign in to MIS</div>
            <div class="login-subtitle mt-1">Use your User ID or email and password to continue.</div>
          </div>

          <form id="loginForm" novalidate>
            <div class="mb-3">
              <label class="input-label">User ID / Email</label>
              <div class="input-group">
                <span class="input-group-text"><i data-lucide="user" style="width:18px"></i></span>
                <input id="username" class="form-control login-input" type="text" autocomplete="username" placeholder="Enter User ID or Email" required>
              </div>
            </div>

            <div class="mb-3">
              <label class="input-label">Password</label>
              <div class="input-group">
                <span class="input-group-text"><i data-lucide="lock-keyhole" style="width:18px"></i></span>
                <input id="password" class="form-control login-input" type="password" autocomplete="current-password" placeholder="Enter Password" required>
                <button class="btn btn-outline-secondary" type="button" id="togglePassword" aria-label="Show password">
                  <i data-lucide="eye" style="width:18px"></i>
                </button>
              </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-4">
              <label class="small text-secondary d-flex align-items-center gap-2">
                <input id="remember" class="form-check-input mt-0" type="checkbox">
                Remember me
              </label>
              <a href="#" class="small text-primary text-decoration-none" onclick="event.preventDefault();showMessage('Password recovery will be connected to the backend.')">Forgot password?</a>
            </div>

            <div id="loginError" class="alert alert-danger d-none py-2 small"></div>

            <button class="btn btn-primary w-100 login-button" type="submit" id="loginButton">
              Sign In
              <i data-lucide="arrow-right" style="width:18px;vertical-align:-4px"></i>
            </button>
          </form>

          <div class="security-note mt-4">
            <i data-lucide="shield" style="width:16px;vertical-align:-3px"></i>
            Your login session is protected by the application. Production authentication should be connected to the Laravel/API backend.
          </div>
          <div class="footer-note text-center mt-4">MIS Department • Management Information System</div>
        </div>
      </div>
    </div>
  </section>
</div>

<script>
lucide.createIcons();

function showMessage(message){
  const box=document.getElementById('loginError');
  box.textContent=message;
  box.classList.remove('d-none');
}
document.getElementById('togglePassword').addEventListener('click',function(){
  const input=document.getElementById('password');
  const showing=input.type==='text';
  input.type=showing?'password':'text';
  this.innerHTML=showing?'<i data-lucide="eye"></i>':'<i data-lucide="eye-off"></i>';
  lucide.createIcons();
});

const remembered=localStorage.getItem('mis_remembered_user');
if(remembered) {
  document.getElementById('username').value=remembered;
  document.getElementById('remember').checked=true;
}

document.getElementById('loginForm').addEventListener('submit',function(e){
  e.preventDefault();
  const username=document.getElementById('username').value.trim();
  const password=document.getElementById('password').value.trim();
  const error=document.getElementById('loginError');
  const button=document.getElementById('loginButton');

  if(!username || !password){
    error.textContent='User ID / Email and Password are required.';
    error.classList.remove('d-none');
    return;
  }

  error.classList.add('d-none');
  button.disabled=true;
  button.innerHTML='Signing in... <i data-lucide="loader-circle"></i>';
  lucide.createIcons();

  // Frontend demo authentication: any non-empty credentials continue to Dashboard.
  setTimeout(()=>{
    sessionStorage.setItem('mis_authenticated','1');
    sessionStorage.setItem('mis_user',username);
    if(document.getElementById('remember').checked){
      localStorage.setItem('mis_remembered_user',username);
    }else{
      localStorage.removeItem('mis_remembered_user');
    }
    window.location.href='pages/dashboard/index.html';
  },450);
});
</script>
</body>
</html><?php /**PATH /app/applet/resources/views/auth/login.blade.php ENDPATH**/ ?>