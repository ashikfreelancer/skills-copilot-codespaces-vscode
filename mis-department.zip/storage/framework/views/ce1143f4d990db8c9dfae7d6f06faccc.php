<!doctype html>
<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Leave Management | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script><script>tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}</script>
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script><script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script><script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script><script src="https://cdn.amcharts.com/lib/5/xy.js"></script><script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css"><script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
<style>
.kpi-card{border:1px solid #e5e7eb;border-radius:14px;background:#fff;padding:16px;height:100%}.kpi-value{font-size:1.6rem;font-weight:800}
.report-only{display:block}.filter-title{font-size:.75rem;font-weight:800;letter-spacing:.05em;color:#64748b;text-transform:uppercase}
@media print{body{background:#fff!important}.desktop-sidebar,.topbar,.no-print,.offcanvas,#toast{display:none!important}.col-lg-10{width:100%!important}.p-3,.p-lg-4{padding:0!important}.cardx{border:0!important;box-shadow:none!important}.report-only{display:block!important}.table{font-size:10px}.table td,.table th{padding:5px}}
</style>
<style>
  .actions-col{white-space:nowrap;min-width:220px;}
  #leaveTable th.actions-col,#leaveTable td.actions-col,#leaveTypeTable th.actions-col,#leaveTypeTable td.actions-col{position:sticky;right:0;background:var(--bs-body-bg,#fff);z-index:2;}
  #leaveTable thead th.actions-col,#leaveTypeTable thead th.actions-col{z-index:4;}
  @media (max-width:768px){.actions-col{min-width:190px}.actions-col .btn{padding:.25rem .45rem;font-size:.75rem}.actions-col .btn i{width:13px;height:13px}}
</style>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="leave-management">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i data-lucide="database" class="text-primary"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div>
<div class="group-title">MAIN</div>
<a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i>Dashboard</a>
<a data-nav="location-branch" href="/location-branch"><i data-lucide="map"></i>Location & Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog"></i>Domain & Zone Head Information</a>
<a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i>Staff Position List</a>
<a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line"></i>MIS Data Entry</a>
<a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i>MIS Reports</a>
<a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined"></i>Analytics</a>
<div class="group-title">LEAVE MANAGEMENT</div>
<a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i>Leave Management</a>
<div class="group-title">DOCUMENTS & FINANCE</div>
<a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open"></i>Note & Document Cabinet</a>
<a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target"></i>Target & Activity</a>
<div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet"></i>Excel Import / Export</a>
<div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings"></i>Backup & Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#mobileNav"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Leave Management</h1></div></div>
<div class="d-flex align-items-center gap-2"><span class="badge bg-primary-subtle text-primary px-3 py-2">SUPER ADMIN</span><button class="btn btn-light no-print" onclick="printReport()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">SA</div></div>
</header>
<div class="p-3 p-lg-4" x-data="leaveTracker()">
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
<div><h2 class="page-title h3">Staff-wise Leave Tracker</h2><p class="muted mb-0">Single Staff + All Staff • Monthly/Yearly summary • Print & Export</p></div>
<div class="d-flex gap-2 no-print"><button class="btn btn-primary" @click="openApplication()"><i data-lucide="plus"></i> Apply Leave</button><button class="btn btn-outline-primary" @click="view='all'"><i data-lucide="users"></i> View All Staff</button></div>
</div>

<div class="row g-3 mb-3">
<div class="col-md-3"><div class="kpi-card"><div class="muted small">Total Allocated</div><div class="kpi-value" x-text="sum('allocated')"></div></div></div>
<div class="col-md-3"><div class="kpi-card"><div class="muted small">Leave Taken</div><div class="kpi-value" x-text="sum('taken')"></div></div></div>
<div class="col-md-3"><div class="kpi-card"><div class="muted small">Pending Applications</div><div class="kpi-value" x-text="sum('pending')"></div></div></div>
<div class="col-md-3"><div class="kpi-card"><div class="muted small">Available Balance</div><div class="kpi-value" x-text="sum('balance')"></div></div></div>
</div>

<div class="cardx p-3 mb-3 no-print">
<div class="filter-title mb-2">Tracker Filters</div>
<div class="row g-2">
<div class="col-md-3"><label class="form-label">View</label><select class="form-select" x-model="view"><option value="single">Single Staff View</option><option value="all">All Staff View</option><option value="monthly">Monthly View</option><option value="yearly">Yearly View</option></select></div>
<div class="col-md-3"><label class="form-label">Staff Name</label><select class="form-select" x-model="filters.staff"><option value="">All Staff</option><template x-for="s in staff" :key="s.id"><option :value="s.id" x-text="s.name"></option></template></select></div>
<div class="col-md-2"><label class="form-label">Division</label><select class="form-select" x-model="filters.division"><option value="">All</option><option>Dhaka</option><option>Rajshahi</option></select></div>
<div class="col-md-2"><label class="form-label">District</label><select class="form-select" x-model="filters.district"><option value="">All</option><option>Dhaka</option><option>Bogura</option></select></div>
<div class="col-md-2"><label class="form-label">Department</label><select id="leaveDepartmentFilter" class="form-select" x-model="filters.department"><option value="">All</option></select></div>
<div class="col-md-2"><label class="form-label">Upazila</label><select class="form-select" x-model="filters.upazila"><option value="">All</option><option>Sherpur</option><option>Shibganj</option></select></div>
<div class="col-md-2"><label class="form-label">Year</label><select class="form-select" x-model="filters.year"><option>2026</option><option>2025</option><option>2024</option></select></div>
<div class="col-md-2"><label class="form-label">Leave Type</label><select class="form-select" x-model="filters.type"><option value="">All</option><option>Casual Leave</option><option>Medical Leave</option><option>Annual Leave</option><option>LWP</option></select></div>
<div class="col-md-2"><label class="form-label">Status</label><select class="form-select" x-model="filters.status"><option value="">All</option><option>Approved</option><option>Pending</option><option>Rejected</option></select></div>
<div class="col-md-3"><label class="form-label">Search</label><input class="form-control" x-model="filters.search" placeholder="Name / ID / Department"></div>
<div class="col-md-3 d-flex align-items-end"><button class="btn btn-primary w-100" @click="refresh()"><i data-lucide="filter"></i> View Tracker</button></div>
</div>
</div>

<div id="leaveReport" class="cardx p-3">
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
<div><h3 class="h5 fw-bold mb-1" x-text="viewTitle()"></h3><div class="small muted">Year <span x-text="filters.year"></span> • Generated from current tracker filters</div></div>
<div class="d-flex gap-2 no-print"><button class="btn btn-sm btn-outline-secondary" @click="printReport()"><i data-lucide="printer"></i> Print</button><button class="btn btn-sm btn-outline-success" @click="downloadCSV()"><i data-lucide="file-down"></i> CSV</button><button class="btn btn-sm btn-outline-success" @click="downloadExcel()"><i data-lucide="table-2"></i> Excel</button><button class="btn btn-sm btn-outline-danger" @click="downloadPDF()"><i data-lucide="file-text"></i> PDF</button></div>
</div>
<div class="table-responsive"><table id="leaveTable" class="table table-bordered table-hover align-middle">
<thead><tr><th>SL</th><th>Staff Name</th><th>ID</th><th>Department</th><th>Designation</th><th>Allocated</th><th>Taken</th><th>Pending</th><th>Balance</th><th>Approved</th><th>Rejected</th><th class="no-print text-center actions-col">Actions</th></tr></thead>
<tbody><template x-for="(row,i) in filtered()" :key="row.id"><tr><td x-text="i+1"></td><td class="fw-semibold" x-text="row.name"></td><td x-text="row.id"></td><td x-text="row.department"></td><td x-text="row.designation"></td><td x-text="row.allocated"></td><td x-text="row.taken"></td><td><span class="badge bg-warning-subtle text-warning-emphasis" x-text="row.pending"></span></td><td class="fw-bold" x-text="row.balance"></td><td x-text="row.approved"></td><td x-text="row.rejected"></td><td class="no-print text-center actions-col"><div class="d-inline-flex gap-1 flex-nowrap"><button class="btn btn-sm btn-outline-primary" @click="single(row.id)" title="View"><i data-lucide="eye" class="me-1"></i>View</button><button class="btn btn-sm btn-outline-secondary" @click="edit(row.id)" title="Edit"><i data-lucide="pencil" class="me-1"></i>Edit</button><button class="btn btn-sm btn-outline-danger" @click="remove(row.id)" title="Delete"><i data-lucide="trash-2" class="me-1"></i>Delete</button></div></td></tr></template></tbody>
</table></div>
<div class="small muted mt-2">Showing <span x-text="filtered().length"></span> staff record(s).</div>
</div>

<!-- Leave Type Entitlement & Usage -->
<div class="cardx p-3 mt-3">
  <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div><h3 class="h5 fw-bold mb-1">Leave Type Entitlement & Usage</h3><div class="small muted">Super Admin can set each staff member's annual quota. Taken is counted from approved leave applications.</div></div>
    <button class="btn btn-sm btn-primary no-print" @click="openQuota(filters.staff || (filtered()[0] && filtered()[0].id))" :disabled="!filtered().length"><i data-lucide="settings-2"></i> Manage Leave Quota</button>
  </div>
  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle small mb-0" id="leaveTypeTable">
      <thead>
        <tr>
          <th rowspan="2">SL</th><th rowspan="2">Staff</th><th rowspan="2">ID</th>
          <th colspan="3" class="text-center">Casual Leave</th>
          <th colspan="3" class="text-center">Medical Leave</th>
          <th colspan="3" class="text-center">Annual Leave</th>
          <th colspan="3" class="text-center">Other / LWP</th>
          <th rowspan="2" class="no-print text-center actions-col">Action</th>
        </tr>
        <tr><template x-for="t in leaveTypes" :key="t"><th>Allocated</th><th>Taken</th><th>Balance</th></template></tr>
      </thead>
      <tbody>
        <template x-for="(row,i) in filtered()" :key="'type-'+row.id">
          <tr>
            <td x-text="i+1"></td><td class="fw-semibold" x-text="row.name"></td><td x-text="row.id"></td>
            <template x-for="t in leaveTypes" :key="t">
              <td x-text="leaveSummary(row.id,t).allocated"></td>
              <td x-text="leaveSummary(row.id,t).taken"></td>
              <td class="fw-bold" x-text="leaveSummary(row.id,t).balance"></td>
            </template>
            <td class="no-print text-center actions-col"><button class="btn btn-sm btn-outline-primary" @click="openQuota(row.id)"><i data-lucide="pencil" class="me-1"></i>Manage Quota</button></td>
          </tr>
        </template>
      </tbody>
    </table>
  </div>
</div>

<!-- Leave Quota Modal -->
<div class="modal fade" id="quotaModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content">
  <div class="modal-header"><div><h5 class="modal-title mb-1">Manage Leave Quota</h5><div class="small text-muted" x-text="quotaStaffName()"></div></div><button class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
    <div class="alert alert-info small"><i data-lucide="info" class="me-1"></i> These are configurable system quotas for the selected staff member. The frontend does not assume any statutory/service rule; Super Admin enters the applicable entitlement.</div>
    <div class="row g-3">
      <template x-for="t in leaveTypes" :key="t"><div class="col-md-6"><div class="border rounded-3 p-3">
        <div class="fw-bold mb-2" x-text="t"></div>
        <label class="form-label small">Annual Allocated Days</label><input type="number" min="0" step="0.5" class="form-control" x-model.number="quotaForm[t]">
        <div class="small text-muted mt-2">Taken: <span x-text="leaveSummary(quotaForm.staff,t).taken"></span> • Balance after allocation: <strong x-text="Math.max(0, Number(quotaForm[t]||0)-leaveSummary(quotaForm.staff,t).taken)"></strong></div>
      </div></div></template>
    </div>
  </div>
  <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" @click="saveQuota()"><i data-lucide="save"></i> Save Quota</button></div>
</div></div></div>

<!-- Application Modal -->
<div class="modal fade" id="leaveModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content">
<div class="modal-header"><h5 class="modal-title" x-text="editing ? 'Edit Leave Application' : 'New Leave Application'"></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body"><div class="row g-3">
<div class="col-md-6"><label class="form-label">Staff</label><select class="form-select" x-model="form.staff"><template x-for="s in staff" :key="s.id"><option :value="s.id" x-text="s.name+' — '+s.id"></option></template></select></div>
<div class="col-md-6"><label class="form-label">Leave Type</label><select class="form-select" x-model="form.type"><option>Casual Leave</option><option>Medical Leave</option><option>Annual Leave</option><option>LWP</option></select></div>
<div class="col-md-4"><label class="form-label">From</label><input type="date" class="form-control" x-model="form.from"></div>
<div class="col-md-4"><label class="form-label">To</label><input type="date" class="form-control" x-model="form.to"></div>
<div class="col-md-4"><label class="form-label">Status</label><select class="form-select" x-model="form.status"><option>Pending</option><option>Approved</option><option>Rejected</option></select></div>
<div class="col-12"><label class="form-label">Reason / Note</label><textarea class="form-control" rows="3" x-model="form.note" placeholder="Leave reason"></textarea></div>

<div class="col-12">
  <div class="border rounded-3 p-3 bg-light-subtle">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-2">
      <div><div class="fw-bold">Supporting Documents</div><div class="small text-muted">PDF, JPG, JPEG, PNG, DOC, DOCX, XLS, XLSX • Max 10 MB per file</div></div>
      <label class="btn btn-outline-primary btn-sm mb-0"><i data-lucide="paperclip"></i> Add Document
        <input type="file" class="d-none" multiple accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx" @change="handleFiles($event)">
      </label>
    </div>
    <div x-show="form.documents.length" class="table-responsive">
      <table class="table table-sm align-middle mb-2">
        <thead><tr><th>Document</th><th>Size</th><th>Added</th><th class="text-end">Actions</th></tr></thead>
        <tbody><template x-for="doc in form.documents" :key="doc.id"><tr>
          <td><i data-lucide="file-text" class="me-1"></i><span x-text="doc.name"></span></td>
          <td x-text="formatBytes(doc.size)"></td><td x-text="doc.addedAt"></td>
          <td class="text-end"><div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" @click="previewDocument(doc)" title="Preview"><i data-lucide="eye"></i></button>
            <button type="button" class="btn btn-outline-secondary" @click="downloadDocument(doc)" title="Download"><i data-lucide="download"></i></button>
            <button type="button" class="btn btn-outline-danger" @click="deleteDocument(doc.id)" title="Delete"><i data-lucide="trash-2"></i></button>
          </div></td>
        </tr></template></tbody>
      </table>
    </div>
    <div x-show="!form.documents.length" class="small text-muted py-2">No document attached yet.</div>
  </div>
</div>

<div class="col-12" x-show="form.history.length">
  <div class="border rounded-3 p-3">
    <div class="fw-bold mb-2"><i data-lucide="history"></i> Document History</div>
    <div class="table-responsive">
      <table class="table table-sm align-middle mb-0"><thead><tr><th>Date & Time</th><th>Action</th><th>Document</th><th>User</th></tr></thead>
      <tbody><template x-for="item in form.history" :key="item.id"><tr><td x-text="item.date"></td><td><span class="badge bg-light text-dark" x-text="item.action"></span></td><td x-text="item.name"></td><td x-text="item.user"></td></tr></template></tbody></table>
    </div>
  </div>
</div>
</div></div>
<div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" @click="saveApplication()"><i data-lucide="save"></i> Save / Update</button></div>
</div></div></div>
</div></main></div></div>

<div class="offcanvas offcanvas-start sidebar" tabindex="-1" id="mobileNav"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body">
<div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i>Dashboard</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i>Leave Management</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i>MIS Reports</a>
<div class="group-title">SYSTEM</div><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i>Users & Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i>Audit Log</a></div></div>
<div id="toast" class="toast position-fixed bottom-0 end-0 m-3"><div class="toast-body">Saved</div></div>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function leaveTracker(){
return {view:'all',editing:false,editId:null,storageKey:'mis_leave_documents_v1',quotaKey:'mis_leave_quotas_v1',leaveTypes:['Casual Leave','Medical Leave','Annual Leave','LWP'],
staff:[
{id:'1001',name:'Staff A',department:'MIS',designation:'Officer',division:'Dhaka',district:'Dhaka',upazila:'Sherpur',allocated:44,taken:17,pending:1,balance:27,approved:17,rejected:0},
{id:'1002',name:'Staff B',department:'MIS',designation:'Officer',division:'Dhaka',district:'Dhaka',upazila:'Shibganj',allocated:44,taken:12,pending:0,balance:32,approved:12,rejected:1},
{id:'1003',name:'Staff C',department:'MIS',designation:'Manager',division:'Rajshahi',district:'Bogura',upazila:'Shibganj',allocated:50,taken:21,pending:2,balance:29,approved:21,rejected:0},
{id:'1004',name:'Staff D',department:'IT',designation:'Senior Officer',division:'Dhaka',district:'Dhaka',upazila:'Sherpur',allocated:44,taken:9,pending:1,balance:35,approved:9,rejected:0},
{id:'1005',name:'Staff E',department:'Accounts',designation:'Officer',division:'Rajshahi',district:'Bogura',upazila:'Shibganj',allocated:44,taken:15,pending:3,balance:29,approved:15,rejected:1}],
filters:{staff:'',division:'',district:'',upazila:'',department:'',year:'2026',type:'',status:'',search:''},
init(){try{const shared=MIS_getStaff();if(shared.length){this.staff=shared.map(x=>({id:x.staffId||x.id,name:x.name,department:x.department||'',designation:x.designation||'',division:x.division||'',district:x.homeDistrict||'',upazila:'',allocated:x.allocated||44,taken:0,pending:0,balance:x.allocated||44,approved:0,rejected:0}));}this.$nextTick(()=>this.refresh())}catch(e){}},
quotaForm:{staff:'', 'Casual Leave':0, 'Medical Leave':0, 'Annual Leave':0, 'LWP':0},
form:{staff:'1001',type:'Casual Leave',from:'',to:'',status:'Pending',note:'',documents:[],history:[]},
_docStore(){try{return JSON.parse(localStorage.getItem(this.storageKey)||'{}')}catch(e){return {}}},
_saveDocStore(store){localStorage.setItem(this.storageKey,JSON.stringify(store))},
_quotaStore(){try{return JSON.parse(localStorage.getItem(this.quotaKey)||'{}')}catch(e){return {}}},
_saveQuotaStore(store){localStorage.setItem(this.quotaKey,JSON.stringify(store))},
_defaultQuota(staff){
  // Demo-only starting values; Super Admin can replace these with the organisation's actual entitlement.
  const total=Number(staff?.allocated||0);
  return {'Casual Leave':Math.min(10,total),'Medical Leave':Math.min(14,Math.max(0,total-Math.min(10,total))),'Annual Leave':Math.max(0,total-Math.min(10,total)-Math.min(14,Math.max(0,total-Math.min(10,total)))),'LWP':0};
},
quotaFor(id){let store=this._quotaStore();let s=this.staff.find(x=>x.id===id);let q=store[id]||this._defaultQuota(s);return {'Casual Leave':Number(q['Casual Leave']||0),'Medical Leave':Number(q['Medical Leave']||0),'Annual Leave':Number(q['Annual Leave']||0),'LWP':Number(q['LWP']||0)}},
applicationRecords(){let store=this._docStore();return Object.keys(store).filter(k=>k.indexOf('APP-')===0).map(k=>Object.assign({id:k},store[k])).filter(r=>r.staff);},
applicationDays(r){if(!r.from||!r.to)return 0;let a=new Date(r.from+'T00:00:00'),b=new Date(r.to+'T00:00:00');return Math.max(0,Math.floor((b-a)/86400000)+1)},
leaveTaken(id,type){let year=String(this.filters.year);return this.applicationRecords().filter(r=>String(r.staff)===String(id)&&r.type===type&&r.status==='Approved'&&(!r.from||r.from.slice(0,4)===year)).reduce((n,r)=>n+this.applicationDays(r),0)},
leavePending(id,type){let year=String(this.filters.year);return this.applicationRecords().filter(r=>String(r.staff)===String(id)&&r.type===type&&r.status==='Pending'&&(!r.from||r.from.slice(0,4)===year)).reduce((n,r)=>n+this.applicationDays(r),0)},
leaveSummary(id,type){let q=this.quotaFor(id),allocated=Number(q[type]||0),taken=this.leaveTaken(id,type);return {allocated,taken,balance:Math.max(0,allocated-taken),pending:this.leavePending(id,type)}},
quotaStaffName(){let s=this.staff.find(x=>x.id===this.quotaForm.staff);return s?s.name+' — '+s.id:'Select staff'},
openQuota(id){if(!id)return;let q=this.quotaFor(id);this.quotaForm=Object.assign({staff:id},q);this.$nextTick(()=>{new bootstrap.Modal('#quotaModal').show();this.refresh()})},
saveQuota(){if(!this.quotaForm.staff)return;let store=this._quotaStore();store[this.quotaForm.staff]={'Casual Leave':Number(this.quotaForm['Casual Leave']||0),'Medical Leave':Number(this.quotaForm['Medical Leave']||0),'Annual Leave':Number(this.quotaForm['Annual Leave']||0),'LWP':Number(this.quotaForm.LWP||0),updatedAt:new Date().toLocaleString(),updatedBy:'Super Admin'};this._saveQuotaStore(store);this.refresh();toast('Leave quota updated');let modal=bootstrap.Modal.getInstance(document.getElementById('quotaModal'));if(modal)modal.hide()},
_applicationKey(){return this.editId||('APP-'+this.form.staff+'-'+Date.now())},
_loadApplicationDocs(key){let store=this._docStore();let rec=store[key]||{documents:[],history:[]};return {documents:rec.documents||[],history:rec.history||[]}},
recordHistory(action,doc){this.form.history.unshift({id:'H-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),date:new Date().toLocaleString(),action,name:doc?.name||'—',user:'Super Admin'})},
syncDocuments(){let key=this._applicationKey();let store=this._docStore();store[key]={documents:this.form.documents,history:this.form.history};this._saveDocStore(store)},
sum(k){return this.filtered().reduce((a,r)=>a+Number(r[k]||0),0)},
filtered(){let f=this.filters,q=f.search.toLowerCase();return this.staff.filter(r=>(!f.staff||r.id===f.staff)&&(!f.division||r.division===f.division)&&(!f.district||r.district===f.district)&&(!f.upazila||r.upazila===f.upazila)&&(!f.department||r.department===f.department)&&(!q||[r.name,r.id,r.department,r.designation].join(' ').toLowerCase().includes(q)))},
viewTitle(){if(this.view==='single'){let r=this.staff.find(x=>x.id===this.filters.staff);return r?'Leave Tracker — '+r.name:'Single Staff Leave Tracker'}if(this.view==='monthly')return 'Monthly Leave Summary';if(this.view==='yearly')return 'Yearly Leave Summary';return 'All Staff Leave Tracker'},
refresh(){this.$nextTick(()=>lucide.createIcons())},
single(id){this.filters.staff=id;this.view='single';this.refresh()},
openApplication(){this.editing=false;this.editId=null;this.form={staff:this.filters.staff||'1001',type:'Casual Leave',from:'',to:'',status:'Pending',note:'',documents:[],history:[]};this.$nextTick(()=>{new bootstrap.Modal('#leaveModal').show();this.refresh()})},
edit(id){this.editing=true;this.editId='APP-'+id;let saved=this._loadApplicationDocs(this.editId);this.form={staff:id,type:'Casual Leave',from:'',to:'',status:'Pending',note:'Updated by Super Admin',documents:saved.documents,history:saved.history};this.$nextTick(()=>{new bootstrap.Modal('#leaveModal').show();this.refresh()})},
async handleFiles(event){let files=[...event.target.files];const allowed=['application/pdf','image/jpeg','image/png','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];for(const file of files){if(file.size>10*1024*1024){toast(file.name+' exceeds 10 MB');continue}if(file.type&&!allowed.includes(file.type)){toast(file.name+' is not an allowed file type');continue}try{let data=await this.fileToDataURL(file);let doc={id:'DOC-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),name:file.name,size:file.size,type:file.type,data,addedAt:new Date().toLocaleString()};this.form.documents.push(doc);this.recordHistory('Uploaded',doc)}catch(e){toast('Could not read '+file.name)}}event.target.value='';this.syncDocuments();this.refresh();toast(files.length+' document(s) processed')},
fileToDataURL(file){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)})},
formatBytes(bytes){if(!bytes)return '0 B';let u=['B','KB','MB','GB'],i=Math.floor(Math.log(bytes)/Math.log(1024));return (bytes/Math.pow(1024,i)).toFixed(i?1:0)+' '+u[i]},
previewDocument(doc){let win=window.open('','_blank','width=1000,height=800');if(!win){toast('Please allow pop-ups to preview documents');return}let isImage=/^image\//.test(doc.type);let isPdf=doc.type==='application/pdf';if(isImage){win.document.write('<title>Document Preview</title><body style="margin:0;background:#111;display:grid;place-items:center;min-height:100vh"><img src="'+doc.data+'" style="max-width:100%;max-height:100vh;object-fit:contain"></body>')}else if(isPdf){win.document.write('<title>Document Preview</title><iframe src="'+doc.data+'" style="border:0;width:100%;height:100vh"></iframe>')}else{win.document.write('<title>Document Preview</title><div style="font-family:Arial;padding:40px;text-align:center"><h2>Preview unavailable</h2><p>'+doc.name+'</p><p>This file type can be downloaded and opened in its native application.</p><a href="'+doc.data+'" download="'+doc.name+'">Download document</a></div>')}win.document.close()},
downloadDocument(doc){let a=document.createElement('a');a.href=doc.data;a.download=doc.name;document.body.appendChild(a);a.click();a.remove();toast('Document downloaded')},
deleteDocument(id){let doc=this.form.documents.find(x=>x.id===id);if(!doc)return;if(confirm('Delete document "'+doc.name+'"?')){this.form.documents=this.form.documents.filter(x=>x.id!==id);this.recordHistory('Deleted',doc);this.syncDocuments();this.refresh();toast('Document deleted')}},
saveApplication(){if(!this.form.staff||!this.form.from||!this.form.to){toast('Please complete Staff, From and To fields');return}if(new Date(this.form.to)<new Date(this.form.from)){toast('To date cannot be before From date');return}let key=this.editId||('APP-'+this.form.staff+'-'+Date.now());let store=this._docStore();store[key]={documents:this.form.documents,history:this.form.history,staff:this.form.staff,type:this.form.type,from:this.form.from,to:this.form.to,status:this.form.status,note:this.form.note,updatedAt:new Date().toLocaleString()};localStorage.setItem(this.storageKey,JSON.stringify(store));toast(this.editing?'Leave application updated':'Leave application created');let modal=bootstrap.Modal.getInstance(document.getElementById('leaveModal'));if(modal)modal.hide()},
remove(id){let r=this.staff.find(x=>x.id===id);if(confirm('Delete leave tracker record for '+r.name+'? This frontend demo uses soft confirmation only.')){this.staff=this.staff.filter(x=>x.id!==id);toast('Record deleted')}},
exportRows(){return this.filtered().map((r,i)=>{let q={};this.leaveTypes.forEach(t=>{let x=this.leaveSummary(r.id,t);q[t+' Allocated']=x.allocated;q[t+' Taken']=x.taken;q[t+' Balance']=x.balance});return Object.assign({SL:i+1,'Staff Name':r.name,ID:r.id,Department:r.department,Designation:r.designation,Allocated:r.allocated,Taken:r.taken,Pending:r.pending,Balance:r.balance,Approved:r.approved,Rejected:r.rejected},q)})},
downloadCSV(){let rows=this.exportRows(),head=Object.keys(rows[0]||{});let csv=[head.join(','),...rows.map(r=>head.map(h=>`"${String(r[h]??'').replaceAll('"','""')}"`).join(','))].join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='staff-leave-tracker-2026.csv';a.click();toast('CSV downloaded')},
downloadExcel(){let ws=XLSX.utils.json_to_sheet(this.exportRows()),wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Leave Tracker');XLSX.writeFile(wb,'staff-leave-tracker-2026.xlsx');toast('Excel downloaded')},
downloadPDF(){let {jsPDF}=window.jspdf,doc=new jsPDF('l','mm','a4');doc.setFontSize(16);doc.text(this.viewTitle(),14,15);doc.setFontSize(9);doc.text('MIS Department • Year '+this.filters.year,14,21);doc.autoTable({startY:26,head:[['SL','Staff Name','ID','Department','Designation','Allocated','Taken','Pending','Balance','Approved','Rejected']],body:this.exportRows().map(r=>[r.SL,r['Staff Name'],r.ID,r.Department,r.Designation,r.Allocated,r.Taken,r.Pending,r.Balance,r.Approved,r.Rejected]),styles:{fontSize:7}});doc.save('staff-leave-tracker-2026.pdf');toast('PDF downloaded')}}
}
function printReport(){window.print()}
function syncLeaveDepartments(){const el=document.getElementById('leaveDepartmentFilter');if(!el)return;const deps=MIS_getDepartments();const current=el.value;el.innerHTML='<option value=\"\">All</option>'+deps.filter(d=>d.status!=='Inactive').map(d=>'<option value=\"'+String(d.name).replaceAll('\"','&quot;')+'\">'+String(d.name).replaceAll('<','&lt;')+'</option>').join('');el.value=current}
syncLeaveDepartments();window.addEventListener('storage',e=>{if(e.key===MIS_SHARED_KEYS.departments)syncLeaveDepartments()});</script></body></html><?php /**PATH /app/applet/resources/views/leave-management/index.blade.php ENDPATH**/ ?>