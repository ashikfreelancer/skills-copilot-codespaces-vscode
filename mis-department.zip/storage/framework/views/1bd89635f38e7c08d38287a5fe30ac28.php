<!DOCTYPE html>

<html lang="en"><head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script><meta charset="utf-8"/><meta content="width=device-width,initial-scale=1" name="viewport"/>
<title>Data Quality | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','system-ui','sans-serif']}}}}
</script>
<script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hammerjs@2.0.8/hammer.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>
<link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet"/><script src="<?php echo e(asset('assets/js/app.js')); ?>"></script></head>
<script>if(typeof MIS_requireAuth==="function")MIS_requireAuth();</script>
<body data-page="data-quality">
<div class="container-fluid"><div class="row g-0">
<aside class="col-lg-2 desktop-sidebar sidebar p-3">
<div class="d-flex align-items-center gap-2 px-2 py-2 mb-2"><div class="bg-white rounded-3 p-2"><i class="text-primary" data-lucide="database"></i></div><div class="text-white fw-bold">MIS Management</div></div>
<div class="text-slate-400 px-2 small mb-3">Management Information System</div><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a>
</aside>
<main class="col-lg-10">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3"><button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button><div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Data Quality</h1></div></div>
<div class="d-flex align-items-center gap-2"><button class="btn btn-light" onclick="printPage()"><i data-lucide="printer"></i></button><button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button><div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div></div>
</header>
<div class="p-3 p-lg-4"><div class="mb-4"><h2 class="page-title h3">Data Quality</h2><p class="muted">Identify missing, duplicate, inconsistent and outdated MIS records.</p></div>
<div class="row g-3 mb-3"><div class="col-md-3"><div class="cardx stat"><div class="muted small">Completeness</div><div class="kpi">96.8%</div></div></div><div class="col-md-3"><div class="cardx stat"><div class="muted small">Duplicates</div><div class="kpi">17</div></div></div><div class="col-md-3"><div class="cardx stat"><div class="muted small">Missing Fields</div><div class="kpi">82</div></div></div><div class="col-md-3"><div class="cardx stat"><div class="muted small">Outdated</div><div class="kpi">34</div></div></div></div>
<div class="cardx p-3"><div class="table-responsive responsive-table"><table class="table"><thead><tr><th>Record</th><th>Issue</th><th>Field</th><th>Priority</th><th>Action</th></tr></thead><tbody><tr><td>TMSS-002</td><td>Missing date</td><td>Promotion Date</td><td><span class="badge bg-danger">High</span></td><td><button class="btn btn-sm btn-primary">Correct</button></td></tr><tr><td>Branch-017</td><td>Duplicate code</td><td>Branch Code</td><td><span class="badge bg-warning text-dark">Medium</span></td><td><button class="btn btn-sm btn-primary">Review</button></td></tr></tbody></table></div></div>
</div>
</main></div></div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body"><div class="group-title">MAIN</div><a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard" style="width:18px"></i>Dashboard</a><a data-nav="location-branch" href="/location-branch"><i data-lucide="map" style="width:18px"></i>Location &amp; Branch</a><a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="user-round-cog" style="width:18px"></i>Domain &amp; Zone Head Information</a><a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users" style="width:18px"></i>Staff Position List</a><a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days" style="width:18px"></i>Leave Management</a><a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line" style="width:18px"></i>MIS Data Entry</a><a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart" style="width:18px"></i>MIS Reports</a><a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check" style="width:18px"></i>Data Quality</a><a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined" style="width:18px"></i>Analytics</a><div class="group-title">DOCUMENTS &amp; FINANCE</div><a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open" style="width:18px"></i>Note &amp; Document Cabinet</a><a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet" style="width:18px"></i>Advance Management</a><a data-nav="target-activity" href="/target-activity"><i data-lucide="target" style="width:18px"></i>Target &amp; Activity</a><div class="group-title">OPERATIONS</div><a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor" style="width:18px"></i>Monitoring</a><a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox" style="width:18px"></i>Report Requests</a><a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet" style="width:18px"></i>Excel Import / Export</a><div class="group-title">SYSTEM</div><a data-nav="notifications" href="/notifications"><i data-lucide="bell" style="width:18px"></i>Notifications</a><a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog" style="width:18px"></i>Users &amp; Permissions</a><a data-nav="audit-log" href="/audit-log"><i data-lucide="history" style="width:18px"></i>Audit Log</a><a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings" style="width:18px"></i>Backup &amp; Settings</a></div></div>
<div class="toast position-fixed bottom-0 end-0 m-3" id="toast"><div class="toast-body">Saved</div></div>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<div aria-hidden="true" class="modal fade" id="checkedFormModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable">
<div class="modal-content border-0 shadow">
<div class="modal-header bg-primary text-white">
<div><h5 class="modal-title">Create / Update Data Quality</h5><small>Unique professional form</small></div>
<button class="btn-close btn-close-white" data-bs-dismiss="modal" type="button"></button>
</div>
<form onsubmit="event.preventDefault(); alert('Demo form saved successfully'); bootstrap.Modal.getInstance(document.getElementById('checkedFormModal')).hide();">
<div class="modal-body"><div class="row g-3"><div class="col-md-6"><label class="form-label fw-semibold">Validation Error</label><input class="form-control" placeholder="Error Description" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Related Module / Report</label><input class="form-control" placeholder="Module or Report" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Previous Value</label><input class="form-control" placeholder="Previous Value" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">New / Correct Value</label><input class="form-control" placeholder="Correct Value" type="text"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Correction Reason</label><textarea class="form-control" placeholder="Reason" rows="3"></textarea></div>
<div class="col-md-6"><label class="form-label fw-semibold">Correction Date</label><input class="form-control" placeholder="" type="date"/></div>
<div class="col-md-6"><label class="form-label fw-semibold">Status</label><select class="form-select"><option value="">Select</option><option>Pending</option><option>Corrected</option><option>Verified</option></select></div></div></div>
<div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal" type="button">Cancel</button><button class="btn btn-primary" type="submit">Save</button></div>
</form>
</div>
</div>
</div>
<script>document.addEventListener('shown.bs.modal',()=>{if(window.lucide) lucide.createIcons();});</script>
</body></html><?php /**PATH /app/applet/resources/views/data-quality/index.blade.php ENDPATH**/ ?>