<!DOCTYPE html>

<html lang="bn">
<head>
<script>try{if(typeof window!=='undefined'&&window.fetch){let _f=window.fetch;const d=Object.getOwnPropertyDescriptor(window,'fetch')||(typeof Window!=='undefined'&&Object.getOwnPropertyDescriptor(Window.prototype,'fetch'));if(!d||d.set===undefined){try{Object.defineProperty(window,'fetch',{get(){return _f;},set(v){_f=v;},configurable:true,enumerable:true});}catch(e){}}}}catch(e){}</script>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<title>ডোমেইন ও জোন প্রধানের তথ্য | MIS Department</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet"/>
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap');
:root{--ink:#111;--grid:#333;--head:#c7c7c7}
body{background:#f3f5f7;font-family:"Noto Sans Bengali",Arial,sans-serif;color:#111}
.page-wrap{padding:24px}
.cardx{background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.05)}
.toolbar{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:14px}
.report-sheet{background:#fff;max-width:1180px;margin:0 auto;padding:28px 26px 36px;border:1px solid #ddd}
.report-header{text-align:center;position:relative;margin-bottom:10px}
.report-logo{position:absolute;left:0;top:0;width:82px;height:82px;object-fit:contain}
.report-header .org{font-size:23px;font-weight:700;line-height:1.2}
.report-header .sub{font-size:20px;font-weight:700;line-height:1.25}
.report-header .office{font-size:15px;font-weight:600;margin-top:2px}
.report-caption{font-size:17px;font-weight:600;text-align:center;margin:8px 0 12px}
.report-table{width:100%;border-collapse:collapse;table-layout:fixed}
.report-table th,.report-table td{border:1px solid var(--grid);padding:5px 6px;text-align:center;vertical-align:middle;font-size:13px;line-height:1.25}
.report-table thead th{background:var(--head);font-weight:700}
.report-table thead tr:first-child th{font-size:13px}
.report-table .operation-row td{background:#bcbcbc;font-weight:600}
.report-table .email{font-family:Georgia,"Times New Roman",serif;font-weight:700;word-break:break-word}
.report-table .comment{text-align:left;word-break:break-word}
.report-table .zone{text-align:left}
.report-table .head{text-align:left}
.report-table .sl{width:5%}.report-table .zonecol{width:12%}.report-table .namecol{width:17%}.report-table .desigcol{width:7%}.report-table .idcol{width:11%}.report-table .mobilecol{width:13%}.report-table .emailcol{width:31%}.report-table .commentcol{width:4%}
.action-cell{white-space:nowrap}
.badge-status{font-size:10px}
.print-only{display:none}
@media(max-width:991px){
 .report-sheet{padding:18px 10px}.report-logo{position:static;display:block;margin:0 auto 6px}.report-header .org{font-size:20px}.report-header .sub{font-size:18px}
 .report-table{min-width:980px}.table-scroll{overflow:auto}
}
@media print{
 @page{size:A4 portrait;margin:8mm}
 body{background:#fff!important}
 .sidebar,.topbar,.toolbar,.stats-row,.no-print,.action-cell,.print-hide{display:none!important}
 main{margin:0!important;width:100%!important}
 .page-wrap{padding:0!important}
 .report-sheet{max-width:none;border:0;box-shadow:none;padding:0;background:#fff}
 .print-only{display:block}
 .report-logo{width:72px;height:72px}
 .report-header .org{font-size:19px}.report-header .sub{font-size:18px}.report-header .office{font-size:12px}
 .report-caption{font-size:13px;margin:5px 0 8px}
 .report-table th,.report-table td{font-size:9px;padding:3px 4px}
 .report-table thead{display:table-header-group}
 tr{break-inside:avoid}
}
</style>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script></head>
<body data-page="domain-zone-management">
<div class="container-fluid">
<aside class="sidebar d-none d-lg-block position-fixed top-0 bottom-0 start-0" style="width:260px;z-index:10">
<div class="p-3 text-white fw-bold fs-5">MIS Management</div>
<div class="px-2">
<div class="group-title">MAIN</div>
<a data-nav="dashboard" href="/dashboard"><i data-lucide="layout-dashboard"></i> Dashboard</a>
<a data-nav="domain-zone-management" href="/domain-zone-management"><i data-lucide="map"></i> Domain &amp; Zone Head Information</a>
<a data-nav="staff-position-list" href="/staff-position-list"><i data-lucide="users"></i> Staff Position List</a>
<a data-nav="leave-management" href="/leave-management"><i data-lucide="calendar-days"></i> Leave Management</a>
<a data-nav="mis-data-entry" href="/mis-data-entry"><i data-lucide="clipboard-pen-line"></i> MIS Data Entry</a>
<a data-nav="reports" href="/reports"><i data-lucide="file-bar-chart"></i> MIS Reports</a>
<a data-nav="data-quality" href="/data-quality"><i data-lucide="shield-check"></i> Data Quality</a>
<a data-nav="analytics" href="/analytics"><i data-lucide="chart-no-axes-combined"></i> Analytics</a>
<div class="group-title">DOCUMENTS &amp; FINANCE</div>
<a data-nav="note-document-cabinet" href="/note-document-cabinet"><i data-lucide="folder-open"></i> Note &amp; Document Cabinet</a>
<a data-nav="advance-management" href="/advance-management"><i data-lucide="wallet"></i> Advance Management</a>
<a data-nav="target-activity" href="/target-activity"><i data-lucide="target"></i> Target &amp; Activity</a>
<div class="group-title">OPERATIONS</div>
<a data-nav="monitoring" href="/monitoring"><i data-lucide="monitor"></i> Monitoring</a>
<a data-nav="report-requests" href="/report-requests"><i data-lucide="inbox"></i> Report Requests</a>
<a data-nav="excel-import-export" href="/excel-import-export"><i data-lucide="file-spreadsheet"></i> Excel Import / Export</a>
<div class="group-title">SYSTEM</div>
<a data-nav="notifications" href="/notifications"><i data-lucide="bell"></i> Notifications</a>
<a data-nav="users-permissions" href="/users-permissions"><i data-lucide="user-cog"></i> Users &amp; Permissions</a>
<a data-nav="audit-log" href="/audit-log"><i data-lucide="history"></i> Audit Log</a>
<a data-nav="backup-settings" href="/backup-settings"><i data-lucide="settings"></i> Backup &amp; Settings</a>
</div>
</aside>
<main class="offset-lg-3 col-lg-9">
<header class="topbar d-flex align-items-center justify-content-between px-3 px-lg-4">
<div class="d-flex align-items-center gap-3">
<button class="btn btn-light d-lg-none" data-bs-target="#mobileNav" data-bs-toggle="offcanvas"><i data-lucide="menu"></i></button>
<div><div class="small muted">MIS Department</div><h1 class="h5 mb-0 fw-bold">Domain &amp; Zone Management</h1></div>
</div>
<div class="d-flex align-items-center gap-2 no-print">
<button class="btn btn-light" onclick="printPage()" title="Print"><i data-lucide="printer"></i></button>
<button class="btn btn-light" onclick="MIS_logout()" title="Logout"><i data-lucide="log-out"></i></button>
<div class="rounded-circle bg-primary text-white d-grid place-items-center" style="width:38px;height:38px">A</div>
</div>
</header>
<div class="page-wrap">
<div class="d-flex justify-content-between align-items-center mb-3 no-print">
<div>
<h2 class="h4 fw-bold mb-1">ডোমেইন ও জোন প্রধানের তথ্য</h2>
<p class="text-secondary mb-0">প্রদত্ত Book1 রিপোর্টের সকল ১৩টি ডোমেইন/অপারেশন ও ৫৪টি জোনের তথ্য। Location &amp; Branch মডিউল অপরিবর্তিত।</p>
</div>
<div class="d-flex gap-2 flex-wrap">
<button class="btn btn-outline-success" onclick="downloadCSV()"><i data-lucide="download"></i> Download</button>
<button class="btn btn-outline-secondary" onclick="printPage()"><i data-lucide="printer"></i> Print</button>
<button class="btn btn-primary" onclick="openAdd()"><i data-lucide="plus"></i> Add Information</button>
</div>
</div>
<div class="row g-3 stats-row no-print mb-3">
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">মোট তথ্য</div><div class="fs-3 fw-bold" id="totalCount">0</div></div></div>
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">জোন প্রধান</div><div class="fs-3 fw-bold" id="zoneHeadCount">0</div></div></div>
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">ডোমেইন প্রধান</div><div class="fs-3 fw-bold" id="domainHeadCount">0</div></div></div>
<div class="col-md-3"><div class="cardx p-3"><div class="text-secondary small">Active</div><div class="fs-3 fw-bold text-success" id="activeCount">0</div></div></div>
</div>
<div class="toolbar no-print mb-3">
<div class="row g-2">
<div class="col-md-3"><label class="small fw-bold">ডোমেইন</label><select class="form-select" id="filterDomain"><option value="">সব ডোমেইন</option></select></div>
<div class="col-md-3"><label class="small fw-bold">জোন</label><select class="form-select" id="filterZone"><option value="">সব জোন</option></select></div>
<div class="col-md-2"><label class="small fw-bold">প্রধানের ধরন</label><select class="form-select" id="filterType"><option value="">সব</option><option value="Zone Head">জোন প্রধান</option><option value="Domain Head">ডোমেইন প্রধান</option></select></div>
<div class="col-md-2"><label class="small fw-bold">স্ট্যাটাস</label><select class="form-select" id="filterStatus"><option value="">সব</option><option>Active</option><option>Inactive</option></select></div>
<div class="col-md-2"><label class="small fw-bold">Search</label><input class="form-control" id="searchBox" placeholder="নাম / ID / মোবাইল / ইমেল"/></div>
</div>
</div>
<section class="report-sheet" id="reportSheet">
<div class="report-header">
<img alt="TMSS" class="report-logo" src="<?php echo e(asset('assets/images/tmss-logo.png')); ?>"/>
<div class="org">টিএমএসএস</div>
<div class="sub">HEM Grand Sector</div>
<div class="sub">MIS দপ্তর</div>
<div class="office">প্রধান কার্যালয়, ঢাকা।</div>
</div>
<div class="report-caption">ডোমেইনের নাম, জোনের নাম, ডোমেইন প্রধানের, জোন প্রধানের নাম ও মোবাইল নম্বর ।</div>
<div class="table-scroll">
<div class="table-responsive responsive-table"><table class="report-table" id="domainZoneTable">
<colgroup>
<col class="sl"/><col class="zonecol"/><col class="namecol"/><col class="desigcol"/><col class="idcol"/><col class="mobilecol"/><col class="emailcol"/><col class="commentcol"/>
</colgroup>
<thead>
<tr>
<th rowspan="2">ক্রঃ<br/>নং</th>
<th rowspan="2">জোনের নাম</th>
<th colspan="4">দায়িত্বপ্রাপ্ত জোন প্রধানের</th>
<th rowspan="2">জোনের ই-মেইল ঠিকানা</th>
<th rowspan="2">মন্তব্য</th>
</tr>
<tr>
<th>নাম</th><th>পদবী</th><th>আইডি নম্বর</th><th>মোবাইল নং</th>
</tr>
<tr class="print-hide no-print">
<th>১</th><th>২</th><th>৩</th><th>৪</th><th>৫</th><th>৬</th><th>৭</th><th>৮</th>
</tr>
</thead>
<tbody id="tableBody"></tbody>
</table></div>
</div>
</section>
</div>
</main>
</div>
<div class="modal fade" id="entryModal" tabindex="-1">
<div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
<div class="modal-header"><div><h5 class="modal-title fw-bold" id="modalTitle">Add Domain / Zone Head</h5><div class="small text-secondary">রিপোর্টের প্রতিটি ঘরের তথ্য এখানে সংরক্ষণ করা যাবে।</div></div><button class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
<form id="entryForm">
<input id="editId" type="hidden"/>
<div class="row g-3">
<div class="col-md-4"><label class="form-label fw-semibold">ডোমেইনের নাম</label><input class="form-control" id="domain" placeholder="যেমন: HEM Grand Sector" required=""/></div>
<div class="col-md-4"><label class="form-label fw-semibold">জোনের নাম</label><input class="form-control" id="zone" placeholder="যেমন: বগুড়া কেন্দ্রীয়" required=""/></div>
<div class="col-md-4"><label class="form-label fw-semibold">প্রধানের ধরন</label><select class="form-select" id="headType"><option value="Zone Head">জোন প্রধান</option><option value="Domain Head">ডোমেইন প্রধান</option></select></div>
<div class="col-md-6"><label class="form-label fw-semibold">প্রধানের নাম</label><input class="form-control" id="headName" required=""/></div>
<div class="col-md-3"><label class="form-label fw-semibold">পদবী</label><input class="form-control" id="designation" placeholder="ZM / AM / AD" required=""/></div>
<div class="col-md-3"><label class="form-label fw-semibold">আইডি নম্বর</label><input class="form-control" id="employeeId" required=""/></div>
<div class="col-md-4"><label class="form-label fw-semibold">মোবাইল নং</label><input class="form-control" id="mobile" required=""/></div>
<div class="col-md-5"><label class="form-label fw-semibold">জোনের ই-মেইল ঠিকানা</label><input class="form-control" id="email" type="email"/></div>
<div class="col-md-3"><label class="form-label fw-semibold">স্ট্যাটাস</label><select class="form-select" id="status"><option>Active</option><option>Inactive</option></select></div>
<div class="col-md-8"><label class="form-label fw-semibold">ঠিকানা</label><textarea class="form-control" id="address" rows="2"></textarea></div>
<div class="col-md-4"><label class="form-label fw-semibold">মন্তব্য</label><textarea class="form-control" id="remarks" rows="2"></textarea></div>
</div>
</form>
</div>
<div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveEntry()"><i data-lucide="save"></i> <span id="saveText">Save</span></button></div>
</div></div>
</div>
<div class="offcanvas offcanvas-start sidebar" id="mobileNav" tabindex="-1"><div class="offcanvas-header text-white"><b>MIS Management</b><button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body">
<a href="/dashboard">Dashboard</a><a href="/domain-zone-management">Domain &amp; Zone Head Information</a><a href="/location-branch">Location &amp; Branch</a><a href="/staff-position-list">Staff Position List</a><a href="/reports">MIS Reports</a>
</div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script>
const STORAGE='mis_domain_zone_report_v3';
const seed=[
 {id:'OP-001',domain:'অপারেশন-০১',zone:'',headType:'Domain Head',headName:'মোঃ সাজ্জাদুর রহমান',designation:'JD',employeeId:'101-0141',mobile:'01713-377266',email:'hemop1@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-001',domain:'অপারেশন-০১',zone:'বগুড়া কেন্দ্রীয়',headType:'Zone Head',headName:'মোঃ ইসহাক আলী',designation:'ZM',employeeId:'101-04678',mobile:'01713-377178',email:'zhbogcentral@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-002',domain:'অপারেশন-০১',zone:'বগুড়া উত্তর',headType:'Zone Head',headName:'মোঃ মোয়াজ্জেম হোসেন',designation:'ZM',employeeId:'101-352',mobile:'01713-377250',email:'zhbognorth@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-003',domain:'অপারেশন-০১',zone:'বগুড়া দক্ষিণ',headType:'Zone Head',headName:'মোঃ সাজ্জাদ হোসেন',designation:'AD',employeeId:'101-7937',mobile:'01713-377032',email:'zhbograsouth@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-004',domain:'অপারেশন-০১',zone:'দরগাহাট',headType:'Zone Head',headName:'সেলিম আহমেদ ফকির',designation:'ZM',employeeId:'101-02990',mobile:'01711-436657',email:'zhdorgahat@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-002',domain:'অপারেশন-০২',zone:'',headType:'Domain Head',headName:'এস এম বাবুল',designation:'AD',employeeId:'101-00301',mobile:'01777-798043',email:'hemop2@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-005',domain:'অপারেশন-০২',zone:'ঢাকা',headType:'Zone Head',headName:'মোঃ কামরুল ইসলাম',designation:'AM',employeeId:'101-8468',mobile:'01713-377185',email:'tmssdhakazone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-006',domain:'অপারেশন-০২',zone:'নারায়ণগঞ্জ',headType:'Zone Head',headName:'মোঃ জাহাঙ্গীর আলম',designation:'ZM',employeeId:'101-40236',mobile:'01730-006938',email:'tmssdhakasouthzone1234@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-007',domain:'অপারেশন-০২',zone:'সাভার',headType:'Zone Head',headName:'মোঃ ইব্রাহীম খলিল',designation:'ZM',employeeId:'101-3216',mobile:'01313-092837',email:'tmsssavarzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-008',domain:'অপারেশন-০২',zone:'নরসিংদী',headType:'Zone Head',headName:'মোঃ আল আমিন',designation:'AM',employeeId:'101-02877',mobile:'01713-377169',email:'narsingdizone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-003',domain:'অপারেশন-০৩',zone:'',headType:'Domain Head',headName:'মোঃ ওসমান গনি',designation:'DD',employeeId:'101-15276',mobile:'01708-491238',email:'hemop3@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-009',domain:'অপারেশন-০৩',zone:'রাজশাহী',headType:'Zone Head',headName:'মোঃ চারোয়ার জাহান',designation:'ZM',employeeId:'101-4722',mobile:'01713-377258',email:'zhrajshahi@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-010',domain:'অপারেশন-০৩',zone:'চাঁপাইনবাবগঞ্জ',headType:'Zone Head',headName:'নিখিল চন্দ্র চক্রবর্তী',designation:'ZM',employeeId:'101-3688',mobile:'01713-377241',email:'zhchapai@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-011',domain:'অপারেশন-০৩',zone:'নওগাঁ জোন',headType:'Zone Head',headName:'মোঃ ইউনুছ আলী',designation:'ZM',employeeId:'101-01941',mobile:'01713-377171',email:'zhnaogaon@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-012',domain:'অপারেশন-০৩',zone:'পুঠিয়া',headType:'Zone Head',headName:'মোঃ আজিজুল হক (আজিজ)',designation:'ZM',employeeId:'101-2685',mobile:'01713-377352',email:'zhputhia@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-004',domain:'অপারেশন-০৪',zone:'',headType:'Domain Head',headName:'মোহাম্মদ শাহীন মিয়া',designation:'AD',employeeId:'101-21036',mobile:'01730-735953',email:'hemop4@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-013',domain:'অপারেশন-০৪',zone:'গাইবান্ধা',headType:'Zone Head',headName:'মোঃ মাকসুদুর রহমান',designation:'SZM',employeeId:'101-968',mobile:'01713-377159',email:'zhgaibandha@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-014',domain:'অপারেশন-০৪',zone:'রংপুর জোন',headType:'Zone Head',headName:'মোঃ ময়নুল হক প্রধান',designation:'ZM',employeeId:'101-3681',mobile:'01713-377157',email:'zhrangpur@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-015',domain:'অপারেশন-০৪',zone:'কুড়িগ্রাম',headType:'Zone Head',headName:'মোঃ আব্দুর রশিদ',designation:'ZM',employeeId:'101-2367',mobile:'01713-377257',email:'zhkurigram@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-016',domain:'অপারেশন-০৪',zone:'লালমনিরহাট',headType:'Zone Head',headName:'মোঃ সাইদুর রহমান',designation:'ZM',employeeId:'101-1408',mobile:'01713-377210',email:'zhlalmoni@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-005',domain:'অপারেশন-০৫',zone:'',headType:'Domain Head',headName:'মোঃ আব্দুর রাজ্জাক',designation:'DD',employeeId:'101-00747',mobile:'01713-377195',email:'hemop5@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-017',domain:'অপারেশন-০৫',zone:'চট্টগ্রাম উত্তর',headType:'Zone Head',headName:'মোঃ মোক্তাদিয়ার রহমান',designation:'AM',employeeId:'101-2305',mobile:'01709-646514',email:'ctgnorthzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-018',domain:'অপারেশন-০৫',zone:'চট্টগ্রাম দক্ষিণ',headType:'Zone Head',headName:'মোঃ মামুনুর রশিদ',designation:'ZM',employeeId:'101-3307',mobile:'01713-377189',email:'tmssctgsouthzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-019',domain:'অপারেশন-০৫',zone:'সাতকানিয়া',headType:'Zone Head',headName:'মোঃ আল মামুন সরকার',designation:'ZM',employeeId:'101-1689',mobile:'01704-124104',email:'tmsssatkaniazone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-020',domain:'অপারেশন-০৫',zone:'ফেনী',headType:'Zone Head',headName:'মোঃ গোলাম মোস্তফা',designation:'ZM',employeeId:'101-02398',mobile:'01755-588923',email:'tmssfenizone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-021',domain:'অপারেশন-০৫',zone:'নোয়াখালী',headType:'Zone Head',headName:'মোঃ মজিবুর রহমান',designation:'AM',employeeId:'101-12672',mobile:'01713-377279',email:'tmssnoakhalizone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'OP-006',domain:'অপারেশন-০৬',zone:'',headType:'Domain Head',headName:'মনিরুল গনি চৌধুরী',designation:'DD',employeeId:'101-40237',mobile:'01313-377092',email:'hemop6@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-022',domain:'অপারেশন-০৬',zone:'সাতক্ষীরা',headType:'Zone Head',headName:'মোঃ আব্দুল বারিক',designation:'AM',employeeId:'101-0344',mobile:'01708-491200',email:'satkhirazone2016@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-023',domain:'অপারেশন-০৬',zone:'যশোর',headType:'Zone Head',headName:'মোঃ হারুনুর রশিদ',designation:'ZM',employeeId:'101-5285',mobile:'01713-377190',email:'tmssjessorezone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-024',domain:'অপারেশন-০৬',zone:'খুলনা',headType:'Zone Head',headName:'মোঃ ইকবাল হোসেন',designation:'SZM',employeeId:'101-00644',mobile:'01713-377275',email:'zhkhulnazone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-025',domain:'অপারেশন-০৬',zone:'কুষ্টিয়া',headType:'Zone Head',headName:'মোঃ মাহবুবুর রহমান',designation:'ZM',employeeId:'101-314',mobile:'01709-646565',email:'tmsskustiazone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'OP-007',domain:'অপারেশন-০৭',zone:'',headType:'Domain Head',headName:'ওয়াকিল আহমেদ',designation:'AD',employeeId:'101-10567',mobile:'01713-377303',email:'hemop7@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-026',domain:'অপারেশন-০৭',zone:'মৌলভীবাজার',headType:'Zone Head',headName:'মোঃ রফিকুল ইসলাম',designation:'ZM',employeeId:'101-1656',mobile:'01730-735950',email:'moulvibazarzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-027',domain:'অপারেশন-০৭',zone:'সিলেট',headType:'Zone Head',headName:'মোঃ সেলিম রেজা',designation:'ZM',employeeId:'101-26985',mobile:'01713-377198',email:'sylhetzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-028',domain:'অপারেশন-০৭',zone:'বিয়ানীবাজার',headType:'Zone Head',headName:'মোঃ আজিজুল হক',designation:'ZM',employeeId:'101-02974',mobile:'01755-588999',email:'beanibazarzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-029',domain:'অপারেশন-০৭',zone:'হবিগঞ্জ',headType:'Zone Head',headName:'মোঃ শাহানুর আলম',designation:'AM',employeeId:'101-05094',mobile:'01730-316078',email:'habiganjzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-030',domain:'অপারেশন-০৭',zone:'সুনামগঞ্জ',headType:'Zone Head',headName:'মোঃ আবুল হাসেম',designation:'ZM',employeeId:'101-5302',mobile:'01713-377123',email:'sunamganjzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-008',domain:'অপারেশন-০৮',zone:'',headType:'Domain Head',headName:'মোঃ গোলাম মোস্তফা',designation:'AD',employeeId:'101-1088',mobile:'01713-377219',email:'hemop8@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-031',domain:'অপারেশন-০৮',zone:'ফরিদপুর',headType:'Zone Head',headName:'আবু বকর সিদ্দিক',designation:'ZM',employeeId:'101-13084',mobile:'01730-735949',email:'faridpurzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-032',domain:'অপারেশন-০৮',zone:'বরিশাল',headType:'Zone Head',headName:'মোঃ আবুল কালাম আজাদ',designation:'ZM',employeeId:'101-0376',mobile:'01755-545692',email:'zhbarisaltmss@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-033',domain:'অপারেশন-০৮',zone:'মাদারীপুর',headType:'Zone Head',headName:'মোঃ মিজানুর রহমান',designation:'ZM',employeeId:'101-11242',mobile:'01725-698957',email:'madaripurzone@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-009',domain:'অপারেশন-০৯',zone:'',headType:'Domain Head',headName:'সাগর কুমার বড়ুয়া',designation:'DD',employeeId:'101-03089',mobile:'01713-377316',email:'hemop9@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-034',domain:'অপারেশন-০৯',zone:'দিনাজপুর',headType:'Zone Head',headName:'মোঃ আহসান হাবিব',designation:'ZM',employeeId:'101-10851',mobile:'01713-377267',email:'dinajpurtmss@yahoo.com',address:'',status:'Active',remarks:''},
 {id:'DZ-035',domain:'অপারেশন-০৯',zone:'সৈয়দপুর',headType:'Zone Head',headName:'মোঃ রুহুল আমিন',designation:'AD',employeeId:'101-02503',mobile:'01730-735937',email:'zhsyedpur@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-036',domain:'অপারেশন-০৯',zone:'ঠাকুরগাঁও',headType:'Zone Head',headName:'মোঃ মাসুদ জাহেদী',designation:'ZM',employeeId:'101-1761',mobile:'01713-377208',email:'zhthakurgaon@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-037',domain:'অপারেশন-০৯',zone:'পঞ্চগড়',headType:'Zone Head',headName:'মোঃ আব্দুল আলীম',designation:'ZM',employeeId:'101-5364',mobile:'01713-377367',email:'zhpancho@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'OP-010',domain:'অপারেশন-১০',zone:'',headType:'Domain Head',headName:'মোঃ মাহবুবুল হাসান',designation:'DD',employeeId:'101-21478',mobile:'01709-642961',email:'hemop10@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-038',domain:'অপারেশন-১০',zone:'লক্ষ্মীপুর',headType:'Zone Head',headName:'কুমুদ কুমার ধর',designation:'ZM',employeeId:'101-8586',mobile:'01709-642990',email:'tmsslaxmipurzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-039',domain:'অপারেশন-১০',zone:'কুমিল্লা পূর্ব',headType:'Zone Head',headName:'মোঃ আতাউর রহমান',designation:'ZM',employeeId:'101-8592',mobile:'01713-377317',email:'tmsscomillaeast@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-040',domain:'অপারেশন-১০',zone:'কুমিল্লা পশ্চিম',headType:'Zone Head',headName:'মোঃ নজরুল ইসলাম',designation:'ZM',employeeId:'101-20824',mobile:'01704-124183',email:'tmsscomillawestzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-041',domain:'অপারেশন-১০',zone:'চাঁদপুর',headType:'Zone Head',headName:'খ.আ.হে মোঃ ছায়েম',designation:'ZM',employeeId:'101-1733',mobile:'01755-588940',email:'tmsschadpur@gmail.com',address:'',status:'Active',remarks:''},
 {id:'OP-011',domain:'অপারেশন-১১',zone:'',headType:'Domain Head',headName:'মোঃ রফিকুল ইসলাম',designation:'AD',employeeId:'101-18522',mobile:'01713-377107',email:'hemop11@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-042',domain:'অপারেশন-১১',zone:'পাবনা',headType:'Zone Head',headName:'আরিফুল ইসলাম',designation:'ZM',employeeId:'101-22155',mobile:'01713-377235',email:'zhpabna@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-043',domain:'অপারেশন-১১',zone:'চাটমোহর',headType:'Zone Head',headName:'মোঃ হানজালাল রহমান',designation:'ZM',employeeId:'101-05047',mobile:'01709-646557',email:'zhchatmohortmss@yahoo.com',address:'',status:'Active',remarks:''},
 {id:'DZ-044',domain:'অপারেশন-১১',zone:'সিরাজগঞ্জ',headType:'Zone Head',headName:'মামুনুর রশিদ মামুন',designation:'ZM',employeeId:'101-2179',mobile:'01713-377172',email:'zhsirajganj@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-045',domain:'অপারেশন-১১',zone:'নাটোর',headType:'Zone Head',headName:'দেব নারায়ণ সাহা',designation:'ZM',employeeId:'101-8874',mobile:'01713-377182',email:'zhnatoretmss@yahoo.com',address:'',status:'Active',remarks:''},
 {id:'OP-012',domain:'অপারেশন-১২',zone:'',headType:'Domain Head',headName:'মোঃ আনোয়ার হোসেন',designation:'AD',employeeId:'101-0247',mobile:'01713-377281',email:'hemop12@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-046',domain:'অপারেশন-১২',zone:'গাজীপুর',headType:'Zone Head',headName:'মোঃ আব্দুল কাদের',designation:'ZM',employeeId:'101-5943',mobile:'01713-377179',email:'gazipurzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-047',domain:'অপারেশন-১২',zone:'টাঙ্গাইল',headType:'Zone Head',headName:'মোঃ কাছেদুল জান্নাত',designation:'ZM',employeeId:'101-09388',mobile:'01713-377013',email:'tmsstangailzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-048',domain:'অপারেশন-১২',zone:'নেত্রকোনা',headType:'Zone Head',headName:'মোঃ জিয়াউর রহমান',designation:'ZM',employeeId:'101-0593',mobile:'01713-377019',email:'netrokonazonetmss@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-049',domain:'অপারেশন-১২',zone:'জামালপুর',headType:'Zone Head',headName:'মোঃ মাসুদ রানা',designation:'AM',employeeId:'101-05769',mobile:'01709-631075',email:'jamalpurzonetmss@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-050',domain:'অপারেশন-১২',zone:'ময়মনসিংহ',headType:'Zone Head',headName:'মোঃ জাহিদুর রহমান',designation:'AZM',employeeId:'101-3131',mobile:'01713-377158',email:'tmssmymensinghzone@gmail.com',address:'',status:'Active',remarks:''},
 {id:'OP-013',domain:'অপারেশন-১৩',zone:'',headType:'Domain Head',headName:'মোঃ ইসমাইল হোসেন',designation:'AD',employeeId:'101-0858',mobile:'01708-491270',email:'hemop13@tmss-bd.org',address:'প্রধান কার্যালয়, ঢাকা',status:'Active',remarks:''},
 {id:'DZ-051',domain:'অপারেশন-১৩',zone:'জয়পুরহাট',headType:'Zone Head',headName:'মোঃ শহিদুল হাসান',designation:'ZM',employeeId:'101-02863',mobile:'01713-377201',email:'zhjoypur@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-052',domain:'অপারেশন-১৩',zone:'বিরামপুর',headType:'Zone Head',headName:'মোঃ জুয়েল হোসেন',designation:'ZM',employeeId:'101-7772',mobile:'01713-377351',email:'zhbirampur@tmss-bd.org',address:'',status:'Active',remarks:''},
 {id:'DZ-053',domain:'অপারেশন-১৩',zone:'নওজপুর',headType:'Zone Head',headName:'মোঃ মাহবুবুল আলম',designation:'ZM',employeeId:'101-13736',mobile:'01711-869844',email:'zhnozipurtmss@gmail.com',address:'',status:'Active',remarks:''},
 {id:'DZ-054',domain:'অপারেশন-১৩',zone:'পলাশবাড়ী',headType:'Zone Head',headName:'মোঃ দেলোয়ার হোসেন',designation:'ZM',employeeId:'101-399',mobile:'01708-491242',email:'zhpolashbari@tmss-bd.org',address:'',status:'Active',remarks:''}
];
function getRows(){try{const x=JSON.parse(localStorage.getItem(STORAGE));if(Array.isArray(x))return x}catch(e){}localStorage.setItem(STORAGE,JSON.stringify(seed));return seed}
function setRows(r){localStorage.setItem(STORAGE,JSON.stringify(r))}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function refreshFilters(rows){
 const ds=[...new Set(rows.map(x=>x.domain).filter(Boolean))].sort(),zs=[...new Set(rows.map(x=>x.zone).filter(Boolean))].sort();
 const d=document.getElementById('filterDomain'),z=document.getElementById('filterZone'),dv=d.value,zv=z.value;
 d.innerHTML='<option value="">সব ডোমেইন</option>'+ds.map(x=>`<option>${esc(x)}</option>`).join('');
 z.innerHTML='<option value="">সব জোন</option>'+zs.map(x=>`<option>${esc(x)}</option>`).join('');
 d.value=ds.includes(dv)?dv:'';z.value=zs.includes(zv)?zv:'';
}
function render(){
 const rows=getRows(),q=document.getElementById('searchBox').value.toLowerCase().trim(),fd=document.getElementById('filterDomain').value,fz=document.getElementById('filterZone').value,ft=document.getElementById('filterType').value,fs=document.getElementById('filterStatus').value;
 refreshFilters(rows);
 const filtered=rows.filter(x=>(!fd||x.domain===fd)&&(!fz||x.zone===fz)&&(!ft||x.headType===ft)&&(!fs||x.status===fs)&&(!q||Object.values(x).join(' ').toLowerCase().includes(q)));
 document.getElementById('tableBody').innerHTML=filtered.map((x,i)=>{
  const op=x.headType==='Domain Head';
  return `<tr class="${op?'operation-row':''}">
   <td>${i+1}</td>
   <td class="zone">${esc(op ? x.domain : x.zone)}</td>
   <td class="head">${esc(x.headName)}</td>
   <td>${esc(x.designation)}</td>
   <td>${esc(x.employeeId)}</td>
   <td>${esc(x.mobile)}</td>
   <td class="email">${x.email?`<span>${esc(x.email)}</span>`:''}</td>
   <td class="comment">${esc(x.remarks||'')}<div class="no-print action-cell mt-1">
    <button class="btn btn-sm btn-outline-primary py-0 px-1" onclick="editEntry('${x.id}')" title="Edit"><i data-lucide="pencil" style="width:14px"></i></button>
    <button class="btn btn-sm btn-outline-danger py-0 px-1" onclick="deleteEntry('${x.id}')" title="Delete"><i data-lucide="trash-2" style="width:14px"></i></button>
   </div></td>
  </tr>`}).join('');
 document.getElementById('totalCount').textContent=rows.length;
 document.getElementById('zoneHeadCount').textContent=rows.filter(x=>x.headType==='Zone Head').length;
 document.getElementById('domainHeadCount').textContent=rows.filter(x=>x.headType==='Domain Head').length;
 document.getElementById('activeCount').textContent=rows.filter(x=>x.status==='Active').length;
 lucide.createIcons();
}
function openAdd(){
 document.getElementById('entryForm').reset();document.getElementById('editId').value='';
 document.getElementById('status').value='Active';document.getElementById('headType').value='Zone Head';
 document.getElementById('modalTitle').textContent='Add Domain / Zone Head';document.getElementById('saveText').textContent='Save';
 bootstrap.Modal.getOrCreateInstance(document.getElementById('entryModal')).show();
}
function editEntry(id){
 const x=getRows().find(r=>r.id===id);if(!x)return;
 ['domain','zone','headType','headName','designation','employeeId','mobile','email','address','status','remarks'].forEach(k=>document.getElementById(k).value=x[k]||'');
 document.getElementById('editId').value=id;document.getElementById('modalTitle').textContent='Edit Domain / Zone Head';document.getElementById('saveText').textContent='Update';
 bootstrap.Modal.getOrCreateInstance(document.getElementById('entryModal')).show();
}
function saveEntry(){
 const form=document.getElementById('entryForm');if(!form.checkValidity()){form.reportValidity();return}
 const id=document.getElementById('editId').value||('DZ-'+Date.now()),obj={id};
 ['domain','zone','headType','headName','designation','employeeId','mobile','email','address','status','remarks'].forEach(k=>obj[k]=document.getElementById(k).value.trim());
 let rows=getRows(),idx=rows.findIndex(x=>x.id===id);
 if(idx>=0){rows[idx]=obj;if(typeof MIS_addAudit==='function')MIS_addAudit('domain-zone-management','update',id)}else{rows.unshift(obj);if(typeof MIS_addAudit==='function')MIS_addAudit('domain-zone-management','create',id)}
 setRows(rows);render();bootstrap.Modal.getInstance(document.getElementById('entryModal')).hide();
 Swal.fire({icon:'success',title:idx>=0?'Updated':'Saved',text:idx>=0?'তথ্য সফলভাবে আপডেট হয়েছে।':'তথ্য সফলভাবে সংরক্ষণ হয়েছে।',timer:1300,showConfirmButton:false});
}
function deleteEntry(id){
 const x=getRows().find(r=>r.id===id);if(!x)return;
 Swal.fire({icon:'warning',title:'তথ্য মুছে ফেলবেন?',text:`${x.zone} — ${x.headName}`,showCancelButton:true,confirmButtonText:'হ্যাঁ, Delete',cancelButtonText:'Cancel',confirmButtonColor:'#dc2626'}).then(r=>{
  if(r.isConfirmed){setRows(getRows().filter(a=>a.id!==id));if(typeof MIS_addAudit==='function')MIS_addAudit('domain-zone-management','delete',id);render();Swal.fire({icon:'success',title:'Deleted',timer:1100,showConfirmButton:false})}
 })
}
function downloadCSV(){
 const rows=getRows(),h=['SL','Domain','Zone','Head Type','Head Name','Designation','ID Number','Mobile Number','Email Address','Address','Status','Remarks'];
 const lines=[h,...rows.map((x,i)=>[i+1,x.domain,x.zone,x.headType,x.headName,x.designation,x.employeeId,x.mobile,x.email,x.address,x.status,x.remarks])].map(a=>a.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\\n');
 const blob=new Blob(['\\ufeff'+lines],{type:'text/csv;charset=utf-8;'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='domain-zone-head-information.csv';a.click();URL.revokeObjectURL(u);
}
function printPage(){if(typeof MIS_addAudit==='function')MIS_addAudit('domain-zone-management','print','domain-zone-report');window.print()}
['searchBox','filterDomain','filterZone','filterType','filterStatus'].forEach(id=>document.getElementById(id).addEventListener(id==='searchBox'?'input':'change',render));
document.addEventListener('DOMContentLoaded',()=>{if(typeof MIS_requireAuth==='function')MIS_requireAuth();render();lucide.createIcons()});
</script>
</body>
</html>
<?php /**PATH /app/applet/resources/views/domain-zone-management/index.blade.php ENDPATH**/ ?>