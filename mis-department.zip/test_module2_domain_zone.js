// test_module2_domain_zone.js
// Automated verification for Module 2: Domain & Zone Head Information
import http from 'http';

function request(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        let parsed = null;
        try {
          parsed = JSON.parse(body);
        } catch (e) {
          parsed = body;
        }
        resolve({ status: res.statusCode, headers: res.headers, body: parsed });
      });
    });
    req.on('error', reject);
    if (data) {
      req.write(typeof data === 'string' ? data : JSON.stringify(data));
    }
    req.end();
  });
}

async function runTests() {
  console.log('================================================================');
  console.log('TEST SUITE: MODULE 2 - DOMAIN & ZONE HEAD INFORMATION');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  [PASS] ${message}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${message}`);
      failed++;
    }
  }

  // 1. Test routes
  console.log('Step 1: Test routes');
  const routeGet = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/domain-zone-management',
    method: 'GET'
  });
  assert(routeGet.status === 200, 'GET /domain-zone-management returns 200 OK');
  assert(routeGet.body.includes('Domain &amp; Zone Head Information') || routeGet.body.includes('Domain & Zone Head'), 'Blade view rendered successfully');

  // 2. Test controller & initial data
  console.log('\nStep 2: Test controller & initial data query');
  const listRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management',
    method: 'GET',
    headers: { 'Cookie': 'user={"role":"Super Admin"}' }
  });
  assert(listRes.status === 200, 'GET /api/domain-zone-management returns 200');
  assert(listRes.body.success === true, 'API returns success flag');
  assert(Array.isArray(listRes.body.data) && listRes.body.data.length >= 67, `Initial seed loaded in SQLite (found ${listRes.body.data?.length} records)`);
  assert(listRes.body.meta.zone_heads >= 50, `Zone heads counted correctly (${listRes.body.meta?.zone_heads})`);
  assert(listRes.body.meta.domain_heads >= 13, `Domain heads counted correctly (${listRes.body.meta?.domain_heads})`);

  // 3. Test validation
  console.log('\nStep 3: Test validation');
  const invalidRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': 'user={"role":"Super Admin"}'
    }
  }, {
    domain: '',
    head_name: ''
  });
  assert(invalidRes.status === 422, 'POST with missing required fields returns 422 Unprocessable Entity');
  assert(invalidRes.body.error === 'Validation Error', 'Validation error returned properly');

  // 4. Test database & CRUD: CREATE
  console.log('\nStep 4 & 5: Test Database & CRUD (CREATE, READ, VIEW, EDIT, UPDATE, DELETE)');
  const testEmpId = 'EMP-' + Date.now();
  const createPayload = {
    domain: 'অপারেশন-০২',
    zone: 'সাভার টেস্ট জোন',
    head_type: 'Zone Head',
    head_name: 'টেস্ট কর্মকর্তা',
    designation: 'ZM',
    employee_id: testEmpId,
    mobile: '01799-999999',
    email: 'testzh@tmss-bd.org',
    address: 'সাভার, ঢাকা',
    status: 'Active',
    remarks: 'Automated test created entry'
  };

  const createRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, createPayload);

  assert(createRes.status === 201, 'POST /api/domain-zone-management creates record with 201');
  const createdId = createRes.body.data?.id;
  assert(createdId && createdId.startsWith('DZ-'), `Record ID generated correctly: ${createdId}`);

  // READ & VIEW
  const viewRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management/${createdId}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(viewRes.status === 200, 'GET /api/domain-zone-management/:id returns 200');
  assert(viewRes.body.data?.head_name === 'টেস্ট কর্মকর্তা', 'Read exact created head name');
  assert(viewRes.body.data?.employee_id === testEmpId, 'Read exact employee ID');

  // SEARCH & FILTER
  const searchRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management?search=${encodeURIComponent(testEmpId)}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(searchRes.status === 200 && searchRes.body.data?.length === 1, 'Search by employee_id returns 1 match');

  const filterRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management?domain=${encodeURIComponent('অপারেশন-০২')}&head_type=${encodeURIComponent('Zone Head')}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(filterRes.status === 200 && filterRes.body.data?.length >= 1, 'Filter by domain & head_type works');

  // UPDATE
  const updateRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management/${createdId}`,
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, {
    domain: 'অপারেশন-০২',
    zone: 'সাভার টেস্ট জোন (আপডেটেড)',
    head_type: 'Zone Head',
    head_name: 'টেস্ট কর্মকর্তা আপডেটেড',
    designation: 'SZM',
    employee_id: testEmpId,
    mobile: '01799-888888',
    email: 'testzh-updated@tmss-bd.org',
    address: 'সাভার, ঢাকা আপডেটেড',
    status: 'Active',
    remarks: 'Updated remarks'
  });
  assert(updateRes.status === 200, 'PUT /api/domain-zone-management/:id returns 200');
  assert(updateRes.body.data?.head_name === 'টেস্ট কর্মকর্তা আপডেটেড', 'Updated head name verified');
  assert(updateRes.body.data?.mobile === '01799-888888', 'Updated mobile verified');

  // STATUS & APPROVAL
  const statusRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management/${createdId}/status`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { status: 'Inactive' });
  assert(statusRes.status === 200, 'POST /api/domain-zone-management/:id/status updates status');
  assert(statusRes.body.status === 'Inactive', 'Status toggled to Inactive');

  // DELETE
  const deleteRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management/${createdId}`,
    method: 'DELETE',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(deleteRes.status === 200, 'DELETE /api/domain-zone-management/:id returns 200');

  const afterDeleteView = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management/${createdId}`,
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(afterDeleteView.status === 404, 'Deleted record no longer exists (404)');

  // 6. Test permissions & authorization
  console.log('\nStep 6: Test Permissions & Authorization');
  const unauthorizedCreate = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Accountant'
    }
  }, createPayload);
  assert(unauthorizedCreate.status === 403, 'Accountant denied CREATE (403 Forbidden)');

  const unauthorizedDelete = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/domain-zone-management/DZ-001`,
    method: 'DELETE',
    headers: { 'x-user-role': 'Computer Operator' }
  });
  assert(unauthorizedDelete.status === 403, 'Computer Operator denied DELETE (403 Forbidden)');

  // 7. Test UI & HTML Elements
  console.log('\nStep 7: Test UI Elements');
  assert(routeGet.body.includes('id="searchBox"'), 'searchBox input present');
  assert(routeGet.body.includes('id="filterDomain"'), 'filterDomain dropdown present');
  assert(routeGet.body.includes('id="filterZone"'), 'filterZone dropdown present');
  assert(routeGet.body.includes('id="filterType"'), 'filterType dropdown present');
  assert(routeGet.body.includes('id="filterStatus"'), 'filterStatus dropdown present');
  assert(routeGet.body.includes('id="tableBody"'), 'tableBody present');
  assert(routeGet.body.includes('id="entryModal"'), 'entryModal present');
  assert(routeGet.body.includes('id="viewModal"'), 'viewModal present');
  assert(routeGet.body.includes('downloadCSV'), 'CSV download handler wired');
  assert(routeGet.body.includes('printPage'), 'Print page handler wired');

  // 8. Test JavaScript & Audit actions
  console.log('\nStep 8: Test JavaScript & Audit Actions (PRINT, EXPORT, AUDIT LOG)');
  const printActionRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management/action',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { action: 'print', reference: 'Domain & Zone Head Master Report' });
  assert(printActionRes.status === 200, 'Print action logged');

  const exportActionRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/domain-zone-management/action',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-user-role': 'Super Admin'
    }
  }, { action: 'export', reference: 'Domain & Zone CSV Export' });
  assert(exportActionRes.status === 200, 'Export action logged');

  // Check audit log table contains these entries
  const auditRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/audit-logs',
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  const auditLogs = auditRes.body.logs || auditRes.body.data || (Array.isArray(auditRes.body) ? auditRes.body : []);
  const hasDzAudit = auditLogs.some(l => l.module === 'domain-zone-management' || l.details?.includes('Domain & Zone') || l.reference?.includes('Domain & Zone'));
  assert(hasDzAudit, 'Audit log contains domain-zone-management activity records');

  // 9. Test related modules (Location & Branch, Dashboard, Permissions)
  console.log('\nStep 9: Test Related Modules');
  const locRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/location-branch/branches',
    method: 'GET',
    headers: { 'x-user-role': 'Super Admin' }
  });
  assert(locRes.status === 200 && locRes.body.success === true, 'Location & Branch module functioning normally');

  const dashRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/dashboard',
    method: 'GET'
  });
  assert(dashRes.status === 200, 'Dashboard route functioning normally');

  console.log('\n================================================================');
  console.log(`SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests().catch(err => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
